# RuleIQ Unit Test Pipeline — New Chat Handoff

**Purpose:** Continue the current conversation in a fresh ChatGPT chat because the original conversation reached the context-length limit.

**Date:** 2026-09-12

**Continuation snapshot:** A1–A8D are completed/promoted. **A8E sequential physical-group execution is COMPLETED/PROMOTED after separate textual/static change and validation stages.** A8E preserves global Author semantic freeze/audit and changes only downstream orchestration to one group at a time: Projection → WriteMemory → Generator terminal result → next group. A4 live deployment and A9 runtime remain open.

## 1. What the new assistant must do first

Treat the files in this bundle as the current source of truth.

Do **not** restart the architecture discussion from scratch.
Do **not** redo M1–M7 or A1–A8B unless A8C regression evidence identifies a concrete defect.
Use the active A8E plan in `01_CURRENT_WORK/UNIT_TEST_PIPELINE_REMEDIATION_PLAN_FINAL.md`. The A8E Author prompt is the current Author authority; A8D Generator/Validator and `01_CURRENT_WORK/A8D_SINGLE_RECORD_MEMORY_CONTRACT.md` remain unchanged authorities.

The completed A1–A8B remediation plan is historical at `05_HISTORICAL_REFERENCE/UNIT_TEST_PIPELINE_REMEDIATION_PLAN_A1_A8B_COMPLETED_SUPERSEDED.md`.

A8C and A8D are complete/promoted. A8E stages A8E-0…A8E-6 are complete and promoted. No further internal A8E action is pending. Separately, the next external evidence step remains the **live Generator + Validator KnowledgeTool capture** for Standard and MultiInput modes and `A4_DEPLOYMENT_VERIFIER.py`. A9 remains separate and not run.

Candidate lineage has been resolved: **no explicit Candidate lineage field**; external orchestration/audit owns repair history.

Latest accepted decisions before chat handoff:
- `WriteMemory(pxCaseID,Type,pyGroup,pyPayload)` is create-only and creates one record per call.
- `GetMemory(pxCaseID,pyGUID)` reads one exact record by unique GUID with case ownership guard.
- `UpdateMemory(pxCaseID,pyGUID,pyStatusValue,pyRouterKey)` updates one exact Candidate lifecycle record only.
- Candidate `pyPayload` is immutable; lifecycle update may change only `pyStatusValue` and `pyRouterKey`.
- Memory tools have no batch carrier semantics; no separate persisted `Pending` update.
- `testLabel` remains semantic; naming uniqueness uses a frozen physical-group discriminator persisted in UnitTestProjectionV3.
- Author keeps the minimal GeneratorRunReport trust boundary: `sourceUUID + groupId + status`.
- Candidate lineage is intentionally omitted; no `supersedesUUID`, lineage list, or mutable version counter is persisted.
- Scenario Author owns Pega data casting. The documented FROM→TO conversion matrix is mandatory Author execution semantics; cast-sensitive reasoning records an internal `CAST` row and freezes post-cast values into Projection.


The user prefers Russian architectural discussion; English technical artifacts/prompts are fine.

---

# 2. Current accepted three-agent architecture

## Scenario Author

Owns semantic truth:

- exact RUT identity and semantic Knowledge;
- dependency discovery/closure;
- execution-path reasoning;
- parameters/context/branches/producers/properties/Data Pages/Decision Tables;
- Scenario construction;
- ASSERT / SIM / OMIT / GAP;
- confidence/testability/traces;
- physical grouping;
- immutable `UnitTestProjectionV3`;
- Projection persistence;
- minimal sequential Generator orchestration.

Author does **not** construct/repair/validate Candidate JSON or RuleCode.

Author → Generator uses one Pega Agent `question` with:

```text
Generate the UnitTestCandidate for the exact persisted UnitTestProjection.

Invocation:
{"CaseID":"<...>","RUTType":"<...>","UnitTestProjectionUUID":"<...>"}

Return only the GeneratorRunReport required by your system instructions.
```

Author validates only:
- `sourceUUID`;
- `groupId`;
- `status`.

This minimal trust boundary is an **accepted decision**.

## Unit Test Generator

Target model: Claude Opus 4.8.

Generator is the deterministic Projection→Candidate compiler.

It:
- reads exact persisted Projection by GUID;
- validates the closed Generator-relevant v3 source grammar;
- selects target schema / Knowledge / JsonExample;
- compiles Candidate deterministically;
- runs full G7 before every Candidate write;
- persists immutable Candidate versions;
- calls Validator using exact source + candidate GUIDs;
- performs only authorized TARGET_REPAIR or FIDELITY_REPAIR;
- never changes Projection semantic facts.

Generator → Validator uses one `question`:

```text
Validate the exact persisted UnitTestCandidate against its exact persisted UnitTestProjection source and the deployed unit-test contract.

Invocation:
{"CaseID":"<...>","RUTType":"<...>","UnitTestProjectionUUID":"<...>","UnitTestCandidateUUID":"<...>"}

Return only the ValidatorReport required by your system instructions.
```

## Validator

Target model: Claude Opus 4.8.

Validator independently reads exact persisted Projection + Candidate and checks three layers:

1. formal JSON Schema via `JsonValidationTool`;
2. closed deterministic Projection fidelity;
3. candidate-internal Pega/documentation invariants.

Core rule:

> Validator checks `Candidate == Compile(Projection)`, never `Projection == BusinessTruth`.

Validator never returns replacement semantic values.

There is a closed synchronized 14-pair issue/action protocol between Validator and Generator.

---

# 3. M1–M7 state

Stages M1–M7 were completed and textually validated.

Final accepted prompts before the new end-to-end seam review:

- `Main_Agent_Prompt_FINAL_ACCEPTED.txt`
- `UnitTestGenerator_Prompt_FINAL_ACCEPTED.txt`
- `Validator_Prompt_FINAL_ACCEPTED.txt`

Final accepted master plan:

- `DETERMINISTIC_FIDELITY_CHANGE_PLAN_FINAL_ACCEPTED.md`

Important evidence boundary:

- textual/contract validation only;
- no Claude runtime tests;
- no Pega execution;
- no synthetic/adversarial harness;
- no hashes/checksums.

Do not describe runtime behavior as already validated.

---

# 4. End-to-end simulation result

A later end-to-end tabletop simulation checked:

Author
→ persisted Projection
→ Generator
→ G7
→ Candidate
→ Validator
→ repair / terminal lifecycle
→ GeneratorRunReport
→ Author.

Detailed report:

- `END_TO_END_UNIT_TEST_PIPELINE_SIMULATION_REVIEW.md`

The core architecture remained sound, but cross-stage seam problems were found.

## P0/P1 findings

### P0 — Candidate naming contract — RESOLVED IN A2

The end-to-end review originally found that the candidate schema referenced unavailable `RuleJSON.pyRuleName`, Author had no exact `testLabel` production rule, and sibling physical groups could collide. A2 resolves that seam without duplicating the target naming algorithm:

- schema naming source is `UnitTestProjection.rut.name`;
- `testLabel` remains semantic-only and is frozen from the exact final name of the original first materialized Scenario in the group;
- final Projection field `physicalGroupKey` is frozen by Author as `G001..G999` after stable physical grouping;
- selected JsonSchema alone owns normalization/truncation and consumes `rut.name + testLabel + physicalGroupKey`;
- Generator never invents/renumbers a discriminator or duplicates the algorithm;
- Validator retrieves the selected JsonSchema and applies that same schema-owned construction independently.

### P0 — Generator lifecycle UpdateMemory contract — HISTORICAL SEAM, SUPERSEDED BY A8D API SYNTAX

The end-to-end simulation originally found a missing lifecycle update contract and led to the accepted create-only/write + lifecycle-only/update semantics. A8D preserves those semantics but replaces the old `RequestsJSON`/row-carrier syntax with the current single-record Memory API. The old carrier syntax in historical reports is not current authority.

### P0 — Author v3 producer validation vs Generator source gate — RESOLVED IN A3

Author §6.8 now validates the same closed UnitTestProjectionV3 grammar consumed by Generator §2.1–2.2 before any Projection `WriteMemory`.

Synchronized coverage includes:
- `testLabel` / Scenario-name lexical constraints;
- nonempty `reasoningTrace` and bounded `dependencyClosureTrace`;
- executable RUT/primary/pages/parameters/setup/actions/simulations;
- all standard assertion kinds;
- Rule-Obj-When row/input grammar;
- exact mode/cardinality rules;
- closed-object and opaque-`data` boundaries;
- forbidden envelope/audit/ledger/source fields.

### P0 deployment precondition — Ruleset/Version template

Generator obtains:
- `pyRuleSet`;
- `pyRuleSetVersion`

from the deployed JsonExample/template.

Need verify the deployed KnowledgeTool key supplies the correct application-specific target, not static local example values.

### P1 — canonical scalar stringification

Generator currently says number/boolean → deterministic string but the exact algorithm is not defined.

Affected:
- RUT parameters;
- setup/cleanup action parameters;
- Rule-Obj-When input values.

Validator intentionally does not fidelity-check those numeric/boolean contents because canonical representation is undefined.

Need define one exact canonical conversion and then enable those fidelity checks.

### P1 — scalar parameter type — RESOLVED IN A6

Projection now preserves authoritative formal scalar type from Scenario Author. Generator does not infer type from value shape. Pega coercion is also Author-owned.

A6 amendment: Author MUST execute the documented Pega Data Casting Matrix for each cast-sensitive binding/assignment and record internal `CAST` evidence (`sourceType`, `destinationType`, matrix cell/notes, source value, post-cast value, validation state). Projection carries only final type/value semantics; Generator/Validator never rerun casting.

### P1 — schema prose vs formal constraints — RESOLVED IN A7

Ordinary Draft-2020-12 keywords now own machine-enforceable target constraints. `x-ruleiq-compilerMappings.CM-NAME-001` is the single naming algorithm owner. `x-ruleiq-crossFieldInvariants` owns normative candidate-internal relationships that ordinary instance keywords cannot express. Heuristics/recommendations are explicitly non-binding. Both bundled JsonExamples validate against their Stage-3 schemas after legacy Scenario/governance fields were removed.

---

# 5. ACCEPTED persistence decision — A8D single-record Memory contract

The persistence semantics remain accepted, but the active tool API is now deliberately single-record-per-call.

## WriteMemory

```text
WriteMemory(pxCaseID,Type,pyGroup,pyPayload)
```

- create-only;
- creates exactly one immutable record per call;
- caller never supplies `pyGUID`;
- success returns one new GUID directly;
- no `RequestsJSON`, `ResultsJSON`, Memory `pxResults[]`, partial-success, or batch correlation.

Author calls WriteMemory once per frozen Projection in group order. Generator calls it once per Candidate version. A repaired Candidate is always a new record with a new GUID.

## GetMemory

```text
GetMemory(pxCaseID,pyGUID)
```

- read-only exact single-record lookup;
- `pyGUID` is the unique Data Type key; `pxCaseID` is an ownership/correlation guard;
- successful response returns stored `pyType`, `pyGroup`, `pyPayload`, lifecycle fields and exact identity;
- `NOT_FOUND` stops the required-artifact workflow; no latest-row inference or substitute record.

## UpdateMemory

```text
UpdateMemory(pxCaseID,pyGUID,pyStatusValue,pyRouterKey)
```

- updates exactly one existing Candidate by GUID;
- may change only `pyStatusValue` and `pyRouterKey`;
- `pyPayload`, `pyType`, `pyGroup`, case identity and GUID remain immutable;
- no `pyUpdates` object and no batch/row carrier.

Allowed lifecycle pairs:

```text
Passed + OK
Failed + GENERATOR_REPAIR
Failed + SEMANTIC_REJECT
Failed + HUMAN
```

`NOT_FOUND` or `UPDATE_FAILED` stops lifecycle/routing. There is no separate persisted `Pending` update.

The canonical active contract is `01_CURRENT_WORK/A8D_SINGLE_RECORD_MEMORY_CONTRACT.md`.

---

# 6. ACCEPTED naming direction

User accepted the recommendation:

- keep `testLabel` semantic;
- introduce a **frozen physical-group discriminator in Projection**;
- use that frozen discriminator in the schema-owned final target naming contract;
- Author creates/freezes it after physical grouping;
- it must be stable for the persisted Projection;
- Generator consumes but never invents/renumbers it.

Final field name:

`physicalGroupKey`

Example conceptually:

```json
{
  "testLabel": "HappyPath",
  "physicalGroupKey": "G001"
}
```

The field name is final: `physicalGroupKey`.

The Stage-3 schema-owned naming algorithm guarantees the target-name construction using `rut.name + testLabel + physicalGroupKey`, including normalization/truncation under the A2 contract.

The user explicitly chose the recommended solution rather than making semantic `testLabel` itself responsible for collision suffixes.

---

# 7. ACCEPTED Author trust decision

Author continues to validate only:

- `sourceUUID`;
- `groupId`;
- `status`.

Author does not duplicate Generator-owned validation for:
- candidate pointer;
- counters;
- representedScenarioNames;
- errorMessage formatting.

---

# 8. ACCEPTED Candidate lineage decision

No explicit Candidate lineage field is persisted.

Specifically:
- do not add `supersedesUUID`;
- do not add a lineage list;
- do not add a mutable version counter;
- every repair still creates a new immutable Candidate GUID;
- the executing workflow continues to pass the exact current Candidate GUID directly;
- post-run repair lineage/audit/navigation is owned by external orchestration/audit facilities.

This keeps one owner for audit lineage and avoids duplicating external workflow history inside Candidate Memory rows.

---

# 9. Current remediation-plan file

Finalized plan:

- `UNIT_TEST_PIPELINE_REMEDIATION_PLAN_FINAL.md`

It reflects:
- single-record `WriteMemory/GetMemory/UpdateMemory`;
- WriteMemory create-only;
- UpdateMemory lifecycle-only on exact GUID;
- no Memory batch carriers and no persisted Pending update;
- frozen physical-group discriminator for naming;
- minimal Author trust boundary;
- no explicit Candidate lineage field; external orchestration/audit owns repair history.

---

# 10. Exact next work

A1 — Original persistence semantics were implemented and textually validated; **A8D supersedes A1/A8C Memory API carrier syntax while preserving create-only/read-only/lifecycle-only semantics.**

A2 — Naming contract repair is implemented and textually validated.

A3 — UnitTestProjectionV3 producer/consumer synchronization is implemented and textually validated.

A4 — **STATIC DEPLOYMENT PACK COMPLETE; LIVE DEPLOYMENT PROOF REQUIRED.** `A4_DEPLOYMENT_VERIFIER.py`, `A4_LIVE_CAPTURE_TEMPLATE.json`, and `A4_DEPLOYMENT_EXPECTED_CONTRACT.json` are prepared and self-tested. No live Pega KnowledgeTool binding was available in this session, so do not claim deployment/runtime target proof from local files.

A5 — exact decimal/boolean canonicalization remains historical validation evidence only; A8 supersedes it for typed UnitTestProjectionV3 transport so downstream cannot normalize Pega-preserved lexical values.

A6 — **Typed parameters + Pega coercion ownership is design-resolved and textually implemented. The documented Pega Data Casting Matrix is authoritative for Pega 26.x by explicit project decision; pipeline runtime proof was not executed.**

A6 implementation artifacts (superseded as current authority by A8 below):
- `Main_Agent_Prompt_A6_CAST_MATRIX_REPAIRED.txt`;
- `UnitTestGenerator_Prompt_A6_CAST_MATRIX_REPAIRED.txt`;
- `Validator_Prompt_A6_CAST_MATRIX_REPAIRED.txt`;
- `A6_TYPED_PARAMETERS_AND_PEGA_COERCION_VALIDATION.md`.

Accepted A6 contract:
- Scenario Author is the sole semantic owner of RUT/action formal parameter type, property destination type, Pega coercion/validation semantics, and the final post-binding/post-assignment semantic value;
- every projected RUT/action parameter carries mandatory `formalType`; Generator/Validator never infer it from the value;
- canonical projection parameter types are `Text|Integer|Decimal|Double|TrueFalse|Date|DateTime|TimeOfDay|Page`; target Page type serializes as `PAGE`;
- Property/Page/List assertion source carries authoritative destination `mode`; Rule-Obj-When inputs carry semantic `valueType`;
- Pega conversion is not a generic host-language cast. In particular, documented `Other -> typed scalar` uses copy-then-validate (`S`); unresolved suitability/External behavior blocks dependent exact claims instead of being guessed;
- Generator performs target serialization only and never recasts source values; Validator independently checks that serialization;
- A8 refines typed scalar Projection transport to exact Author-frozen post-cast Pega clipboard lexical strings; A5 numeric canonicalization is historical and is not part of current typed Generator/Validator transport.

Evidence consulted for A6 included the current Pegasystems `infinity-ai-plugins` 26.1 Rule-Obj-When, Rule-Obj-Property, Rule-Test-Unit-Case skills/examples plus Pega conversion/Property-Set documentation. By explicit project decision, the documented conversion matrix is authoritative for Pega 26.x; this does not imply that the RuleIQ-generated pipeline has itself been runtime-executed.

Important A4 dependency discovered during A6:
- upstream 26.1 Unit Test examples explicitly emit Text `pyParametersParamType` and quoted Text method-parameter values;
- the pre-A6 bundled standard JsonExample used an untyped/unquoted Text parameter; it was updated locally, but the deployed KnowledgeTool binding is still unverified;
- exact deployed parameter/assertion lexical conventions must be verified before a real Pega/model trial.

A7 — **schema prose/formal consistency cleanup is TEXTUALLY / STRUCTURALLY VALIDATED.** Current target schemas distinguish ordinary formal keywords, `x-ruleiq-compilerMappings`, `x-ruleiq-crossFieldInvariants`, and explicit heuristics/recommendations. `CM-NAME-001` is the single naming owner. Both bundled JsonExamples validate with zero local Draft-2020-12 errors.

A8 — **end-to-end tabletop is TEXTUALLY / STRUCTURALLY VALIDATED.** A8B corrected target-fixture alignment and A8C completed example-driven prompt refactoring.

A8D — **single-record Memory contract refactor is COMPLETED/PROMOTED.** It replaces only Memory interface syntax/cardinality; semantic/compiler behavior remains A8C baseline. Every A8D stage reached separate `CHANGE_COMPLETE` and `VALIDATION_COMPLETE` statuses.

A8E — **sequential physical-group Author orchestration is COMPLETED/PROMOTED.** Global dependency/semantic work, Scenario formation/grouping and `B→A / A=PASS` remain global. After `A=PASS`, Author processes exactly one frozen group through Projection → self-check → WriteMemory → terminal Generator report before starting the next group. No new persisted plan/ledger exists.

# 11. User preferences / execution discipline

- Russian architectural discussion preferred.
- English technical artifacts/prompts are fine.
- Precise, condensed reasoning.
- Do not perform runtime/model/Pega tests unless separately requested.
- Do not create synthetic/adversarial harnesses unless requested.
- No SHA/checksum/hash manifests; A8E baseline/change validation is explicitly text/structure-only.
- Private project questions do not need public web browsing.
- Generator and Validator target Claude Opus 4.8.
- One concept must have one owner.
- Avoid duplicating target naming algorithms in prompts.
- Repair never uses Validator-proposed semantic values.
- Implementation and validation should be separate states/passes.
- Preserve source-of-truth discipline and exact GUID correlation.


## Current A8E authorities

- Memory contract: `01_CURRENT_WORK/A8D_SINGLE_RECORD_MEMORY_CONTRACT.md`
- Author: `01_CURRENT_WORK/Main_Agent_Prompt_A8E_SEQUENTIAL_REFACTORED.txt`
- Generator: `01_CURRENT_WORK/UnitTestGenerator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt`
- Validator: `01_CURRENT_WORK/Validator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt`
- Target schemas/examples: `04_TARGET_CONTRACTS/*STAGE3*` and bundled JsonExamples
- A8/A8B evidence: `01_CURRENT_WORK/A8_CAST_LEXICAL_TRANSPORT_AMENDMENT.md`, `01_CURRENT_WORK/A8_FINAL_END_TO_END_TABLETOP_VALIDATION.md`, `01_CURRENT_WORK/A8B_TARGET_SCHEMA_GENERATOR_ALIGNMENT_VALIDATION.md`, `01_CURRENT_WORK/A8B_CANONICAL_FIXTURE_CHECK.py`

Typed scalar Projection values are exact Author-frozen post-cast Pega clipboard lexical strings paired with authoritative Pega type facts. `CanonicalBareScalar` is not part of current Generator/Validator authority. Physical PegaUnit `pyExpectedValue` is always a JSON string; text/temporal string-like modes receive only the required Pega literal wrapper, while numeric/TrueFalse lexical content remains exact inside the JSON string.

### Exact next evidence step

When a live Pega interface is available, capture the exact Standard/MultiInput target batches independently as Generator and Validator, populate `A4_LIVE_CAPTURE_TEMPLATE.json`, and run `A4_DEPLOYMENT_VERIFIER.py`. Only PASS (or an explicitly accepted REVIEW revision) permits A9. A9 is optional real Claude/Pega runtime execution after that; do not claim runtime verification until actually executed.


## A8C promoted evidence

- `A8C_EXAMPLE_DRIVEN_REFACTOR_VALIDATION.md` — A8C stage/metric/authority report.
- `A8C_REGRESSION_ADVERSARIAL_CHECK.py` — A8B regression + T1–T10 anti-anchoring suite, 10/10 PASS.
- `04_TARGET_CONTRACTS/a8c_shared_reference/` — proposed Standard/MultiInput shared Generator+Validator target-reference content; deployment still requires A4 proof.


## A4 static deployment pack

- `01_CURRENT_WORK/A4_DEPLOYMENT_EXPECTED_CONTRACT.json` — expected keys/local authorities/closure rules.
- `01_CURRENT_WORK/A4_LIVE_CAPTURE_TEMPLATE.json` — exact live capture envelope for Generator and Validator.
- `01_CURRENT_WORK/A4_DEPLOYMENT_VERIFIER.py` — deterministic PASS/REVIEW/FAIL checker.
- `01_CURRENT_WORK/A4_DEPLOYMENT_PACK_VALIDATION.md` — self-test evidence and live procedure.
- `01_CURRENT_WORK/A4_LOCAL_SELFTEST_REPORT.txt` / `.json` — expected local FAIL only because Standard/MultiInput demo rulesets differ.
