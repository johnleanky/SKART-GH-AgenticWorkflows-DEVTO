# RuleIQ Unit Test Pipeline — Continuation Bundle Manifest

**Snapshot:** 2026-09-12, A8E sequential physical-group execution is COMPLETED/PROMOTED after textual/structural/static validation. A8D Memory/Generator/Validator contracts remain unchanged. A4 live deployment remains open; A9 runtime not run.

## Start here

1. `CONTINUE_RULEIQ_UNIT_TEST_PIPELINE.md` — complete handoff/state summary.
2. `UNIT_TEST_PIPELINE_REMEDIATION_PLAN_FINAL.md` — current A8E plan/status; A8E-0…A8E-6 complete; promoted.
3. `END_TO_END_UNIT_TEST_PIPELINE_SIMULATION_REVIEW.md` — seam findings and simulations.


## A8C refactoring result

`01_CURRENT_WORK/UNIT_TEST_PIPELINE_REMEDIATION_PLAN_FINAL.md` is the completed A8C plan/result. The completed A1–A8B plan remains preserved as `05_HISTORICAL_REFERENCE/UNIT_TEST_PIPELINE_REMEDIATION_PLAN_A1_A8B_COMPLETED_SUPERSEDED.md`.

A8C results:
- A8B baseline frozen and byte-preserved;
- shared Generator/Validator-only target reference prepared under `04_TARGET_CONTRACTS/a8c_shared_reference/`;
- explicit exactly-once independent KnowledgeArea retrieval/no-memory-fallback added;
- Author/Generator/Validator prompts compressed only in approved high-ROI zones;
- A8B canonical fixtures preserved;
- T1–T10 adversarial/anti-anchoring suite = 10/10 PASS;
- permanent prompt context reduced by ~10.1%; incremental target context does not increase;
- runtime/deployment claims are not made.

## Current production-contract sources

- `A8D_SINGLE_RECORD_MEMORY_CONTRACT.md` — current Memory-tool API/cardinality/error authority.
- `Main_Agent_Prompt_A8E_SEQUENTIAL_REFACTORED.txt` — current A8E Author authority; global semantics unchanged, downstream physical groups processed sequentially end-to-end.
- `UnitTestGenerator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt` — current Generator authority; A8C compiler behavior plus single-record Memory read/create/update.
- `Validator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt` — current Validator authority; A8C independent fidelity behavior plus single-record exact reads.
- `rule-test-unit-case_JsonSchema_STAGE3.txt` and `rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt` — current target schema/naming/cross-field authority.
- `rule-test-unit-case_JsonExample(5).txt` and `rule-test-unit-case_multInpComb-JsonExample(6).txt` — canonical Generator-output target examples; exact paired fixtures live under `04_TARGET_CONTRACTS/fixtures/`.
- `DETERMINISTIC_FIDELITY_CHANGE_PLAN_FINAL_ACCEPTED.md` — accepted M1–M7 baseline plan.
- `UNIT_TEST_PIPELINE_REMEDIATION_PLAN_FINAL.md` — current A8E implementation/validation plan and stage status.
- `A8_CAST_LEXICAL_TRANSPORT_AMENDMENT.md` — accepted A8 correction preserving exact Pega lexical cast results.
- `A8_FINAL_END_TO_END_TABLETOP_VALIDATION.md` — A8 static/tabletop evidence.
- `A8B_TARGET_SCHEMA_GENERATOR_ALIGNMENT_VALIDATION.md` + `A8B_CANONICAL_FIXTURE_CHECK.py` — corrective proof that canonical examples equal deterministic compile output and validate against Stage-3 schemas.
- `A8C_EXAMPLE_DRIVEN_REFACTOR_VALIDATION.md` — promoted A8C static/adversarial validation and before/after context metrics.
- `A8E_SEQUENTIAL_REFACTOR_VALIDATION.md` — promoted A8E sequencing/static regression evidence.
- `A8C_REFACTOR_PLAN_VALIDATION.md` — historical pre-execution validation of the plan replacement.
- `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_KnowledgeArea_A8C_PROPOSED.txt` and `Rule-Test-Unit-Case_MultInpComb-KnowledgeArea_A8C_PROPOSED.txt` — promoted local shared Generator/Validator target-reference content; live deployment still requires A4 proof.
- `A4_TARGET_CONFIGURATION_VERIFICATION.md` — A4 live deployment gate; static preparation complete.
- `A4_DEPLOYMENT_EXPECTED_CONTRACT.json` — exact deployment keys/local authorities/closure rules.
- `A4_LIVE_CAPTURE_TEMPLATE.json` — live Generator/Validator capture envelope.
- `A4_DEPLOYMENT_VERIFIER.py` — deterministic A4 PASS/REVIEW/FAIL verifier.
- `A4_DEPLOYMENT_PACK_VALIDATION.md` — verifier self-test and exact live procedure.

A1–A7 working prompts and validations remain evidence/history for how the current contract was reached; they are not current prompt authority.

## Historical reference

- `UnitTestGenerator_Prompt(4).txt` — historical reference for the old batch-shaped UpdateMemory carrier. It is NOT current authority; A8D single-record contract supersedes that syntax.
- `UNIT_TEST_PIPELINE_REMEDIATION_PLAN_DRAFT_V3_SUPERSEDED.md` — superseded pre-lineage-decision plan; historical only.

## Latest accepted decisions

- Memory tools are one-record-per-call; future batch behavior requires a separate tool.
- `WriteMemory(pxCaseID,Type,pyGroup,pyPayload)` = create-only.
- `GetMemory(pxCaseID,pyGUID)` = exact read-only lookup.
- `UpdateMemory(pxCaseID,pyGUID,pyStatusValue,pyRouterKey)` = exact lifecycle-only update.
- Candidate pyPayload is immutable.
- No separate persisted Pending lifecycle update.
- testLabel remains semantic.
- naming uniqueness uses frozen `physicalGroupKey=G001..G999` persisted in Projection; `testLabel` remains semantic-only.
- Author validates Generator terminal correlation only via sourceUUID + groupId + status.
- Candidate lineage is DECIDED: no explicit internal lineage field; external orchestration/audit owns repair history.
- Author owns formal parameter/property type and Pega coercion semantics; the documented Pega Data Casting Matrix is mandatory Author execution logic with internal `CAST` evidence and is authoritative for Pega 26.x by explicit project decision; Projection carries mandatory formal/type metadata and exact Author-frozen post-cast Pega clipboard lexical values; Generator only applies target wrapper/escaping and never recasts or normalizes them.


## A8E CURRENT AUTHORITIES — PROMOTED

- `01_CURRENT_WORK/A8D_SINGLE_RECORD_MEMORY_CONTRACT.md`
- `01_CURRENT_WORK/Main_Agent_Prompt_A8E_SEQUENTIAL_REFACTORED.txt`
- `01_CURRENT_WORK/UnitTestGenerator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt`
- `01_CURRENT_WORK/Validator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt`
- `04_TARGET_CONTRACTS/rule-test-unit-case_JsonSchema_STAGE3.txt`
- `04_TARGET_CONTRACTS/rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt`
- `01_CURRENT_WORK/A8_CAST_LEXICAL_TRANSPORT_AMENDMENT.md`
- `01_CURRENT_WORK/A8_FINAL_END_TO_END_TABLETOP_VALIDATION.md`
- `01_CURRENT_WORK/A8B_TARGET_SCHEMA_GENERATOR_ALIGNMENT_VALIDATION.md`
- `01_CURRENT_WORK/A8B_CANONICAL_FIXTURE_CHECK.py`
- `04_TARGET_CONTRACTS/fixtures/standard_projection.json` → `standard_candidate.json`
- `04_TARGET_CONTRACTS/fixtures/when_projection.json` → `when_candidate.json`

Older A1–A8 pre-A8B Generator/Validator working prompts remain evidence/history only; do not use them as current authority.

- `01_CURRENT_WORK/A8C_EXAMPLE_DRIVEN_REFACTOR_VALIDATION.md`
- `01_CURRENT_WORK/A8C_REGRESSION_ADVERSARIAL_CHECK.py`
- `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_KnowledgeArea_A8C_PROPOSED.txt`
- `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_MultInpComb-KnowledgeArea_A8C_PROPOSED.txt`
