# A2 — Naming Contract Validation

**Status:** TEXTUALLY VALIDATED  
**Date:** 2026-09-12  
**Evidence boundary:** static contract/text validation only. No Claude runtime, Pega execution, Memory runtime, candidate save, or Pega rule-name persistence test was performed.

## Scope

A2 repairs only the Candidate naming seam discovered by the end-to-end tabletop review. M1–M7 semantic/fidelity decisions are not reopened.

Validated current artifacts:

- `Main_Agent_Prompt_A2_NAMING_REPAIRED.txt`
- `UnitTestGenerator_Prompt_A2_NAMING_REPAIRED.txt`
- `Validator_Prompt_A2_NAMING_REPAIRED.txt`
- `rule-test-unit-case_JsonSchema_STAGE3.txt`
- `rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt`

## Contract checks

| Check | Result | Evidence |
|---|---|---|
| `testLabel` remains semantic-only | PASS | Author freezes it from the exact final name of the original first materialized Scenario; no collision suffix is added |
| Frozen physical discriminator exists in Projection | PASS | root `physicalGroupKey`; Author assigns `G001..G999` only after stable physical grouping |
| Cross-group discriminator is source-owned | PASS | Generator/Validator may consume but never invent/renumber `physicalGroupKey` |
| Old unavailable naming source removed | PASS | no current A2 artifact contains `RuleJSON.pyRuleName` |
| One target naming owner | PASS | both Stage-3 candidate JsonSchemas contain the same sole `pyPurpose` naming construction |
| Naming inputs are exactly the intended frozen source facts | PASS | schema construction consumes `UnitTestProjection.rut.name + testLabel + physicalGroupKey` |
| Target name stays within formal max | PASS | schema construction caps label at 32 and sets `BASE_ALLOC = 44 - len(LABEL_CANON)`; mechanical boundary example produced exactly 53 characters |
| Generator does not duplicate naming algorithm | PASS | Generator delegates normalization/truncation to selected JsonSchema |
| Validator does not duplicate naming algorithm | PASS | Validator retrieves selected JsonSchema and applies its single normative naming construction in section 5.1 |
| Informational candidate naming remains independently checkable | PASS | Validator now retrieves schema-only Knowledge for informational mode before naming fidelity |
| Author source prevents empty normalized label | PASS | `testLabel` must contain at least one ASCII alphanumeric |
| Informational Projection shape includes discriminator | PASS | exact informational root includes `testLabel,physicalGroupKey,rut,scenarios` |
| Candidate lineage remains external | PASS | no `supersedesUUID` introduced in A2 prompts |
| Author GeneratorRunReport trust remains minimal | PASS | Author consumes only `sourceUUID + groupId + status`; report internal consistency remains Generator-owned |
| Persisted Pending remains absent | PASS | A2 inherits A1 create-only + implicit pending/unvalidated lifecycle; no new Pending update introduced |

## Mechanical naming examples

The schema prose was independently transcribed into a small local mechanical check only to test its length/pattern arithmetic; this is **not runtime evidence** and does not replace the schema text.

- `rut.name="Review Scenarios.Post"`, `testLabel="Happy Path"`, `physicalGroupKey="G001"` -> `TC_ReviewScenarios_Post_Happy_Path_G001` (39 chars)
- 100-character RUT name + 50-character label + `G999` -> generated name length 53 exactly
- `rut.name="My-Rule @ 1"`, `testLabel="Under_score label"`, `G042` -> `TC_My_Rule_1_Under_score_label_G042`

Both Stage-3 schema files parsed successfully as JSON after the edits and carry byte-equivalent naming-description text for `RuleCode.pyPurpose`.

## Deliberate non-changes

- No Candidate lineage field or version counter was added.
- No semantic Scenario/grouping decision was changed.
- No Generator repair ownership was changed.
- No scalar canonicalization, parameter type, or broader v3 grammar work was pulled forward from A3/A5/A6.

## Next stage

A3 — synchronize the remaining UnitTestProjectionV3 producer self-validation with the Generator closed source grammar, beyond the naming-specific fields already repaired here.
