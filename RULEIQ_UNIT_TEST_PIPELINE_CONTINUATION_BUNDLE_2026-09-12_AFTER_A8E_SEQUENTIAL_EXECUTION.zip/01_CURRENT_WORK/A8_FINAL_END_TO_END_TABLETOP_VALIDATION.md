# A8 Final End-to-End Tabletop Validation

Status: **TEXTUALLY / STRUCTURALLY VALIDATED**

Runtime evidence: **ABSENT**. No Claude runtime, Pega execution, Memory runtime, or synthetic/adversarial harness was run.

> **A8B correction notice (2026-09-12):** A later strict re-audit found that A8 T4 proved only `JsonExample ⊨ Stage-3 schema`, not that the examples were canonical outputs of the current Generator. A8B corrected target typing and examples, added paired Projection→Candidate fixtures, and mechanically verifies `Candidate == Compile(Projection)` plus schema validity. For current target/example authority use `A8B_TARGET_SCHEMA_GENERATOR_ALIGNMENT_VALIDATION.md` and the A8B Generator/Validator prompts.

## Authorities validated

- Author: `Main_Agent_Prompt_A8_CAST_LEXICAL_REPAIRED.txt`
- Generator: `UnitTestGenerator_Prompt_A8_REPRESENTABILITY_AND_LEXICAL_REPAIRED.txt`
- Validator: `Validator_Prompt_A8_LEXICAL_FIDELITY_REPAIRED.txt`
- Target schemas:
  - `rule-test-unit-case_JsonSchema_STAGE3.txt`
  - `rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt`
- Bundled target examples:
  - `rule-test-unit-case_JsonExample(5).txt`
  - `rule-test-unit-case_multInpComb-JsonExample(6).txt`

## Tabletop outcome

### T1 — Author semantic ownership
PASS.

Author owns RUT/dependency reasoning, exact formal/property types, the authoritative Pega Data Casting Matrix, CAST evidence, post-cast semantic reasoning, and exact post-cast clipboard lexical values. Generator and Validator contain no `CanonicalBareScalar` and no Pega cast execution.

### T2 — `S` lexical preservation seam
PASS after A8 amendment.

The former v3 requirement to convert typed Decimal/Double/Integer/TrueFalse values into JSON native tokens was removed. Typed scalar Projection transport is now `authoritative type + exact Pega lexical string`. A valid Pega-preserved lexical distinction such as Decimal `12.50` therefore does not become RuleIQ-normalized `12.5` before compilation.

### T3 — Source→target representability
PASS.

Generator now owns a mandatory pre-write representability gate. A frozen source fact that has no legal source-preserving target representation terminates as `Failed/SEMANTIC_REJECTED` before Candidate `WriteMemory`. Ambiguous target serialization terminates as `Failed/HUMAN_REVIEW_REQUIRED` rather than guessing.

This generalizes the old R8 seam, including `Rule-Obj-When + rut.singlePage=true`, reserved target page names, unsatisfied PAGE parameter context, target enum/const/pattern conflicts, and target encodings unable to preserve required frozen lexical content.

### T4 — Target schema/examples
PASS.

Both Stage-3 files parse as Draft 2020-12 schemas and pass local `Draft202012Validator.check_schema`. Both bundled JsonExamples validate with zero local schema errors.

### T5 — Naming ownership
PASS.

Each selected schema has exactly one `x-ruleiq-compilerMappings` entry, `CM-NAME-001`. Generator/Validator reference it instead of maintaining an independent naming algorithm. `physicalGroupKey` remains Author-frozen.

### T6 — Persistence and lifecycle
PASS textually.

A1 contract remains intact:

- `WriteMemory` creates one immutable Candidate version and never overwrites;
- no separate persisted Pending state;
- exact lifecycle update uses only `pyStatusValue` and `pyRouterKey`;
- lifecycle merge precedes route action;
- uncertain create/update is never retried;
- repair creates a new Candidate GUID from the same frozen Projection.

### T7 — Candidate lineage
PASS.

No current Author/Generator/Validator authority introduces `supersedesUUID` or another internal lineage field. External orchestration/audit remains the sole owner of repair lineage/history.

### T8 — Validator trust/fidelity boundary
PASS.

Validator independently reads exact source/candidate GUIDs, validates selected schema first, checks exact group correlation, runs only closed deterministic fidelity transforms and schema-owned cross-field invariants, and never returns a replacement semantic value.

### T9 — Author trust of GeneratorRunReport
PASS.

Author validates only exact `sourceUUID`, expected `groupId`, and terminal `status=Completed|Failed`; remaining report consistency is Generator-owned.

### T10 — A4 deployment dependency
OPEN EXTERNAL PRECONDITION, not an A8 contract defect.

The local bundle does not prove that deployed KnowledgeTool bindings return the intended application-specific test ruleset/version and exact target contract. No connected Pega interface was available in this session. See `A4_TARGET_CONFIGURATION_VERIFICATION.md`.

## Static checks performed

- current Author contains mandatory `CAST` matrix execution and `postCastLexical`;
- current Generator/Validator contain zero `CanonicalBareScalar` occurrences;
- current Generator contains the pre-write representability gate before Candidate persistence;
- current prompts contain no `supersedesUUID`;
- Generator still contains create-only Candidate persistence, implicit pending/unvalidated state, exact lifecycle whitelist, and immutable repair behavior;
- both target schemas remain valid Draft 2020-12 JSON;
- both bundled target examples remain schema-valid after the A8 description changes;
- one schema-owned naming mapping exists in each target schema.

## Final A8 assessment

**PASS at textual/structural tabletop level, with A4 explicitly external and runtime evidence still absent.**

No remaining product/design question was found in A1–A8. The next evidence-producing phase is deployment verification (A4) and, only if desired, A9 real Claude/Pega runtime trials.

## Final mechanical consistency pass

A final local static pass reported **16/16 PASS** across current authorities: CAST/postCastLexical presence, lexical source grammar alignment, pre-write representability, absence of `CanonicalBareScalar` in current Generator/Validator, absence of internal lineage, no persisted Pending lifecycle, create-only Candidate persistence, exact lifecycle whitelist, minimal Author report trust, both Stage-3 schemas valid, both bundled examples at zero schema errors, and exactly one `CM-NAME-001` mapping owner per schema.
