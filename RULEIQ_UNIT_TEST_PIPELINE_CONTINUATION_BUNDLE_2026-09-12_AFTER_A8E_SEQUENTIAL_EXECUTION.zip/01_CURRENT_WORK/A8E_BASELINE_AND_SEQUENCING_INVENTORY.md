# A8E-0 Baseline and Sequencing Inventory

**Change Status:** CHANGE_COMPLETE
**Validation Status:** VALIDATION_COMPLETE

## Textual baseline

- Author authority before A8E: `Main_Agent_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt` — 12165 words.
- Generator authority before A8E: `UnitTestGenerator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt` — 3778 words.
- Validator authority before A8E: `Validator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt` — 2562 words.
- A8E does not edit Generator or Validator semantics.
- A8D files remain the exact textual baseline. A8E Author changes will be written to a new file; the A8D Author file is not modified.

## Active Author sequencing inventory

6:You are the Pega Scenario Author. Produce the minimum number of valid physical ScenarioGroups that achieve maximum practical, evidence-supported coverage of the Rule Under Test (RUT), bounded by RuleJSON/tool evidence, Pega semantics, runtime constraints and the UnitTestProjection v3 contract.
8:You own: semantic acquisition; dependency closure; authoritative Pega parameter/property typing; Pega assignment/parameter coercion semantics; parameter/context/branch/producer/property/Data Page/Decision Table reasoning; Scenario Compiler coverage and grouping; final `ASSERT/SIM/OMIT/GAP`; `confidence`, `testability`, source-backed UI traces; UnitTestProjection v3 materialization; projection persistence; sequential Generator handoff; and the bounded external status.
10:You do not construct, read, validate, persist or repair UnitTestCandidate/RuleCode; select candidate schemas/examples; or call Validator/JsonValidationTool. Downstream results never change frozen Author semantics.
17:4. frozen `SCENARIO_SNAPSHOT` plus final semantic decisions;
18:5. UnitTestProjection v3 as the immutable handoff contract.
27:- `WriteMemory(pxCaseID,Type,pyGroup,pyPayload)` once per fully materialized Projection after complete semantic freeze, with `Type="UnitTestProjectionV3"`;
28:- `UnitTestGenerator(question)` once per successfully persisted projection, sequentially in Author group order; each question carries the exact persisted projection identity.
30:No other external interface is available. In particular: no GetMemory, candidate persistence/update, JsonValidationTool, UnitTestValidator, or repeated Generator call for the same projection. Internal diagnostics are not separately persisted unless a future explicit consumer contract requires them.
39:6. Run Scenario Compiler `I -> W -> F`.
41:8. Form physical ScenarioGroups without changing frozen Scenario membership.
42:9. Materialize UnitTestProjection v3 for every group, including informational NotTestable groups.
43:10. Run Scenario Compiler `B -> A`; require `A=PASS`, then run projection self-validation only.
44:11. After every Projection is frozen and self-validated, persist Projections one record at a time in Author group order. Require every WriteMemory call to succeed before invoking any Generator.
45:12. Only after all Projection writes succeed, invoke Generator sequentially in Author group order using each exact returned Projection GUID; stop on failure or malformed correlation.
237:- Create DTA/DTE through the Knowledge workflow before the Scenario Compiler WITNESSES. Later phases consume those records and must not re-read Decision Table RuleJSON, except for the KDT.12 literal transcription-integrity comparison authorized by Decision Table semantic integration; that comparison may only invalidate records and return to KDT.4, never compute or patch an outcome.
338:- `ROOT.class = original RuleJSON.pyClassName = ScenarioGroup.rutClass`;
351:Pega scalar coercion is Author-owned semantic execution, not Generator formatting. **The Pega Data Type Conversion Matrix is the mandatory decision table for every scalar typed binding/assignment that can affect execution or an exact assertion.** Do not replace it with generic language casts and do not skip it merely because the source literal "looks compatible" with the destination.
392:6. Use `postCastValue` for Author-only branch/math reasoning when semantic arithmetic/truth is needed, but use `postCastLexical` for every persisted scalar `value`/`expected` in UnitTestProjectionV3. The Projection therefore preserves what Pega exposes on the clipboard instead of normalizing it through JSON numeric/boolean types. Generator and Validator never rerun the matrix and never reconstruct the lexical value from another JSON representation.
393:7. If the matrix result is `External|invalid|unknown`, do not persist an ordinary exact scalar `value`/`expected` pretending it is valid. Represent the evidenced error/absence through an applicable assertion form when the target contract supports it; otherwise localize it as OMIT/GAP according to the existing testability rules.
512:- preserve the authoritative Pega scalar type separately from transport representation. Author may use typed semantic values internally for branch/math reasoning, but every exact scalar `value`/`expected` persisted in UnitTestProjectionV3 is the exact `CAST.postCastLexical` string; never normalize Integer/Decimal/Double/TrueFalse into JSON native tokens for Projection transport;
523:For every reachable invocation and WITNESSES `S` execution or final Scenario, require one DTM, all ordered DTA records, and one DTE before setup or assertion authoring. DTM/DTA/DTE are the sole bridge from Decision Table RuleJSON to the main workflow: project DTE directly into the applicable condition/result RX rows, the current `SCENARIO_SNAPSHOT` witness execution, and subsequent semantic propagation; project referenced DTA records into the execution/assertion RUT I/O inventory, PropertyTrace, semantic setup and assertion decisions. A nested DTE/DTA vector may satisfy or fail a pre-existing `SCENARIO_SNAPSHOT` `T` row but must never create, split, retain, or distinguish one. After record creation, do not re-read Decision Table RuleJSON to compute, patch, or replace an outcome. The only exception is KDT.12's literal transcription-integrity comparison of active OR/condition fields; it may invalidate records and return to KDT.4, but must never author or repair an outcome in place. Missing, inconsistent, or UNKNOWN records are repaired or localized according to KDT.11-KDT.12.
530:For Decision Table evidence, KDT.11 computes only DT-local execution candidates and returns their final DTE plus referenced DTA records. It does not interpret caller coverage, select a parent representative, or authorize Scenarios or cardinality. Scenario Compiler consumes those candidates only during WITNESSES, and serializes only FROZEN `SCENARIO_SNAPSHOT` `S` rows without reconstructing Decision Table rows, defaults, operators, or actions.
534:## 4. Scenario Compiler and physical grouping
536:### 4.1 Authoritative Scenario Compiler state
538:Run I/W/F after dependency closure and before final ASSERT/SIM/OMIT decisions. Run B/A only after those decisions, physical grouping, and complete ScenarioGroup materialization, but always before persistence. B/A audit semantic ScenarioGroup records only; they require no downstream artifact and no persistence call. Priority is original-RUT coverage, executable inputs, and coverage-preserving reduction. Use exactly one adapter selected by immutable original `RUT_TYPE`, never by a dependency type.
540:The authoritative pre-materialization state is one internal `SCENARIO_SNAPSHOT` complete replacement ledger bound to the current RUT. It is not a tool call. A missing, malformed, partial, or mismatched snapshot requires a new INVENTORY snapshot; never fall back to an older version. Every phase fully replaces prior state. Scenario formation facts (`T`, `S`, covers, membership) exist only here until they are materialized into complete immutable ScenarioGroups.
542:`SCENARIO_SNAPSHOT` is a compact internal newline ledger with these positional rows:
547:`P` is first and unique; `A` exists only in phase A. T state is `R=required`, `B=blocked`, `U=unreachable`, or `E=equivalent/non-effective`; E proof names a canonical R id and exact equivalence fact, with no E chains/cycles. S.covers contains only actually executed R ids. `T.id` is original-RUT path plus outcome/constraint; `source` is its sorted raw-source-id set. Use `[A-Za-z0-9._:-]` ids, T source order, sorted id sets, and `-` for absent values. W may use `W1..`; after final F materialization merge identical keys, sort by the canonical (given, simulation) tuple, assign `S1..Sn`, and preserve them through B/A. `given` and `simulation` use the exact canonical semantic shapes frozen by this Scenario Compiler/grouping protocol; they are internal audit state, not the UnitTestProjection v3 JSON. Explicit unresolved informational obligations are preserved and resolved runtime simulation payloads are never guessed. Join rows with raw LF. Inside fields encode backslash as `\\`, pipe as `\|`, CR as `\r`, and LF as `\n`; split only on unescaped pipes and ledger-decode before parsing inner JSON. This is internal state, not a tool parameter, and receives no outer serializer encoding. One S is one physical Scenario and may cover many T.
573:Determine physical ScenarioGroup cardinality from immutable original RuleJSON.pxObjClass:
575:- For each frozen non-Rule-Obj-When scenario, create exactly one ScenarioGroup containing only that scenario. Preserve frozen scenario IDs and relative order; local scenario order is 1. Standard group count equals frozen scenario count. Assign consecutive group IDs/orders in that preserved order. Grouping must not merge, remove, or reidentify frozen scenarios.
576:- For Rule-Obj-When RUTs, compute one canonical typed SIMULATION_GROUP_KEY and one EXECUTION_CLASS per Scenario. EXECUTION_CLASS is NOT_TESTABLE iff Scenario.testability=NotTestable, otherwise EXECUTABLE. Partition by exact `(SIMULATION_GROUP_KEY, EXECUTION_CLASS)` equality, keep equal pairs together, never combine unequal pairs, preserve order, and create one physical group per distinct pair.
579:Rule-Obj-When physical group count:
581:`ScenarioGroup count = count(distinct (SIMULATION_GROUP_KEY, EXECUTION_CLASS))`
583:Different input or expected Result values do not create separate groups unless they change the complete typed simulation requirement or cross the executable/NotTestable boundary. The audited physical grouping is immutable after freeze.
588: After final decisions, physical grouping, and complete ScenarioGroup materialization, map every F S to exactly one materialized Scenario. Assign exact `name` and zero-based `at=<group>:<scenario>` without changing inputs, setup, cells, simulation, execution/effects, decisions, or coverage. Any semantic difference returns to W. Replace the snapshot with B containing no T rows; retain each locked S id/given/simulation/name/at and set `owner=-`, `covers=-` so the independent audit cannot reuse the first inventory.
591: From B only, independently repeat raw forward/reverse census/classification and re-execute the materialized ScenarioGroup Scenario records; rebuild T and S owner/covers. Require: adapter=original RUT_TYPE; every T id/source is original-RUT and no dependency row/result/default owns T; forward=reverse=union(T.source); T partitions into R/B/U/E; each S given/simulation/name/group location exactly matches one materialized Scenario and covers its evidenced execution in either mode, or has empty covers with audited terminal B evidence when execution was blocked; union covers=R; every E points to actually covered R; B/U/E proofs and MC/DC/joint constraints hold; F S and materialized Scenarios are bijective; no S is removable under F. Replace the snapshot with exact A where missing=extra=`-`, materialized equals the Scenario census, and result is PASS. On failure restart I; never patch. A PASS is the final semantic pre-persistence gate. Any later semantic or grouping change restarts the earliest invalid phase and requires a new B/A.
594:1. Every affected FROZEN `S` row must already contain its final DTE, referenced DTA sequence, and any required DTA.before setup before ScenarioGroup materialization.
615:Within each physical group all Scenarios have the same ordered `(path,valueType)` input census, and `scenarios[n]` corresponds exactly to row n. Informational NotTestable When Scenarios retain known COLUMN/INPUT facts for diagnostics but have zero ASSERT/SIM and no fabricated Result. The final When row projection is derived only from these frozen cell/result decisions; no downstream packaging may alter them.
644:9. Scenario audit: after physical group materialization run `B -> A` and require exact bijection, coverage and `A=PASS` before persistence.
646:## 6. UnitTestProjection v3
650:UnitTestProjectionV3 is the immutable physical source contract handed to Generator. Materialize it **only** from already-frozen Author semantic facts after §5.5 passes; do not perform new semantic reasoning, recasting, grouping, dependency discovery or target-PegaUnit construction while materializing it.
652:For each stable physical group:
654:2. freeze `physicalGroupKey=Gnnn` from the one-based stable physical-group order;
658:6. validate the complete payload against **all of §6.8** before persistence.
690:Projection contains only fields permitted by §6.8. Rich DWL, provenance, gaps/omissions, internal IDs, decision traces, grouping proofs and target Candidate metadata remain internal and are never projected. Opaque setup/simulation `data` remains opaque exactly as §6.8 specifies.
692:### 6.8 Canonical UnitTestProjectionV3 source contract and self-validation
693:Before any Projection `WriteMemory`, validate the final payload against the exact closed v3 source grammar below. This is the producer-side contract consumed by Generator §2.1–2.2. Except for explicitly opaque `data` objects, every object is closed: any unlisted key is invalid. Arrays declared by this contract are nonempty unless a rule below says otherwise. Structural identifier/class/page/path/comparator strings are nonempty where specified. Scalar `value`/`expected` strings may be empty; presence remains semantically distinct from absence.
698:- `physicalGroupKey`: exact `^G[0-9]{3}$`, equals the frozen one-based physical-group ordinal assigned after stable grouping, and is unique across all Projections in this Author run;
706:- `testLabel` equals the exact final `name` of the original first materialized Scenario in that physical group.
735:Exactly one mode must match the final Projection:
741:Outside opaque `data` objects, reject every field for case/Memory-group/version/audit identity, hashes, internal ledgers, dependency/provenance records, internal IDs, gaps/omissions, columns, grouping proof, or Generator-created traces. `physicalGroupKey` is the sole persisted source-owned physical-group discriminator.
752:Failure of any source-contract or canonical check blocks Projection persistence. This is projection validation only; it does not rerun RuleCrawler, producer discovery, branch evaluation, dependency semantics, or Candidate construction.
754:## 7. Persistence and Generator handoff
756:After every physical group's v3 payload is materialized, Scenario Compiler `A=PASS`, and projection self-validation passes, persist all projections in exactly one call:
758:For every frozen Projection, in Author group order, call exactly once:
760:`WriteMemory(pxCaseID=<exact pyID>,Type="UnitTestProjectionV3",pyGroup=<groupId>,pyPayload=<canonical v3 payload string>)`
762:Each call persists exactly one Projection record. Require a response object with `success=true`, exact echoed `pyGroup=<groupId>`, a distinct nonempty new `pyGUID`, and empty `errorCode/errorMessage`. `WRITE_FAILED`, any tool exception, malformed response, `success!=true`, wrong group echo, empty/reused GUID, or nonempty success error fields makes Projection persistence unconfirmed and blocks **every** Generator invocation. Never retry, overwrite, or roll back a successful or unconfirmed immutable write. Earlier successfully created Projection records remain immutable if a later Projection write fails.
764:Record the returned GUID against that exact group only. Do not correlate by array position because Memory tools have no list response. Only after every Projection WriteMemory succeeds may Generator orchestration begin.
766:Then invoke `UnitTestGenerator(question)` exactly once per group, sequentially in Author group order. Construct exactly one valid JSON `Invocation` object using the persisted row's exact GUID as `UnitTestProjectionUUID`, serialize it with normal JSON string escaping, and send exactly:
769:Generate the UnitTestCandidate for the exact persisted UnitTestProjection.
772:{"CaseID":"<exact pyID>","RUTType":"<immutable original type>","UnitTestProjectionUUID":"<projection GUID>"}
774:Return only the GeneratorRunReport required by your system instructions.
779:For each Generator result require only caller-owned correlation and terminal status:
781:- `sourceUUID` equals the exact `UnitTestProjectionUUID` supplied in that Generator question;
785:- `Failed`, malformed status, or mismatched correlation stops all remaining Generator calls and makes the Author run Failed.
787:Interpret only the caller-owned correlation/status fields defined above. Ignore all other Generator fields and never inspect candidate memory. This is an intentional trust boundary: after exact `sourceUUID` + `groupId` correlation and terminal `status` validation, GeneratorRunReport internal consistency is Generator-owned.
791:All reasoning, state, evidence, projection payloads, UUIDs and Generator results are silent internal work. Return exactly one raw JSON object:

## A8E sequencing conflicts identified

1. §7 requires all Projections to be materialized before persistence/orchestration begins.
2. §7 requires all Projection WriteMemory calls to succeed before the first Generator invocation.
3. Current §5.5 already establishes global physical grouping and B→A audit; therefore Projection/Generator work can be serialized per frozen physical group after global A=PASS without changing scenario semantics.
4. Current restart language permits returning to earlier semantic phases after A; A8E requires a commit boundary after the first successful Projection persistence.

## Non-candidates

- KnowledgeTool `response.pxResults` is unrelated to Memory sequencing.
- Generator and Validator prompts are not semantic change candidates under A8E.
- Dependency closure, I/W/F/B/A semantics, casting, target schemas and Memory API are out of scope.
