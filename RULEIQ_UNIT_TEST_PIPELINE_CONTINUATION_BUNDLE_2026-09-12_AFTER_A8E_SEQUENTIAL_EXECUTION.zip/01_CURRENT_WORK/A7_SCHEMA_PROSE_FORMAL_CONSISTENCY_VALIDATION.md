# A7 — Schema prose / formal consistency cleanup — validation

**Status:** TEXTUALLY / STRUCTURALLY VALIDATED

**Evidence boundary:** static contract inspection only. No Claude runtime, Pega runtime, deployed KnowledgeTool, or Pega JsonValidationTool execution was performed.

> **A8B supersession note (2026-09-12):** A7's "illustrative JsonExample" treatment and schema-validity evidence remain historical, but A8B replaces the examples with canonical Generator-output fixtures and tightens physical target typing (`pyExpectedValue` string-only). Use A8B artifacts for current target/example authority.

## Scope

A7 aligns the two Stage-3 candidate JsonSchemas and their bundled illustrative JsonExamples with the accepted ownership model:

1. ordinary JSON Schema Draft 2020-12 keywords own machine-enforceable instance constraints;
2. `x-ruleiq-compilerMappings` owns deterministic Projection→candidate algorithms that cannot be expressed as instance-only predicates;
3. `x-ruleiq-crossFieldInvariants` owns normative candidate-internal/Pega relationships not expressible by ordinary instance keywords;
4. only text explicitly labeled `Heuristic:` or `Recommendation:` is non-binding advice;
5. JsonExample remains illustrative and cannot override schema/Knowledge.

## Implemented repairs

### 1. One naming owner

Both schemas now contain exactly one `x-ruleiq-compilerMappings` entry:

- `CM-NAME-001`

It owns the complete `rut.name + testLabel + physicalGroupKey -> TC_...` normalization/truncation/construction algorithm.

`UnitTestRules[].Name`, `RuleCode.pyPurpose`, and `RuleCode.pyLabel` descriptions no longer duplicate the algorithm. They reference the single owner.

Executable identity equality is documented once as:

- `CF-IDENTITY-001`

### 2. Cross-field Pega/documentation invariants centralized

Both schemas contain:

- `CF-IDENTITY-001` — executable Name / pyPurpose / pyLabel equality;
- `CF-PRIMARY-001` — effective primary page/class relationship;
- `CF-PAGE-PARAM-001` — PAGE parameter must reference an available test page.

The multi-input schema additionally contains:

- `CF-WHEN-ORDER-001` — input cells first, exactly one Result cell last.

The stale false relationship `RuleUnderTest.pyDetails.pyClassName` was removed. `RuleCode.pyClassName` is the executable primary-page class; `pyRuleUnderTestObjClass` remains the RUT Apply-To class and may legitimately differ.

### 3. Machine-enforceable prose moved into schema keywords

Static negative tests confirm:

- regular `PagePropertyAssertion` now formally requires `pyPropertyMode`;
- standard `RuleUnderTestDetails.pyIsSinglePageImplementation` is formally limited to `"true"|"false"`;
- when standard `pyRuleUnderTestType="Rule-Obj-Model"`, `pyIsSinglePageImplementation` is formally constrained to `"false"`;
- `SimulationRule.pyClassName="Code-Pega-List"` formally requires `pxReferredFromClass="Code-Pega-List"`;
- non-list `SimulationRule` formally rejects `pxReferredFromClass`;
- literal `Primary` and reserved top-level system pages are formally rejected for `RuleCode.pyPrimaryPageForRUT`;
- reserved top-level system pages are formally rejected for Pages & Classes, setup-page, and simulation-setup-page names where the schemas expose those fields;
- enum/const-owned statements for simulation method, mocked rule type, Param assertion constants, CUSTOMPAGES, Result labels/types remain ordinary formal constraints.

### 4. Ownership-stale prose removed

Simulation schema prose no longer instructs Unit Test Generator to call RuleCrawler or infer Data Page structure/class. It now explicitly consumes frozen `UnitTestProjection` simulation facts.

`RuleUnderTest` prose no longer references nonexistent `pyDetails.pyClassName`.

Optional persisted UI metadata (`pySelected`, `pySkipPostLoad`, `pxWarningsToDisplay`, etc.) no longer sounds semantically mandatory or recoverable from hidden Author state.

Open business payload objects (`pyPageDetails`, simulation payload) are explicitly documented as source-fidelity-owned open payload containers rather than pretending the target schema has a semantic allowlist.

### 5. Heuristic wording normalized

Advice remains non-binding only when explicitly marked `Heuristic:` or `Recommendation:`. Examples include cleanup preference, ruleset choice, filter usage, and setup-action preference.

### 6. Bundled examples repaired

Legacy Scenario fields and hidden-governance counters/checklists were removed from both JsonExamples rather than re-admitted into the Stage-3 schemas.

Local Draft-2020-12 validation result:

- `rule-test-unit-case_JsonExample(5).txt` -> **0 schema errors**;
- `rule-test-unit-case_multInpComb-JsonExample(6).txt` -> **0 schema errors**.

Before A7 those examples failed their own schemas because of legacy Scenario narratives/counters/checklists.

## Prompt synchronization

Current Generator authority:

- `UnitTestGenerator_Prompt_A7_SCHEMA_CONTRACT_REPAIRED.txt`

Changes are target-authority only:

- ordinary schema keywords vs compiler mappings vs cross-field invariants are distinct owners;
- naming reads exactly `x-ruleiq-compilerMappings.CM-NAME-001`;
- G7 includes all applicable `x-ruleiq-crossFieldInvariants`.

Current Validator authority:

- `Validator_Prompt_A7_SCHEMA_CONTRACT_REPAIRED.txt`

Changes are target-validation authority only:

- JsonValidationTool owns ordinary keywords;
- naming reads exactly `CM-NAME-001`;
- cross-field checks execute selected-schema `x-ruleiq-crossFieldInvariants` once and do not reconstruct duplicates from individual descriptions/examples;
- Heuristic/Recommendation text is explicitly non-binding.

Scenario Author remains `Main_Agent_Prompt_A6_CAST_MATRIX_REPAIRED.txt`; A7 does not change Author semantics.

## Static checks

PASS:

- both Stage-3 files parse as JSON;
- `Draft202012Validator.check_schema(...)` passes for both;
- exactly one `CM-NAME-001` exists per schema;
- expected cross-field invariant IDs exist exactly once per schema;
- both bundled examples validate with zero errors;
- missing regular property `pyPropertyMode` is rejected;
- Rule-Obj-Model + single-page `"true"` is rejected;
- reserved Primary/system page name is rejected;
- Code-Pega-List without `pxReferredFromClass` is rejected;
- Code-Pega-List with exact wrapper passes;
- non-list simulation carrying `pxReferredFromClass` is rejected;
- no schema description refers to nonexistent `RuleUnderTest.pyDetails.pyClassName`;
- no simulation description tells Generator to fetch RuleCrawler / `pyStructure`;
- full naming construction is not duplicated in pyPurpose/Name descriptions.

## Result

**A7 = TEXTUALLY / STRUCTURALLY VALIDATED.**

This does not close A4 deployment proof and does not constitute runtime Pega validation.

**Next stage: A8 — final end-to-end tabletop simulation against the current A1–A7 contracts.**
