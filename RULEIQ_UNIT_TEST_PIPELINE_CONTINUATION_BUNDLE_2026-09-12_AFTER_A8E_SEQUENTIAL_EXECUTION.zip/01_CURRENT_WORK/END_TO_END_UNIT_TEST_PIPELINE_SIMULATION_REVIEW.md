> **A8D NOTE:** This simulation review is historical seam evidence. Any `RequestsJSON`/batch-shaped Memory syntax in this document is superseded by the current A8D single-record Memory contract.

# End-to-End Unit Test Pipeline Simulation Review

**Date:** 2026-09-12  
**Target model:** Claude Opus 4.8  
**Scope:** Scenario Author → UnitTestProjectionV3 → UnitTestGenerator → G7 → UnitTestCandidate → UnitTestValidator → lifecycle update / repair → GeneratorRunReport → Author terminal status  
**Evidence type:** tabletop / contract simulation only. No Claude runtime execution, Pega execution, synthetic harness, hashes or checksums.

## 1. Executive conclusion

The **core architecture is sound**:

- Scenario Author owns semantic truth.
- UnitTestProjectionV3 is immutable source.
- Generator is a deterministic projection compiler.
- G7 is a mandatory pre-write full-candidate fidelity check.
- Validator independently reads the persisted Projection and Candidate.
- Validator checks only formal schema, closed deterministic Projection fidelity, and candidate-internal Pega/documentation invariants.
- Fidelity repair reconstructs Candidate from immutable Projection, never from Validator-proposed values.
- Candidate versions are immutable.
- Agent-to-Agent handoffs use one `question` with an explicit Invocation envelope.
- Validator and Generator have one closed 14-pair diagnostic protocol.

However, an **end-to-end execution simulation finds important seams that were not covered by the previous per-stage textual acceptance**. The main problems are not in the fidelity philosophy; they are at producer/consumer and tool-protocol boundaries.

### Overall disposition

| Priority | Finding | Impact |
|---|---|---|
| **P0 / Critical** | Candidate naming contract is not executable as written: schema names `RuleJSON.pyRuleName`, Generator only has `Projection.rut.name`; `testLabel` creation/uniqueness is not specified | Can cause `PROJECTION_FAILED`, model-dependent substitution, or duplicate Pega test rule names across physical groups |
| **P0 / High** | Final Generator lost the exact `UpdateMemory` lifecycle carrier and response contract | Every happy path reaches an underspecified tool payload after Validator; Opus must invent `RequestsJSON` |
| **P0 / High** | Author producer validation does not enforce several lexical bounds that Generator treats as source validity | Author can persist a projection that Generator rejects as `SOURCE_INVALID` |
| **P0 / deployment precondition** | `pyRuleSet` / `pyRuleSetVersion` depend on the JsonExample key carrying an already-selected application target | Correct only if Pega integration dynamically injects the target; static local examples contain demo rulesets |
| **P1 / High** | Numeric/boolean scalar stringification is undefined and deliberately not Validator-checked | Different Opus runs may serialize equivalent native numbers differently; fidelity hole remains |
| **P1 / Medium-High** | Scalar formal parameter type is removed from Projection | Target examples/Knowledge carry Text/Integer/TrueFalse types; runtime correctness of omission is not proven |
| **P1 / Medium** | Schema prose can be stronger than schema keywords | Generator may omit a formally optional field while Validator documentation layer later demands it, creating repair churn |
| **P1 / Medium** | `PF_SOURCE_TARGET_CONFLICT` can be masked by schema-first Validator short-circuit | Same underlying source incompatibility can terminate as PROJECTION_FAILED, schema repair/HUMAN, or SEMANTIC_REJECT depending on where detected |
| **P2 / Intentional trust boundary** | Author validates only `sourceUUID`, `groupId`, `status` from Generator report | A malformed candidate pointer/counter can be ignored if Generator still says Completed |
| **P2 / deployment check** | Unversioned KnowledgeArea keys must resolve to the Stage-3 schemas | If they resolve to older schemas, Generator returns KNOWLEDGE_FAILED |

**Recommendation:** do not move to a real Claude/Pega runtime trial before P0 items 1–4 are closed or explicitly accepted as deployment preconditions.

---

# 2. Sources used

Primary final prompts:

- `Main_Agent_Prompt_FINAL_ACCEPTED.txt`
- `UnitTestGenerator_Prompt_FINAL_ACCEPTED.txt`
- `Validator_Prompt_FINAL_ACCEPTED.txt`

Target contracts / evidence:

- `rule-test-unit-case_JsonSchema_STAGE3.txt`
- `rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt`
- standard / multi-input JsonExamples available in the project
- Rule-Obj-When KnowledgeArea material
- historical `UnitTestGenerator_Prompt(4).txt` / related earlier Generator versions, used **only** to identify contracts that existed before refactoring (especially lifecycle `UpdateMemory`), not as current authority

The review does not silently replace the final prompts with historical behavior. Historical material is marked only where it proves that a current omission is a regression or where it shows an earlier explicit contract.

---

# 3. End-to-end state machine reconstructed from the final prompts

## 3.1 Scenario Author

1. Acquire case/RUT identity.
2. Close semantic dependencies.
3. Build Scenario Compiler inventory/witnesses/frozen set.
4. Freeze ASSERT/SIM/OMIT/GAP.
5. Physically group Scenarios.
6. Materialize one UnitTestProjectionV3 per physical group.
7. Self-validate projections.
8. Persist all projections in one `WriteMemory(Type="UnitTestProjectionV3")`.
9. For each returned projection GUID, call Generator with one `question`.
10. Accept only `sourceUUID`, `groupId`, `status`; stop on Failed/malformed correlation.

## 3.2 Generator

1. Parse one Invocation:
   `CaseID,RUTType,UnitTestProjectionUUID`.
2. Read exact Projection by UUID.
3. Validate closed source grammar and select mode.
4. Acquire target schema / Knowledge / example.
5. Compile deterministic Candidate.
6. Run full G7.
7. Write immutable Candidate v0.
8. Call Validator with source UUID + current candidate UUID.
9. Validate ValidatorReport.
10. Update current Candidate lifecycle.
11. Route:
   - OK → terminal success;
   - HUMAN → terminal human;
   - SEMANTIC_REJECT → terminal reject;
   - GENERATOR_REPAIR → rebuild from authoritative owner → full G7 → v1/v2 → revalidate.
12. Return GeneratorRunReport.

## 3.3 Validator

1. Parse one Invocation:
   `CaseID,RUTType,UnitTestProjectionUUID,UnitTestCandidateUUID`.
2. Select candidate schema.
3. Run JsonValidationTool first.
4. If schema-valid: read exact Projection and Candidate.
5. Correlate `pyGroup`.
6. Parse payloads.
7. Run closed deterministic Projection fidelity.
8. For executable candidate, run documentation/Pega validation.
9. Return exact read-only ValidatorReport.

This ownership model is coherent. The problems below are mostly incomplete information at the transitions.

---

# 4. Happy-path simulations

## H1 — Executable Standard rule, string-only values

### Frozen Author scenario

Illustrative Projection:

```json
{
  "testLabel": "ApprovedCase",
  "rut": {
    "name": "CalculateStatus",
    "applyToClass": "MyApp-Data-Case",
    "singlePage": false
  },
  "primary": {
    "class": "MyApp-Data-Case"
  },
  "scenarios": [
    {
      "name": "Approved case",
      "confidence": "High",
      "testability": "FullyTestable",
      "reasoningTrace": "Closed evidence supports the approved branch.",
      "dependencyClosureStatus": "Closed",
      "dependencyClosureTrace": "No RuleCrawler waves occurred."
    }
  ],
  "setupPages": [
    {
      "name": "RunRecordPrimaryPage",
      "data": {
        "pxObjClass": "MyApp-Data-Case",
        "InputStatus": "A"
      }
    }
  ],
  "assertions": [
    {
      "kind": "Property",
      "path": ".Status",
      "comparator": "Is Equals To",
      "expected": "Approved",
      "mode": "Text"
    }
  ]
}
```

### Trace

1. Author persists Projection under e.g. `pyGroup=G001`, receives `P-GUID-001`.
2. Author invokes Generator:
   `CaseID`, original `RUTType`, `UnitTestProjectionUUID=P-GUID-001`.
3. Generator exact source read succeeds.
4. Source matches `EXECUTABLE_STANDARD`.
5. Generator acquires standard schema + Knowledge + JsonExample.
6. It compiles:
   - Scenario pass-through;
   - primary page default;
   - RUT identity;
   - setup page;
   - one Property assertion.
7. G7 checks source census/value/order and target constants.
8. Candidate v0 is written under the same `pyGroup=G001`.
9. Generator invokes Validator with Projection UUID + Candidate UUID.
10. JsonValidationTool passes.
11. Validator reads exact Projection and Candidate, groups match.
12. Closed fidelity checks pass.
13. Documentation/Pega checks pass.
14. Validator returns `route=OK`, zero issues.
15. Generator should mark current candidate `Passed/OK`.
16. Generator returns Completed, attempts=1, repairs=0.
17. Author checks sourceUUID/groupId/status and returns external Completed.

### Result

**Conceptual path: PASS.**

### Current blockers / assumptions

The trace is not fully executable from the final prompt alone because:

- test-rule naming is ambiguous at the schema boundary;
- target Ruleset/Version must be supplied correctly by the Pega JsonExample integration;
- exact lifecycle `UpdateMemory RequestsJSON` is missing from the final Generator prompt.

So H1 is a **logical happy path but not yet a fully specified tool-execution path**.

---

## H2 — Executable Rule-Obj-When, two rows

Use string inputs to avoid the unresolved native-number stringification problem.

```json
{
  "testLabel": "RiskDecision",
  "rut": {
    "name": "IsReviewRequired",
    "applyToClass": "MyApp-Data-Case",
    "singlePage": false
  },
  "primary": {
    "class": "MyApp-Data-Case"
  },
  "scenarios": [
    {
      "name": "High risk mobile",
      "confidence": "High",
      "testability": "FullyTestable",
      "reasoningTrace": "Closed evidence supports true result.",
      "dependencyClosureStatus": "Closed",
      "dependencyClosureTrace": "No RuleCrawler waves occurred."
    },
    {
      "name": "Low risk portal",
      "confidence": "High",
      "testability": "FullyTestable",
      "reasoningTrace": "Closed evidence supports false result.",
      "dependencyClosureStatus": "Closed",
      "dependencyClosureTrace": "No RuleCrawler waves occurred."
    }
  ],
  "rows": [
    {
      "inputs": [
        {"path": ".RiskBand", "value": "High"},
        {"path": "Param.Channel", "value": "Mobile"}
      ],
      "result": true
    },
    {
      "inputs": [
        {"path": ".RiskBand", "value": "Low"},
        {"path": "Param.Channel", "value": "Portal"}
      ],
      "result": false
    }
  ]
}
```

### Trace

Generator creates one Decision block:

- `pyAllowMultipleInputCombinations="true"`
- `pyAssertionType="Decision"`
- `pyClassContext=MyApp-Data-Case`
- two rows, exact order
- input cells exact path/order
- Result last
- result values `"true"` and `"false"`

Validator checks:

- Scenario count == row count
- exact row index correlation
- same ordered input-path census
- exact string input values
- Result boolean → lowercase text
- Result last

### Result

**PASS under current contracts.**

### Risk exposed by the simulation

`Param.Channel` has no scalar formal type in Projection. Current examples and Rule-Obj-When Knowledge show that formal parameter types such as `Text`, `Integer`, `TrueFalse` exist. The target schema permits a parameter type, but current mapping omits scalar type. This is formally schema-valid, but actual Pega invocation semantics are not proven equivalent.

---

## H3 — Informational NotTestable

```json
{
  "testLabel": "UnavailableDependency",
  "rut": {
    "name": "NotTestableFixture"
  },
  "scenarios": [
    {
      "name": "Unavailable dependency",
      "confidence": "Low",
      "testability": "NotTestable",
      "reasoningTrace": "A required dependency could not be resolved.",
      "dependencyClosureStatus": "Blocked",
      "dependencyClosureTrace": "No RuleCrawler waves occurred."
    }
  ]
}
```

### Trace

1. Generator identifies `INFORMATIONAL_NOT_TESTABLE`.
2. It requests only the matching JsonSchema.
3. It creates wrapper/Scenario metadata and no RuleCode.
4. G7 confirms informational mode/no RuleCode.
5. Candidate is persisted.
6. Validator schema-validates it.
7. Validator reads Projection + Candidate.
8. Fidelity passes.
9. Validator skips KnowledgeTool because there is no executable Pega structure.
10. Validator returns OK.
11. Generator lifecycle update → Passed/OK.
12. Generator returns Completed.
13. Author returns external Completed.

### Result

**Architecture: clean PASS.**

This is one of the strongest paths in the design. “Completed” correctly means “faithfully represented”, not “unit test executed”.

---

# 5. Non-happy-path simulations

## N1 — Author produces a source string that Generator rejects

Suppose Author produces:

```json
"testLabel": "High-risk > 1000"
```

or:

```json
"name": "Approved: VIP"
```

Author's final self-validation does not explicitly enforce the Generator's lexical source rule.

Generator requires both `testLabel` and Scenario `name`:

- length 1..50;
- `^(?!TC_)[A-Za-z0-9 _]+$`.

### Outcome

Author can complete semantic/persistence gates, then Generator immediately returns:

`SOURCE_INVALID`

before candidate generation.

### Classification

**HIGH producer/consumer mismatch.**

This is not a semantic disagreement. It is a missing shared source-contract validation rule.

---

## N2 — Two physical groups produce the same candidate test identity

Assume one RUT produces two physical standard groups and Author gives both:

```text
testLabel = "HappyPath"
```

Generator invocations are isolated and each builds target identity from:

`rut.name + testLabel`

No downstream component sees sibling candidate names. Validator validates one candidate at a time.

### Outcome

Both generators may produce the same:

```text
UnitTestRules[0].Name
RuleCode.pyPurpose
RuleCode.pyLabel
```

There is no cross-group uniqueness gate.

Historical project versions used a stable group suffix in naming; current v3 intentionally removed group identity from Projection. The final Author also does not define how `testLabel` must be unique across physical groups.

### Classification

**CRITICAL collision risk.**

Potential results:
- second rule save conflicts with first;
- one test overwrites/duplicates another depending on downstream persistence semantics;
- Opus invents its own uniqueness suffix;
- Generation fails with an ambiguous naming contract.

---

## N3 — G7 catches a pre-write compiler defect

Projection says:

```json
"expected": "Approved"
```

In-memory candidate accidentally has:

```json
"pyExpectedValue": "Declined"
```

### Outcome

G7 runs before WriteMemory.

It detects mismatch and terminates:

`PROJECTION_FAILED`

No candidate is written. Validator is never called.

### Classification

**Correct behavior.**

This is a major strength of the architecture.

---

## N4 — Persisted candidate is schema-valid but fidelity-wrong

Assume a defect somehow escapes the initial G7 or a stored candidate differs from the expected in-memory representation:

Projection:
```json
expected = "Approved"
```

Candidate:
```json
pyExpectedValue = "Declined"
```

Formal schema still passes.

### Validator

After exact dual read:

```text
PF_ASSERTION_MISMATCH
RESTORE_FROM_PROJECTION
route=GENERATOR_REPAIR
```

Validator does **not** return `"Approved"`.

### Generator

1. Ignores any replacement value in message.
2. Locates the source assertion.
3. Recomputes from frozen Projection.
4. Rebuilds the complete containing assertion fragment.
5. Runs full G7.
6. Writes v1 with a new GUID.
7. Revalidates.
8. Validator returns OK.

Expected counters:

```text
validationAttempts = 2
repairAttempts = 1
```

### Classification

**Correct behavior.**

This is the strongest part of the new M1–M7 design.

---

## N5 — Formal schema defect

Candidate v0 is missing a required formal field such as `pyPurpose`.

### Validator

JsonValidationTool fails first:

```text
JSON_SCHEMA_INVALID / FIX_JSON
route=GENERATOR_REPAIR
groupId=null
```

No Projection read occurs.

### Generator

This is TARGET_REPAIR.

It may rebuild only from:
- target schema;
- deterministic mapping;
- template-owned facts;
- frozen source where mapping needs it.

Then full G7 → v1 → Validator.

### Classification

**Conceptually correct.**

### Important current defect

After the valid ValidatorReport, Generator must call UpdateMemory on v0 **before** next action. The final prompt gives no exact RequestsJSON carrier.

Therefore this path becomes operationally ambiguous at precisely the lifecycle transition.

---

## N6 — Rule-Obj-When has `rut.singlePage=true`

Projection:

```json
"rut": {
  "name": "IsX",
  "applyToClass": "MyApp-Data",
  "singlePage": true
}
```

Target multi-input schema requires:

```text
pyIsSinglePageImplementation = "false"
```

### Correct Generator behavior

Source + mapping + target schema are incompatible.

Generator should stop pre-write:

`PROJECTION_FAILED`

because changing source `true` to target `"false"` would change source meaning.

### If Generator incorrectly writes `"true"`

Validator runs JsonValidationTool **before** reading Projection.

Formal schema fails:

```text
JSON_SCHEMA_INVALID/FIX_JSON
```

Validator never reaches the explicit `PF_SOURCE_TARGET_CONFLICT`.

Generator cannot legally perform FIX_JSON by changing true→false from schema alone because that contradicts frozen Projection. Its repair-authority safety should then stop, likely HUMAN.

### Result

One underlying incompatibility has several possible terminal classifications depending on detection stage.

### Classification

**MEDIUM contract-consistency issue.**

The safe behavior is still fail-closed, but diagnostics/routing are not uniform.

---

## N7 — Projection/Candidate group correlation mismatch

Validator reads exact UUIDs:

```text
Projection.pyGroup = G001
Candidate.pyGroup = G002
```

### Validator

Returns exactly:

```text
AMBIGUOUS / HUMAN_REVIEW
path=/Correlation
groupId=null
route=HUMAN
```

### Generator

Correctly rejects normal group correlation and routes HUMAN.

### Hidden lifecycle problem

The Generator must still perform one lifecycle UpdateMemory for every **valid** ValidatorReport before the route action.

But the exact UpdateMemory carrier is absent from the final prompt.

If the historical carrier were restored, it would target:
- source group G001;
- current candidate GUID.

If the candidate really lives under G002, the update itself should fail correlation and end `LIFECYCLE_UPDATE_FAILED`.

That is defensible, but the final prompt does not specify it.

### Classification

**Good Validator behavior; incomplete Generator lifecycle protocol.**

---

## N8 — Repair budget exhaustion

v0 → Validator requests repair  
v1 → Validator requests repair  
v2 → Validator requests repair again

Contract limits:
- repairAttempts max 2
- validationAttempts max 3

### Outcome

After v2's third validation requests another repair:

`REPAIR_BUDGET_EXHAUSTED`

No v3 is written.

### Classification

**PASS.**

---

## N9 — Numeric / boolean input serialization ambiguity

Projection has:

```json
{"name":"Threshold","value":1.0}
```

or When input:

```json
{"path":".Amount","value":1e3}
```

Generator only says:

```text
number/boolean deterministic string
```

Possible model outputs:
- `"1"`
- `"1.0"`
- `"1.000"`
- `"1000"`
- `"1e3"`

For booleans, examples suggest lowercase `"true"/"false"`, but parameters do not have an exact algorithm in the prompt.

Validator explicitly does not fidelity-check numeric/boolean content.

### Outcome

Two Opus runs can produce different schema-valid candidate values from the same Projection without Validator detecting a fidelity difference.

### Classification

**HIGH determinism gap.**

The architecture recognized this and intentionally excluded it from fidelity; the end-to-end review says it should now be resolved rather than left as a permanent exclusion.

---

## N10 — Target Ruleset template is static instead of application-specific

Final Generator treats JsonExample/template as the only owner of:

- `pyRuleSet`
- `pyRuleSetVersion`

Project-local examples visibly contain demo/test values such as:
- `3010067594@`
- `GenericTestRules`
- `SampleTestRules`
- version `01-01-01`

Earlier project material explicitly states that **the Pega integration is supposed to replace these carriers with the already-selected operational target**, and local values are only formatting examples.

### Outcome if deployment does inject current app target

PASS.

### Outcome if KnowledgeTool returns a static project file unchanged

Generator faithfully copies the wrong ruleset/version.

Formal schema passes because the values are syntactically valid.

Validator has no independent source for the intended application target.

### Classification

**P0 deployment precondition, not proven prompt failure.**

This must be verified in configuration before runtime testing.

---

# 6. Detailed findings

## F1 — Candidate naming is not currently a closed executable contract

**Severity: CRITICAL**

There are two independent problems.

### F1a — schema naming algorithm references unavailable RuleJSON

Stage-3 candidate schema describes `pyPurpose` construction using:

`RuleJSON.pyRuleName`

Generator is forbidden to fetch RuleJSON and has only:

`UnitTestProjection.rut.name`

Generator simultaneously says:
- build identity from `rut.name + testLabel`;
- JsonSchema alone owns target naming construction;
- do not duplicate a second naming algorithm;
- if available facts cannot deterministically produce identity, fail PROJECTION_FAILED.

For a literal model, these statements conflict.

Possible Opus interpretations:

1. substitute `rut.name` for `RuleJSON.pyRuleName`;
2. refuse because schema explicitly says RuleJSON;
3. infer that `rut.name` was copied from RuleJSON and treat it as equivalent;
4. use another naming convention from an example.

Only #3 is probably intended, but it is not stated by the schema.

### F1b — `testLabel` creation and cross-group uniqueness are not defined in Author

Author says root must always include `testLabel`, but does not state:
- source of the value;
- normalization;
- max length;
- allowed characters;
- uniqueness across physical groups;
- collision handling.

Physical groups get consecutive group IDs/orders, but `testLabel` is not explicitly bound to them.

### Required correction

Do **not** duplicate target naming algorithm into Generator/Validator.

Instead:

1. repair the candidate schema naming description:
   - use `UnitTestProjection.rut.name` as RUT technical name;
   - use `UnitTestProjection.testLabel` as semantic label source;
   - remove unavailable `RuleJSON.pyRuleName`.
2. define Author-owned `testLabel` contract:
   - deterministic;
   - frozen after physical grouping;
   - valid under v3 lexical contract;
   - unique across projections in the Author run.
3. guarantee target-name uniqueness after normalization/truncation. A stable group discriminator is the simplest solution, but its exact ownership should be decided centrally in the schema/Author source contract rather than independently invented by Generator.

---

## F2 — Final Generator lost exact lifecycle UpdateMemory contract

**Severity: HIGH / operational blocker**

Final Generator says:

```text
valid ValidatorReport -> call UpdateMemory exactly once with lifecycle result only
```

But does not define `RequestsJSON`.

Historical accepted Generator explicitly defined:

```json
{
  "pxResults": [
    {
      "pyGroup": "<source groupId>",
      "pyGUID": "<current candidate GUID>",
      "pyUpdates": {
        "pyStatusValue": "<Passed or Failed>",
        "pyRouterKey": "<route>"
      }
    }
  ]
}
```

Rules were:
- route OK → `pyStatusValue="Passed"`, `pyRouterKey="OK"`;
- all other valid routes → `pyStatusValue="Failed"`, router = exact route;
- send both fields and no others;
- never touch candidate payload;
- require exact response correlation by group/GUID.

That information disappeared in the compressed final prompt.

### Why this is dangerous for Opus 4.8

`UpdateMemory` accepts generic `RequestsJSON`. Without exact content, model choices include:
- use candidate `pyPayload`;
- use `pyStatus`;
- use `status`;
- omit `pyGUID`;
- use source UUID instead of candidate UUID;
- write report fields into lifecycle;
- invent operation names.

### Required correction

Restore the exact lifecycle request and response contract in Generator §6.

This is not architecture expansion; it is necessary tool-call syntax.

---

## F3 — Author source self-validation does not equal Generator source gate

**Severity: HIGH**

Generator treats these as source validity requirements:

- testLabel: 1..50 and regex;
- Scenario name: 1..50 and regex;
- reasoningTrace nonempty;
- dependencyClosureTrace 1..3500;
- closed page/path/action/parameter shapes.

Author self-validation is less explicit on lexical bounds.

### Consequence

A projection can be:
- semantically accepted by Author;
- persisted;
- then immediately rejected by Generator as SOURCE_INVALID.

### Required correction

Create one shared **UnitTestProjectionV3 source contract** and make Author self-validation and Generator source validation reference the same exact constraints.

At minimum add to Author:
- exact testLabel lexical constraint;
- exact Scenario name lexical constraint;
- nonempty reasoningTrace;
- dependencyClosureTrace max 3500;
- all other Generator source lexical/path restrictions not already explicit.

The best long-term design is a formal Projection schema or deterministic validation tool, but a textual synchronized contract is sufficient for now.

---

## F4 — Target ruleset/version is an external integration dependency

**Severity: P0 deployment precondition**

Current architecture intentionally delegates target Ruleset/Version to the Pega JsonExample/template carrier.

Earlier project documentation explicitly says this target selection is already implemented in Pega, and local examples are illustrative only.

The final Generator prompt compresses this to:

> JsonExample/template supplies only pyRuleSet, pyRuleSetVersion.

That is correct **only if** the KnowledgeTool key returns the operationally selected target.

### Required action

Before runtime trial, verify:
- `Rule-Test-Unit-Case_JsonExample`
- `Rule-Test-Unit-Case_MultInpComb-JsonExample`

return the current application's selected UT target values, not static local example values.

Also restore one sentence to Generator making this precondition explicit, so Opus does not treat an arbitrary static example as authoritative merely because it has those fields.

---

## F5 — Canonical scalar stringification is missing

**Severity: HIGH**

Affected:
- RUT parameter values;
- action parameter values;
- Rule-Obj-When numeric/boolean input values.

The final Generator owns conversion but does not define it.

Validator intentionally excludes those value-content comparisons.

### Recommended canonical algorithm

A separately reviewed exact rule should be added, for example:

- string → exact string, including empty string;
- boolean → `true` / `false`;
- integer JSON number → base-10 integer text, no plus sign, no leading zeros except `0`;
- non-integer JSON number → one canonical finite decimal representation defined once (prefer a JSON-number canonicalization standard or explicit decimal lexical algorithm);
- do not accept exponent-vs-decimal alternatives as equivalent after projection;
- PAGE values remain exact page-name string and are not scalar-canonicalized.

Then activate corresponding Validator fidelity rows currently marked NO_FIDELITY_CHECK.

Do not simply write “use str(value)”.

---

## F6 — Scalar formal parameter type is lost

**Severity: MEDIUM-HIGH / runtime confirmation required**

Author explicitly does not serialize scalar declaration type.

Generator emits:
- PAGE type when page=true;
- otherwise type absent.

But target examples and Rule-Obj-When Knowledge show formal parameter types:
- Text
- Integer
- TrueFalse
- etc.

Formal schema allows omission, so Validator cannot flag it.

### Risk

Pega runner may:
- infer type from RUT definition and be fine;
- or require explicit type for correct coercion/UI/runtime behavior.

### Required action

Confirm Pega unit-test runtime semantics.

If type matters:
- make scalar formal type an Author/source fact, or
- make it a deterministic Generator-side fact obtainable from a structural source it is already allowed to read.

Do not let Validator invent it.

---

## F7 — Formal schema vs normative prose can create repair churn

**Severity: MEDIUM**

Examples:
- descriptions say some fields are “Always CUSTOMPAGES” or “Required for all Property assertions”;
- formal `required[]` may not require them;
- Generator says omit optional target metadata unless required;
- Validator is allowed to enforce normative descriptions/comments.

### Possible path

1. Generator produces schema-valid minimal candidate.
2. Validator documentation layer says field is normatively required.
3. DOC_TARGET_CONTRACT_MISMATCH.
4. Generator adds field in TARGET_REPAIR.
5. Second validation passes.

This is safe but unnecessary and model-interpretive.

### Required correction

For every documentation rule intended to be mandatory:
- encode it in formal schema when machine-expressible;
- otherwise state one exact cross-field invariant.

For advisory text:
- use “may”, “recommended”, or “heuristic”, not “always/required”.

---

## F8 — Source-target conflict routing is stage-dependent

**Severity: MEDIUM**

Explicit `PF_SOURCE_TARGET_CONFLICT` is conceptually useful, but schema-first Validator can prevent reaching it.

The When `singlePage=true` case demonstrates this.

### Recommended correction

Prefer detecting all known deterministic source-target non-representability in Generator **before Candidate WriteMemory**.

Then `PF_SOURCE_TARGET_CONFLICT` remains a defensive Validator path only for a persisted candidate whose formal representation can still pass schema.

Do not weaken the schema-first Validator gate merely to improve diagnostics.

---

## F9 — Author intentionally trusts Generator terminal status

**Severity: LOW / intentional**

Author reads only:
- sourceUUID
- groupId
- status

This is a clean decoupling boundary and was deliberate.

But it means Author does not independently verify:
- final candidate pointer;
- counters;
- errorMessage formatting;
- representedScenarioNames.

### Recommendation

Keep as-is unless you specifically want Author to defend against malformed Generator output beyond correlation/status.

If retained, state explicitly in architecture documentation:

> GeneratorRunReport internal consistency is Generator-owned; Author trusts it after source/group/status correlation.

That makes the reduced validation an explicit trust decision rather than an accidental omission.

---

## F10 — unversioned Knowledge keys are deployment-sensitive

**Severity: MEDIUM / configuration**

Final prompts use unversioned keys:
- `Rule-Test-Unit-Case_JsonSchema`
- `Rule-Test-Unit-Case_MultInpComb-JsonSchema`

Generator includes a defensive check for minimal Stage-3 Scenario metadata, which is good.

If a key still resolves to an older schema, Generator fails `KNOWLEDGE_FAILED`.

### Required action

Before runtime:
- verify both keys resolve to the Stage-3 content;
- verify Validator and Generator see the same deployed schema content.

---

# 7. Claude Opus 4.8 interpretation risk analysis

## Low-risk / well specified

Opus should interpret these consistently:

- one-question Invocation parsing;
- exact UUID source read;
- closed Standard/When/Informational mode discriminator;
- Scenario pass-through fields;
- Standard assertion census/order;
- When row/input/result ordering;
- G7 role;
- immutable candidate versions;
- fidelity vs target repair distinction;
- 14-pair diagnostic catalog;
- replacement-value firewall;
- exact route precedence.

These instructions have one owner and little semantic overlap.

## Medium-risk

Likely to vary under long context or ambiguous target docs:

- optional target metadata driven by prose descriptions;
- formal parameter type omission;
- target ruleset carrier if examples look like ordinary static examples;
- precise classification of source-target conflict after schema-first short-circuit.

## High-risk

Likely to produce different behavior between runs or require the model to invent missing protocol:

- naming with schema requiring `RuleJSON.pyRuleName` while Generator has `rut.name`;
- same `testLabel` across physical groups;
- undefined numeric/boolean scalar stringification;
- `UpdateMemory RequestsJSON` absent;
- Author source strings outside Generator lexical grammar.

These should be corrected before relying on Opus runtime consistency.

---

# 8. Recommended remediation order

## P0 — before any real model/Pega trial

### R1. Close the naming contract

Edit the candidate schemas, not Generator/Validator, so:
- naming source is `UnitTestProjection.rut.name`;
- semantic label source is `UnitTestProjection.testLabel`;
- unavailable `RuleJSON.pyRuleName` is removed;
- uniqueness across physical groups is guaranteed by one deterministic source-owned discriminator.

Add the corresponding Author `testLabel` freeze/uniqueness rule.

### R2. Restore exact Generator lifecycle UpdateMemory protocol

Restore:
- exact RequestsJSON;
- Passed/Failed + router mapping;
- exact response fields;
- group/GUID correlation;
- fail/no-retry semantics.

### R3. Synchronize Author source validation with Generator v3 grammar

Add all lexical limits and closed source constraints to Author's projection self-validation.

### R4. Verify deployment target template and Knowledge keys

Configuration proof:
- JsonExample key contains current app UT ruleset/version;
- schema keys resolve to Stage-3 schemas;
- Generator and Validator retrieve the same schema generation.

## P1 — before production use

### R5. Define canonical scalar stringification

Then turn numeric/boolean fidelity checks back on.

### R6. Resolve formal parameter type strategy

Confirm Pega runtime behavior, then either retain type in Projection or define a deterministic allowed source for Generator.

### R7. Align schema prose with formal constraints

Eliminate “optional formally / mandatory in prose” where possible.

### R8. Normalize source-target conflict ownership

Generator should own deterministic pre-write representability conflicts.

## P2 — architecture documentation

### R9. Document Author's trust boundary for GeneratorRunReport

Make the reduced correlation/status consumption explicit.

---

# 9. What I would change — and what I would NOT change

## Keep unchanged

- Author semantic ownership.
- Immutable Projection.
- Generator deterministic compiler role.
- G7 pre-write gate.
- Validator independent persisted source/candidate read.
- schema-first JsonValidationTool.
- closed deterministic fidelity whitelist.
- no semantic correction by Validator.
- source-driven fidelity repair.
- immutable candidate versions.
- one-question Agent handoff.
- 14-pair catalog concept.
- informational NotTestable behavior.

## Change

Only the seam contracts:

1. Author `testLabel` + source lexical contract.
2. Candidate schema naming source.
3. Generator lifecycle UpdateMemory carrier.
4. deployment template/schema-key preconditions.
5. scalar canonicalization.
6. parameter-type strategy if runtime requires it.
7. schema prose/formal alignment.

The end-to-end review does **not** justify reopening the semantic compiler or fidelity architecture.

---

# 10. Final assessment

The new pipeline is **architecturally much safer than the historical design** because:

- Validator cannot invent corrections;
- Generator cannot reinterpret Author truth;
- persisted source and candidate identities are explicit;
- repair is source-driven and versioned;
- fidelity is deterministic and fail-closed.

But it is **not yet ready for a high-confidence Claude Opus 4.8 runtime trial** without closing the P0 seams.

The most important insight from this review is:

> The remaining risks are no longer “LLM reasoning quality” problems. They are mostly **missing deterministic contracts at stage boundaries**.

That is good news: the high-risk items can be fixed with relatively small, explicit contract amendments rather than another broad prompt redesign.
