# RuleIQ Unit Test Pipeline — A8E Sequential Physical-Group Execution Refactoring Plan

**Status:** COMPLETED / PROMOTED — A8E TEXTUAL / STRUCTURAL / STATIC VALIDATION COMPLETE  
**Date:** 2026-09-12  
**Baseline:** promoted A8D single-record Memory baseline.  
**Scope:** change only Scenario Author orchestration after global semantic freeze so each physical group is completed end-to-end before the next group starts.  
**Out of scope:** new persisted planning artifacts, new ledgers, Generator/Validator semantics, Memory API, target schemas/examples, Pega casting rules, dependency semantics, scenario-generation rules, A4 live deployment, A9 runtime.

The completed A8D plan is archived as:

`05_HISTORICAL_REFERENCE/UNIT_TEST_PIPELINE_REMEDIATION_PLAN_A8D_COMPLETED_SUPERSEDED.md`

This document replaces the previous active-plan content. A8D remains the immutable behavioral baseline except for the Author sequencing changes explicitly authorized here.

---

# 1. Objective

Preserve the existing global Author semantic process and frozen scenario/group authority, but replace the current two-phase downstream orchestration:

```text
materialize ALL Projections
→ persist ALL Projections
→ invoke Generator for ALL groups
```

with:

```text
global semantic freeze + physical grouping + B/A audit
→ for each frozen physical group in order:
     materialize ONE Projection
     → self-validate
     → WriteMemory
     → UnitTestGenerator
     → require terminal correlated GeneratorRunReport
     → next group
```

No new `FrozenUnitTestPlan`, external ledger, Memory record, schema, or tool is introduced.

The existing `SCENARIO_SNAPSHOT` plus frozen physical grouping remain the only Author-owned scenario/group state.

---

# 2. Architectural constraints

## 2.1 Scenario semantics remain global and immutable

Before the first Projection is persisted, Author must complete the existing global semantic workflow:

```text
acquisition/dependency closure
→ semantic execution
→ Scenario Compiler I → W → F
→ final ASSERT/SIM/OMIT/GAP
→ physical grouping
→ complete ScenarioGroup materialization
→ Scenario Compiler B → A
→ require A=PASS
```

Dependency investigation must not create, remove, split, merge, reorder, or reinterpret Scenarios after they are frozen. Dependency-internal variants never create Scenario cardinality.

## 2.2 No per-group dependency-closure redesign

A8E does **not** move dependency closure after grouping or into the per-group loop.

Reason: current witness construction, simulation requirements, Rule-Obj-When grouping, testability and physical grouping depend on resolved semantic/dependency facts. Moving closure later would change Scenario Compiler semantics rather than merely improve model focus.

A8E therefore optimizes only the Projection/persistence/Generator phase after global semantics are already frozen and audited.

## 2.3 Existing Author state, no new ledger

Author must iterate the existing frozen physical-group list in stable Author order.

Before each iteration:
- select the next unprocessed frozen physical group from current canonical Author state;
- never reconstruct remaining groups from Generator results, dependency work, or model recollection;
- never recompute grouping.

No additional JSON/text ledger is introduced.

## 2.4 Commit boundary

Before the first successful Projection `WriteMemory`, existing semantic restart rules remain valid.

After the first Projection is successfully persisted, Author must not restart semantic discovery/grouping in the same run. Any later need for semantic change, new dependency discovery, regrouping, or modification of a frozen Scenario is a terminal Author failure for that run.

Previously persisted Projection/Candidate records remain immutable.

---

# 3. Claude Opus 4.8 prompt-design requirements

A8E wording must be short, imperative, state-oriented and non-redundant.

Preferred pattern:

```text
Freeze globally. Process locally.
For each frozen physical group in order:
Projection → self-check → WriteMemory → Generator → terminal report → next group.
Do not start the next group before the current Generator call terminates successfully.
```

Avoid:
- explanatory narrative already implied by existing ownership rules;
- new aliases for Scenario/group concepts;
- duplicate descriptions of dependency semantics;
- new hidden-state structures;
- repeating Generator/Validator internals in Author prompt.

Target: **no increase in Author prompt word count** versus A8D. Prefer a small net reduction by replacing obsolete all-Projections-first wording rather than appending new prose.

---

# 4. Mandatory two-status execution model

Every A8E stage has separate mandatory statuses:

```text
Change Status:
  NOT_STARTED | IN_PROGRESS | CHANGE_COMPLETE | BLOCKED

Validation Status:
  NOT_STARTED | IN_PROGRESS | VALIDATION_COMPLETE | FAILED | BLOCKED
```

A stage is complete only when:

```text
Change Status     = CHANGE_COMPLETE
AND
Validation Status = VALIDATION_COMPLETE
```

Implementation and validation must be separate logical steps. A validation status cannot be marked complete during the same operation that edits the artifact being validated.

## 4.1 Text-only change verification policy

A8E and all subsequent work under this plan use textual/structural verification only.

Do not use SHA, hash, checksum, digest, or other cryptographic fingerprinting for baseline capture, change detection, promotion, or regression evidence.

Allowed verification methods:
- exact text comparison;
- section-level textual diff;
- required/forbidden phrase checks;
- structural/semantic assertions over prompt or JSON content;
- word-count/context-size comparison where relevant;
- deterministic static regression checks based on artifact content.

A stage must never pass merely because a file fingerprint is unchanged or changed. Validation must inspect the relevant text/structure itself.

---

# 5. Stage plan

| Stage | Scope | Change Status | Validation Status | Completion criterion |
|---|---|---|---|---|
| A8E-0 | Freeze A8D textual baseline + inventory sequencing language | CHANGE_COMPLETE | VALIDATION_COMPLETE | current text/behavior captured; no production edits |
| A8E-1 | Refactor Author phase ordering around global freeze and B/A | CHANGE_COMPLETE | VALIDATION_COMPLETE | global semantics complete before first group loop; no new state structure |
| A8E-2 | Refactor Projection→WriteMemory→Generator into one-group loop | CHANGE_COMPLETE | VALIDATION_COMPLETE | exactly one group reaches terminal Generator result before next group starts |
| A8E-3 | Add post-first-write commit boundary and failure behavior | CHANGE_COMPLETE | VALIDATION_COMPLETE | no semantic restart/regroup after external persistence begins |
| A8E-4 | Remove obsolete/contradictory all-Projections-first wording | CHANGE_COMPLETE | VALIDATION_COMPLETE | no active statement requires all Projection writes before first Generator |
| A8E-5 | Static + adversarial sequencing validation | CHANGE_COMPLETE | VALIDATION_COMPLETE | positive flow passes; all prohibited reorderings are detected |
| A8E-6 | Regression, context-size check and promotion | CHANGE_COMPLETE | VALIDATION_COMPLETE | A8B/A8C/A8D regressions pass; Author prompt does not grow; A8E promoted |

---

# 6. A8E-0 — Baseline freeze and sequencing inventory

## Change step

1. Preserve the exact A8D Author/Generator/Validator text as the baseline.
2. Record word counts and a section-level textual baseline snapshot. Do not calculate or use cryptographic fingerprints.
3. Inventory Author statements concerning:
   - Scenario Compiler phase order;
   - physical grouping freeze;
   - Projection materialization;
   - `B → A` audit;
   - Projection `WriteMemory`;
   - Generator orchestration;
   - restart semantics after `F` and after persistence.
4. Identify contradictions such as:
   - materialize every Projection before `B/A` although `B/A` audits ScenarioGroups, not Projection JSON;
   - require every Projection write before any Generator;
   - language implying a semantic restart remains possible after externally persisted outputs exist.

## Validation step

Independently confirm:
- exact baseline text remains unchanged before production edits;
- inventory contains every relevant active occurrence;
- Generator/Validator prompts are not candidates for semantic modification.

## Exit status

`CHANGE_COMPLETE + VALIDATION_COMPLETE`

---

# 7. A8E-1 — Global freeze before downstream loop

## Change step

Refactor Author `§1.4` and the minimum supporting text so the global phase ends at audited physical ScenarioGroups **before** any Projection persistence.

Target phase sequence:

```text
1–6. Existing acquisition, dependency closure, semantic execution, I→W→F.
7. Freeze final ASSERT/SIM/OMIT/GAP and Scenario metadata.
8. Form and fully materialize all physical ScenarioGroups.
9. Run B→A over the complete frozen ScenarioGroup set; require A=PASS.
10. Enter sequential physical-group processing.
```

Do not change I/W/F/B/A semantics themselves except wording needed to remove the old Projection-before-B/A ordering.

## Validation step

Require:
- `A=PASS` occurs before the first Projection `WriteMemory`;
- B/A still audits the complete ScenarioGroup set, not one group at a time;
- no Projection is needed to establish Scenario membership/grouping;
- dependencies still cannot create Scenario targets/cardinality;
- no new ledger/artifact is introduced.

## Exit status

`CHANGE_COMPLETE + VALIDATION_COMPLETE`

---

# 8. A8E-2 — Sequential one-group execution loop

## Change step

Replace current Author `§6/§7` orchestration with one compact loop.

Normative target wording should be equivalent to:

```text
After global A=PASS, process frozen physical groups exactly once in Author order.
For the current group only:
1. materialize its UnitTestProjectionV3 from frozen Author facts;
2. run §6.8 self-validation;
3. WriteMemory that one Projection;
4. require confirmed write success and retain its exact GUID;
5. call UnitTestGenerator exactly once with that GUID;
6. require terminal correlated GeneratorRunReport;
7. only then continue to the next frozen group.
```

Failure rule:

```text
Any Projection validation, WriteMemory, Generator status or correlation failure stops the run; do not start a later group.
```

Remove the existing barriers:
- “materialize Projection v3 for every group” before orchestration;
- “require every WriteMemory to succeed before invoking any Generator”; and
- “only after all Projection writes succeed, invoke Generator”.

## Validation step

Static positive trace must be exactly:

```text
A=PASS
→ Projection G001
→ WriteMemory G001
→ Generator G001 terminal success
→ Projection G002
→ WriteMemory G002
→ Generator G002 terminal success
→ ...
```

Reject traces where:
- `Projection G002` is persisted before terminal Generator G001;
- Generator G002 starts before G001 terminates;
- all Projections are materialized/persisted first;
- group order changes;
- Generator is invoked twice for one Projection.

## Exit status

`CHANGE_COMPLETE + VALIDATION_COMPLETE`

---

# 9. A8E-3 — External-persistence commit boundary

## Change step

Clarify restart semantics with one short rule:

```text
Before the first successful Projection WriteMemory, semantic invalidation returns to the earliest owning Author phase.
After the first successful Projection WriteMemory, any required semantic change or regrouping terminates the run; never rewrite or reinterpret already persisted groups.
```

This replaces broader wording that would otherwise permit an in-run return to `W/I` after external artifacts already exist.

## Validation step

Check these cases:

1. Semantic defect found before first write → restart allowed.
2. Missing/changed semantic fact discovered while materializing G002 after G001 was persisted/generated → run fails; no restart/patch.
3. Earlier G001 Projection/Candidate remains immutable.
4. Failure does not authorize creation of a replacement Scenario inventory.

## Exit status

`CHANGE_COMPLETE + VALIDATION_COMPLETE`

---

# 10. A8E-4 — Prompt cleanup and context optimization

## Change step

Remove obsolete duplicated sequencing prose rather than append explanations.

Specifically remove/rewrite any active statement equivalent to:
- build every Projection before B/A;
- persist all Projection records before any Generator call;
- keep a parallel list of persisted rows for later batch orchestration;
- restart semantic phases after downstream persistence begins.

Do not alter:
- UnitTestProjectionV3 grammar;
- casting/type ownership;
- Memory single-record API;
- GeneratorRunReport trust boundary;
- scenario coverage/grouping semantics.

## Validation step

Measure Author prompt word count:

```text
A8E words <= A8D words
```

Search active Author prompt for contradictory all-groups-first sequencing phrases. Expected result: zero active contradictions.

## Exit status

`CHANGE_COMPLETE + VALIDATION_COMPLETE`

---

# 11. A8E-5 — Static and adversarial sequencing validation

Create a deterministic A8E sequencing checker. It must validate positive invariants and detect at least these negative mutations:

| Test | Mutation | Expected |
|---|---|---|
| T1 | Generator called before global `A=PASS` | FAIL |
| T2 | G002 Projection persisted before G001 Generator terminal result | FAIL |
| T3 | all Projections persisted before first Generator | FAIL |
| T4 | physical-group order changed after freeze | FAIL |
| T5 | dependency result creates/adds a Scenario after freeze | FAIL |
| T6 | regrouping after freeze | FAIL |
| T7 | semantic restart after first successful Projection write | FAIL |
| T8 | second Generator invocation for same Projection | FAIL |
| T9 | Generator failure followed by processing next group | FAIL |
| T10 | canonical sequential G001→Generator→G002 flow | PASS |

Validation is static/contractual. It does not claim Claude or Pega runtime behavior.

## Exit status

`CHANGE_COMPLETE + VALIDATION_COMPLETE`

---

# 12. A8E-6 — Regression and promotion

## Change step

Only after A8E-0…A8E-5 pass:
- promote the A8E Author prompt;
- keep A8D Generator and Validator byte-identical unless a purely referential filename/manifest update is required;
- update continuation/manifest authority pointers;
- archive A8D Author prompt as historical baseline.

## Validation step

Require all of:

```text
A8E sequencing suite       = PASS (10/10)
A8B canonical fixture      = PASS
A8C adversarial suite      = PASS (10/10)
A8D Memory checker         = PASS
Generator text             = exactly unchanged from A8D
Validator text             = exactly unchanged from A8D
Author word count          <= A8D
A4 state                   = unchanged/open for live deployment
A9 runtime                 = not claimed
```

## Promotion criterion

A8E becomes current design/static baseline only when every stage has:

```text
Change Status     = CHANGE_COMPLETE
Validation Status = VALIDATION_COMPLETE
```

---

# 13. Exact intended behavioral result

After A8E, Author behavior is:

```text
GLOBAL, ONCE
RUT acquisition
→ dependency closure
→ semantic execution
→ I/W/F
→ decisions
→ physical ScenarioGroups
→ B/A
→ A=PASS

THEN LOCAL, SEQUENTIAL
G001: Projection → self-check → WriteMemory → Generator terminal result
G002: Projection → self-check → WriteMemory → Generator terminal result
G003: Projection → self-check → WriteMemory → Generator terminal result
...
```

The sequence improves model focus without introducing new persisted state and without allowing dependency exploration to redefine frozen Scenarios.

---

# 14. Exact next action

A8E is complete/promoted. The next external evidence step is A4 live Generator + Validator KnowledgeTool capture for Standard and MultiInput modes using `A4_LIVE_CAPTURE_TEMPLATE.json` and `A4_DEPLOYMENT_VERIFIER.py`. A9 remains optional runtime validation after A4; no runtime verification is currently claimed.
