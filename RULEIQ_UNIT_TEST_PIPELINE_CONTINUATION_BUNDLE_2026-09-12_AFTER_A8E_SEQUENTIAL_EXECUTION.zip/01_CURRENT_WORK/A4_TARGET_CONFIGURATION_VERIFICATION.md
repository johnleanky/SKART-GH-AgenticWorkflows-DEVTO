# A4 — Target Configuration Verification

**Status:** STATIC DEPLOYMENT PACK COMPLETE — LIVE DEPLOYMENT PROOF REQUIRED  
**Date:** 2026-09-12  
**Evidence boundary:** A8C local authorities and deterministic A4 verifier are prepared and self-tested. No deployed Pega KnowledgeTool response was available in this session.

## Deployment authorities to verify

### Standard executable mode

- `Rule-Test-Unit-Case_KnowledgeArea`
- `Rule-Test-Unit-Case_JsonSchema`
- `Rule-Test-Unit-Case_JsonExample`

Local promoted references:

- `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_KnowledgeArea_A8C_PROPOSED.txt`
- `04_TARGET_CONTRACTS/rule-test-unit-case_JsonSchema_STAGE3.txt`
- `04_TARGET_CONTRACTS/rule-test-unit-case_JsonExample(5).txt`

### Rule-Obj-When / MultiInput executable mode

- `Rule-Test-Unit-Case_MultInpComb-KnowledgeArea`
- `Rule-Test-Unit-Case_MultInpComb-JsonSchema`
- `Rule-Test-Unit-Case_MultInpComb-JsonExample`

Local promoted references:

- `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_MultInpComb-KnowledgeArea_A8C_PROPOSED.txt`
- `04_TARGET_CONTRACTS/rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt`
- `04_TARGET_CONTRACTS/rule-test-unit-case_multInpComb-JsonExample(6).txt`

## Required live proof

A4 closes only when live evidence proves all of the following:

1. Generator and Validator independently retrieve the same generation for each selected key.
2. Both schemas are the promoted Stage-3 logical contract, or an explicitly accepted semantically equivalent revision.
3. Both KnowledgeAreas expose the promoted A8C shared Generator/Validator deterministic mapping/reference, including canonical/contrastive examples, or an explicitly accepted semantically equivalent revision.
4. The MethodParam target contract supports exactly the accepted pipeline type set: `Text|Integer|Decimal|Double|TrueFalse|Date|DateTime|TimeOfDay|PAGE`.
5. Method parameter physical values and all physical `pyExpectedValue` representations are JSON strings; exact Author-frozen lexical transport remains possible without Generator-side parsing/recasting/normalization.
6. Each JsonExample is the current canonical target generation apart from operational `pyRuleSet` / `pyRuleSetVersion`.
7. Standard and MultiInput JsonExamples expose the same intended operational `pyRuleSet` and `pyRuleSetVersion`.
8. No selected target artifact conflicts with the A8C system-prompt behavioral boundaries or persisted Projection ownership.

## Deterministic verifier

Use:

- `A4_DEPLOYMENT_EXPECTED_CONTRACT.json`
- `A4_LIVE_CAPTURE_TEMPLATE.json`
- `A4_DEPLOYMENT_VERIFIER.py`
- `A4_DEPLOYMENT_PACK_VALIDATION.md`

The verifier returns `PASS`, `REVIEW`, or `FAIL` and does not fall back to model memory.

## Local evidence and why it does not close A4

The promoted local schemas, KnowledgeArea proposals and canonical JsonExamples are mutually consistent with the A8C static baseline. The verifier self-test confirms this.

However, the bundled JsonExamples intentionally remain demo/local carriers and expose different operational rulesets:

- Standard: `3010067594@ / 01-01-01`
- MultiInput: `SampleTestRules / 01-01-01`

Therefore the local bundle correctly produces A4 `FAIL` on operational-target consistency and cannot be used as deployment proof.

## Current blocker

No live Pega / Infinity Authoring integration was available or discoverable in this session. A4 is therefore waiting only for the exact deployed KnowledgeTool capture; no further architecture/design work is required to perform the verification.

## Runtime gate

Do not start or claim A9 runtime validation before A4 is `PASS` or an explicit project decision accepts a `REVIEW` deployment revision.
