# A8C Baseline Snapshot

**Stage:** A8C-0 — PASS

A8B mechanical check: `PASS` before any production-prompt edit.

## Prompt metrics

| Agent | Words | Characters |
|---|---:|---:|
| Author | 12696 | 101740 |
| Generator | 4460 | 40943 |
| Validator | 3361 | 29003 |

## Target-section metrics

| Section | Words | Characters |
|---|---:|---:|
| Author §6.1–§6.7 | 890 | 7613 |
| Author §6.8 | 992 | 8602 |
| Generator §3.1 | 280 | 2311 |
| Generator §4.2–§4.4 | 935 | 8704 |
| Validator §4.2–§4.7 | 1172 | 10069 |

## Frozen baseline

- Immutable copies: `05_HISTORICAL_REFERENCE/A8C_BASELINE/`
- Hash manifest: `01_CURRENT_WORK/A8C_BASELINE_SHA256.txt`
- Existing regression: `A8B_CANONICAL_FIXTURE_CHECK.py`
- No production prompt was edited before this snapshot.
