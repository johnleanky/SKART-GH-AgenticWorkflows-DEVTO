# A8B — Target Schema / Generator / JsonExample Alignment Validation

**Status:** TEXTUALLY / STRUCTURALLY VALIDATED — runtime not run  
**Date:** 2026-09-12

## Why A8B was required

A strict post-A8 re-audit found that the two Stage-3 JsonExamples were schema-valid but were not canonical outputs of the current Generator. The important mismatches were: legacy names without `physicalGroupKey`, grouped Property assertions that violated the one-source-assertion→one-target-block compiler rule, missing typed Page-assertion metadata, optional legacy target metadata with no current Generator owner, and native JSON number/boolean `pyExpectedValue` values even though the Pega 26.1 Rule-Test-Unit-Case target contract represents `pyExpectedValue` as a string.

A8B does not change Author semantic ownership or the A6/A8 casting model. It repairs only the physical target contract, deterministic wrapper rules, and canonical fixtures.

## Contract changes

1. Both Stage-3 schemas now define `$defs.ExpectedValue` as JSON `string` only.
2. `RuleCode.pyIsInactive` and `RuleCode.pyCleanUpTestData` use Pega's persisted lowercase string representation (`"true"|"false"|""`) rather than native JSON booleans.
3. RuleIQ-generated structural Page assertion items require authoritative `pyPropertyMode`.
4. Generator/Validator now share explicit deterministic wrappers:
   - `PegaQuotedLiteral(L)` preserves Author lexical `L` and adds only Pega inner quotes/JSON-safe escaping.
   - Method parameters: Text/Date/DateTime/TimeOfDay → quoted literal; Integer/Decimal/Double/TrueFalse → exact bare lexical string; Page → exact page name.
   - Property/Page/List expected values: Text/String/Identifier/Password/TextEncrypted/Date/DateTime/TimeOfDay → quoted literal; Integer/Decimal/Double/TrueFalse → exact bare lexical string.
   - Param assertions use Text target mode and therefore `PegaQuotedLiteral(source.expected)`.
   - Decision cells remain exact bare lexical strings; ResultCount remains decimal integer string.
   - every emitted `pyExpectedValue` is a JSON string; Generator never emits JSON number/boolean/null there.
5. Existing JsonExample files were replaced by exact canonical Generator-output fixtures; they remain template owners only for `pyRuleSet` and `pyRuleSetVersion`.

## Paired fixtures

Added under `04_TARGET_CONTRACTS/fixtures/`:

- `standard_projection.json`
- `standard_candidate.json`
- `when_projection.json`
- `when_candidate.json`

The standard fixture covers Text and Decimal RUT parameters plus Property, Param, Page, List and ResultCount assertions. It preserves Decimal lexical `12.50` exactly as target string `"12.50"` while Text lexical content is serialized as an inner-quoted Pega literal.

The When fixture covers two scenario/row pairs, property/named-page/parameter inputs, Integer and TrueFalse lexical values, Decision Result-last order, default primary page handling, and deterministic `CM-NAME-001` naming.

## Mechanical validation

`A8B_CANONICAL_FIXTURE_CHECK.py` executes an independent compact transcription of the current compiler mappings for the fixture-covered constructs and verifies for both standard and When cases:

1. focused closed UnitTestProjectionV3 fixture shape;
2. `Candidate == Compile(Projection)`;
3. current JsonExample is byte-equivalent as decoded JSON to the paired canonical Candidate;
4. `Candidate ⊨ selected Stage-3 JSON Schema` using Draft 2020-12 validation;
5. every `pyExpectedValue` is a JSON string;
6. `CM-NAME-001` result equals `UnitTestRules[0].Name == RuleCode.pyPurpose == RuleCode.pyLabel`;
7. `CF-PRIMARY-001` holds for the first Pages & Classes row.

Latest local run:

```text
A8B_CANONICAL_FIXTURE_CHECK: PASS
paired fixtures: standard, when
invariants: Projection fixture closed-shape subset; Candidate == Compile(Projection); JsonExample == Candidate; Candidate ⊨ Stage-3 schema; all pyExpectedValue are strings; CM-NAME-001 and CF-PRIMARY-001 hold
```

## Evidence boundary

This is deterministic/static contract validation. It does **not** claim that a Candidate was saved or executed in Pega, that JsonValidationTool/KnowledgeTool was invoked in a deployed environment, or that Claude executed the full prompts. A4 remains the deployed target-binding check and A9 remains optional runtime validation.

The Pega 26.1 `rules-rule-test-unit-case` repository material used for the target-typing correction defines `pyExpectedValue` as a string and documents inner quoting for Text/Date/DateTime Property assertions versus no inner quotes for numeric/TrueFalse values. The local Stage-3 contract is intentionally stricter now so canonical RuleIQ output cannot use native JSON numbers/booleans for `pyExpectedValue`.
