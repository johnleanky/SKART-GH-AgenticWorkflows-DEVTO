# A8C — High-Impact Example-Driven Prompt Refactor Validation

**Status:** PASS — STATIC / CONTRACT / ADVERSARIAL VALIDATION
**Date:** 2026-09-12
**Runtime boundary:** no Claude/Pega runtime was executed; deployed KnowledgeArea contents were not available. A4 remains open and A9 remains not run.

## 1. Promoted authorities

- Author: `Main_Agent_Prompt_A8C_EXAMPLE_REFACTORED.txt`
- Generator: `UnitTestGenerator_Prompt_A8C_EXAMPLE_REFACTORED.txt`
- Validator: `Validator_Prompt_A8C_EXAMPLE_REFACTORED.txt`
- Proposed shared Standard target reference: `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_KnowledgeArea_A8C_PROPOSED.txt`
- Proposed shared MultiInput target reference: `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_MultInpComb-KnowledgeArea_A8C_PROPOSED.txt`
- Regression/adversarial harness: `A8C_REGRESSION_ADVERSARIAL_CHECK.py`

A8B prompts remain preserved as immutable pre-refactor baseline and historical evidence.

## 2. A8C stage results

| Stage | Result | Evidence |
|---|---|---|
| A8C-0 baseline freeze | PASS | immutable A8B copies + SHA-256 + baseline metrics + A8B fixture PASS |
| A8C-1 shared examples | PASS locally | shared Generator/Validator-only target references; no Author-only semantics |
| A8C-2 retrieval contract | PASS statically | explicit exactly-once retrieval, freeze, authority precedence, no memory fallback |
| A8C-3 Generator compression | PASS | hard boundaries retained; deterministic mapping prose compressed |
| A8C-4 Validator compression | PASS | independent reference compile retained; Candidate never authority |
| A8C-5 Author compression | PASS | only §6 materialization prose compressed; §6.8 grammar/casting semantics retained |
| A8C-6 anchoring/adversarial suite | PASS | T1–T10 = 10/10 |
| A8C-7 context/regression | PASS | A8B fixtures preserved; prompt and incremental target context reduced |
| A8C-8 promotion | PASS locally | new prompt authorities promoted; deployed KA/A9 explicitly not claimed |

## 3. Prompt metrics

| Agent | A8B words | A8C words | Delta | Delta % |
|---|---:|---:|---:|---:|
| Scenario Author | 12,696 | 12,065 | -631 | -5.0% |
| UnitTestGenerator | 4,460 | 3,857 | -603 | -13.5% |
| UnitTestValidator | 3,361 | 2,523 | -838 | -24.9% |
| **Total** | **20,517** | **18,445** | **-2,072** | **-10.1%** |

The exact count differs slightly from the planning estimate because the A8C-0 recount used current file tokenization rather than the earlier planning count. The frozen snapshot is authoritative for comparison.

## 4. Shared reference size and TOTAL_TARGET_CONTEXT delta

Proposed A8C additions:
- Standard shared reference: 575 words.
- MultiInput shared reference: 420 words.

Schemas and JsonExamples are unchanged by A8C. The existing deployed KnowledgeArea body was unavailable, so absolute runtime `TOTAL_TARGET_CONTEXT` cannot be measured. The valid local metric is the incremental delta relative to the same pre-existing deployed KnowledgeArea content:

| Mode | Agent | Prompt delta | A8C KA addition | Net target-context delta |
|---|---|---:|---:|---:|
| Standard | Generator | -603 | +575 | **-28** |
| Standard | Validator | -838 | +575 | **-263** |
| MultiInput | Generator | -603 | +420 | **-183** |
| MultiInput | Validator | -838 | +420 | **-418** |

Therefore A8C does not create the anti-pattern of making the system prompt shorter while increasing equivalent target-contract context.

## 5. Hard-boundary preservation

Static checks require and confirmed:

### Author
- `CAST` evidence contract remains;
- Pega Data Casting Matrix rule codes remain;
- §6.8 remains the sole closed Projection grammar;
- Projection persistence contract remains.

### Generator
- exactly-once KnowledgeTool target retrieval and freeze;
- no fallback to model memory/Candidate;
- Projection semantic immutability;
- no Pega casting or lexical normalization;
- impossible vs ambiguous representability classification;
- CM-NAME-001 sole naming owner;
- G7 before every Candidate write;
- WriteMemory create-only and UpdateMemory lifecycle-only contracts retained.

### Validator
- JsonValidationTool gate retained;
- exact Projection/Candidate GUID reads and group correlation retained;
- independent exactly-once target retrieval retained;
- Candidate never target authority;
- no Pega semantic recast/normalization;
- synchronized fidelity issue/action classes retained.

No full canonical Candidate fixture is duplicated into Generator or Validator system prompts.

## 6. Shared-example eligibility

Only Generator+Validator shared target knowledge was moved into the proposed KnowledgeArea additions.

Included:
- typed lexical serialization contrast;
- one-source-assertion -> one-target-block demonstration;
- primary context demonstration;
- naming variability;
- impossible-vs-ambiguous representability;
- ordered When inputs/result;
- row/input order contrast;
- absent-vs-empty input presence.

Excluded:
- Data Casting Matrix derivation examples;
- CAST evidence derivation;
- DWL/RuleCrawler;
- Scenario Compiler;
- ASSERT/SIM/OMIT/GAP semantics;
- Generator lifecycle examples;
- Validator-only routing examples.

Every example is explicitly subordinate to system behavior + Projection + schema/mappings/invariants.

## 7. Adversarial / anti-anchoring evidence

`A8C_REGRESSION_ADVERSARIAL_CHECK.py` passes T1–T10:

1. unseen `G731` naming;
2. Text lexical `0012.500` remains Text/quoted;
3. unseen Decimal lexical `98.7600` preserves exact spelling;
4. absent vs present-empty remains distinct;
5. unfamiliar explicit primary page becomes first page/class context;
6. unseen Property/Page/Param assertion permutation preserves order and one-block-per-source;
7. unseen When paths/types/order preserves exact cells and lexical values;
8. target-impossible `singlePage=true` under MultiInput const=false -> semantic rejection;
9. non-unique target authority -> human review rather than guessing;
10. unseen Candidate assertion-order mutation is detected by independent reference comparison.

Result: **10/10 PASS**.

This suite deliberately uses literals and structures not present in canonical examples, which is the primary static protection against example anchoring.

## 8. A8B regression preservation

`A8B_CANONICAL_FIXTURE_CHECK.py` remains PASS:
- Standard paired fixture unchanged;
- When paired fixture unchanged;
- Candidate == Compile(Projection);
- JsonExample == canonical Candidate;
- Candidate validates against Stage-3 schema;
- all `pyExpectedValue` are JSON strings;
- CM-NAME-001 / CF-PRIMARY-001 checks pass.

A8B baseline files are byte-identical to the frozen A8C-0 copies.

## 9. Deployment boundary

The two A8C KnowledgeArea files are **proposed deployable additions/reference content**, not evidence that the live Pega KnowledgeTool currently returns them.

Before runtime A9, A4 must verify that the deployed Standard and MultiInput KnowledgeAreas expose the A8C shared deterministic mapping/reference examples (or an explicitly accepted semantically identical revision) to both Generator and Validator under the exact keys used by their prompts.

Until then A8C is the promoted **static/design contract baseline**, not a deployed/runtime-validated baseline.
