#!/usr/bin/env python3
import json,re,sys
from pathlib import Path
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
F=ROOT/'04_TARGET_CONTRACTS/fixtures'

def load(p): return json.loads(Path(p).read_text())
def q(s): return json.dumps(s,ensure_ascii=False)
def name(rut,label,g):
    r=''.join(c for c in rut if c not in ' \t\r\n\f\v'); r=re.sub(r'[^A-Za-z0-9_]+','_',r); r=re.sub(r'_+','_',r).strip('_')
    l=re.sub(r'[ _]+','_',label).strip('_')[:32].rstrip('_'); a=44-len(l); rb=r[:a].rstrip('_')
    return f'TC_{rb}_{l}_{g}'
def sc(x): return {'Status':'New','Name':x['name'],'ReasoningConfidence':x['confidence'],'Testability':x['testability'],'EvidenceSummary':{'ReasoningTrace':x['reasoningTrace'],'DependencyClosureStatus':x['dependencyClosureStatus'],'DependencyClosureTrace':x['dependencyClosureTrace']}}
def pmap(s):
    p=s['primary'].get('page','RunRecordPrimaryPage'); out=[{'pyPagesAndClassesPage':p,'pyPagesAndClassesClass':s['primary']['class']}]
    out += [{'pyPagesAndClassesPage':n,'pyPagesAndClassesClass':c} for n,c in s.get('pages',{}).items()]; return out
def pcl(s,p): return s['primary']['class'] if p==s['primary'].get('page','RunRecordPrimaryPage') else s.get('pages',{}).get(p)
def leaf(p): return p.split('.')[-1]
def smp(t,v,nam):
    o={'pyParametersParamName':nam,'pyParametersParamType':'PAGE' if t=='Page' else t}
    if v is None:return o
    if t=='Page': o['pyParametersParamValue']=v
    elif t in {'Text','Date','DateTime','TimeOfDay'}: o['pyParametersParamValue']=q(v)
    elif t in {'Integer','Decimal','Double','TrueFalse'}: o['pyParametersParamValue']=v
    else: raise AssertionError(t)
    return o
def sae(m,v):
    if m in {'Text','String','Identifier','Password','TextEncrypted','Date','DateTime','TimeOfDay'}: return q(v)
    if m in {'Integer','Decimal','Double','TrueFalse'}: return v
    raise AssertionError(m)
def base(s,rs,rsv,rt):
    n=name(s['rut']['name'],s['testLabel'],s['physicalGroupKey']); rc={'pyLabel':n,'pyRuleSet':rs,'pyClassName':s['primary']['class'],'pyPurpose':n,'pyRuleSetVersion':rsv}
    if 'page' in s['primary']:rc['pyPrimaryPageForRUT']=s['primary']['page']
    rut={'pyDetails':{'pyRuleUnderTestInsName':s['rut']['applyToClass'].upper()+'!'+s['rut']['name'].upper(),'pyIsSinglePageImplementation':str(s['rut']['singlePage']).lower(),'pyRuleUnderTestName':s['rut']['name'],'pyRuleUnderTestObjClass':s['rut']['applyToClass'],'pyRuleUnderTestType':rt}}
    if s.get('parameters'):rut['pyParameters']=[smp(p['formalType'],p.get('value'),p['name']) for p in s['parameters']]
    rc['pyRuleUnderTest']=rut; rc['pyPagesAndClasses']=pmap(s)
    return {'UnitTestRules':[{'Name':n,'Scenarios':[sc(x) for x in s['scenarios']],'RuleCode':rc}]}
def comp_std(s,rs,rsv):
    c=base(s,rs,rsv,'Rule-Obj-Model'); rc=c['UnitTestRules'][0]['RuleCode']; pp=s['primary'].get('page','RunRecordPrimaryPage'); bs=[]
    for a in s['assertions']:
        k=a['kind']
        if k=='Property':
            p=a.get('page',pp); ch={'pyComparator':a['comparator'],'pyPropertyName':leaf(a['path']),'pyPropertyAbsolutePath':a['path'],'pyPropertyMode':a['mode']}
            if 'expected' in a:ch['pyExpectedValue']=sae(a['mode'],a['expected'])
            if 'applyToClass' in a:ch['pyPropertyApplyToClass']=a['applyToClass']
            if 'parentMode' in a:ch['pyParentPropertyMode']=a['parentMode']
            bs.append({'pyAssertionType':'Property','pyStepPageClass':pcl(s,p),'pyStepPageName':p,'pyExpectedResults':[ch]})
        elif k=='Param':
            ch={'pyComparator':a['comparator'],'pyPropertyName':a['path'],'pyPropertyAbsolutePath':a['path'],'pyPropertyMode':'Text','pyAssertionType':'Property'}
            if 'expected' in a:ch['pyExpectedValue']=q(a['expected'])
            bs.append({'pyAssertionType':'Property','pyStepPageClass':s['primary']['class'],'pyStepPageName':pp,'pyExpectedResults':[ch]})
        elif k=='Page':
            p=a.get('page',pp); cs=[]
            for i in a['items']:
                z={'pyComparator':i['comparator'],'pyPropertyAbsolutePath':i['path'],'pyPropertyMode':i['mode']}
                if 'expected' in i:z['pyExpectedValue']=sae(i['mode'],i['expected'])
                cs.append(z)
            bs.append({'pyAssertionType':'Page','pyStepPageName':p,'pyExpectedResults':cs})
        elif k=='List':
            p=a.get('page',pp); cs=[]
            for i in a['items']:
                z={'pyComparator':i['comparator'],'pyPropertyName':leaf(i['path']),'pyPropertyAbsolutePath':i['path'],'pyPropertyMode':i['mode']}
                if 'expected' in i:z['pyExpectedValue']=sae(i['mode'],i['expected'])
                if 'applyToClass' in i:z['pyPropertyApplyToClass']=i['applyToClass']
                if 'parentMode' in i:z['pyParentPropertyMode']=i['parentMode']
                cs.append(z)
            b={'pyAssertionType':'List','pyStepPageClass':pcl(s,p),'pyStepPageName':p,'pyListContext':a['list'],'pyExpectedResults':cs}
            if 'filter' in a:b['pyListFilter']=a['filter']
            if 'appearance' in a:b['pyNumberOfAppearances']=a['appearance']
            bs.append(b)
        elif k=='ResultCount':
            b={'pyAssertionType':'ResultCount','pyListContext':a['list'],'pyComparator':a['comparator'],'pyExpectedValue':str(a['expected'])}
            if 'filter' in a:b['pyListFilter']=a['filter']
            bs.append(b)
        else: raise AssertionError(k)
    rc['pyExpectedResults']=bs; return c
def comp_when(s,rs,rsv):
    c=base(s,rs,rsv,'Rule-Obj-When'); rows=[]
    for r in s['rows']:
        cs=[]
        for i in r['inputs']:
            z={'pyPropertyType':'input','pyPropertyName':i['path'],'pyPropertyAbsolutePath':i['path'],'pyPropertyMode':'text','pyDisplayLabel':i['path']}
            if 'value' in i:z['pyExpectedValue']=i['value']
            cs.append(z)
        cs.append({'pyPropertyType':'result','pyPropertyName':'Result','pyPropertyAbsolutePath':'Result','pyPropertyMode':'text','pyExpectedValue':'true' if r['result'] else 'false','pyDisplayLabel':'Result'})
        rows.append({'pyPageName':'rowLevelPage','pyExpectedResults':cs})
    c['UnitTestRules'][0]['RuleCode']['pyExpectedResults']=[{'pyAllowMultipleInputCombinations':'true','pyAssertionType':'Decision','pyClassContext':s['rut']['applyToClass'],'pyPropertyType':'Decision Result','pyExpectedResults':rows}]
    return c

def all_expected_strings(x,path='$'):
    bad=[]
    if isinstance(x,dict):
        for k,v in x.items():
            p=path+'.'+k
            if k=='pyExpectedValue' and not isinstance(v,str):bad.append((p,type(v).__name__,v))
            bad += all_expected_strings(v,p)
    elif isinstance(x,list):
        for i,v in enumerate(x):bad += all_expected_strings(v,f'{path}[{i}]')
    return bad

def closed_fixture_shape(p,mode):
    # Focused machine check of the closed v3 fields exercised by these canonical fixtures.
    assert set(p) <= ({'testLabel','physicalGroupKey','rut','primary','pages','parameters','assertions','rows','scenarios'})
    assert re.fullmatch(r'G\d{3}',p['physicalGroupKey']); assert p['testLabel']==p['scenarios'][0]['name']
    assert set(p['rut'])=={'name','applyToClass','singlePage'}; assert set(p['primary'])<= {'class','page'}
    assert p['scenarios'] and all(set(x)=={'name','confidence','testability','reasoningTrace','dependencyClosureStatus','dependencyClosureTrace'} for x in p['scenarios'])
    if mode=='standard': assert p.get('assertions') and 'rows' not in p and len(p['scenarios'])==1
    else: assert p.get('rows') and 'assertions' not in p and len(p['rows'])==len(p['scenarios'])

checks=[]
for mode,schema_f,proj_f,cand_f,example_f,rs in [
 ('standard',ROOT/'04_TARGET_CONTRACTS/rule-test-unit-case_JsonSchema_STAGE3.txt',F/'standard_projection.json',F/'standard_candidate.json',ROOT/'04_TARGET_CONTRACTS/rule-test-unit-case_JsonExample(5).txt','3010067594@'),
 ('when',ROOT/'04_TARGET_CONTRACTS/rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt',F/'when_projection.json',F/'when_candidate.json',ROOT/'04_TARGET_CONTRACTS/rule-test-unit-case_multInpComb-JsonExample(6).txt','SampleTestRules')]:
    sch,proj,cand,ex=map(load,[schema_f,proj_f,cand_f,example_f]); closed_fixture_shape(proj,mode)
    actual=comp_std(proj,rs,'01-01-01') if mode=='standard' else comp_when(proj,rs,'01-01-01')
    assert actual==cand, f'{mode}: Candidate != Compile(Projection)'
    assert ex==cand, f'{mode}: JsonExample != canonical candidate fixture'
    errs=list(Draft202012Validator(sch).iter_errors(cand)); assert not errs, f'{mode}: schema errors: {[e.message for e in errs]}'
    assert not all_expected_strings(cand), f'{mode}: non-string pyExpectedValue: {all_expected_strings(cand)}'
    u=cand['UnitTestRules'][0]; assert u['Name']==u['RuleCode']['pyPurpose']==u['RuleCode']['pyLabel']==name(proj['rut']['name'],proj['testLabel'],proj['physicalGroupKey'])
    pm=u['RuleCode']['pyPagesAndClasses'][0]; assert pm['pyPagesAndClassesPage']==proj['primary'].get('page','RunRecordPrimaryPage') and pm['pyPagesAndClassesClass']==proj['primary']['class']
    checks.append(mode)
# Schema-level target typing checks.
for sf in [ROOT/'04_TARGET_CONTRACTS/rule-test-unit-case_JsonSchema_STAGE3.txt',ROOT/'04_TARGET_CONTRACTS/rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt']:
    s=load(sf); assert s['$defs']['ExpectedValue'].get('type')=='string'
    for k in ['pyIsInactive','pyCleanUpTestData']:
        assert s['$defs']['RuleCode']['properties'][k].get('type')=='string'
print('A8B_CANONICAL_FIXTURE_CHECK: PASS')
print('paired fixtures:', ', '.join(checks))
print('invariants: Projection fixture closed-shape subset; Candidate == Compile(Projection); JsonExample == Candidate; Candidate ⊨ Stage-3 schema; all pyExpectedValue are strings; CM-NAME-001 and CF-PRIMARY-001 hold')
