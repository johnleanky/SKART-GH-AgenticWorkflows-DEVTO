#!/usr/bin/env python3
import copy, hashlib, importlib.util, json, re, subprocess, sys
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT=Path(__file__).resolve().parents[1]
CUR=ROOT/'01_CURRENT_WORK'
BASE=ROOT/'05_HISTORICAL_REFERENCE/A8C_BASELINE'
TC=ROOT/'04_TARGET_CONTRACTS'
KA=TC/'a8c_shared_reference'

# 0. Frozen A8B regression and immutable baseline originals.
subprocess.run([sys.executable, str(CUR/'A8B_CANONICAL_FIXTURE_CHECK.py')], check=True)

pairs=[
 ('Main_Agent_Prompt_A8_CAST_LEXICAL_REPAIRED.txt','Main_Agent_Prompt_A8_CAST_LEXICAL_REPAIRED.txt'),
 ('UnitTestGenerator_Prompt_A8B_TARGET_ALIGNMENT_REPAIRED.txt','UnitTestGenerator_Prompt_A8B_TARGET_ALIGNMENT_REPAIRED.txt'),
 ('Validator_Prompt_A8B_TARGET_ALIGNMENT_REPAIRED.txt','Validator_Prompt_A8B_TARGET_ALIGNMENT_REPAIRED.txt'),
]
for cur,base in pairs:
    assert (CUR/cur).read_bytes()==(BASE/base).read_bytes(), f'A8B baseline changed: {cur}'

# Load the frozen A8B reference compiler functions.
spec=importlib.util.spec_from_file_location('a8b', CUR/'A8B_CANONICAL_FIXTURE_CHECK.py')
a8b=importlib.util.module_from_spec(spec); spec.loader.exec_module(a8b)

# 1. Shared KnowledgeArea proposal hygiene.
std=(KA/'Rule-Test-Unit-Case_KnowledgeArea_A8C_PROPOSED.txt').read_text()
whn=(KA/'Rule-Test-Unit-Case_MultInpComb-KnowledgeArea_A8C_PROPOSED.txt').read_text()
for ex in [f'EX-STD-{i:02d}' for i in range(1,6)]:
    assert ex in std, f'missing {ex}'
for ex in [f'EX-WHEN-{i:02d}' for i in range(1,4)]:
    assert ex in whn, f'missing {ex}'
for txt in (std,whn):
    assert 'Consumers:** UnitTestGenerator and UnitTestValidator' in txt
    assert 'never authorize semantic inference, Pega casting, lexical normalization' in txt
    for forbidden in ['CAST|scenario=', 'RuleCrawler', 'DWL/', 'ASSERT/SIM/OMIT/GAP']:
        assert forbidden not in txt, f'Author-only material leaked to shared KA: {forbidden}'
    assert 'Authority demonstrated:' in txt

# 2. Static system-prompt critical-boundary checks.
author=(CUR/'Main_Agent_Prompt_A8C_EXAMPLE_REFACTORED.txt').read_text()
gen=(CUR/'UnitTestGenerator_Prompt_A8C_EXAMPLE_REFACTORED.txt').read_text()
val=(CUR/'Validator_Prompt_A8C_EXAMPLE_REFACTORED.txt').read_text()

for s in ['CAST|scenario=', 'matrix=<I|X|C|S|D|N|V plus notes>', '§6.8` is the sole closed grammar',
          'WriteMemory(pxCaseID=<exact pyID>,Type="UnitTestProjectionV3"']:
    assert s in author, f'Author hard invariant missing: {s}'

for s in ['KnowledgeTool **exactly once**', 'model memory', 'Pega casting', 'lexical normalization',
          'Projection modification', 'CM-NAME-001', 'G7', 'WriteMemory', 'UpdateMemory',
          'Failed/SEMANTIC_REJECTED', 'Failed/HUMAN_REVIEW_REQUIRED']:
    assert s in gen, f'Generator hard invariant missing: {s}'
assert '"UnitTestRules": [' not in gen, 'Full candidate fixture duplicated into Generator prompt'

for s in ['JsonValidationTool', 'GetMemory(pxCaseID=<CaseID>,Type="UnitTestProjectionV3"',
          'GetMemory(pxCaseID=<CaseID>,Type="UnitTestCandidate"', 'KnowledgeTool exactly once',
          'Candidate is never target authority', 'Pega coercion', 'AMBIGUOUS/HUMAN_REVIEW']:
    assert s in val, f'Validator hard invariant missing: {s}'
for code in ['PF_RUT_CONTEXT_MISMATCH','PF_PARAMETER_MISMATCH','PF_SETUP_ACTION_MISMATCH',
             'PF_SIMULATION_MISMATCH','PF_ASSERTION_MISMATCH','PF_WHEN_ROW_MISMATCH',
             'PF_SOURCE_TARGET_CONFLICT']:
    assert code in val, f'Validator diagnostic missing: {code}'
assert '"UnitTestRules": [' not in val, 'Full candidate fixture duplicated into Validator prompt'

# Helpers.
def scenario(name='Case X'):
    return {'name':name,'confidence':'High','testability':'FullyTestable',
            'reasoningTrace':'Adversarial fixture.',
            'dependencyClosureStatus':'Closed',
            'dependencyClosureTrace':'Closed for adversarial static validation.'}

def rep(possible, unique):
    if not possible: return 'SEMANTIC_REJECTED'
    if not unique: return 'HUMAN_REVIEW_REQUIRED'
    return 'CONTINUE'

# T1 unseen group key.
assert a8b.name('Rate Check','Unexpected Branch','G731')=='TC_RateCheck_Unexpected_Branch_G731'

# T2 unseen Text content resembling a number.
t=a8b.sae('Text','0012.500')
assert t=='"0012.500"', repr(t)

# T3 unseen Decimal lexical form preserved exactly.
assert a8b.sae('Decimal','98.7600')=='98.7600'

# T4 absent vs present-empty.
absent=a8b.smp('Text',None,'Code')
empty=a8b.smp('Text','','Code')
assert 'pyParametersParamValue' not in absent
assert empty['pyParametersParamValue']=='""'
base_when={
 'testLabel':'Absent Empty','physicalGroupKey':'G731',
 'rut':{'name':'UnseenGate','applyToClass':'Acme-Data-Case','singlePage':False},
 'primary':{'class':'Acme-Data-Case'},
 'rows':[
  {'inputs':[{'path':'.OptionalCode','valueType':'Text'}],'result':True},
  {'inputs':[{'path':'.OptionalCode','valueType':'Text','value':''}],'result':False},
 ],
 'scenarios':[scenario('Absent Value'),scenario('Empty Value')]
}
cw=a8b.comp_when(base_when,'TmpRules','01-01-01')
rows=cw['UnitTestRules'][0]['RuleCode']['pyExpectedResults'][0]['pyExpectedResults']
assert 'pyExpectedValue' not in rows[0]['pyExpectedResults'][0]
assert rows[1]['pyExpectedResults'][0]['pyExpectedValue']==''

# T5 unfamiliar explicit primary page.
std_proj={
 'testLabel':'Primary Variant','physicalGroupKey':'G731',
 'rut':{'name':'ContextProbe','applyToClass':'Acme-Data-Base','singlePage':False},
 'primary':{'class':'Acme-Work-Order','page':'ZebraContext'},
 'pages':{'AuxPage':'Acme-Data-Aux'},
 'assertions':[{'kind':'Property','path':'.Flag','comparator':'Is Equals To','expected':'Y','mode':'Text'}],
 'scenarios':[scenario('Primary Variant')]
}
cs=a8b.comp_std(std_proj,'TmpRules','01-01-01')
rc=cs['UnitTestRules'][0]['RuleCode']
assert rc['pyPrimaryPageForRUT']=='ZebraContext'
assert rc['pyPagesAndClasses'][0]=={'pyPagesAndClassesPage':'ZebraContext','pyPagesAndClassesClass':'Acme-Work-Order'}

# T6 unfamiliar assertion sequence; preserve exact block order and one source -> one block.
seq_proj=copy.deepcopy(std_proj)
seq_proj['testLabel']='Order Permutation'; seq_proj['scenarios']=[scenario('Order Permutation')]
seq_proj['assertions']=[
 {'kind':'Property','path':'.Alpha','comparator':'Is Equals To','expected':'A','mode':'Text'},
 {'kind':'Page','items':[{'path':'.Beta','comparator':'Is Equals To','expected':'false','mode':'TrueFalse'}]},
 {'kind':'Param','path':'Param.Gamma','comparator':'Is Equals To','expected':'009'},
]
seq=a8b.comp_std(seq_proj,'TmpRules','01-01-01')
blocks=seq['UnitTestRules'][0]['RuleCode']['pyExpectedResults']
assert [b['pyAssertionType'] for b in blocks]==['Property','Page','Property']
assert len(blocks)==3 and all(len(b.get('pyExpectedResults',[]))==1 for b in blocks)

# T7 unseen When paths/types/order.
when_proj={
 'testLabel':'Novel Row','physicalGroupKey':'G731',
 'rut':{'name':'EligibilityGate','applyToClass':'Acme-Data-Eligibility','singlePage':False},
 'primary':{'class':'Acme-Data-Eligibility'},
 'rows':[{'inputs':[
   {'path':'.Priority','valueType':'Integer','value':'007'},
   {'path':'.RequestedLimit','valueType':'Decimal','value':'1000.50'},
   {'path':'Param.Channel','valueType':'Text','value':'API'},
 ],'result':True}],
 'scenarios':[scenario('Novel Row')]
}
wc=a8b.comp_when(when_proj,'TmpRules','01-01-01')
cells=wc['UnitTestRules'][0]['RuleCode']['pyExpectedResults'][0]['pyExpectedResults'][0]['pyExpectedResults']
assert [c['pyPropertyName'] for c in cells]==['.Priority','.RequestedLimit','Param.Channel','Result']
assert [c['pyExpectedValue'] for c in cells]==['007','1000.50','API','true']

# T8 impossible source->target not copied from EX-STD-05: When singlePage=true vs schema const false.
ms=json.loads((TC/'rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt').read_text())
const=ms['$defs']['RuleUnderTestDetails']['properties']['pyIsSinglePageImplementation']['const']
assert const=='false'
assert rep(possible=not (True and const=='false'), unique=True)=='SEMANTIC_REJECTED'

# T9 abstract target ambiguity -> HUMAN, never semantic repair/guess.
assert rep(possible=True, unique=False)=='HUMAN_REVIEW_REQUIRED'

# T10 mutation not shown by examples: swap two independently compiled assertion blocks.
expected=a8b.comp_std(seq_proj,'TmpRules','01-01-01')
mut=copy.deepcopy(expected)
mblocks=mut['UnitTestRules'][0]['RuleCode']['pyExpectedResults']
mblocks[0],mblocks[1]=mblocks[1],mblocks[0]
assert mut != expected
assert [b['pyAssertionType'] for b in mut['UnitTestRules'][0]['RuleCode']['pyExpectedResults']] != [b['pyAssertionType'] for b in expected['UnitTestRules'][0]['RuleCode']['pyExpectedResults']]
detected_issue='PF_ASSERTION_MISMATCH' if mut!=expected else None
assert detected_issue=='PF_ASSERTION_MISMATCH'

# Baseline schemas/examples remain unchanged and canonical fixtures still validate.
for schema_f,cand_f in [
 (TC/'rule-test-unit-case_JsonSchema_STAGE3.txt',TC/'fixtures/standard_candidate.json'),
 (TC/'rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt',TC/'fixtures/when_candidate.json')]:
    sch=json.loads(schema_f.read_text()); cand=json.loads(cand_f.read_text())
    assert not list(Draft202012Validator(sch).iter_errors(cand))

print('A8C_REGRESSION_ADVERSARIAL_CHECK: PASS')
print('A8B baseline unchanged; shared-reference hygiene PASS; static hard-boundary checks PASS')
print('T1-T10 adversarial/anti-anchoring suite: 10/10 PASS')
