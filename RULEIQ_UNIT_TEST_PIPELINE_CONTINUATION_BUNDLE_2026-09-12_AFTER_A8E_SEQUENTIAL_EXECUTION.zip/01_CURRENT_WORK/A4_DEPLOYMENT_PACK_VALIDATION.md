# A4 Deployment Pack Validation

**Status:** STATIC PREPARATION COMPLETE — LIVE PEGA CAPTURE REQUIRED  
**Date:** 2026-09-12  
**Runtime boundary:** no Pega KnowledgeTool response from the deployed environment was available; A4 is not PASS and A9 was not run.

## What was added

- `A4_DEPLOYMENT_EXPECTED_CONTRACT.json` — exact keys, local target authorities and closure rules without any runtime claim.
- `A4_LIVE_CAPTURE_TEMPLATE.json` — capture envelope for independent Generator and Validator retrievals in Standard and MultiInput modes.
- `A4_DEPLOYMENT_VERIFIER.py` — deterministic deployment-binding verifier.
- `A4_LOCAL_SELFTEST_REPORT.txt` / `.json` — verifier self-test against the local bundle.

## Verifier checks

The verifier requires independent Generator and Validator captures and checks:

1. all six executable target areas exist for each consumer;
2. Generator and Validator retrieved the same generation for the same mode/key;
3. each deployed schema matches the promoted Stage-3 logical JSON for direct PASS;
4. required `CM-*` / `CF-*` compiler invariants are present;
5. `pyParametersParamType` exposes exactly the accepted target set;
6. physical method parameter values and assertion expected values resolve to JSON string;
7. the deployed Standard/MultiInput KnowledgeAreas contain the A8C shared reference/examples and the no-casting/no-normalization boundary;
8. each JsonExample matches the promoted canonical fixture except operational `pyRuleSet` / `pyRuleSetVersion`;
9. Standard and MultiInput expose the same operational ruleset/version.

A materially different schema/KnowledgeArea/example revision produces `REVIEW` when it can still be recognized as plausible; it is not silently accepted as PASS.

## Self-test result

The verifier was executed against a local capture constructed from the bundled authorities. All target-generation, schema, shared-reference and Generator/Validator-equality checks passed. The overall result was intentionally **FAIL** because the bundled demo JsonExamples expose different operational targets:

- Standard: `3010067594@ / 01-01-01`
- MultiInput: `SampleTestRules / 01-01-01`

This confirms that local files cannot accidentally satisfy A4.

A synthetic self-test with the MultiInput operational target aligned to the Standard target produced **OVERALL=PASS**. This validates the verifier logic only; it is not deployment evidence and the synthetic capture is not retained as project evidence.

## Exact live procedure

When a live Pega KnowledgeTool interface is available:

1. independently capture Generator Standard batch;
2. independently capture Validator Standard batch;
3. independently capture Generator MultiInput batch;
4. independently capture Validator MultiInput batch;
5. place the exact returned area contents into `A4_LIVE_CAPTURE_TEMPLATE.json`;
6. run:

```text
python A4_DEPLOYMENT_VERIFIER.py A4_LIVE_CAPTURE.json --json-report A4_LIVE_REPORT.json
```

Only `OVERALL=PASS` closes A4 automatically. `REVIEW` requires an explicit project decision accepting the deployed revision as semantically equivalent. `FAIL` blocks A9.

## Environment availability check

No Pega / Infinity Authoring plugin was discoverable from the integrations available in this session, including an explicit plugin search. Therefore the live capture could not be produced here.
