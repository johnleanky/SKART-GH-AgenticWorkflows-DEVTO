#!/usr/bin/env python3
from pathlib import Path
import copy

ROOT=Path(__file__).resolve().parents[1]
CUR=ROOT/'01_CURRENT_WORK'

AUTHOR=CUR/'Main_Agent_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt'
GEN=CUR/'UnitTestGenerator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt'
VAL=CUR/'Validator_Prompt_A8D_SINGLE_RECORD_MEMORY_REFACTORED.txt'
CONTRACT=CUR/'A8D_SINGLE_RECORD_MEMORY_CONTRACT.md'


def validate(author:str, gen:str, val:str, contract:str):
    e=[]
    def req(txt,needle,label):
        if needle not in txt: e.append(f'MISSING:{label}')
    def forbid(txt,needle,label):
        if needle in txt: e.append(f'FORBIDDEN:{label}')

    # Contract signatures and cardinality.
    req(contract,'WriteMemory(\n  pxCaseID,\n  Type,\n  pyGroup,\n  pyPayload','contract WriteMemory signature')
    req(contract,'GetMemory(\n  pxCaseID,\n  pyGUID','contract GetMemory signature')
    req(contract,'UpdateMemory(\n  pxCaseID,\n  pyGUID,\n  pyStatusValue,\n  pyRouterKey','contract UpdateMemory signature')
    req(contract,'exactly one Memory record per tool invocation','contract single-record cardinality')
    for code in ['NOT_FOUND','WRITE_FAILED','UPDATE_FAILED']:
        req(contract,code,f'contract error {code}')

    # Author: one create per Projection, all writes before any Generator.
    req(author,'`WriteMemory(pxCaseID,Type,pyGroup,pyPayload)` once per fully materialized Projection','Author single-record WriteMemory allowlist')
    req(author,'persist Projections one record at a time in Author group order','Author write loop')
    req(author,'Require every WriteMemory call to succeed before invoking any Generator','Author all-writes-before-Generator gate')
    req(author,'Only after all Projection writes succeed, invoke Generator sequentially','Author Generator sequencing')
    req(author,'WRITE_FAILED','Author write failure handling')
    req(author,'Earlier successfully created Projection records remain immutable if a later Projection write fails.','Author partial-prefix immutability')
    forbid(author,'WriteMemory(pxCaseID,Type,RequestsJSON)','Author old WriteMemory signature')
    forbid(author,'RequestsJSON is exactly','Author RequestsJSON carrier')
    forbid(author,'Persist all projections in one immutable batch','Author batch persistence')
    # Legitimate non-Memory KnowledgeTool pxResults must survive.
    req(author,'Parse `response.pxResults` as an array.','KnowledgeTool pxResults preserved')

    # Generator: exact read, create, update.
    req(gen,'`GetMemory(pxCaseID,pyGUID)` — exact single-record source read;','Generator GetMemory signature')
    req(gen,'`WriteMemory(pxCaseID,Type,pyGroup,pyPayload)` — create-only single-record immutable Candidate persistence;','Generator WriteMemory signature')
    req(gen,'`UpdateMemory(pxCaseID,pyGUID,pyStatusValue,pyRouterKey)` — exact single-record Candidate lifecycle update only;','Generator UpdateMemory signature')
    req(gen,'exact `pyType="UnitTestProjectionV3"`','Generator source type check')
    req(gen,'`WRITE_FAILED`','Generator write tool error')
    req(gen,'`UPDATE_FAILED`','Generator update tool error')
    req(gen,'`NOT_FOUND`','Generator not-found handling')
    req(gen,'→ `CANDIDATE_WRITE_FAILED`','Generator write failure terminal')
    req(gen,'→ `LIFECYCLE_UPDATE_FAILED`','Generator update failure terminal')
    req(gen,'new WriteMemory → new GUID','Generator repair new-record rule')
    req(gen,'no separate persisted `Pending` lifecycle update','Generator no Pending update')
    for bad,label in [
        ('RequestsJSON','Generator RequestsJSON'),('ResultsJSON','Generator ResultsJSON'),
        ('pyUpdates','Generator pyUpdates'),('{"pxResults":[','Generator Memory pxResults carrier'),
        ('GetMemory(pxCaseID,Type,pyGUID)','Generator old GetMemory signature'),
        ('UpdateMemory(pxCaseID,Type,RequestsJSON)','Generator old UpdateMemory signature')]:
        forbid(gen,bad,label)

    # Validator: two exact single reads with returned type checks.
    req(val,'`GetMemory(pxCaseID,pyGUID)` exactly twice','Validator GetMemory allowlist')
    req(val,'`GetMemory(pxCaseID=<CaseID>,pyGUID=<UnitTestProjectionUUID>)`','Validator Projection read')
    req(val,'`GetMemory(pxCaseID=<CaseID>,pyGUID=<UnitTestCandidateUUID>)`','Validator Candidate read')
    req(val,'exact `pyType="UnitTestProjectionV3"`','Validator Projection type check')
    req(val,'exact `pyType="UnitTestCandidate"`','Validator Candidate type check')
    req(val,'`NOT_FOUND`','Validator not-found handling')
    req(val,'ProjectionMemory.pyGroup == CandidateMemory.pyGroup','Validator group correlation')
    req(val,'Candidate is never target authority','Validator independence')
    for bad,label in [
        ('GetMemory(pxCaseID,Type,pyGUID)','Validator old GetMemory signature'),
        ('GetMemory(pxCaseID=<CaseID>,Type=','Validator Type lookup input'),
        ('substitute another row','Validator row/list semantics')]:
        forbid(val,bad,label)
    return e


def run_current():
    a=AUTHOR.read_text(); g=GEN.read_text(); v=VAL.read_text(); c=CONTRACT.read_text()
    errs=validate(a,g,v,c)
    if errs:
        raise AssertionError('CURRENT FAIL:\n'+'\n'.join(errs))
    return a,g,v,c


def must_fail(name,a,g,v,c,expected_fragment):
    errs=validate(a,g,v,c)
    if not errs:
        raise AssertionError(f'{name}: mutation unexpectedly passed')
    if not any(expected_fragment in x for x in errs):
        raise AssertionError(f'{name}: wrong failure set {errs}')
    return errs


def run_negative(a,g,v,c):
    results=[]
    # N1 RequestsJSON reintroduced into WriteMemory.
    gm=g+'\n`WriteMemory(pxCaseID,Type,RequestsJSON)`\n'
    results.append(('N1',must_fail('N1',a,gm,v,c,'RequestsJSON')))
    # N2 Memory pxResults carrier reintroduced.
    gm=g+'\n{"pxResults":[{"pyGroup":"G001"}]}\n'
    results.append(('N2',must_fail('N2',a,gm,v,c,'Memory pxResults carrier')))
    # N3 Type reintroduced as GetMemory lookup input.
    gm=g.replace('`GetMemory(pxCaseID,pyGUID)` — exact single-record source read;','`GetMemory(pxCaseID,Type,pyGUID)` — source read;')
    results.append(('N3',must_fail('N3',a,gm,v,c,'old GetMemory signature')))
    # N4 pyUpdates reintroduced.
    gm=g+'\npyUpdates={"pyStatusValue":"Passed"}\n'
    results.append(('N4',must_fail('N4',a,gm,v,c,'pyUpdates')))
    # N5 Author loses all-writes-before-Generator gate.
    am=a.replace('Only after all Projection writes succeed, invoke Generator sequentially','Invoke Generator sequentially')
    results.append(('N5',must_fail('N5',am,g,v,c,'Generator sequencing')))
    # N6 Generator loses terminal create-failure transition.
    gm=g.replace('→ `CANDIDATE_WRITE_FAILED`','→ continue')
    results.append(('N6',must_fail('N6',a,gm,v,c,'write failure terminal')))
    # N7 Validator accepts wrong Candidate type by removing exact expected type.
    vm=v.replace('exact `pyType="UnitTestCandidate"`','exact `pyType="SomethingElse"`')
    results.append(('N7',must_fail('N7',a,g,vm,c,'Candidate type check')))
    # N8 repair no longer creates a new Candidate GUID.
    gm=g.replace('new WriteMemory → new GUID','overwrite current Candidate')
    results.append(('N8',must_fail('N8',a,gm,v,c,'repair new-record rule')))
    return results

if __name__=='__main__':
    a,g,v,c=run_current()
    neg=run_negative(a,g,v,c)
    print('A8D_SINGLE_RECORD_MEMORY_CHECK: CURRENT PASS')
    print(f'NEGATIVE MUTATIONS: {len(neg)}/8 EXPECTED FAIL')
    for name,errs in neg:
        print(name+': PASS (detected)')
