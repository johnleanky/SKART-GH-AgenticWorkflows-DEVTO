# A6 Amendment — Pega Data Casting Matrix Is Author-Executable Semantics

**Status:** ACCEPTED USER DECISION; TEXTUALLY IMPLEMENTED; CASTING MATRIX AUTHORITATIVE FOR PEGA 26.x BY PROJECT DECISION  
**Date:** 2026-09-12  
**Supersedes:** any A6 wording that treated the Pega conversion matrix mainly as a caution/reference or defaulted castable cases to `unknown` instead of executing the documented matrix.

## Accepted decision

The Scenario Author must use the documented Pega **Data type conversions (casting) in expressions and property assignments** matrix to model runtime type coercion.

The matrix is part of semantic execution, not target serialization.

For every scalar assignment or typed parameter binding that can affect branch truth, later execution, setup, or an exact assertion, Author must:

1. determine Pega source-expression type;
2. determine authoritative destination property/formal-parameter type;
3. select the exact FROM→TO matrix cell;
4. execute the matrix conversion family and numbered note(s);
5. apply destination-property validation where applicable;
6. carry the resulting post-cast value into RX / PropertyTrace / ASSERT reasoning;
7. preserve an internal `CAST` evidence row.

Generator and Validator do **not** re-run casting.

## Normative project matrix

The documented scalar matrix is represented in Author reasoning as follows (`I` = identity, `X` = prohibited):

| FROM \\ TO | DateTime | Date | TimeOfDay | Integer | Decimal | Double | TrueFalse | Other |
|---|---|---|---|---|---|---|---|---|
| DateTime | I | D | D | V | V | V | X | C |
| Date | V+2 | I | X | V+5 | V+5 | V+5 | X | C |
| TimeOfDay | X | X | I | V+N+3 | V+4 | V+4 | X | C |
| Integer | V+1 | V+5 | V+3 | I | V | V | 6 | C |
| Decimal | V+1 | V+5 | V+4 | N | I | V | 6 | C |
| Double | V+1 | V+5 | V+4 | N | V | I | 6 | C |
| TrueFalse | X | X | X | X | X | X | I | C |
| Other (Text/Identifier-like) | S | S | S | S | S | S | S | I |

Legend:

- `C`: copy without validity examination.
- `S`: copy unchanged, then test suitability; unsuitable values become `External`.
- `D`: date narrowing.
- `N`: numeric narrowing; fractional portion is rounded.
- `V`: preferred numeric conversion using the platform numeric representation.
- `1`: numeric→DateTime treats value as DateTime in GMT.
- `2`: Date→DateTime appends midnight and GMT.
- `3`: Integer↔TimeOfDay uses seconds since midnight.
- `4`: Decimal/Double↔TimeOfDay uses fractional day.
- `5`: numeric↔Date uses day offset from Java epoch 1970-01-01 (numeric→Date rounded).
- `6`: numeric→TrueFalse maps zero to false and nonzero to true.

Page/container types are not scalar matrix entries. `TextEncrypted` has no automatic conversion and must not be treated as `Other` for casting.

## Source-type determination is also Author-owned

Author must not identify `sourceType` from JSON representation. It comes from the Pega expression:

- property reference → exact Rule-Obj-Property type;
- Param reference → exact formal parameter declaration;
- function/RUF → exact return signature / authoritative Knowledge;
- quoted string literal → Other/Text-like;
- boolean literal → TrueFalse;
- numeric literal/expression → Pega expression numeric type;
- compound expression → Pega expression evaluation/promotion semantics.

This distinction is required for cases such as a Text literal assigned to a Decimal property: the matrix cell is `S`, not a generic `parseDecimal` operation.

## Mandatory internal evidence

For each cast-sensitive assignment/binding Author creates:

`CAST|scenario=<id>|target=<parameter-or-property-path>|sourceExpr=<raw>|sourceType=<matrix type>|destinationType=<matrix type>|matrix=<cell+notes>|sourceValue=<value>|postCastValue=<value|External|invalid|unknown>|validation=<valid|External|not_applicable|unknown>|proof=<evidence>`

`CAST` is internal and is not serialized into UnitTestProjectionV3. The Projection carries the authoritative type plus the final semantic value needed by Generator.

## Exactness boundary

The matrix must be applied whenever its source/destination types are known. Runtime evidence being absent is **not** a reason to skip a documented conversion.

Only a detail that the matrix/documentation itself leaves underspecified may remain unresolved. Examples:

- a tie-sensitive `N` rounding result if the exact Pega tie rule is material and not otherwise evidenced;
- a Date/DateTime conversion whose documented timezone caveat materially changes the expected value;
- destination validation beyond the conversion matrix when the relevant property validation contract is unavailable.

In those cases Author retains the known matrix cell and blocks only the unresolved exact claim, rather than discarding the whole casting model.

## Evidence boundary

Research basis used for this amendment:

- Pega Platform documentation: *Data type conversions (casting) in expressions and property assignments* — automatic conversions during expression evaluation/assignment and the matrix/legend above: https://community.pega.com/sites/pdn.pega.com/files/help_v73/designer%20studio/expressionbuilder/ref_conversions.htm
- Pegasystems 26.1 Activity authoring skill (formal parameter types including `TimeOfDay`): https://github.com/pegasystems/infinity-ai-plugins/blob/main/plugins/pega/infinity-ai-plugins/codex/resources/26-1/skills/rules-rule-obj-activity/SKILL.md
- Pegasystems 26.1 expression syntax library (expression typing/coercion context): https://github.com/pegasystems/infinity-ai-plugins/blob/main/plugins/pega/infinity-ai-plugins/codex/resources/26-1/library/expression-syntax.md

The public full conversion matrix is served from legacy-version Pega help pages. By explicit project decision, the matrix is treated as authoritative for Pega 26.x because the project accepts that Pega type-conversion semantics have not changed in this area. Version age alone is therefore **not** an uncertainty, blocker, or A9 proof requirement.

A9 may still execute representative matrix cases to validate the RuleIQ implementation and target integration, but it does not need to re-prove the applicability of the matrix to Pega 26.x. No Pega runtime was executed while making this amendment.
