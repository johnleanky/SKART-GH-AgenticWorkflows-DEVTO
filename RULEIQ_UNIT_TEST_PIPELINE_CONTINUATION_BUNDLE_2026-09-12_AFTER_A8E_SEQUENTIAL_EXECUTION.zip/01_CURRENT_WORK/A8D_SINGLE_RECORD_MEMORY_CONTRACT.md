# A8D Canonical Single-Record Memory Tool Contract

**Status:** CURRENT A8D CONTRACT  
**Scope:** `WriteMemory`, `GetMemory`, `UpdateMemory` only.  
**Cardinality:** exactly one Memory record per tool invocation.

## 1. WriteMemory

### Input

```text
WriteMemory(
  pxCaseID,
  Type,
  pyGroup,
  pyPayload
)
```

- `pxCaseID`: required nonempty case id.
- `Type`: required nonempty artifact type.
- `pyGroup`: required nonempty logical group.
- `pyPayload`: required complete immutable payload string.

The caller never supplies `pyGUID` on create.

### Success

```json
{
  "success": true,
  "pyGUID": "<new GUID>",
  "pyGroup": "<exact input pyGroup>",
  "errorCode": "",
  "errorMessage": ""
}
```

### Failure

```json
{
  "success": false,
  "pyGUID": "",
  "pyGroup": "<exact input pyGroup>",
  "errorCode": "WRITE_FAILED",
  "errorMessage": "<diagnostic text>"
}
```

### Contract

- Create-only; never overwrite an existing record.
- One call creates at most one record.
- No `RequestsJSON`, `ResultsJSON`, Memory `pxResults[]`, row carrier, partial-success or batch semantics.
- `pyPayload` becomes immutable after successful create.
- Any exception, malformed response, `success!=true`, wrong echoed `pyGroup`, empty/reused GUID or nonempty success error fields is a caller-side write failure.
- Agents do not retry an unconfirmed/failed create.

---

## 2. GetMemory

### Input

```text
GetMemory(
  pxCaseID,
  pyGUID
)
```

`pyGUID` is the unique Data Type key. `pxCaseID` is an ownership/correlation guard, not an additional result selector.

### Success

```json
{
  "success": true,
  "pxCaseID": "<stored case id>",
  "pyType": "<stored artifact type>",
  "pyGroup": "<stored group>",
  "pyGUID": "<exact requested GUID>",
  "pyPayload": "<stored immutable payload>",
  "pyStatusValue": "<stored lifecycle status or empty>",
  "pyRouterKey": "<stored router key or empty>",
  "errorCode": "",
  "errorMessage": ""
}
```

### Not found

```json
{
  "success": false,
  "pyGUID": "<requested GUID>",
  "errorCode": "NOT_FOUND",
  "errorMessage": "Memory record was not found"
}
```

### Contract

- Read-only.
- Exact one-record lookup by unique `pyGUID`, guarded by `pxCaseID`.
- No list result and no empty-list success convention.
- Caller validates returned `pxCaseID`, `pyGUID`, expected `pyType`, and required nonempty `pyGroup`/`pyPayload`.
- `NOT_FOUND`, exception or malformed response stops the required-artifact workflow; never substitute another row, infer latest, or reconstruct from memory.

---

## 3. UpdateMemory

### Input

```text
UpdateMemory(
  pxCaseID,
  pyGUID,
  pyStatusValue,
  pyRouterKey
)
```

Allowed pairs only:

```text
Passed + OK
Failed + GENERATOR_REPAIR
Failed + SEMANTIC_REJECT
Failed + HUMAN
```

### Success

```json
{
  "success": true,
  "pyGUID": "<exact input GUID>",
  "pyStatusValue": "<exact stored status>",
  "pyRouterKey": "<exact stored router key>",
  "errorCode": "",
  "errorMessage": ""
}
```

### Not found

```json
{
  "success": false,
  "pyGUID": "<requested GUID>",
  "errorCode": "NOT_FOUND",
  "errorMessage": "Memory record was not found"
}
```

### Other update failure

```json
{
  "success": false,
  "pyGUID": "<requested GUID>",
  "errorCode": "UPDATE_FAILED",
  "errorMessage": "<diagnostic text>"
}
```

### Contract

- Exact one-record update by unique `pyGUID`, guarded by `pxCaseID`.
- Only `pyStatusValue` and `pyRouterKey` may change.
- `pyPayload`, `pyType`, `pyGroup`, `pxCaseID`, `pyGUID` remain immutable.
- No `pyUpdates`, `RequestsJSON`, `ResultsJSON`, Memory `pxResults[]`, full Candidate replacement or batch merge semantics.
- `NOT_FOUND`, `UPDATE_FAILED`, exception or malformed response stops lifecycle/routing; agent does not retry an unconfirmed/failed update.
- No persistent `Pending` update is written.

---

## 4. Caller behavior summary

```text
GetMemory / NOT_FOUND
  -> required record absent
  -> stop current required-artifact workflow

WriteMemory / WRITE_FAILED or malformed/exception
  -> create not confirmed
  -> stop
  -> do not continue to downstream agent

UpdateMemory / NOT_FOUND or UPDATE_FAILED or malformed/exception
  -> lifecycle update not confirmed
  -> stop lifecycle/routing
```

Tool-level business error vocabulary is intentionally limited to:

```text
NOT_FOUND
WRITE_FAILED
UPDATE_FAILED
```

Diagnostic `errorMessage` is not a branching contract. Agents branch on the structured outcome/error code only.

---

## 5. Batch boundary

These tools intentionally do not support batch operations.

If batch Memory operations are needed later, create a separate explicitly named tool and contract. Do not extend these three tools with arrays or carrier JSON.

This restriction does **not** apply to other tools such as KnowledgeTool that legitimately return `pxResults[]`.
