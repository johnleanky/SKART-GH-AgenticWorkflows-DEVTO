> **A8D NOTE:** This A1 document is historical validation evidence. Its old Memory carrier syntax is superseded by `A8D_SINGLE_RECORD_MEMORY_CONTRACT.md`; only the persistence semantics remain inherited.

# A1 — Persistence Contract Textual Validation

**Result:** PASS

**Evidence boundary:** static/textual contract validation only. No Claude runtime, Pega execution, or Memory-tool runtime test was performed.

| Check | Result | Evidence |
|---|---|---|
| WriteMemory explicitly create-only | PASS | interface + section 6 |
| No explicit Candidate lineage field introduced | PASS | no supersedesUUID token |
| No persisted Pending update | PASS | Pending is implicit only |
| Exact create carrier | PASS | single create row, no GUID |
| Exact lifecycle carrier | PASS | exact group+GUID patch |
| Route mapping OK | PASS | OK->Passed |
| Route mapping GENERATOR_REPAIR | PASS | GENERATOR_REPAIR->Failed |
| Route mapping SEMANTIC_REJECT | PASS | SEMANTIC_REJECT->Failed |
| Route mapping HUMAN | PASS | HUMAN->Failed |
| Lifecycle whitelist only | PASS | pyStatusValue + pyRouterKey only |
| Atomic partial merge | PASS | tool/storage semantics stated |
| Exact update correlation | PASS | response identity |
| No retry after uncertain lifecycle update | PASS | terminal LIFECYCLE_UPDATE_FAILED behavior |
| Lifecycle update precedes route action | PASS | ordering invariant |
| Diff scope limited to persistence interface/section 6 | PASS | old-file hunk starts=[12, 219, 243, 245, 249, 260] |
| Sections 7+ byte-identical | PASS | post-section-6 content unchanged |

## Scope conclusion

A1 changes are confined to Candidate persistence/lifecycle contract wording. M1–M7 semantic/fidelity mappings are not reopened by this patch.
