from pathlib import Path
import sys

PROMPT = Path(__file__).with_name('Main_Agent_Prompt_A8E_SEQUENTIAL_REFACTORED.txt')

REQUIRED_PROMPT = [
    'Run Scenario Compiler `B -> A` over the complete frozen ScenarioGroup set and require `A=PASS`.',
    'After global Scenario Compiler `A=PASS`, process frozen physical groups exactly once in Author order.',
    'For the current group only:',
    'only `Completed` permits selecting the next frozen physical group.',
    '**Commit boundary.**',
    'Do not restart `I/W/F/B/A`, modify persisted records, or continue to another group.',
]
FORBIDDEN_PROMPT = [
    'Require every WriteMemory call to succeed before invoking any Generator',
    'Only after all Projection writes succeed',
    'Only after every Projection WriteMemory succeeds may Generator orchestration begin',
    'Materialize UnitTestProjection v3 for every group',
]


def prompt_contract_errors(text: str):
    errors=[]
    for x in REQUIRED_PROMPT:
        if x not in text:
            errors.append(f'missing required prompt contract: {x}')
    for x in FORBIDDEN_PROMPT:
        if x in text:
            errors.append(f'forbidden obsolete prompt contract present: {x}')
    return errors


def validate_trace(events, frozen_order=('G001','G002')):
    errors=[]
    a_pass=False
    frozen=True
    first_write=False
    group_index=0
    state='EXPECT_PROJECTION'
    current=None
    generator_calls=set()
    terminal_failure=False

    for pos,event in enumerate(events):
        kind=event[0]
        group=event[1] if len(event)>1 else None
        value=event[2] if len(event)>2 else None

        if terminal_failure:
            errors.append(f'event after terminal failure at {pos}: {event}')
            continue

        if kind=='A_PASS':
            if a_pass:
                errors.append('duplicate A_PASS')
            a_pass=True
            continue

        if kind in {'ADD_SCENARIO','REGROUP'}:
            if a_pass and frozen:
                errors.append(f'frozen scenario/group mutation: {kind}')
            continue

        if kind=='RESTART':
            if first_write:
                errors.append('semantic restart after first successful Projection write')
            continue

        if kind in {'PROJECTION','WRITE','GEN_CALL','GEN_TERMINAL'} and not a_pass:
            errors.append(f'{kind} before A_PASS')
            continue

        if kind=='PROJECTION':
            if group_index >= len(frozen_order) or group != frozen_order[group_index]:
                errors.append(f'group order violation at Projection {group}')
                continue
            if state!='EXPECT_PROJECTION':
                errors.append(f'Projection {group} while state={state}')
                continue
            current=group
            state='EXPECT_WRITE'
            continue

        if kind=='WRITE':
            if state!='EXPECT_WRITE' or group!=current:
                errors.append(f'Write {group} before current Projection is ready')
                continue
            first_write=True
            state='EXPECT_GEN_CALL'
            continue

        if kind=='GEN_CALL':
            if group in generator_calls:
                errors.append(f'duplicate Generator invocation for {group}')
                continue
            if state!='EXPECT_GEN_CALL' or group!=current:
                errors.append(f'Generator {group} before current Write or before prior terminal result')
                continue
            generator_calls.add(group)
            state='EXPECT_GEN_TERMINAL'
            continue

        if kind=='GEN_TERMINAL':
            if state!='EXPECT_GEN_TERMINAL' or group!=current:
                errors.append(f'terminal Generator result for non-current group {group}')
                continue
            if value not in {'Completed','Failed'}:
                errors.append(f'invalid Generator terminal status {value}')
                terminal_failure=True
                continue
            if value=='Failed':
                terminal_failure=True
                continue
            group_index += 1
            current=None
            state='EXPECT_PROJECTION'
            continue

        errors.append(f'unknown event {event}')

    return errors


def run_case(name, events, expect_pass):
    errors=validate_trace(events)
    passed=(len(errors)==0)
    ok=(passed==expect_pass)
    print(('PASS' if ok else 'FAIL'), name, 'trace=', 'accepted' if passed else 'rejected', ('; '.join(errors) if errors else ''))
    return ok


def main():
    text=PROMPT.read_text()
    prompt_errors=prompt_contract_errors(text)
    if prompt_errors:
        for e in prompt_errors: print('FAIL PROMPT', e)
        return 1
    print('PASS PROMPT contract')

    cases=[
      ('T1 Generator before global A=PASS', [('GEN_CALL','G001')], False),
      ('T2 G002 Projection before G001 terminal', [('A_PASS',),('PROJECTION','G001'),('WRITE','G001'),('PROJECTION','G002')], False),
      ('T3 all Projections persisted before first Generator', [('A_PASS',),('PROJECTION','G001'),('WRITE','G001'),('PROJECTION','G002'),('WRITE','G002')], False),
      ('T4 physical-group order changed', [('A_PASS',),('PROJECTION','G002')], False),
      ('T5 dependency result adds Scenario after freeze', [('A_PASS',),('ADD_SCENARIO','S999')], False),
      ('T6 regrouping after freeze', [('A_PASS',),('REGROUP','G001')], False),
      ('T7 semantic restart after first successful write', [('A_PASS',),('PROJECTION','G001'),('WRITE','G001'),('RESTART',)], False),
      ('T8 second Generator invocation for same Projection', [('A_PASS',),('PROJECTION','G001'),('WRITE','G001'),('GEN_CALL','G001'),('GEN_CALL','G001')], False),
      ('T9 Generator failure then next group', [('A_PASS',),('PROJECTION','G001'),('WRITE','G001'),('GEN_CALL','G001'),('GEN_TERMINAL','G001','Failed'),('PROJECTION','G002')], False),
      ('T10 canonical sequential flow', [('A_PASS',),('PROJECTION','G001'),('WRITE','G001'),('GEN_CALL','G001'),('GEN_TERMINAL','G001','Completed'),('PROJECTION','G002'),('WRITE','G002'),('GEN_CALL','G002'),('GEN_TERMINAL','G002','Completed')], True),
    ]
    oks=[run_case(*c) for c in cases]
    return 0 if all(oks) else 1

if __name__=='__main__':
    sys.exit(main())
