# A3 — UnitTestProjectionV3 Producer/Consumer Contract Validation

**Status:** TEXTUALLY VALIDATED  
**Date:** 2026-09-12  
**Evidence boundary:** static contract/text validation only. No Claude runtime, Pega execution, Memory-tool runtime, persisted Projection, candidate generation, or Validator runtime was executed.

## Scope

A3 repairs only the producer/consumer source-grammar seam identified by the end-to-end tabletop review.

Current A3 Author artifact:

- `Main_Agent_Prompt_A3_SOURCE_CONTRACT_REPAIRED.txt`

Existing consumer baseline used for synchronization:

- `UnitTestGenerator_Prompt_A2_NAMING_REPAIRED.txt`, especially §2.1–2.2.

Validator, Stage-3 target schemas, M1–M7 semantic/fidelity mapping, A1 persistence behavior, and A2 naming behavior are not changed by A3.

## Contract synchronization

Author §6.8 now performs pre-persistence validation for the closed UnitTestProjectionV3 source grammar consumed by Generator §2.1–2.2.

| Source-contract area | Result | A3 producer-side coverage |
|---|---|---|
| Root closure and mode-owned optional fields | PASS | common root plus only fields permitted by exactly one mode |
| `testLabel` | PASS | 1..50, non-`TC_` regex, at least one ASCII alphanumeric |
| `physicalGroupKey` | PASS | `^G[0-9]{3}$`, frozen ordinal equality, run-local uniqueness |
| Scenario object closure | PASS | exact six-field Scenario metadata shape |
| Scenario name | PASS | 1..50 and same non-`TC_` lexical rule |
| Scenario enums | PASS | exact confidence/testability/dependency-closure enums |
| Trace constraints | PASS | nonempty `reasoningTrace`; `dependencyClosureTrace` length 1..3500 |
| Executable RUT / primary | PASS | exact closed shapes, nonempty identifiers/classes, boolean `singlePage` |
| Additional pages | PASS | nonempty map, exact page-name regex, nonempty class values |
| Parameters | PASS | exact `{name,value?,page?}` shape; native scalar types; PAGE marker rule |
| Setup/actions | PASS | exact setup-page/action shapes, allowed action-type enum, nonempty optional arrays |
| Simulations | PASS | exact simulation/setup-page shapes; opaque JSON `data` boundary preserved |
| Standard assertions | PASS | Property / Param / Page / List / ResultCount closed kind grammars and bounds |
| Rule-Obj-When rows | PASS | exact row/input shapes, boolean result, shared ordered input-path census |
| Mode/cardinality | PASS | exact standard / When / informational mode requirements; zero/multiple matches invalid |
| Forbidden source fields | PASS | envelope/audit/ledger/provenance/internal/grouping fields rejected outside opaque `data` |
| Empty optional physical collections | PASS | must be absent rather than serialized empty |

A local static assertion pass checked these 17 constraint groups and passed. This check only verifies presence/isolation of the textual contract; it is not runtime evidence.

## Scope-isolation checks

| Check | Result |
|---|---|
| Author content before §6.8 remains byte-identical to A2 | PASS |
| Author content after §6.8 remains byte-identical to A2 | PASS |
| Generator source grammar was not loosened | PASS |
| M1–M7 semantic/fidelity ownership was not changed | PASS |
| Candidate lineage remains external; no `supersedesUUID` introduced | PASS |
| No persisted `Pending` lifecycle update introduced | PASS |
| Minimal Author GeneratorRunReport trust boundary remains `sourceUUID + groupId + status` | PASS |

## Producer-only checks intentionally remain stricter

The Author still owns additional pre-persistence checks that Generator need not reproduce, including:

- canonical JSON serialization discipline;
- equality to frozen Author source facts;
- physical decision census completeness;
- run-level `physicalGroupKey` ordinal/uniqueness proof.

These stricter producer checks cannot create the original failure mode (Author-valid Projection rejected by Generator for a missing duplicated source lexical/shape rule); they reduce the set of persisted source artifacts.

## Deliberate non-changes

A3 does not:

- change Scenario semantics, grouping, assertions, simulations, expected values, or When results;
- change Projection→Candidate deterministic mappings;
- change Candidate naming;
- change Candidate persistence/lifecycle behavior;
- define scalar canonicalization (A5);
- resolve scalar formal parameter type (A6);
- alter target schema/JsonExample deployment bindings (A4).

## Next stage

A4 — verify the deployed target configuration contract:

- KnowledgeTool schema keys resolve to the current Stage-3 standard and Rule-Obj-When schemas;
- JsonExample/template carrier supplies the intended application-specific `pyRuleSet` and `pyRuleSetVersion`, not static sample values.
