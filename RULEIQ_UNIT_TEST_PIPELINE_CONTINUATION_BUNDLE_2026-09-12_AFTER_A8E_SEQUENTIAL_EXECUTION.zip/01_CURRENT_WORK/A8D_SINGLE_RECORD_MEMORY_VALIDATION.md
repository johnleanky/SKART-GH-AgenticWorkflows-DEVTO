# A8D Single-Record Memory Validation

**Result:** PASS  
**Evidence boundary:** static/contract validation only; no Pega Memory-tool runtime execution.

## Current-contract checks

| Check | Result |
|---|---|
| WriteMemory single-record signature | PASS |
| GetMemory single-record signature | PASS |
| UpdateMemory single-record signature | PASS |
| Author one Projection per WriteMemory | PASS |
| Author waits for all Projection writes before Generator orchestration | PASS |
| Generator exact single Projection read | PASS |
| Generator one Candidate per WriteMemory | PASS |
| Generator exact lifecycle UpdateMemory | PASS |
| Validator two exact single GetMemory reads | PASS |
| `pyPayload` immutable | PASS |
| repair creates new Candidate GUID | PASS |
| no persisted Pending update | PASS |
| no active Memory `RequestsJSON` | PASS |
| no active Memory `ResultsJSON` | PASS |
| no active Memory `pxResults[]` carrier | PASS |
| no active `pyUpdates` carrier | PASS |
| KnowledgeTool `response.pxResults` preserved | PASS |
| tool-level codes limited to NOT_FOUND / WRITE_FAILED / UPDATE_FAILED | PASS |

## Negative-mutation checks

`A8D_SINGLE_RECORD_MEMORY_CHECK.py` was run against the promoted-candidate artifacts.

| Mutation | Expected | Result |
|---|---|---|
| N1 reintroduce WriteMemory RequestsJSON | FAIL | PASS — detected |
| N2 reintroduce Memory pxResults carrier | FAIL | PASS — detected |
| N3 reintroduce Type into GetMemory lookup | FAIL | PASS — detected |
| N4 reintroduce pyUpdates | FAIL | PASS — detected |
| N5 allow Author Generator call before all writes succeed | FAIL | PASS — detected |
| N6 remove Generator terminal handling after Candidate write failure | FAIL | PASS — detected |
| N7 remove exact Validator Candidate pyType check | FAIL | PASS — detected |
| N8 repair overwrites Candidate instead of new create | FAIL | PASS — detected |

**Negative suite:** 8/8 expected failures detected.

## Conclusion

A8D Memory semantics are internally consistent at the prompt/contract level and the checker distinguishes Memory carriers from legitimate KnowledgeTool `pxResults` usage.

## Promotion regression

| Regression | Result |
|---|---|
| A8D current checker | PASS |
| A8D negative mutations | 8/8 expected FAIL detected |
| A8B canonical Projection→Candidate fixtures | PASS |
| A8C anti-anchoring/adversarial suite | 10/10 PASS |
| A4 static self-test expectation | PASS — local verifier remains intentionally FAIL only on demo ruleset mismatch |

**Promotion decision:** A8D is promoted as the current static/design Memory contract baseline. A4 live deployment proof and A9 runtime remain open.
