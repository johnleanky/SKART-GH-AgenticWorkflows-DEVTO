> **A8 note:** Casting ownership remains accepted, but typed scalar Projection transport was refined in A8 to exact post-cast Pega clipboard lexical strings. Any A6 wording that implies JSON-native numeric/boolean transport is superseded by `A8_CAST_LEXICAL_TRANSPORT_AMENDMENT.md`.

# A6 — Typed Parameters and Pega Coercion Validation

**Status:** DESIGN RESOLVED; TEXTUALLY IMPLEMENTED; RUNTIME PROOF NOT EXECUTED  
**Amendment authority:** `A6_DATA_CASTING_MATRIX_AMENDMENT.md` + `Main_Agent_Prompt_A6_CAST_MATRIX_REPAIRED.txt` supersede the earlier conservative casting wording below wherever it conflicts. The documented Pega conversion matrix must now be executed by Author for known source/destination types; it is not optional/reference-only.  
**Date:** 2026-09-12  
**Evidence boundary:** live continuation bundle + current Pegasystems `infinity-ai-plugins` 26.1 resources + Pega Community conversion documentation. No Pega runtime, Claude runtime, Memory write, candidate save, or JsonValidationTool execution was performed.

## Decision

The Scenario Author is the sole semantic owner of:

1. formal RUT/action parameter type;
2. destination property type used by execution reasoning;
3. Pega assignment/parameter coercion and validation semantics;
4. the final post-binding/post-assignment semantic value frozen into UnitTestProjectionV3.

Generator never infers type from a value and never re-runs Pega coercion. It performs target serialization only. Validator independently verifies target serialization from the frozen typed Projection and never changes semantic values.

## Evidence

Current Pegasystems 26.1 plugin resources show:

- `rules-rule-obj-when/SKILL.md`: rule-level formal parameters carry a Pega data type such as Text, Integer, Decimal, TrueFalse, Double, Page, Date/DateTime/TimeOfDay; the caller supplies the value.
- `rules-rule-obj-property/schema/rule-obj-property.json`: scalar property type is explicit (`pyStringType` such as Text, Integer, Decimal, TrueFalse, Date, DateTime) and separate from storage mode.
- `rules-rule-test-unit-case/examples/pyRuleUnderTest/rule-obj-model.md` and `rule-obj-when.md`: RUT parameter examples explicitly emit `pyParametersParamType: "Text"`; Text parameter value is represented as a quoted Pega string literal inside the JSON field.
- `rules-rule-test-unit-case/SKILL.md`: RUT string parameter values require inner quotes; Property assertion formatting is type-sensitive; Decision assertion cells use their own bare-string convention.

Pega Community documentation states:

- activity formal parameter declarations have types and expression evaluation follows the same casting/type-conversion operations as properties;
- Property-Set evaluates the source expression, converts it when source/destination types differ, then validates the destination property;
- the conversion matrix distinguishes identity, copy (`C`), copy-then-validate (`S`), numeric narrowing (`N`), preferred numeric conversion (`V`), disallowed conversions, and numeric-to-boolean zero/nonzero behavior.

Therefore the formal type cannot be reconstructed safely from a runtime value and the expected post-execution value cannot be frozen correctly without destination-type-aware Author semantics.

## Important correction to the intuitive "string -> Decimal cast" model

Pega's documented matrix describes `Other` (Text/Identifier-like) -> typed scalar as `S`: the lexical value is copied unchanged and then tested for suitability. It is not equivalent to applying a generic Java/Python numeric cast. If unsuitable, the property can carry the External attribute. This is why the Author must model Pega conversion/validation rather than call a generic language cast.

For the semantic Projection, the Author freezes the proven target-typed semantic value; raw lexical/source expression plus conversion proof remain internal evidence. If conversion/validation outcome is not provable, the dependent exact claim is `unknown`/omitted or becomes an explicit validation/error scenario instead of being guessed.

## UnitTestProjectionV3 A6 contract

### Parameters

Every RUT and setup/cleanup action parameter is now:

`{name,formalType,value?}`

Canonical formal types:

`Text|Integer|Decimal|Double|TrueFalse|Date|DateTime|TimeOfDay|Page`

`formalType` is mandatory and is grounded from the exact RUT/callee declaration. It is never inferred from JSON value shape.

### Standard property-like assertions

Destination type is now mandatory source information:

- Property has required `mode`;
- Page child item has required `mode`;
- List child item has required `mode`.

`expected`, when present, is the Author's post-coercion semantic value. Generator must not apply Pega casting again.

### Rule-Obj-When inputs

Each row input is now:

`{path,valueType,value?}`

`valueType` is the Author-grounded semantic type of the referenced property/formal parameter. The current MultInpComb Decision target may still serialize the physical cell with `pyPropertyMode="text"`; this does not erase semantic source typing.


## Upstream type-token inconsistency and deployment consequence

The 26.1 repository is not perfectly uniform about parameter type tokens. Rule-type skills/examples show rule-specific declaration tokens (for example Activity supports mixed tokens such as `STRING`, `INTEGER`, `TrueFalse`, `BOOLEAN`, `Decimal`, `Double`, `PAGE`; Rule-Obj-When examples use semantic tokens such as `Text` and `Integer`). The generic Rule-Test-Unit-Case schema retrieved during research exposes a narrower/different enum than the broader rule-definition type sets.

Therefore A6 deliberately separates:

- **Projection `formalType`** — one normalized semantic type owned by Author;
- **candidate `pyParametersParamType`** — target lexical token owned by the selected deployed Unit Test contract.

The current local Stage-3 schemas use the normalized target set `Text|Integer|Decimal|Double|TrueFalse|Date|DateTime|TimeOfDay|PAGE`. That is a project target-contract decision and still requires A4 deployment proof; it is not claimed as universally accepted by every Pega rule API or every PegaUnit version.

## Generator / Validator serialization

A5 numeric canonicalization is retained as a primitive **bare-scalar formatting** algorithm, not a semantic cast.

A6 adds a typed method-parameter serializer:

- Page -> target type PAGE; exact page-name value;
- Text -> target type Text; Pega quoted string-literal value;
- Integer/Decimal/Double/TrueFalse -> explicit target type plus bare canonical scalar text;
- Date/DateTime/TimeOfDay -> explicit type, but exact lexical form must be uniquely specified by the selected normative target contract; otherwise fail/return HUMAN rather than guess.

The Stage-3 standard and MultInpComb schemas now require `pyParametersParamType` and enumerate the supported scalar types plus PAGE.

## A5 amendment

A5's exact decimal normalization remains valid for numeric/bool **target lexemes**. Its earlier wording that one context-free `CanonicalScalarString(v)` owns all scalar target values is superseded by A6 because Text method parameters require target-specific quoting and source type is authoritative.

A5 was not semantic casting evidence and is not treated as such.

## Upstream-vs-bundled target warning

The bundled standard JsonExample previously showed an untyped Text RUT parameter (`EntityKey`) with unquoted value. Current Pegasystems 26.1 Rule-Test-Unit-Case examples show explicit Text type plus an inner-quoted Pega string literal. The bundled example was updated locally to the A6 contract.

This does **not** prove the deployed KnowledgeTool binding has the same schema/example. A4 remains `DEPLOYMENT PROOF REQUIRED` and must verify the actual deployed target contract before a real model/Pega trial.

There is also upstream evidence that assertion lexical conventions vary by assertion context. A6 therefore keeps semantic coercion in Author and target lexical formatting in Generator/selected target contract instead of moving target syntax into Author.

## Static checks performed

- Author/Generator/Validator all carry mandatory formal source type; no scalar type inference instruction remains in the A6 stage prompts.
- Standard and MultInpComb Stage-3 MethodParam schemas both require `pyParametersParamType`.
- Both schemas enumerate the same supported type set.
- Property/Page/List source assertions carry destination type where Generator needs target property-mode serialization.
- Rule-Obj-When row inputs carry semantic `valueType`.
- old A5 stage files remain preserved as historical current-work evidence; A6 stage files are the new current authority.

## Pre-existing JsonExample fixture note

A local schema-validation pass also found that the bundled JsonExample files are not full schema-valid fixtures against the current minimal Stage-3 schemas because they still carry legacy illustrative Scenario/EvidenceSummary metadata. Those mismatches pre-date A6 and are unrelated to typed parameter/coercion changes. Generator already treats JsonExample as illustrative/target-policy input rather than as a candidate template. A6 therefore does not rewrite that legacy metadata; A7 should either align the examples to the schemas or explicitly formalize their illustrative-only status.

## Runtime evidence still required

Not proven in this session:

- exact deployed KnowledgeTool schema/example bindings (A4);
- actual Pega runner acceptance for every listed scalar formal type;
- Date/DateTime/TimeOfDay parameter lexical edge cases;
- quote/backslash edge cases inside Text parameter values;
- implementation/integration behavior for representative casting cases if/when A9 is run; this is verification of RuleIQ execution, not re-validation of the Pega casting matrix itself;
- any exact edge detail that the documented matrix leaves genuinely unspecified (for example a material tie-breaking rule not stated by the documentation).

By explicit project decision, the documented Pega Data Casting Matrix is authoritative for Pega 26.x; its legacy documentation version is not an open evidence gap. No runtime/model/Pega PASS is claimed for the generated pipeline itself.
