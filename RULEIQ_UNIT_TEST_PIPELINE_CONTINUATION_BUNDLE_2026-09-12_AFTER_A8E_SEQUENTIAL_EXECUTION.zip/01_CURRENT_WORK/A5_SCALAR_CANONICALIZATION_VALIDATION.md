# A5 — Scalar Canonicalization Validation

**Status:** TEXTUALLY VALIDATED AS A5 PRIMITIVE; CONTEXT-FREE SERIALIZATION SUPERSEDED BY A6  
**Date:** 2026-09-12  
**Evidence boundary:** static prompt/contract validation plus a local mechanical transcription of the number algorithm. No Claude runtime, Pega execution, candidate persistence, JsonValidationTool, or Pega parameter parsing was executed.

## Scope

**A6 amendment:** the exact decimal/boolean canonicalization below remains the primitive bare-scalar formatter. A6 supersedes the claim that one context-free scalar stringifier is sufficient for every target field, because formal type and target context can require different physical representation (notably Text method-parameter quoting).


A5 closes the deterministic scalar→string gap for exactly these source→candidate mappings:

- RUT parameter scalar values;
- setup/cleanup action parameter scalar values;
- Rule-Obj-When input-cell scalar values.

Current artifacts:

- `UnitTestGenerator_Prompt_A5_SCALAR_CANONICALIZATION_REPAIRED.txt`
- `Validator_Prompt_A5_SCALAR_CANONICALIZATION_REPAIRED.txt`

A5 does not change Author semantic source facts or scalar formal parameter type ownership.

## Canonical contract

Generator and Validator contain a byte-identical `CanonicalScalarString(v)` definition:

- string -> exact source string, including empty;
- boolean -> `true` / `false`;
- JSON number -> one canonical plain-decimal string derived from the exact decimal JSON-number token without binary floating-point conversion;
- mathematically equivalent exponent/decimal spellings normalize to the same output;
- negative zero normalizes to `0`;
- PAGE parameter values remain exact page-name strings and bypass scalar canonicalization.

The explicit decimal algorithm removes:

- plus signs;
- exponent notation;
- redundant leading integer zeroes;
- redundant trailing fractional zeroes.

## Fidelity activation

| Mapping | Result |
|---|---|
| RUT parameter string content | PASS — exact/canonical value checked |
| RUT parameter numeric content | PASS — canonical value checked |
| RUT parameter boolean content | PASS — canonical value checked |
| action parameter string content | PASS — exact/canonical value checked |
| action parameter numeric content | PASS — canonical value checked |
| action parameter boolean content | PASS — canonical value checked |
| Rule-Obj-When string input content | PASS — exact/canonical value checked |
| Rule-Obj-When numeric input content | PASS — canonical value checked |
| Rule-Obj-When boolean input content | PASS — canonical value checked |
| scalar presence/absence | PASS — remains independently checked |
| PAGE value | PASS — exact page-name string, not canonicalized |

The three old Validator exclusions for numeric/boolean parameter, action-parameter, and When-input content are absent from the A5 Validator prompt.

## Mechanical number checks

A small local transcription of the documented decimal algorithm was used only to verify the arithmetic/normalization rules. All checked cases matched the expected canonical output:

| Source JSON number token | Canonical string |
|---|---|
| `0`, `-0`, `0.0`, `-0.000` | `0` |
| `1`, `1.0` | `1` |
| `1.2300` | `1.23` |
| `1000`, `1000.0`, `1e3`, `1E+3` | `1000` |
| `1e-3`, `0.00100` | `0.001` |
| `-0.00100` | `-0.001` |
| `123.45e2` | `12345` |
| `123.45e-2` | `1.2345` |
| `1.200e+2` | `120` |
| `1.2e-2` | `0.012` |

This mechanical check is not evidence that every possible numeric string is accepted by Pega at runtime.

## Preserved boundaries

- A6 remains responsible for whether scalar `pyParametersParamType` must be emitted; A5 does not infer `Text`, `Integer`, `Decimal`, or `TrueFalse`.
- Standard assertion `expected` values are not pulled into this conversion because the current target schema permits their native scalar/null representation; ResultCount retains its existing integer-string rule.
- Candidate lineage remains external.
- No persisted Pending lifecycle update is introduced.
- A1/A2/A3 contracts are unchanged.

## Next stage

A6 — resolve the scalar formal-parameter type requirement/authority. This requires Pega-specific evidence; do not let Generator or Validator guess a scalar type.
