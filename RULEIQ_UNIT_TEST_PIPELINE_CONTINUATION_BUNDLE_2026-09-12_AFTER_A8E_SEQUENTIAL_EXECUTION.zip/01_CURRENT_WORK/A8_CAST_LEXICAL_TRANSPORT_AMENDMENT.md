# A8 Cast-Lexical Transport Amendment

Status: **ACCEPTED / TEXTUALLY IMPLEMENTED**

## Why this amendment was required

A6 correctly made Scenario Author the owner of Pega type coercion through the authoritative Pega Data Casting Matrix. During A8 tabletop review, one remaining representation defect was found: the v3 Projection still required typed numeric/boolean results to be materialized as JSON native numbers/booleans.

That is not faithful for matrix operations that preserve the entered lexical value. In particular, `S` means copy the lexical value unchanged and then validate destination-type suitability. Re-materializing a valid Decimal lexical value such as `12.50` as JSON number `12.5` would introduce RuleIQ normalization that Pega did not perform.

## Accepted model

Scenario Author remains the only casting owner.

For every relevant binding/assignment, Author keeps internal CAST evidence containing both semantic and lexical outcomes:

`CAST|...|sourceValue=<...>|postCastValue=<semantic result|External|...>|postCastLexical=<exact raw Pega clipboard lexical value|absent>|validation=<...>|...`

Rules:

1. `sourceType` and `destinationType` come from Pega rule/property/function evidence, never JSON token shape.
2. Author executes the documented Pega Data Casting Matrix.
3. `C` and valid `S` preserve the copied lexical content exactly.
4. `D`, `N`, `V`, and numbered conversion notes produce the corresponding Pega result; Author records its exact clipboard lexical representation.
5. `S` never becomes a RuleIQ parse-and-reformat operation.
6. `External|invalid|unknown` is never persisted as an ordinary valid exact scalar assertion/input.
7. Author may retain typed semantic `postCastValue` internally for branch/math reasoning, but UnitTestProjectionV3 transports exact scalar values as **Pega lexical strings**.

## UnitTestProjectionV3 transport rule

For typed scalar fields:

- `formalType` / `valueType` / assertion `mode` remains the authoritative Pega type fact.
- every present scalar `value` or `expected` is a JSON string containing the exact Author-frozen post-binding/post-cast Pega clipboard lexical value;
- Page parameter values are also strings and contain the exact page name;
- no typed scalar value is normalized into a JSON number or JSON boolean merely for Projection transport;
- ResultCount remains an integer because it is structural test metadata, not a Pega property-value cast result;
- Rule-Obj-When row `result` remains boolean because it is the semantic decision outcome, not an input property transport value.

Opaque setup/simulation `data` remains copied as an opaque replay payload, but Author is responsible for resolving any typed property assignment/casting needed to construct that final payload before persistence.

## Generator boundary

Generator never executes Pega coercion and never reconstructs a lexical value from a JSON native number/boolean.

It may only:

- copy bare lexical content exactly when the target field expects bare text;
- add the exact target-required quoting/escaping wrapper around unchanged lexical content;
- map canonical source type `Page` to target token `PAGE`;
- reject pre-write when the selected target representation cannot preserve a materially required lexical value without changing it.

A5 `CanonicalBareScalar` is therefore superseded for typed UnitTestProjectionV3 transport. It is not part of current Generator or Validator authority.

## Validator boundary

Validator independently verifies exact source type, value presence, and target wrapper/encoding. It never parses/canonicalizes the source lexical value and never reruns the Pega casting matrix.

## Evidence boundary

This amendment is a contract correction derived from the accepted Pega casting semantics and clipboard value model. It is textually/static validated only. No Claude execution and no Pega runtime test was performed in A8.
