#!/usr/bin/env python3
"""RuleIQ A4 live deployment verifier.

Consumes a JSON capture containing independent Generator and Validator
KnowledgeTool results for Standard and MultiInput executable modes.

The verifier intentionally distinguishes:
- PASS: exact promoted A8C target generation / required operational consistency;
- REVIEW: semantically plausible revision that is not byte/logically identical to the promoted local authority;
- FAIL: missing/contradictory/stale/incompatible deployment evidence.

This script validates deployment binding only. It does not execute Claude, Pega rules,
PegaUnit, Memory, or JsonValidationTool.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "04_TARGET_CONTRACTS"

EXPECTED_FILES = {
    "standard_schema": TARGET / "rule-test-unit-case_JsonSchema_STAGE3.txt",
    "multi_schema": TARGET / "rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt",
    "standard_ka": TARGET / "a8c_shared_reference" / "Rule-Test-Unit-Case_KnowledgeArea_A8C_PROPOSED.txt",
    "multi_ka": TARGET / "a8c_shared_reference" / "Rule-Test-Unit-Case_MultInpComb-KnowledgeArea_A8C_PROPOSED.txt",
    "standard_example": TARGET / "rule-test-unit-case_JsonExample(5).txt",
    "multi_example": TARGET / "rule-test-unit-case_multInpComb-JsonExample(6).txt",
}

KEYS = {
    "standard": {
        "ka": "Rule-Test-Unit-Case_KnowledgeArea",
        "schema": "Rule-Test-Unit-Case_JsonSchema",
        "example": "Rule-Test-Unit-Case_JsonExample",
    },
    "multi": {
        "ka": "Rule-Test-Unit-Case_MultInpComb-KnowledgeArea",
        "schema": "Rule-Test-Unit-Case_MultInpComb-JsonSchema",
        "example": "Rule-Test-Unit-Case_MultInpComb-JsonExample",
    },
}

FORMAL_TYPES = {
    "Text", "Integer", "Decimal", "Double", "TrueFalse",
    "Date", "DateTime", "TimeOfDay", "PAGE",
}

KA_REQUIRED_MARKERS = {
    "standard": [
        "Shared deterministic mapping reference",
        "EX-STD-01",
        "EX-STD-02",
        "EX-STD-03",
        "EX-STD-04",
        "EX-STD-05",
        "never authorize semantic inference",
        "Pega casting",
        "lexical normalization",
    ],
    "multi": [
        "Shared deterministic mapping reference",
        "EX-WHEN-01",
        "EX-WHEN-02",
        "EX-WHEN-03",
        "EX-STD-04",
        "EX-STD-05",
        "never authorize semantic inference",
        "Pega casting",
        "lexical normalization",
    ],
}

SCHEMA_REQUIRED_IDS = {
    "CM-NAME-001",
    "CF-IDENTITY-001",
    "CF-PRIMARY-001",
    "CF-EXPECTED-STRING-001",
    "CF-PAGE-PARAM-001",
}

@dataclass
class Check:
    status: str
    check: str
    detail: str


def canonical_json_text(text: str) -> str:
    obj = json.loads(text)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def norm_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return "\n".join(line.rstrip() for line in text.strip().split("\n"))


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_expected() -> dict[str, str]:
    return {k: p.read_text(encoding="utf-8") for k, p in EXPECTED_FILES.items()}


def walk(obj: Any) -> Iterable[tuple[str, Any]]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield k, v
            yield from walk(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from walk(v)


def find_rulecode(example: dict[str, Any]) -> dict[str, Any]:
    try:
        return example["UnitTestRules"][0]["RuleCode"]
    except Exception as e:
        raise ValueError("JsonExample missing UnitTestRules[0].RuleCode") from e


def operational_target(example_text: str) -> tuple[str, str]:
    obj = json.loads(example_text)
    rc = find_rulecode(obj)
    rs = rc.get("pyRuleSet")
    rsv = rc.get("pyRuleSetVersion")
    if not isinstance(rs, str) or not rs:
        raise ValueError("JsonExample RuleCode.pyRuleSet missing/empty")
    if not isinstance(rsv, str) or not rsv:
        raise ValueError("JsonExample RuleCode.pyRuleSetVersion missing/empty")
    return rs, rsv


def normalize_example_target(text: str) -> str:
    obj = json.loads(text)
    rc = find_rulecode(obj)
    rc["pyRuleSet"] = "__OPERATIONAL_RULESET__"
    rc["pyRuleSetVersion"] = "__OPERATIONAL_RULESET_VERSION__"
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def schema_required_ids(schema_obj: Any) -> set[str]:
    found: set[str] = set()
    for k, v in walk(schema_obj):
        if isinstance(v, str) and v in SCHEMA_REQUIRED_IDS:
            found.add(v)
        if k in ("id", "ruleId", "mappingId", "invariantId") and isinstance(v, str):
            if v in SCHEMA_REQUIRED_IDS:
                found.add(v)
    # Fallback: extensions are sometimes encoded as object keys.
    raw = json.dumps(schema_obj, ensure_ascii=False)
    for x in SCHEMA_REQUIRED_IDS:
        if x in raw:
            found.add(x)
    return found


def method_param_type_enums(schema_obj: Any) -> list[set[str]]:
    out: list[set[str]] = []
    def rec(o: Any):
        if isinstance(o, dict):
            props = o.get("properties")
            if isinstance(props, dict) and "pyParametersParamType" in props:
                node = props["pyParametersParamType"]
                if isinstance(node, dict) and isinstance(node.get("enum"), list):
                    out.append(set(node["enum"]))
            for v in o.values():
                rec(v)
        elif isinstance(o, list):
            for v in o:
                rec(v)
    rec(schema_obj)
    return out


def named_field_nodes(schema_obj: Any, field_name: str) -> list[dict[str, Any]]:
    vals: list[dict[str, Any]] = []
    def rec(o: Any):
        if isinstance(o, dict):
            props = o.get("properties")
            if isinstance(props, dict) and field_name in props and isinstance(props[field_name], dict):
                vals.append(props[field_name])
            for v in o.values():
                rec(v)
        elif isinstance(o, list):
            for v in o:
                rec(v)
    rec(schema_obj)
    return vals


def node_is_string(schema_obj: dict[str, Any], node: dict[str, Any]) -> bool:
    if node.get("type") == "string":
        return True
    ref = node.get("$ref")
    if isinstance(ref, str) and ref.startswith("#/$defs/"):
        name = ref.split("/")[-1]
        target = schema_obj.get("$defs", {}).get(name)
        return isinstance(target, dict) and target.get("type") == "string"
    return False


def get_capture_text(capture: dict[str, Any], consumer: str, mode: str, kind: str) -> str:
    key = KEYS[mode][kind]
    try:
        value = capture[consumer][mode][key]
    except KeyError as e:
        raise KeyError(f"missing capture path {consumer}.{mode}.{key}") from e
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"empty/non-string capture path {consumer}.{mode}.{key}")
    return value


def add(checks: list[Check], status: str, check: str, detail: str):
    checks.append(Check(status, check, detail))


def verify(capture: dict[str, Any]) -> list[Check]:
    expected = load_expected()
    checks: list[Check] = []

    # 1) Required capture paths and independent consumer retrieval.
    texts: dict[tuple[str, str, str], str] = {}
    for consumer in ("generator", "validator"):
        for mode in ("standard", "multi"):
            for kind in ("ka", "schema", "example"):
                try:
                    text = get_capture_text(capture, consumer, mode, kind)
                    texts[(consumer, mode, kind)] = text
                    add(checks, "PASS", f"capture:{consumer}:{mode}:{kind}", "present and nonempty")
                except Exception as e:
                    add(checks, "FAIL", f"capture:{consumer}:{mode}:{kind}", str(e))

    if any(c.status == "FAIL" and c.check.startswith("capture:") for c in checks):
        return checks

    # 2) Generator/Validator must retrieve identical generation for same mode/key.
    for mode in ("standard", "multi"):
        for kind in ("ka", "schema", "example"):
            g = texts[("generator", mode, kind)]
            v = texts[("validator", mode, kind)]
            try:
                if kind in ("schema", "example"):
                    equal = canonical_json_text(g) == canonical_json_text(v)
                else:
                    equal = norm_text(g) == norm_text(v)
            except Exception as e:
                add(checks, "FAIL", f"same-generation:{mode}:{kind}", f"cannot parse/normalize: {e}")
                continue
            add(
                checks,
                "PASS" if equal else "FAIL",
                f"same-generation:{mode}:{kind}",
                "Generator and Validator retrieved identical content" if equal else "Generator/Validator content diverges",
            )

    # 3) Schemas exact promoted generation + semantic safety checks.
    for mode, exp_key in (("standard", "standard_schema"), ("multi", "multi_schema")):
        actual = texts[("generator", mode, "schema")]
        expected_text = expected[exp_key]
        try:
            actual_obj = json.loads(actual)
            expected_obj = json.loads(expected_text)
        except Exception as e:
            add(checks, "FAIL", f"schema:{mode}:json", f"invalid JSON: {e}")
            continue

        exact = canonical_json_text(actual) == canonical_json_text(expected_text)
        add(
            checks,
            "PASS" if exact else "REVIEW",
            f"schema:{mode}:promoted-generation",
            "canonical JSON equals promoted Stage-3 schema" if exact else "schema differs from promoted Stage-3; semantic revision requires explicit acceptance",
        )

        ids = schema_required_ids(actual_obj)
        missing_ids = sorted(SCHEMA_REQUIRED_IDS - ids)
        add(
            checks,
            "PASS" if not missing_ids else "FAIL",
            f"schema:{mode}:compiler-invariants",
            "required CM/CF ids present" if not missing_ids else f"missing {missing_ids}",
        )

        enums = method_param_type_enums(actual_obj)
        if not enums:
            add(checks, "FAIL", f"schema:{mode}:formal-types", "no pyParametersParamType enum found")
        else:
            bad = [sorted(e) for e in enums if e != FORMAL_TYPES]
            add(
                checks,
                "PASS" if not bad else "FAIL",
                f"schema:{mode}:formal-types",
                f"all pyParametersParamType enums equal {sorted(FORMAL_TYPES)}" if not bad else f"unexpected enum(s): {bad}",
            )

        value_nodes = named_field_nodes(actual_obj, "pyParametersParamValue")
        bad_param_value_nodes = [x for x in value_nodes if not node_is_string(actual_obj, x)]
        add(
            checks,
            "PASS" if value_nodes and not bad_param_value_nodes else "FAIL",
            f"schema:{mode}:parameter-value-string",
            f"{len(value_nodes)} pyParametersParamValue definition(s), all resolve to string" if value_nodes and not bad_param_value_nodes else f"non-string nodes={bad_param_value_nodes}",
        )

        expected_nodes = named_field_nodes(actual_obj, "pyExpectedValue")
        bad_expected_nodes = [x for x in expected_nodes if not node_is_string(actual_obj, x)]
        add(
            checks,
            "PASS" if expected_nodes and not bad_expected_nodes else "FAIL",
            f"schema:{mode}:expected-value-string",
            f"{len(expected_nodes)} pyExpectedValue definition(s), all resolve to string" if expected_nodes and not bad_expected_nodes else f"non-string nodes={bad_expected_nodes}",
        )

    # 4) Shared KnowledgeArea exact promoted text or explicit-review semantic revision.
    for mode, exp_key in (("standard", "standard_ka"), ("multi", "multi_ka")):
        actual = texts[("generator", mode, "ka")]
        expected_text = expected[exp_key]
        exact = norm_text(actual) == norm_text(expected_text)
        add(
            checks,
            "PASS" if exact else "REVIEW",
            f"knowledge:{mode}:promoted-generation",
            "normalized text equals promoted A8C shared reference" if exact else "KnowledgeArea differs; may be semantically equivalent but requires explicit acceptance",
        )
        missing = [m for m in KA_REQUIRED_MARKERS[mode] if m not in actual]
        add(
            checks,
            "PASS" if not missing else "FAIL",
            f"knowledge:{mode}:required-reference-content",
            "all required A8C shared-reference markers present" if not missing else f"missing markers: {missing}",
        )

    # 5) JsonExamples must be current canonical fixture generation except operational target fields.
    for mode, exp_key in (("standard", "standard_example"), ("multi", "multi_example")):
        actual = texts[("generator", mode, "example")]
        expected_text = expected[exp_key]
        try:
            exact_except_target = normalize_example_target(actual) == normalize_example_target(expected_text)
        except Exception as e:
            add(checks, "FAIL", f"example:{mode}:canonical-generation", f"invalid shape/JSON: {e}")
            continue
        add(
            checks,
            "PASS" if exact_except_target else "REVIEW",
            f"example:{mode}:canonical-generation",
            "matches promoted canonical fixture after operational ruleset normalization" if exact_except_target else "example differs beyond pyRuleSet/pyRuleSetVersion; explicit acceptance required",
        )
        try:
            rs, rsv = operational_target(actual)
            add(checks, "PASS", f"example:{mode}:operational-target", f"pyRuleSet={rs!r}, pyRuleSetVersion={rsv!r}")
        except Exception as e:
            add(checks, "FAIL", f"example:{mode}:operational-target", str(e))

    # 6) Standard/Multi operational target must be identical, and G/V are already identical by step 2.
    try:
        std_target = operational_target(texts[("generator", "standard", "example")])
        mul_target = operational_target(texts[("generator", "multi", "example")])
        same = std_target == mul_target
        add(
            checks,
            "PASS" if same else "FAIL",
            "example:operational-target-consistency",
            f"Standard/Multi target both {std_target}" if same else f"Standard={std_target}, Multi={mul_target}",
        )
    except Exception as e:
        add(checks, "FAIL", "example:operational-target-consistency", str(e))

    return checks


def summarize(checks: list[Check]) -> str:
    statuses = [c.status for c in checks]
    if "FAIL" in statuses:
        return "FAIL"
    if "REVIEW" in statuses:
        return "REVIEW"
    return "PASS"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("capture", type=Path, help="A4 live capture JSON")
    ap.add_argument("--json-report", type=Path, default=None)
    args = ap.parse_args()

    capture = json.loads(args.capture.read_text(encoding="utf-8"))
    checks = verify(capture)
    overall = summarize(checks)

    for c in checks:
        print(f"[{c.status:6}] {c.check}: {c.detail}")
    print(f"\nOVERALL={overall}")

    if args.json_report:
        args.json_report.write_text(
            json.dumps(
                {"overall": overall, "checks": [c.__dict__ for c in checks]},
                indent=2,
                ensure_ascii=False,
            ) + "\n",
            encoding="utf-8",
        )

    return 0 if overall == "PASS" else (2 if overall == "REVIEW" else 1)


if __name__ == "__main__":
    sys.exit(main())
