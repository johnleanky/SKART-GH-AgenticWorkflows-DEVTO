# A6 Project Decision — Pega 26.x Casting Matrix Authority

**Status:** ACCEPTED USER DECISION  
**Date:** 2026-09-12

## Decision

For the RuleIQ Unit Test Pipeline, the documented Pega **Data type conversions (casting) in expressions and property assignments** matrix is authoritative for Pega 26.x.

The fact that the full public matrix is hosted on legacy-version Pega documentation does **not** create a version-specific uncertainty for this project. The project explicitly accepts that Pega 26.x has not changed these type-conversion semantics.

Therefore:

- Scenario Author MUST execute the documented matrix when source and destination types require conversion.
- Author MUST NOT downgrade a documented matrix result to `unknown` merely because the public page is from an older Pega documentation version.
- Author MUST still respect details that the matrix/documentation itself genuinely leaves unspecified.
- Generator and Validator MUST NOT implement a competing casting model.
- A9 runtime tests, if performed, verify RuleIQ implementation/integration and target payload behavior; they are **not** required to establish that the matrix applies to Pega 26.x.
- This decision does not claim that any RuleIQ-generated Candidate has already been executed successfully in Pega runtime.

## Relationship to A6

This decision strengthens the evidence status of `A6_DATA_CASTING_MATRIX_AMENDMENT.md` only. It does not change the A6 ownership model:

`Scenario Author -> typed semantic execution/casting -> frozen Projection -> Generator target serialization -> Validator fidelity verification`.
