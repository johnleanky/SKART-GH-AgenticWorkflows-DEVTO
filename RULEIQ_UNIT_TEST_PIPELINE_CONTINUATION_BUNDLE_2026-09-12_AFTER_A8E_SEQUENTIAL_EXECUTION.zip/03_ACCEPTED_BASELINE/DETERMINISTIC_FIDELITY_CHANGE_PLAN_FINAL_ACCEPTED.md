# Deterministic Projection Fidelity — Cross-Agent Change Plan

Date: 2026-09-12

Applies to:
- UnitTestGenerator
- UnitTestValidator
- Agent-to-Agent invocation contracts
- later small Scenario Author handoff amendment

Current Generator source of truth before amendment:
`UnitTestGenerator_Prompt_REFACTORED_FINAL_ACCEPTED.txt`

Related existing plans:
- `UNIT_TEST_GENERATOR_POST_ACCEPTANCE_AMENDMENT_PLAN.md`
- `VALIDATOR_REFCTORING_PLAN_V2.md`
- `AGENT_TO_AGENT_INVOCATION_CONTRACT_AMENDMENT.md`

This document supersedes the overlapping fidelity/repair portions of those plans and should be used as the authoritative plan for the newly agreed architecture.

---

# 0. Architectural decision

The system will use **independent deterministic Projection Fidelity Validation**.

The Validator does **not** validate whether the Scenario itself is semantically correct.

The Validator validates only:

> whether the persisted UnitTestCandidate faithfully represents the explicit facts contained in the persisted UnitTestProjectionV3 according to an enumerated deterministic mapping contract.

The Validator must never:
- reinterpret Scenario meaning;
- decide that an expected value “should really be” something else;
- add missing assertions that are absent from Projection;
- change Scenario membership/order;
- infer additional simulations;
- revise confidence/testability/dependency closure;
- derive business truth;
- propose replacement semantic values.

If a fidelity check cannot be expressed as a closed deterministic comparison, **that check is forbidden**.

---

# 1. Core invariant

The fidelity layer checks only:

`Candidate == Compile(Projection)`

for explicitly enumerated mappings.

It does not check:

`Projection == BusinessTruth`.

This creates four separate responsibilities:

1. **Scenario Author**
   - semantic truth;
   - Scenario selection;
   - expected values;
   - simulations;
   - assertions;
   - confidence/testability;
   - UnitTestProjectionV3.

2. **UnitTestGenerator**
   - deterministic compilation of ProjectionV3 into UnitTestCandidate;
   - G7 pre-write self-check;
   - deterministic repair from frozen Projection.

3. **UnitTestValidator**
   - independent post-write Projection→Candidate fidelity comparison;
   - formal schema disposition via JsonValidationTool;
   - documentation/Pega structural validation.

4. **Runtime test execution**
   - verifies actual behavior of the generated Pega unit test / RUT.

---

# 2. Non-negotiable fidelity safety rules

These rules are mandatory. If they cannot be enforced textually and operationally, Projection Fidelity Validation should not be enabled.

## F1 — immutable source

Validator reads persisted UnitTestProjectionV3 but never writes or edits it.

Generator repairs never modify Projection.

Any semantic correction requires a new Author projection.

## F2 — immutable persisted candidate versions

Validator never writes candidate JSON.

Generator never mutates a written candidate.

Each repair produces a new candidate GUID.

## F3 — closed fidelity whitelist

Validator may run a fidelity check only if the mapping appears in the approved `Projection Fidelity Matrix`.

No open-ended instruction such as:
- “check whether the unit test makes sense”;
- “verify semantic correctness”;
- “ensure the candidate properly tests the scenario”;
- “infer missing checks”.

## F4 — allowed comparison operators only

Fidelity checks are limited to explicitly defined forms:

- exact decoded-value equality;
- presence equality;
- absence equality;
- exact count/cardinality;
- exact ordered sequence;
- exact index correlation;
- exact set/census only when order is explicitly irrelevant;
- deterministic scalar conversion;
- deterministic string construction;
- deterministic constant;
- deterministic structural placement.

Anything requiring judgment is outside fidelity scope.

## F5 — no Validator replacement values

ValidatorReport must never contain:
- `newValue`;
- `correctValue`;
- replacement expected value;
- replacement When result;
- replacement Scenario metadata;
- replacement simulation data;
- suggested assertion content.

Validator reports **where and how the candidate differs**, not what semantic value to write.

## F6 — repair source of truth is Projection

For any fidelity repair, Generator must retrieve/use the frozen Projection fact and rerun the authoritative mapping.

Never patch candidate using a value supplied in Validator prose.

## F7 — rebuild fragment, do not patch semantic leaf

Preferred repair behavior:

`Projection source fragment`
→ authoritative Generator mapping
→ rebuilt target fragment
→ full G7
→ new immutable candidate.

Do not directly assign:
`candidate[path] = validatorSuggestedValue`.

## F8 — no Author-semantic inference

If fixing an issue would require deciding:
- what assertion should have existed;
- what expected value is logically correct;
- whether a simulation is needed;
- what When result should be;
- which Scenario is better;

Validator must not issue `GENERATOR_REPAIR`.

Route must be non-repair (`HUMAN` or another explicit non-repair route according to final catalog).

## F9 — deterministic-repair proof

Before a fidelity issue is allowed to authorize Generator repair, the plan must prove:

> Given the frozen Projection and authoritative Generator mapping, there is exactly one target representation to rebuild.

If not, repair authorization is forbidden.

## F10 — independent verification remains independent

Generator G7 and Validator fidelity intentionally overlap in compared facts but not in trust boundary:

- G7: pre-write self-check performed by compiler;
- Validator: post-write persisted-source verification performed independently.

Neither gate is removed.

---

# 3. Pega Agent-to-Agent invocation contract

Agent invocation is one `question`, not a typed RPC call.

## 3.1 Author -> Generator

Canonical question:

```text
Generate the UnitTestCandidate for the exact persisted UnitTestProjection.

Invocation:
{"CaseID":"<...>","RUTType":"<...>","UnitTestProjectionUUID":"<...>"}

Return only the GeneratorRunReport required by your system instructions.
```

Generator parses exactly one Invocation object.

## 3.2 Generator -> Validator

Canonical question:

```text
Validate the exact persisted UnitTestCandidate against its exact persisted UnitTestProjection source and the deployed unit-test contract.

Invocation:
{"CaseID":"<...>","RUTType":"<...>","UnitTestProjectionUUID":"<...>","UnitTestCandidateUUID":"<...>"}

Return only the ValidatorReport required by your system instructions.
```

No candidate payload or projection payload is copied into the question.

Validator independently reads both persisted objects.

---

# 4. Required ValidatorReport correlation

Target report should include exact identities for both persisted objects.

Preferred envelope:

```text
{
  "CaseID": "...",
  "RUTType": "...",
  "sourceUUID": "...",
  "UnitTestCandidateUUID": "...",
  "groupId": "...",
  "route": "...",
  "blocking": 0,
  "warnings": 0,
  "issues": [...]
}
```

Where:

`sourceUUID == UnitTestProjectionUUID`.

Generator must reject a report if any of these mismatch:
- CaseID;
- RUTType;
- sourceUUID;
- UnitTestCandidateUUID;
- groupId after successful exact dual read.

---

# 5. Fidelity issue design

Fidelity diagnostics should identify mismatch without carrying semantic replacement content.

Recommended issue model remains compatible with existing report shape where possible:

```text
{
  "severity":"B",
  "code":"...",
  "action":"RESTORE_FROM_PROJECTION",
  "scenario":0,
  "path":"/candidate/path",
  "message":"Candidate expected-value presence differs from Projection assertion[2]."
}
```

The `message` may identify:
- source coordinate;
- candidate coordinate;
- mismatch class.

It must not provide a new semantic value.

---

# 6. Fidelity issue classes

The final catalog should prefer a small set of precise deterministic mismatch classes.

Candidate classes to evaluate:

## PF_SCENARIO_MISMATCH
For:
- scenario count;
- scenario order;
- scenario pass-through field equality.

Action:
`RESTORE_FROM_PROJECTION`.

## PF_RUT_CONTEXT_MISMATCH
For:
- rut name;
- apply-to class;
- singlePage representation;
- primary page/class;
- Pages & Classes deterministic mapping;
- RUT instance name;
- RUT type.

Action:
`RESTORE_FROM_PROJECTION`.

## PF_PARAMETER_MISMATCH
For:
- parameter count/order;
- name;
- value presence/value;
- PAGE marker;
- deterministic scalar stringification.

Action:
`RESTORE_FROM_PROJECTION`.

## PF_SETUP_ACTION_MISMATCH
For:
- setup page count/order/data;
- action count/order/type/name/target page;
- action parameters;
- cleanup actions.

Action:
`RESTORE_FROM_PROJECTION`.

## PF_SIMULATION_MISMATCH
For:
- simulation count/order;
- runtimeClass;
- rule;
- setup pages;
- source payload facts;
- deterministic simulation constants where fidelity mapping owns them.

Action:
`RESTORE_FROM_PROJECTION`.

## PF_ASSERTION_MISMATCH
For Standard assertions:
- count/order;
- assertion kind;
- source page/context;
- path;
- comparator;
- expected presence;
- expected decoded value;
- optional source fields;
- deterministic target derivations.

Action:
`RESTORE_FROM_PROJECTION`.

## PF_WHEN_ROW_MISMATCH
For:
- row count/order;
- Scenario↔row index;
- input count/order/path;
- input value presence/value;
- result boolean;
- deterministic Result/input conversion.

Action:
`RESTORE_FROM_PROJECTION`.

## PF_EXTRA_TARGET_CONTENT
For candidate semantic content with no allowed Projection/target owner.

Action:
`REBUILD_FROM_PROJECTION`.

Final code granularity must be decided during catalog audit. Do not add these names to production until Generator and Validator catalogs are synchronized.

---

# 7. What fidelity validation explicitly must not check

Forbidden examples:

- “expected 100 looks wrong; use 200”;
- “Scenario should contain another assertion”;
- “there should probably be another Data Page simulation”;
- “confidence should be Medium”;
- “dependency closure is not convincing”;
- “When result should logically be false”;
- “this assertion is not useful”;
- “the Scenario should test another branch”;
- “business logic implies a different expected value”.

These are Author/runtime concerns, not Projection fidelity.

---

# 8. Projection Fidelity Matrix requirements

Before fidelity validation is implemented, create a complete matrix with one row per deterministic mapping.

Required columns:

`ID`
`Mode`
`ProjectionPath`
`CandidatePath`
`MappingType`
`Transform`
`Comparison`
`OrderSensitive`
`PresenceSensitive`
`Repairable`
`RepairSource`
`ValidatorIssueCode`
`Notes`

Allowed `MappingType`:
- `SOURCE_COPY`
- `DERIVED`
- `CONSTANT`
- `TARGET_ONLY`
- `TEMPLATE_ONLY`

Allowed `Comparison`:
- `EXACT_VALUE`
- `EXACT_PRESENCE`
- `EXACT_COUNT`
- `EXACT_ORDER`
- `EXACT_INDEX`
- `DETERMINISTIC_TRANSFORM`
- `NO_FIDELITY_CHECK`

Every row marked `Repairable=YES` must have:
`RepairSource=PROJECTION_OR_MAPPING`.

Never:
`RepairSource=VALIDATOR_MESSAGE`.

---

# 9. Generator repair model changes

The existing repair lifecycle remains:
- v0;
- v1;
- v2;
- max 2 repair attempts;
- max 3 validation attempts;
- immutable candidate versions.

But `GENERATOR_REPAIR` authority must now have two explicit classes.

## 9.1 TARGET_REPAIR

For:
- schema;
- target placement;
- documented Pega structure;
- deterministic formatting;
- candidate-only serialization defect.

Repair source:
- target schema;
- Knowledge documentation;
- authoritative Generator mapping;
- frozen Projection where needed.

## 9.2 FIDELITY_REPAIR

For:
- persisted candidate differs from persisted Projection under an approved deterministic mapping.

Repair source:
- frozen Projection;
- authoritative mapping only.

Validator provides:
- mismatch code;
- candidate coordinate;
- source coordinate/class;
- action authorization.

Validator does not provide:
- replacement semantic value.

## 9.3 New repair invariant

Replace any wording equivalent to:

> repair never changes expected values / When results / simulations / setup actions

with:

> repair may change any candidate field necessary to restore exact fidelity to the frozen UnitTestProjection or deterministic target contract, but must never change, reinterpret, or override the UnitTestProjection source fact itself.

This allows correcting a wrong candidate expected value back to the Projection value without allowing semantic invention.

---

# 10. Generator G7 after repair

Every repair version must pass full G7 before WriteMemory.

For a fidelity repair:

1. identify affected source coordinate;
2. rebuild candidate fragment from Projection + mapping;
3. integrate into new in-memory candidate;
4. rerun **full** G7, not only affected path;
5. WriteMemory new candidate GUID;
6. invoke Validator with same sourceUUID + new candidate UUID.

If full G7 fails:
- do not write repaired candidate;
- return `PROJECTION_FAILED` or the final agreed internal failure code.

---

# 11. Validator validation layers

Validator executes three independent validation dimensions.

## Layer 1 — FORMAL_SCHEMA

Owner:
`JsonValidationTool`.

No LLM duplication of ordinary schema keywords after successful deterministic validation.

## Layer 2 — PROJECTION_FIDELITY

Owner:
Validator, but only through the approved deterministic matrix.

No free-form semantic reasoning.

## Layer 3 — DOCUMENTATION_PEGA

Owner:
Validator model.

Uses:
- schema descriptions/comments;
- KnowledgeArea structural documentation;
- candidate-visible cross-field Pega rules.

Still may not modify or reinterpret Projection semantics.

---

# 12. Recommended validation order

Target flow:

1. parse one question Invocation envelope;
2. select target family;
3. run JsonValidationTool;
4. exact read UnitTestProjectionV3;
5. exact read UnitTestCandidate;
6. verify CaseID/GUID/Type/group correlation;
7. determine mode;
8. deterministic Projection Fidelity Matrix checks;
9. acquire normative schema/Knowledge documentation;
10. documentation/Pega checks;
11. aggregate issues;
12. return ValidatorReport.

A later implementation may reorder schema/read steps only if tool contracts require it, but the three validation dimensions remain distinct.

---

# 13. Route rules

## OK

No blocking formal-schema, fidelity, or documentation issue.

## GENERATOR_REPAIR

Allowed only if every blocking repair issue has a uniquely derivable repair from:
- frozen Projection;
- deterministic mapping;
- target schema/documentation.

## HUMAN

Use when:
- fidelity cannot be determined mechanically;
- source/candidate identity is ambiguous;
- documentation conflicts;
- repair requires semantic judgment;
- replacement would require inventing a source fact;
- tool evidence is malformed/uncertain.

## SEMANTIC_REJECT

Keep narrow.

It must not mean:
“Validator disagrees with Author semantics”.

Use only for candidate-visible/documented states that cannot be represented safely without changing source semantics, according to final catalog policy.

---

# 14. Master implementation plan

Implementation and validation remain separate.

---

# Stage M1 — Freeze contracts and build deterministic fidelity matrix

No production prompt edits.

## M1.1 Freeze Generator + Validator baselines

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Map:
- current accepted Generator;
- current Validator Stage-3;
- existing amendment plans.

Identify all affected sections.

## M1.2 Finalize one-question invocation envelopes

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Freeze:
- Author→Generator envelope;
- Generator→Validator envelope;
- exact key names;
- sourceUUID terminology.

## M1.3 Finalize dual persisted-object correlation

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Specify exact reads:
- Projection UUID;
- Candidate UUID;
- CaseID;
- Type;
- groupId.

## M1.4 Build complete Projection Fidelity Matrix

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Cover:
- informational;
- common scenario metadata;
- executable context;
- params;
- setup/cleanup;
- simulations;
- Standard assertions;
- When rows.

Every fidelity check must be deterministic.

## M1.5 Forbidden-semantic-check audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

For every proposed check ask:

> Can the required candidate representation be computed mechanically from explicit Projection fields + approved mapping?

If `NO`:
- mark `NO_FIDELITY_CHECK`;
- Validator must not diagnose it as fidelity mismatch.

## M1.6 Fidelity repairability audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

For every repairable check prove:
- one source coordinate;
- one authoritative mapping;
- one allowed target representation class.

If not unique:
- repair forbidden;
- route HUMAN.

## M1 validation corrections

M1 validation tightened the matrix before gate acceptance:
- ambiguous/conditional mappings became explicit `NO_FIDELITY_CHECK`;
- numeric/boolean scalar stringification remains disabled until canonicalized;
- generic semantic/opaque inference is forbidden;
- repairable rows have Projection/mapping-only repair authority.

## Stage M1 gate

Do not edit either prompt until M1.1–M1.6 are `COMPLETED + VALIDATED`.

Required artifacts:
- `M1_INVOCATION_CONTRACT.md`
- `M1_DUAL_READ_CORRELATION.md`
- `M1_PROJECTION_FIDELITY_MATRIX.md`
- `M1_FORBIDDEN_SEMANTIC_CHECKS.md`
- `M1_FIDELITY_REPAIRABILITY_AUDIT.md`
- `M1_VALIDATION.md`

---

# Stage M2 — Validator contract amendment

## M2.1 Replace typed input with one-question parser

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M2.2 Add exact Projection + Candidate reads

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M2.3 Implement deterministic fidelity engine instructions

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Prompt must explicitly say:
- only M1 matrix checks;
- only allowed comparison operators;
- no semantic inference;
- no replacement values;
- no new source facts.

## M2.4 Preserve formal schema validation separation

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M2.5 Preserve documentation-aware validation

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M2.6 Redesign fidelity diagnostics

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Issues identify mismatch and action, never corrected semantic values.

## M2.7 Add sourceUUID to ValidatorReport

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M2.8 Close route rules

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Mechanical only → repair.
Semantic uncertainty → HUMAN.

## M2 validation corrections

Separate validation tightened the implemented Validator contract:
- exact GetMemory response names;
- fail-closed MASS classification;
- malformed source traversal -> HUMAN, never repair;
- Page-class conditionality restored;
- documentation/formal/fidelity duplication blocked;
- legacy pairs treated as protocol placeholders;
- invalid invocation coordinate fixed.

## Stage M2 gate

Validator candidate must pass textual guardrail review before Generator repair changes are implemented.

---

# Stage M3 — Generator invocation + independent-validation amendment

## M3.1 Replace inbound scalar pseudo-signature

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M3.2 Normalize UnitTestProjectionUUID terminology

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M3.3 Replace Validator pseudo-signature with one-question call

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M3.4 Pass sourceUUID + candidate UUID to Validator

**Implementation:** COMPLETED  
**Validation:** VALIDATED

## M3.5 Validate returned source/candidate correlation

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Mismatch → `VALIDATOR_RESPONSE_INVALID`.

## M3.6 Update G7 rationale

**Implementation:** COMPLETED  
**Validation:** VALIDATED

G7 = pre-write self-check.
Validator = independent post-write verifier.

Keep all G7 checks.

## M3 validation corrections

Separate validation tightened correlation only:
- invalid Generator invocation -> `sourceUUID=null, groupId=null`;
- null group allowed only for the explicit pre-dual-correlation code set;
- Invocation envelope must be valid JSON with normal escaping.

Compiler mappings, G7 checks, repair semantics and catalog remain unchanged.

---

# Stage M4 — Generator fidelity repair amendment

## M4.1 Split repair authority

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Define:
- TARGET_REPAIR;
- FIDELITY_REPAIR.

Do not necessarily add these as report fields; they may be internal action classes derived from issue codes.

## M4.2 Replace over-broad “never change expected values” rule

**Implementation:** COMPLETED  
**Validation:** VALIDATED

New rule:

Generator may modify candidate fields to restore exact Projection fidelity, but may never modify/reinterpret Projection facts.

## M4.3 Enforce restore-from-source only

**Implementation:** COMPLETED  
**Validation:** VALIDATED

For fidelity issues:
- ignore any semantic replacement suggestion in message;
- locate source fact;
- rerun mapping;
- rebuild fragment.

## M4.4 Full G7 after every repair

**Implementation:** COMPLETED  
**Validation:** VALIDATED

No targeted-only G7.

## M4.5 Immutable new candidate version

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Retain v1/v2 limits.

## M4.6 Revalidate repaired candidate independently

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Same sourceUUID, new candidate UUID.

## M4 validation corrections

Separate validation tightened repair safety:
- admitted-but-insufficient repair -> HUMAN, not protocol-invalid;
- report route must match route recomputed from issues;
- overlapping repairs must reconstruct one identical fragment state or stop;
- pre-M5 catalog wording no longer implies synchronization already happened.

Compiler mappings, G7 checks and PF protocol activation remain unchanged.

---

# Stage M5 — Cross-agent issue/action catalog synchronization

## M5.1 Audit existing catalog

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Classify every issue:
- formal schema;
- fidelity;
- documentation;
- tool integrity;
- ambiguous/human.

## M5.2 Remove ambiguous overloaded meanings

**Implementation:** COMPLETED  
**Validation:** VALIDATED

One code should not simultaneously mean:
- source mismatch;
- schema shape problem;
- documentation problem.

## M5.3 Add minimum necessary fidelity codes

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Prefer coarse but precise deterministic classes over dozens of semantic subcodes.

## M5.4 Synchronize Generator allowed pairs

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Generator must accept exactly every Validator-emittable pair.

## M5.5 Verify no issue carries replacement semantics

**Implementation:** COMPLETED  
**Validation:** VALIDATED

No issue/message/action may be interpreted as a new semantic source value.

## M5 validation corrections

Separate validation tightened the synchronized protocol:
- every current M5 issue code is blocking-only (`severity=B`, `warnings=0`);
- group correlation now occurs immediately after both successful Memory reads and before payload parsing;
- null-group AMBIGUOUS is accepted only for exact `/Correlation` mismatch.

The exact 14 code/action pairs did not change.

---

# Stage M6 — Final prompt construction

## M6.1 Produce amended Validator prompt

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Target responsibility blocks:
1. role + one-question invocation;
2. schema target + deterministic tool gate;
3. exact dual persisted reads;
4. deterministic Projection fidelity;
5. documentation/Pega validation;
6. diagnostics/routes;
7. exact ValidatorReport.

## M6.2 Produce amended Generator prompt

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Use accepted Generator as base.

Change only:
- inbound question parsing;
- source UUID terminology;
- Validator handoff/report;
- G7 rationale;
- repair authority;
- issue catalog compatibility.

Do not alter mapping/compiler sections except cross-references required by the new repair contract.

## M6.3 Prepare small Scenario Author handoff amendment

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Author calls Generator with one question containing:
- CaseID;
- RUTType;
- UnitTestProjectionUUID.

No Author semantic behavior changes.

---

# Stage M7 — Final textual acceptance

## M7 acceptance corrections

Final acceptance corrected only production wording/state consistency:
- removed stale pre-synchronization wording from Generator;
- clarified that source immutability applies to Projection expected values/When results while candidate repair may restore them from Projection;
- removed historical stage labels from Validator.

No compiler mapping, fidelity rule, G7 check, catalog pair, repair budget or Author semantic behavior changed.


No runtime/model/Pega tests.

## M7.1 Deterministic-fidelity coverage audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Every M1 matrix row has:
- exact Validator check;
- exact allowed comparison;
- exact Generator repairability disposition.

## M7.2 Semantic-safety audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Search final Validator prompt for any instruction allowing:
- semantic inference;
- expected-value correction;
- missing-assertion invention;
- scenario reinterpretation;
- repair value proposal.

All must be absent.

## M7.3 Repair-source audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Every fidelity repair derives from:
- Projection;
- mapping;
- target contract.

Never Validator message value.

## M7.4 G7 preservation audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Existing G7 coverage unchanged.

## M7.5 Agent invocation audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

All Agent handoffs use one question envelope.

## M7.6 Report/correlation audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Exact:
- CaseID;
- RUTType;
- sourceUUID;
- candidate UUID;
- groupId.

## M7.7 Issue catalog compatibility audit

**Implementation:** COMPLETED  
**Validation:** VALIDATED

Validator and Generator catalogs exactly synchronized.

## M7.8 Final acceptance report

**Implementation:** COMPLETED  
**Validation:** VALIDATED

State textual-only evidence boundary.

---

# 15. Stop conditions

The fidelity feature must be disabled/deferred if any of these remain unresolved:

1. Projection source cannot be read by exact UUID.
2. Candidate cannot be correlated to the same source group.
3. A proposed fidelity check requires semantic interpretation.
4. A repair requires a value not explicitly available from Projection/mapping.
5. ValidatorReport cannot identify exact source + candidate.
6. Generator cannot rebuild the affected fragment deterministically.
7. Validator and Generator issue catalogs cannot be synchronized.
8. Documentation conflicts make the target representation non-unique.

In these cases:
- do not guess;
- do not “best effort” repair;
- route to HUMAN or defer the check.

---

# 16. Recommended execution order

1. Execute M1 completely.
2. Validate M1 independently.
3. Implement M2 Validator contract.
4. Validate M2 guardrails before enabling fidelity repair.
5. Implement M3 Generator invocation/correlation.
6. Implement M4 Generator fidelity repair.
7. Synchronize M5 issue catalog.
8. Build final prompts M6.
9. Perform textual acceptance M7.
10. Only after textual acceptance consider runtime/Pega evaluation as a separate project.

---

# 17. Final design statement

The system should be able to make this guarantee:

> Validator may report only deterministic evidence that the persisted candidate differs from the persisted Projection or violates the target contract. Validator cannot author, replace, or reinterpret Scenario semantics. Generator may repair only by recompiling the affected candidate structure from the immutable Projection and authoritative target mapping.

If that guarantee cannot be maintained for a proposed check, that check is excluded from fidelity validation.
