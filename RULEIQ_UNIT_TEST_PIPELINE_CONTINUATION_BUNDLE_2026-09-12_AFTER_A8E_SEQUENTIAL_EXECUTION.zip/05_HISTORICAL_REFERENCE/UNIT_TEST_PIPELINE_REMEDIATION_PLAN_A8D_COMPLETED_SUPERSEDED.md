# RuleIQ Unit Test Pipeline — A8D Single-Record Memory Contract Refactoring Plan

**Status:** COMPLETED STATIC/DESIGN — A8D PROMOTED; A4 LIVE DEPLOYMENT OPEN; A9 RUNTIME NOT RUN  
**Date:** 2026-09-12  
**Baseline:** promoted A8C example-driven prompt baseline + A4 static deployment-preparation bundle.  
**Scope:** refactor every active Memory-tool contract from batch/carrier semantics to one-record-per-call semantics for `WriteMemory`, `GetMemory`, and `UpdateMemory`.  
**Out of scope:** KnowledgeTool `pxResults`, RuleCrawler batches, Scenario grouping semantics, Projection/Candidate payload schemas, Pega Data Casting Matrix, target compiler mappings, A4 live deployment verification, and A9 runtime execution.

The previous active A8C plan is archived as:

`05_HISTORICAL_REFERENCE/UNIT_TEST_PIPELINE_REMEDIATION_PLAN_A8C_COMPLETED_SUPERSEDED.md`

This document **replaces the previous active plan content**. A8C remains the immutable behavioral baseline except for the Memory-tool interface changes explicitly authorized here.

---

# 1. Objective

Replace the current batch-shaped Memory protocol (`RequestsJSON`, `ResultsJSON`, Memory `pxResults[]`) with the smallest useful single-record contract:

```text
WriteMemory(pxCaseID, Type, pyGroup, pyPayload)
GetMemory(pxCaseID, pyGUID)
UpdateMemory(pxCaseID, pyGUID, pyStatusValue, pyRouterKey)
```

Each tool invocation operates on exactly one Memory record. If batch behavior is required later, it must be implemented as a separate explicitly named tool; it must not be added implicitly to these three contracts.

The refactor must preserve all accepted persistence semantics:

- `WriteMemory` is create-only;
- `GetMemory` is read-only;
- `UpdateMemory` changes lifecycle metadata only;
- `pyPayload` is immutable after creation;
- a repaired Candidate is a new record with a new `pyGUID`;
- there is no persisted `Pending` update;
- no agent may continue as though a failed/unconfirmed mutation succeeded.

---

# 2. Mandatory two-status execution model

Every A8D stage has two independent mandatory statuses:

- **Change Status** — whether the required artifact changes are complete.
- **Validation Status** — whether those completed changes have passed their dedicated validation step.

Allowed values:

```text
Change Status:
  NOT_STARTED | IN_PROGRESS | CHANGE_COMPLETE | BLOCKED

Validation Status:
  NOT_STARTED | IN_PROGRESS | VALIDATION_COMPLETE | FAILED | BLOCKED
```

A stage is **COMPLETED** only when:

```text
Change Status     = CHANGE_COMPLETE
AND
Validation Status = VALIDATION_COMPLETE
```

A change step and its validation step must be executed separately. Validation may not be marked complete in the same logical operation that edits the artifacts it validates.

No later stage may be promoted over an earlier stage whose Change Status or Validation Status is incomplete, except read-only inventory work explicitly required to prepare the later stage.

---

# 3. Canonical A8D Memory API

## 3.1 WriteMemory

Input:

```text
WriteMemory(
  pxCaseID=<nonempty case id>,
  Type=<nonempty artifact type>,
  pyGroup=<nonempty logical group>,
  pyPayload=<complete immutable payload string>
)
```

Success response:

```json
{
  "success": true,
  "pyGUID": "<new nonempty GUID>",
  "pyGroup": "<exact input pyGroup>",
  "errorCode": "",
  "errorMessage": ""
}
```

Failure response:

```json
{
  "success": false,
  "pyGUID": "",
  "pyGroup": "<exact input pyGroup>",
  "errorCode": "WRITE_FAILED",
  "errorMessage": "<diagnostic text>"
}
```

Rules:
- exactly one record per call;
- create-only;
- agent never supplies `pyGUID` on create;
- no `RequestsJSON`, `ResultsJSON`, Memory `pxResults[]`, list carrier, partial-success semantics, or batch correlation;
- any tool exception, malformed response, `success!=true`, wrong echoed `pyGroup`, empty/reused GUID, or nonempty success error fields is treated by the caller as write failure;
- no retry by the agent after an unconfirmed/failed create.

## 3.2 GetMemory

Input:

```text
GetMemory(
  pxCaseID=<nonempty case id>,
  pyGUID=<exact immutable GUID>
)
```

Success response:

```json
{
  "success": true,
  "pxCaseID": "<stored case id>",
  "pyType": "<stored artifact type>",
  "pyGroup": "<stored group>",
  "pyGUID": "<exact GUID>",
  "pyPayload": "<stored immutable payload>",
  "pyStatusValue": "<stored lifecycle status or empty>",
  "pyRouterKey": "<stored router key or empty>",
  "errorCode": "",
  "errorMessage": ""
}
```

Not found:

```json
{
  "success": false,
  "pyGUID": "<requested GUID>",
  "errorCode": "NOT_FOUND",
  "errorMessage": "Memory record was not found"
}
```

Rules:
- exact single-record lookup by unique `pyGUID`, guarded by `pxCaseID` ownership/correlation;
- no list/empty-list result semantics;
- `NOT_FOUND` is terminal for the current required-artifact operation;
- any exception/malformed response is a caller-side Memory read failure; no substitute row or inferred latest record.

## 3.3 UpdateMemory

Input:

```text
UpdateMemory(
  pxCaseID=<nonempty case id>,
  pyGUID=<exact Candidate GUID>,
  pyStatusValue=<Passed|Failed>,
  pyRouterKey=<OK|GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>
)
```

Success response:

```json
{
  "success": true,
  "pyGUID": "<exact input GUID>",
  "pyStatusValue": "<stored status>",
  "pyRouterKey": "<stored router key>",
  "errorCode": "",
  "errorMessage": ""
}
```

Not found:

```json
{
  "success": false,
  "pyGUID": "<requested GUID>",
  "errorCode": "NOT_FOUND",
  "errorMessage": "Memory record was not found"
}
```

Other update failure:

```json
{
  "success": false,
  "pyGUID": "<requested GUID>",
  "errorCode": "UPDATE_FAILED",
  "errorMessage": "<diagnostic text>"
}
```

Allowed lifecycle combinations remain:

```text
Passed + OK
Failed + GENERATOR_REPAIR
Failed + SEMANTIC_REJECT
Failed + HUMAN
```

Rules:
- exact one-record update by unique `pyGUID` plus `pxCaseID` guard;
- only `pyStatusValue` and `pyRouterKey` may change;
- no `pyUpdates`, `RequestsJSON`, Memory `pxResults[]`, full Candidate replacement, or batch merge semantics;
- `NOT_FOUND` and `UPDATE_FAILED` stop the current lifecycle/routing workflow;
- no agent retry after an unconfirmed/failed update.

---

# 4. Stage plan and status matrix

| Stage | Scope | Change Status | Validation Status | Completion criterion |
|---|---|---|---|---|
| A8D-0 | Freeze A8C/A4 baseline + inventory Memory-contract occurrences | NOT_STARTED | NOT_STARTED | snapshot/inventory complete and independently checked |
| A8D-1 | Create canonical single-record Memory contract artifact | NOT_STARTED | NOT_STARTED | contract complete and schema/examples internally consistent |
| A8D-2 | Refactor Scenario Author persistence/handoff rules | NOT_STARTED | NOT_STARTED | Author has one-record WriteMemory loop and no Memory batch carrier |
| A8D-3 | Refactor Generator Get/Write/Update rules | NOT_STARTED | NOT_STARTED | all three Generator Memory interfaces are single-record and lifecycle behavior preserved |
| A8D-4 | Refactor Validator exact reads | NOT_STARTED | NOT_STARTED | both reads use single-record GetMemory and exact correlation is preserved |
| A8D-5 | Refactor active handoff/docs/checks and mark historical contracts superseded | NOT_STARTED | NOT_STARTED | all current authorities point to A8D; historical evidence remains intact |
| A8D-6 | Full static contract validation + negative checks | NOT_STARTED | NOT_STARTED | active Memory contract has zero batch/carrier remnants and expected failures are detected |
| A8D-7 | Regression + promotion | NOT_STARTED | NOT_STARTED | A8B/A8C compiler/anchoring regression still passes; A8D becomes promoted baseline |

---

# 5. A8D-0 — Baseline freeze and inventory

## Change step

1. Preserve promoted A8C prompts byte-for-byte as the pre-A8D baseline.
2. Record SHA-256 for current Author/Generator/Validator and continuation artifacts.
3. Inventory every active occurrence of:
   - `WriteMemory`;
   - `GetMemory`;
   - `UpdateMemory`;
   - `RequestsJSON`;
   - `ResultsJSON`;
   - Memory-specific `pxResults`/row-correlation language;
   - batch persistence wording.
4. Explicitly distinguish Memory-tool carriers from legitimate `KnowledgeTool.response.pxResults` and other non-Memory structures.

## Validation step

Independently verify:
- baseline hashes match untouched files;
- inventory covers current promoted prompts and current continuation docs;
- no KnowledgeTool/RuleCrawler `pxResults` is incorrectly classified as a Memory defect.

## Exit status

```text
Change Status     = CHANGE_COMPLETE
Validation Status = VALIDATION_COMPLETE
```

---

# 6. A8D-1 — Canonical Memory contract artifact

## Change step

Create `01_CURRENT_WORK/A8D_SINGLE_RECORD_MEMORY_CONTRACT.md` containing only the canonical API in section 3 plus caller behavior/error mapping.

Caller outcomes:

```text
GetMemory NOT_FOUND       -> stop required-artifact workflow
WriteMemory WRITE_FAILED  -> stop; do not continue to downstream agent
UpdateMemory NOT_FOUND    -> stop lifecycle/routing workflow
UpdateMemory UPDATE_FAILED-> stop lifecycle/routing workflow
malformed/exception       -> treat as the corresponding caller-side read/write/update failure
```

No retry semantics are exposed to agents for mutation calls.

## Validation step

Check that:
- each tool takes/returns one record only;
- `pxGUID`/`pyGUID` spelling is consistent (`pyGUID` only for this Data Type contract);
- `GetMemory`/`UpdateMemory` do not require `Type` or `pyGroup` for lookup;
- no batch field exists;
- error set is limited to `NOT_FOUND`, `WRITE_FAILED`, `UPDATE_FAILED` at the tool contract level.

---

# 7. A8D-2 — Scenario Author refactor

## Change step

Create a new Author authority from A8C.

Required changes:
1. Tool allowlist becomes `WriteMemory(pxCaseID,Type,pyGroup,pyPayload)`.
2. Replace “persist all projections in one immutable batch” with:
   - after **all** projections are semantically frozen and self-validated, call WriteMemory once per projection in Author group order;
   - each call persists exactly that group's canonical v3 payload;
   - correlate the returned GUID only to that call/group;
   - require success before recording that projection GUID;
   - if any write fails/malformed/unconfirmed, stop and invoke **no Generator**;
   - earlier successfully created immutable Projection records remain immutable; do not roll back or overwrite them.
3. Only after every projection write succeeds, invoke Generator sequentially in group order using each exact returned GUID.
4. Remove Memory `RequestsJSON`, Memory `pxResults[]`, multi-row response correlation, duplicate/missing row logic and batch-write wording.
5. Do not touch KnowledgeTool `response.pxResults` or RuleCrawler batching.

## Validation step

Check exact Author contract properties:
- no Memory `RequestsJSON`;
- no Memory batch persistence wording;
- one WriteMemory call per Projection;
- all projections freeze before first write;
- all writes succeed before first Generator call;
- write failure blocks every Generator invocation;
- unique nonempty returned GUID required per successful write;
- no changes to casting, DWL, Projection grammar or Scenario semantics.

---

# 8. A8D-3 — UnitTestGenerator refactor

## Change step

Create a new Generator authority from A8C.

Required interfaces:

```text
GetMemory(pxCaseID=<CaseID>,pyGUID=<UnitTestProjectionUUID>)
WriteMemory(pxCaseID=<CaseID>,Type="UnitTestCandidate",pyGroup=<source pyGroup>,pyPayload=<complete Candidate JSON string>)
UpdateMemory(pxCaseID=<CaseID>,pyGUID=<current Candidate GUID>,pyStatusValue=<...>,pyRouterKey=<...>)
```

Required behavior:
- exact source read validates returned `pxCaseID`, `pyGUID`, `pyType="UnitTestProjectionV3"`, nonempty `pyGroup/pyPayload`;
- `NOT_FOUND`/malformed/tool failure -> existing source read/projection failure path; never infer another Projection;
- Candidate create is one record and returns exactly one new GUID directly;
- no Candidate GUID supplied on create;
- Candidate write failure -> `CANDIDATE_WRITE_FAILED`, no Validator call;
- UpdateMemory directly sends the two lifecycle fields; no `pyUpdates` object;
- lifecycle success must echo exact Candidate GUID and requested status/router values;
- `NOT_FOUND`, `UPDATE_FAILED`, exception or malformed update -> `LIFECYCLE_UPDATE_FAILED`; stop routing;
- repair remains new Candidate -> new WriteMemory -> new GUID;
- no persisted Pending update.

## Validation step

Check:
- no `RequestsJSON`, `ResultsJSON`, Memory `pxResults`, `pyUpdates` or row-correlation language remains in current Generator;
- all three signatures match A8D contract;
- create-only/immutable/repair behavior unchanged;
- all four lifecycle mappings unchanged;
- Validator correlation still uses exact new Candidate GUID.

---

# 9. A8D-4 — UnitTestValidator refactor

## Change step

Create a new Validator authority from A8C.

Required reads:

```text
GetMemory(pxCaseID=<CaseID>,pyGUID=<UnitTestProjectionUUID>)
GetMemory(pxCaseID=<CaseID>,pyGUID=<UnitTestCandidateUUID>)
```

For each successful read require:
- `success=true`;
- exact input `pxCaseID`;
- exact input `pyGUID`;
- expected `pyType` (`UnitTestProjectionV3` or `UnitTestCandidate`);
- nonempty `pyGroup` and `pyPayload`;
- empty errors.

`NOT_FOUND`, exception, malformed response or ownership/type mismatch -> existing `MEMORY_READ_TOOL_ERROR/HUMAN_REVIEW` path.

After both reads, exact `pyGroup` equality remains mandatory.

## Validation step

Check:
- no `Type` input remains on Validator GetMemory calls;
- no list/row response semantics exist;
- exact GUID/case/type/group correlation remains at least as strict as A8C;
- no Candidate-as-authority or latest-row inference is introduced.

---

# 10. A8D-5 — Current docs, handoff and historical boundary

## Change step

Update current authoritative handoff/manifest/status documents so they identify:
- A8D prompts as current authorities;
- `A8D_SINGLE_RECORD_MEMORY_CONTRACT.md` as the current Memory-tool contract;
- A8C prompts and old persistence forms as historical/superseded for Memory API syntax;
- A4 deployment open and A9 runtime not run.

Do not rewrite old stage prompts or accepted historical evidence merely to remove old syntax. Historical files remain evidence of previous decisions.

Update any current validation script that intentionally asserts current prompt Memory syntax, or add a dedicated A8D checker rather than mutating historical A8C regression intent.

## Validation step

Check current authority resolution from `00_START_HERE` reaches only A8D prompts/contract for active Memory semantics and does not accidentally promote an older A1/A8C Memory contract.

---

# 11. A8D-6 — Full static validation and negative testing

## Change step

No production artifact edits are allowed during this step. Create only validation/report artifacts.

Create an A8D static checker covering:

### Positive checks
- exact three signatures;
- expected success/error fields;
- Author one-write-per-Projection sequencing;
- Generator exact single source read/create/update;
- Validator two exact single reads;
- immutable payload and repair-new-GUID rules;
- no Pending update.

### Forbidden active patterns
For Memory contexts only:

```text
RequestsJSON
ResultsJSON
{"pxResults":[...]} carrier
response-row correlation
missing/extra/duplicate Memory rows
pyUpdates
Memory batch write/update
```

Do **not** reject legitimate KnowledgeTool `pxResults` or RuleCrawler batching.

### Negative cases
The checker must fail when a synthetic prompt mutation introduces at least:
1. `RequestsJSON` back into WriteMemory;
2. Memory `pxResults[]` carrier;
3. `Type` back into GetMemory lookup;
4. `pyUpdates` back into UpdateMemory;
5. Author invokes Generator before all projection writes succeed;
6. Generator continues after `WRITE_FAILED`;
7. Validator accepts wrong `pyType`;
8. repair overwrites old Candidate instead of new create.

## Validation step

Run the checker against:
- current A8D artifacts -> PASS;
- each negative mutation -> expected FAIL.

Produce `A8D_SINGLE_RECORD_MEMORY_VALIDATION.md` with explicit evidence.

---

# 12. A8D-7 — Regression and promotion

## Change step

No semantic edits. Promotion metadata only after validation succeeds.

## Validation step

Run unchanged baseline regressions:
- A8B canonical Projection->Candidate fixture checker;
- A8C anti-anchoring/adversarial suite;
- A4 static verifier self-test expectations.

The Memory API refactor must not change target compile behavior, schemas, KnowledgeArea examples, casting semantics, or A4 target artifacts.

Promotion requires:

```text
A8D-0 .. A8D-7:
  Change Status     = CHANGE_COMPLETE
  Validation Status = VALIDATION_COMPLETE
```

Then update plan status to:

```text
COMPLETED STATIC/DESIGN — A8D PROMOTED;
A4 LIVE DEPLOYMENT OPEN;
A9 RUNTIME NOT RUN
```

---

# 13. Global acceptance criteria

A8D passes only if all are true:

1. Current active Memory tools are strictly single-record-per-call.
2. No active Memory contract contains `RequestsJSON`, `ResultsJSON`, Memory `pxResults[]`, `pyUpdates`, batch result correlation, or partial-success semantics.
3. Legitimate KnowledgeTool/RuleCrawler batch structures remain untouched.
4. Author persists one Projection per WriteMemory call and waits for all projection writes before Generator orchestration.
5. Generator reads one Projection, creates one Candidate per write, and updates one Candidate lifecycle per update.
6. Validator independently reads exactly one Projection and one Candidate by GUID.
7. `pyPayload` remains immutable.
8. repair creates a new Candidate GUID.
9. Tool-level error vocabulary is limited to `NOT_FOUND`, `WRITE_FAILED`, `UPDATE_FAILED`; caller-side malformed/exception handling remains deterministic.
10. Every stage records both mandatory completion statuses independently.
11. A8B/A8C regression behavior is unchanged.
12. A4 live deployment verification and A9 runtime remain explicitly outside A8D completion.

---

# 14. Current execution status

| Stage | Change Status | Validation Status |
|---|---|---|
| A8D-0 | CHANGE_COMPLETE | VALIDATION_COMPLETE |
| A8D-1 | CHANGE_COMPLETE | VALIDATION_COMPLETE |
| A8D-2 | CHANGE_COMPLETE | VALIDATION_COMPLETE |
| A8D-3 | CHANGE_COMPLETE | VALIDATION_COMPLETE |
| A8D-4 | CHANGE_COMPLETE | VALIDATION_COMPLETE |
| A8D-5 | CHANGE_COMPLETE | VALIDATION_COMPLETE |
| A8D-6 | CHANGE_COMPLETE | VALIDATION_COMPLETE |
| A8D-7 | CHANGE_COMPLETE | VALIDATION_COMPLETE |

**Exact next action:** obtain the live Generator + Validator Pega KnowledgeTool capture for Standard and MultiInput modes and run `A4_DEPLOYMENT_VERIFIER.py`. A9 remains separate and not run.
