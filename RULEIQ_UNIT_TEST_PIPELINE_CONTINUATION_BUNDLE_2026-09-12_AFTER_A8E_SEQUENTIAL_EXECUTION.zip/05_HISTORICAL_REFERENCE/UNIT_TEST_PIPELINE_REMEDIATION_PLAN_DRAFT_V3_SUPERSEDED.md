# Unit Test Pipeline — End-to-End Remediation Plan

**Status:** DRAFT — architecture decisions in progress  
**Date:** 2026-09-12  
**Scope:** Scenario Author → UnitTestProjectionV3 → UnitTestGenerator → UnitTestCandidate → UnitTestValidator → repair / terminal status

This plan follows the end-to-end simulation review and does not reopen the core semantic/fidelity architecture.

---

# 1. Preserved architecture

The following remain unchanged unless a later finding proves otherwise:

1. Scenario Author owns semantic truth.
2. UnitTestProjectionV3 is immutable after persistence.
3. Generator is a deterministic Projection→Candidate compiler.
4. Full G7 runs before every Candidate write.
5. Validator independently reads the exact persisted Projection and Candidate.
6. Validator checks formal schema, closed deterministic fidelity, and candidate-internal documentation/Pega invariants.
7. Validator never invents or supplies replacement semantic values.
8. Fidelity repair derives only from frozen Projection + authoritative mapping.
9. Candidate versions are immutable.
10. Agent-to-Agent workflow correlation uses exact GUIDs, never "latest".

---

# 2. REVISED DECISION — WriteMemory create-only + UpdateMemory merge

**Decision status: ACCEPTED**

The previous append-only-only proposal is withdrawn.

Memory uses two distinct persistence operations with non-overlapping semantics.

## 2.1 WriteMemory

`WriteMemory` is **create-only**.

Its purpose is to create a new immutable semantic artifact/version, for example:

- a new `UnitTestProjectionV3`;
- an initial `UnitTestCandidate`;
- a repaired `UnitTestCandidate` version with a new GUID.

`WriteMemory` never overwrites an existing record.

A repair always creates a new Candidate GUID.

## 2.2 UpdateMemory

`UpdateMemory` updates an existing record identified by its exact persistent identity.

It performs a **partial merge**, not full replacement.

Core invariant:

> Only fields explicitly present in `pyUpdates` are changed. Every field not present in `pyUpdates` remains unchanged.

The update operation must never replace the whole record merely because an update is requested.

## 2.3 Exact update addressing

Update must target one exact existing record.

The request must identify at minimum:

- exact `pyGUID`;
- exact `pyGroup` / correlation key where required by the Memory implementation;
- exact case/type context.

A group key alone must never select an arbitrary/latest Candidate version.

If the exact target record cannot be identified uniquely, UpdateMemory fails.

## 2.4 Candidate payload immutability

For `UnitTestCandidate`, lifecycle updates must not modify candidate content.

Candidate `pyPayload` remains immutable after the Candidate is created.

Allowed lifecycle update fields are explicitly whitelisted.

Current intended fields:

```json
{
  "pyStatusValue": "<Passed|Failed>",
  "pyRouterKey": "<OK|GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>"
}
```

No other field is changed by the Generator lifecycle operation.

The tool implementation should reject any attempt by this lifecycle operation to modify `pyPayload`.

## 2.5 Merge semantics

Conceptually:

```text
existing record
    +
pyUpdates
    ↓
atomic shallow field merge
```

Example:

Existing:

```json
{
  "pyGUID": "C1",
  "pyGroup": "G001",
  "pyPayload": "{...candidate...}",
  "pyStatusValue": "Pending",
  "pyRouterKey": ""
}
```

Request:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyGUID": "C1",
      "pyUpdates": {
        "pyStatusValue": "Failed",
        "pyRouterKey": "GENERATOR_REPAIR"
      }
    }
  ]
}
```

Result:

```json
{
  "pyGUID": "C1",
  "pyGroup": "G001",
  "pyPayload": "{...candidate...}",
  "pyStatusValue": "Failed",
  "pyRouterKey": "GENERATOR_REPAIR"
}
```

`pyPayload` and every unspecified field remain exactly unchanged.

## 2.6 Atomicity

The merge must be implemented atomically at tool/storage level.

Do not implement the externally visible semantics as:

1. model reads record;
2. model modifies it;
3. model writes full replacement.

The model sends only the exact update patch.

The tool/storage layer owns the atomic merge.

## 2.7 Generator lifecycle

Candidate lifecycle becomes:

```text
Projection P1
   ↓
WriteMemory → Candidate C1 / Pending
   ↓
Validator
   ↓
UpdateMemory(C1)
   ├── OK               → Passed / OK
   ├── GENERATOR_REPAIR → Failed / GENERATOR_REPAIR
   ├── SEMANTIC_REJECT  → Failed / SEMANTIC_REJECT
   └── HUMAN            → Failed / HUMAN
```

If repair is authorized:

```text
C1 / Failed
   ↓
rebuild from frozen Projection
   ↓
full G7
   ↓
WriteMemory → new Candidate C2 / Pending
   ↓
Validator
   ↓
UpdateMemory(C2)
```

Candidate versions remain immutable with respect to payload.

Only lifecycle metadata on the exact Candidate row is merged.

## 2.8 Workflow identity

Agents continue to pass exact GUIDs.

"Latest" must not be used for an executing workflow to resolve source or Candidate identity.

Exact GUID correlation remains unchanged.

---

# 3. P0 remediation work

## R1 — Close Candidate naming contract

Problems:

- target schema naming prose refers to unavailable `RuleJSON.pyRuleName`;
- Generator owns only `UnitTestProjection.rut.name`;
- Author does not yet define deterministic creation / normalization / uniqueness of `testLabel`;
- multiple physical groups can potentially generate the same Pega test-rule identity.

Required changes:

1. Candidate schema naming contract must use `UnitTestProjection.rut.name`.
2. Author must define deterministic `testLabel` production.
3. Author must guarantee cross-projection naming uniqueness.
4. Generator must not invent a second naming algorithm.

**OPEN DESIGN DECISION:** how cross-group uniqueness is encoded.

---

## R2 — Restore exact Generator UpdateMemory lifecycle contract

`UpdateMemory` remains part of the Generator interface.

Required Generator contract:

1. After every valid `ValidatorReport`, update the exact current Candidate row once before taking the next route action.
2. Use exact Candidate `pyGUID` and exact source/candidate `pyGroup`.
3. Send lifecycle fields only:
   - `pyStatusValue`;
   - `pyRouterKey`.
4. Route mapping:
   - `OK` -> `pyStatusValue="Passed"`, `pyRouterKey="OK"`;
   - `GENERATOR_REPAIR` -> `pyStatusValue="Failed"`, `pyRouterKey="GENERATOR_REPAIR"`;
   - `SEMANTIC_REJECT` -> `pyStatusValue="Failed"`, `pyRouterKey="SEMANTIC_REJECT"`;
   - `HUMAN` -> `pyStatusValue="Failed"`, `pyRouterKey="HUMAN"`.
5. `pyPayload` is forbidden in `pyUpdates`.
6. Tool semantics are partial merge: unspecified fields remain unchanged.
7. The tool/storage layer performs the merge atomically.
8. Generator verifies exact update response correlation; uncertain/failed update -> `LIFECYCLE_UPDATE_FAILED`.
9. No retry on uncertain write/update.

This closes the current final-Generator lifecycle gap without introducing a new artifact type.

---

## R3 — Synchronize Author producer validation with Generator v3 source gate

Create one exact source-contract definition for UnitTestProjectionV3.

Author must validate before WriteMemory everything Generator later treats as `SOURCE_INVALID`, including:

- `testLabel` lexical constraints;
- Scenario `name` lexical constraints;
- `reasoningTrace` nonempty;
- `dependencyClosureTrace` bounds;
- closed object shapes;
- page/path/action/parameter constraints;
- mode/cardinality constraints.

No Author-valid persisted Projection should fail the Generator merely because of a missing duplicated lexical rule.

This change does not require a product decision.

---

## R4 — Verify deployed target template / schema bindings

Before runtime testing verify that KnowledgeTool keys return:

- the current Stage-3 standard/multi-input schemas;
- application-specific target `pyRuleSet`;
- application-specific `pyRuleSetVersion`;

rather than static sample values.

This is primarily a deployment/configuration verification task.

---

# 4. P1 remediation work

## R5 — Define canonical scalar→string serialization

Affected:

- RUT parameter values;
- setup/cleanup action parameter values;
- Rule-Obj-When input values.

Current phrase "deterministic string" is insufficient.

A single exact algorithm must own:

- strings;
- booleans;
- integers;
- non-integer finite numbers.

After it is defined, currently excluded numeric/boolean Validator fidelity checks should be activated.

**OPEN DESIGN DECISION:** exact canonical number representation.

---

## R6 — Resolve scalar formal parameter type

Question to prove in Pega:

Does correct Unit Test execution require explicit `pyParametersParamType` for scalar parameters such as:

- Text;
- Integer;
- Decimal;
- TrueFalse;

or does the runner reliably obtain type from the RUT definition?

If explicit type is required, define its authoritative source.

Do not let Validator infer it.

This is a technical/Pega research question, not necessarily a user design decision.

---

## R7 — Align schema prose with enforceable target contract

Audit descriptions/comments for wording such as:

- MUST;
- required;
- always;

where the formal schema does not enforce the same invariant.

For machine-enforceable invariants, move authority to schema keywords.

For genuinely cross-field Pega invariants, state one exact documentation rule.

For advice only, use heuristic/recommended wording.

No product decision required.

---

## R8 — Normalize deterministic source-target conflict ownership

Known deterministic representability conflicts should be detected by Generator before Candidate persistence.

Example:

`Rule-Obj-When + rut.singlePage=true`

should fail pre-write rather than depend on schema-first Validator behavior.

Validator conflict handling remains defensive.

No product decision required.

---

# 5. P2 clarification/documentation

## R9 — Document Author trust boundary

Current proposal:

Author intentionally consumes only:

- Generator `sourceUUID`;
- Generator `groupId`;
- Generator `status`.

Generator owns internal consistency of:

- candidate pointer;
- representedScenarioNames;
- validationAttempts;
- repairAttempts;
- errorMessage.

This should be made an explicit trust boundary if retained.

**OPEN DESIGN DECISION:** whether Author should continue to trust Generator at this boundary or validate more report fields.

---

# 6. Product/design decisions

## D1 — Persist Pending?

**DECIDED: NO.**

A newly created Candidate has no persisted `Pending` lifecycle update.

Interpretation:

- Candidate exists and has not yet received a terminal lifecycle update -> pending/unvalidated by implication.
- After a valid ValidatorReport, Generator performs one exact `UpdateMemory` merge:
  - `OK` -> `Passed / OK`;
  - every non-OK terminal/current route -> `Failed / <exact route>`.

This avoids a redundant write while preserving exact Candidate lifecycle.

---

## D2 — Candidate/test naming uniqueness

**DECIDED: use a frozen physical-group discriminator in UnitTestProjectionV3.**

`testLabel` remains semantic-only.

A separate frozen physical-group discriminator is materialized by Author after physical grouping and before Projection persistence.

Tentative field name:

`physicalGroupKey`

Example:

```json
{
  "testLabel": "HappyPath",
  "physicalGroupKey": "G001"
}
```

The exact field name is subject to implementation review, but the ownership is fixed:

- Author creates and freezes it after stable physical grouping;
- it is persisted inside the Projection, not inferred later from Memory ordering;
- Generator consumes it only for deterministic target identity/correlation where defined;
- Generator never invents or renumbers it;
- a semantic/grouping rebuild rematerializes the complete Projection and may therefore produce a different frozen key.

The final candidate naming contract must consume:

- `rut.name`;
- semantic `testLabel`;
- frozen physical-group discriminator;

under one schema-owned naming algorithm.

This guarantees uniqueness between physical groups without polluting semantic `testLabel`.

---

## D3 — Candidate lineage

**OPEN — user requested explanation before deciding.**

Possible minimal mechanism:

A repaired Candidate may carry one immutable Memory-row metadata field:

`supersedesUUID = <previous Candidate GUID>`

Example:

```text
C1  --Validator: GENERATOR_REPAIR-->
C2.supersedesUUID = C1
```

A second repair:

```text
C3.supersedesUUID = C2
```

This forms a chain without storing a lineage list or mutable version counter.

Execution does not require this field because Generator and Validator already use exact GUIDs.

Its only purpose is durable audit/navigation after the run.

Recommendation pending user decision:
- if repair history must be directly traversable and concurrency/re-runs are possible, keep `supersedesUUID`;
- otherwise omit it and derive history from source UUID + group + timestamps/tool logs.

---

## D4 — Author trust in GeneratorRunReport

**DECIDED: keep minimal trust boundary.**

Author validates only:

- `sourceUUID`;
- `groupId`;
- `status`.

Author does not duplicate Generator-owned checks for:

- candidate pointer;
- counters;
- representedScenarioNames;
- errorMessage formatting.

Generator owns internal consistency of its terminal report.

---

# 7. Questions that do NOT require a user answer

The following should be resolved technically by analysis / Pega contract inspection:

1. Exact scalar parameter type requirement.
2. Exact schema/Knowledge mandatory-vs-heuristic rules.
3. Generator-side representability conflict census.
4. Exact source grammar synchronization.
5. Whether deployment JsonExample is dynamically application-specific.
6. Exact canonical scalar serialization proposal (we can prepare and review it).
7. How append-only Memory query/indexes should efficiently resolve current state.

---

# 8. Proposed next stage sequence

After D1–D5 are resolved:

1. **A1 — Persistence contract repair**
   - WriteMemory create-only semantics;
   - UpdateMemory exact-record partial merge semantics;
   - lifecycle field whitelist;
   - atomic merge behavior;
   - exact update-response correlation.

2. **A2 — Naming contract repair**
   - Author `testLabel`;
   - schema naming source;
   - cross-group uniqueness.

3. **A3 — UnitTestProjectionV3 producer/consumer contract synchronization**
   - exact lexical/shape constraints in Author and Generator.

4. **A4 — Target configuration verification contract**
   - schema key version/content;
   - JsonExample target ruleset/version precondition.

5. **A5 — Scalar canonicalization**
   - exact conversion algorithm;
   - re-enable Validator fidelity rows.

6. **A6 — Parameter type decision**
   - Pega research;
   - contract amendment only if required.

7. **A7 — Schema prose/formal consistency cleanup**

8. **A8 — Final end-to-end tabletop simulation**

9. **A9 — Only then, optional real Claude/Pega runtime trial**

Implementation and validation remain separate for every stage.
