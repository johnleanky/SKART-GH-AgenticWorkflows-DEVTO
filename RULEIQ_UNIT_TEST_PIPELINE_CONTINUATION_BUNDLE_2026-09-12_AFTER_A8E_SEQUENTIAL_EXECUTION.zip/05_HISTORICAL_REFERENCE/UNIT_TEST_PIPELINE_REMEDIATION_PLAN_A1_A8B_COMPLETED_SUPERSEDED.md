# Unit Test Pipeline — End-to-End Remediation Plan

**Status:** FINAL DESIGN BASELINE — A1–A8 plus A8B target alignment completed; A4 deployment proof open; A9 runtime not run  
**Date:** 2026-09-12  
**Scope:** Scenario Author → UnitTestProjectionV3 → UnitTestGenerator → UnitTestCandidate → UnitTestValidator → repair / terminal status

This plan follows the end-to-end simulation review and does not reopen the core semantic/fidelity architecture.

---

## Execution status

| Stage | Status | Evidence |
|---|---|---|
| A1 — Persistence contract repair | TEXTUALLY VALIDATED | `UnitTestGenerator_Prompt_A1_PERSISTENCE_REPAIRED.txt`; `A1_PERSISTENCE_CONTRACT_VALIDATION.md` |
| A2 — Naming contract repair | TEXTUALLY VALIDATED | `Main_Agent_Prompt_A2_NAMING_REPAIRED.txt`; `UnitTestGenerator_Prompt_A2_NAMING_REPAIRED.txt`; `Validator_Prompt_A2_NAMING_REPAIRED.txt`; Stage-3 schemas; `A2_NAMING_CONTRACT_VALIDATION.md` |
| A3 — UnitTestProjectionV3 producer/consumer synchronization | TEXTUALLY VALIDATED | `Main_Agent_Prompt_A3_SOURCE_CONTRACT_REPAIRED.txt`; existing Generator §2.1–2.2 consumer grammar; `A3_PROJECTION_SOURCE_CONTRACT_VALIDATION.md` |
| A4 — Target configuration verification contract | DEPLOYMENT PROOF REQUIRED | local bundle checked; deployed KnowledgeTool bindings unavailable in this session; see `A4_TARGET_CONFIGURATION_VERIFICATION.md` |
| A5 — Scalar canonicalization | HISTORICAL PRIMITIVE; SUPERSEDED FOR TYPED PROJECTION TRANSPORT | A8 lexical transport amendment removes `CanonicalBareScalar` from current Generator/Validator authority so Pega-preserved lexical values are not normalized |
| A6 — Typed parameters + Pega coercion ownership | DESIGN RESOLVED; CAST-MATRIX AUTHORITATIVE FOR PEGA 26.x; A8 REFINES TRANSPORT | Author remains sole casting owner; A8 preserves exact `postCastLexical` in Projection. See A6 evidence plus `A8_CAST_LEXICAL_TRANSPORT_AMENDMENT.md` |
| A7 — Schema prose/formal consistency cleanup | TEXTUALLY / STRUCTURALLY VALIDATED | Stage-3 schemas + examples; A7 Generator/Validator prompts; `A7_SCHEMA_PROSE_FORMAL_CONSISTENCY_VALIDATION.md` |
| A8 — Final end-to-end tabletop + A8B target alignment | TEXTUALLY / STRUCTURALLY VALIDATED | current A8 Author + A8B Generator/Validator authorities; canonical paired fixtures; `A8_CAST_LEXICAL_TRANSPORT_AMENDMENT.md`; `A8_FINAL_END_TO_END_TABLETOP_VALIDATION.md`; `A8B_TARGET_SCHEMA_GENERATOR_ALIGNMENT_VALIDATION.md` |
| A9 — Optional real Claude/Pega runtime trial | NOT RUN | runtime evidence absent; A4 deployed target verification remains external precondition |

Runtime evidence remains absent unless explicitly added later.

---

# 1. Preserved architecture

The following remain unchanged unless a later finding proves otherwise:

1. Scenario Author owns semantic truth.
2. UnitTestProjectionV3 is immutable after persistence.
3. Generator is a deterministic Projection→Candidate compiler.
4. Full G7 runs before every Candidate write.
5. Validator independently reads the exact persisted Projection and Candidate.
6. Validator checks formal schema, closed deterministic fidelity, and candidate-internal documentation/Pega invariants.
7. Validator never invents or supplies replacement semantic values.
8. Fidelity repair derives only from frozen Projection + authoritative mapping.
9. Candidate versions are immutable.
10. Agent-to-Agent workflow correlation uses exact GUIDs, never "latest".

---

# 2. REVISED DECISION — WriteMemory create-only + UpdateMemory merge

**Decision status: ACCEPTED**

The previous append-only-only proposal is withdrawn.

Memory uses two distinct persistence operations with non-overlapping semantics.

## 2.1 WriteMemory

`WriteMemory` is **create-only**.

Its purpose is to create a new immutable semantic artifact/version, for example:

- a new `UnitTestProjectionV3`;
- an initial `UnitTestCandidate`;
- a repaired `UnitTestCandidate` version with a new GUID.

`WriteMemory` never overwrites an existing record.

A repair always creates a new Candidate GUID.

## 2.2 UpdateMemory

`UpdateMemory` updates an existing record identified by its exact persistent identity.

It performs a **partial merge**, not full replacement.

Core invariant:

> Only fields explicitly present in `pyUpdates` are changed. Every field not present in `pyUpdates` remains unchanged.

The update operation must never replace the whole record merely because an update is requested.

## 2.3 Exact update addressing

Update must target one exact existing record.

The request must identify at minimum:

- exact `pyGUID`;
- exact `pyGroup` / correlation key where required by the Memory implementation;
- exact case/type context.

A group key alone must never select an arbitrary/latest Candidate version.

If the exact target record cannot be identified uniquely, UpdateMemory fails.

## 2.4 Candidate payload immutability

For `UnitTestCandidate`, lifecycle updates must not modify candidate content.

Candidate `pyPayload` remains immutable after the Candidate is created.

Allowed lifecycle update fields are explicitly whitelisted.

Current intended fields:

```json
{
  "pyStatusValue": "<Passed|Failed>",
  "pyRouterKey": "<OK|GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>"
}
```

No other field is changed by the Generator lifecycle operation.

The tool implementation should reject any attempt by this lifecycle operation to modify `pyPayload`.

## 2.5 Merge semantics

Conceptually:

```text
existing record
    +
pyUpdates
    ↓
atomic shallow field merge
```

Example:

Existing:

```json
{
  "pyGUID": "C1",
  "pyGroup": "G001",
  "pyPayload": "{...candidate...}"
}
```

Request:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyGUID": "C1",
      "pyUpdates": {
        "pyStatusValue": "Failed",
        "pyRouterKey": "GENERATOR_REPAIR"
      }
    }
  ]
}
```

Result:

```json
{
  "pyGUID": "C1",
  "pyGroup": "G001",
  "pyPayload": "{...candidate...}",
  "pyStatusValue": "Failed",
  "pyRouterKey": "GENERATOR_REPAIR"
}
```

`pyPayload` and every unspecified field remain exactly unchanged.

## 2.6 Atomicity

The merge must be implemented atomically at tool/storage level.

Do not implement the externally visible semantics as:

1. model reads record;
2. model modifies it;
3. model writes full replacement.

The model sends only the exact update patch.

The tool/storage layer owns the atomic merge.

## 2.7 Generator lifecycle

Candidate lifecycle becomes:

```text
Projection P1
   ↓
WriteMemory → Candidate C1 / lifecycle-unset (implicitly pending/unvalidated)
   ↓
Validator
   ↓
UpdateMemory(C1)
   ├── OK               → Passed / OK
   ├── GENERATOR_REPAIR → Failed / GENERATOR_REPAIR
   ├── SEMANTIC_REJECT  → Failed / SEMANTIC_REJECT
   └── HUMAN            → Failed / HUMAN
```

If repair is authorized:

```text
C1 / Failed
   ↓
rebuild from frozen Projection
   ↓
full G7
   ↓
WriteMemory → new Candidate C2 / lifecycle-unset (implicitly pending/unvalidated)
   ↓
Validator
   ↓
UpdateMemory(C2)
```

Candidate versions remain immutable with respect to payload.

Only lifecycle metadata on the exact Candidate row is merged.

## 2.8 Workflow identity

Agents continue to pass exact GUIDs.

"Latest" must not be used for an executing workflow to resolve source or Candidate identity.

Exact GUID correlation remains unchanged.

---

# 3. P0 remediation work

## R1 — Close Candidate naming contract

Problems:

- target schema naming prose refers to unavailable `RuleJSON.pyRuleName`;
- Generator owns only `UnitTestProjection.rut.name`;
- Author does not yet define deterministic creation / normalization / uniqueness of `testLabel`;
- multiple physical groups can potentially generate the same Pega test-rule identity.

Required changes:

1. Candidate schema naming contract must use `UnitTestProjection.rut.name`.
2. Author must define deterministic `testLabel` production.
3. Cross-projection target-name uniqueness must be guaranteed by the frozen physical-group discriminator plus the one schema-owned naming algorithm; semantic `testLabel` itself is not mutated merely to resolve collisions.
4. Generator must not invent a second naming algorithm.

**DECIDED:** cross-group uniqueness is encoded by the frozen physical-group discriminator defined in D2.

---

## R2 — Restore exact Generator UpdateMemory lifecycle contract

`UpdateMemory` remains part of the Generator interface.

Required Generator contract:

1. After every valid `ValidatorReport`, update the exact current Candidate row once before taking the next route action.
2. Use exact Candidate `pyGUID` and exact source/candidate `pyGroup`.
3. Send lifecycle fields only:
   - `pyStatusValue`;
   - `pyRouterKey`.
4. Route mapping:
   - `OK` -> `pyStatusValue="Passed"`, `pyRouterKey="OK"`;
   - `GENERATOR_REPAIR` -> `pyStatusValue="Failed"`, `pyRouterKey="GENERATOR_REPAIR"`;
   - `SEMANTIC_REJECT` -> `pyStatusValue="Failed"`, `pyRouterKey="SEMANTIC_REJECT"`;
   - `HUMAN` -> `pyStatusValue="Failed"`, `pyRouterKey="HUMAN"`.
5. `pyPayload` is forbidden in `pyUpdates`.
6. Tool semantics are partial merge: unspecified fields remain unchanged.
7. The tool/storage layer performs the merge atomically.
8. Generator verifies exact update response correlation; uncertain/failed update -> `LIFECYCLE_UPDATE_FAILED`.
9. No retry on uncertain write/update.

This closes the current final-Generator lifecycle gap without introducing a new artifact type.

---

## R3 — Synchronize Author producer validation with Generator v3 source gate

Create one exact source-contract definition for UnitTestProjectionV3.

Author must validate before WriteMemory everything Generator later treats as `SOURCE_INVALID`, including:

- `testLabel` lexical constraints;
- Scenario `name` lexical constraints;
- `reasoningTrace` nonempty;
- `dependencyClosureTrace` bounds;
- closed object shapes;
- page/path/action/parameter constraints;
- mode/cardinality constraints.

No Author-valid persisted Projection should fail the Generator merely because of a missing duplicated lexical rule.

**A3 EXECUTION OUTCOME — TEXTUALLY VALIDATED:** Author §6.8 now mirrors the Generator §2.1–2.2 closed v3 grammar for common root/Scenario metadata, executable shapes, assertion kinds, Rule-Obj-When rows, mode/cardinality rules, opaque-data boundary, and forbidden source fields. Producer-only canonical/source-equality/census checks remain Author-owned. Generator consumer grammar was not loosened or semantically changed.

This change does not require a product decision.

---

## R4 — Verify deployed target template / schema bindings

Before runtime testing verify that KnowledgeTool keys return:

- the current Stage-3 standard/multi-input schemas;
- application-specific target `pyRuleSet`;
- application-specific `pyRuleSetVersion`;

rather than static sample values.

This is primarily a deployment/configuration verification task.

---

# 4. P1 remediation work

## R5 — Define canonical scalar→string serialization

Affected:

- RUT parameter values;
- setup/cleanup action parameter values;
- Rule-Obj-When input values.

Current phrase "deterministic string" is insufficient.

A single exact algorithm must own:

- strings;
- booleans;
- integers;
- non-integer finite numbers.

After it is defined, currently excluded numeric/boolean Validator fidelity checks should be activated.

**A5 EXECUTION OUTCOME — TEXTUALLY VALIDATED:** Generator and Validator now share one byte-identical `CanonicalScalarString(v)` definition. Strings copy exactly, booleans use lowercase literals, and JSON numbers use an explicit exact-decimal normalization from the persisted source token without binary floating-point conversion. Numeric/boolean fidelity checks are activated for RUT parameters, action parameters, and Rule-Obj-When inputs. PAGE values remain exact page-name strings. Scalar formal parameter type remains outside A5 and is not inferred.

**TECHNICAL REMEDIATION:** resolved in A5; no product decision was required.

---

## R6 — Resolve scalar formal parameter type and Pega coercion ownership

**DECIDED / IMPLEMENTED AT CONTRACT LEVEL:** explicit formal type is part of UnitTestProjectionV3 and is supplied by Scenario Author. Generator and Validator never infer it from runtime value shape.

Authoritative source:
- RUT parameter -> exact original RUT formal declaration visible to Scenario Author;
- setup/cleanup action parameter -> exact fetched callee/action signature;
- property assertion/input typing -> exact property definition / grounded Pega property metadata.

A6 canonical formal types are `Text|Integer|Decimal|Double|TrueFalse|Date|DateTime|TimeOfDay|Page`; Page maps physically to target `PAGE`. Both Stage-3 MethodParam schemas require `pyParametersParamType`.

**Coercion ownership:** Pega assignment/parameter coercion is semantic execution and belongs to Scenario Author. The Author freezes the proven post-binding/post-assignment value plus authoritative type. Generator performs target serialization only; Validator checks that serialization independently.

**Accepted casting-matrix amendment:** the documented Pega Data Type Conversion Matrix is an executable Author decision table, not merely a caution/reference. For every cast-sensitive binding/assignment, Author determines Pega source-expression type and destination type, selects the exact matrix cell (`I/X/C/S/D/N/V` plus numbered notes), executes that rule, applies destination validation where applicable, and records an internal `CAST` row. `Other -> typed scalar` therefore uses `S` (copy lexical value unchanged, then validate/External), numeric narrowing uses `N`, preferred numeric conversion uses `V`, numeric→TrueFalse uses zero/nonzero note 6, and documented Date/Time notes are applied rather than ignored. Only details the matrix itself leaves underspecified may block the exact claim; absence of runtime proof does not authorize skipping a documented conversion. See `A6_DATA_CASTING_MATRIX_AMENDMENT.md`.

**A5 amendment:** A5's decimal/boolean canonicalization remains the bare-scalar lexical primitive. A6 supersedes context-free scalar serialization because Text method parameters require type/context-sensitive target encoding.

**Evidence boundary:** design/source contract is textually implemented. By explicit project decision, the documented Pega Data Casting Matrix is authoritative for Pega 26.x and does not require version-specific re-proof. Runtime Pega acceptance of generated Rule-Test-Unit-Case payloads, deployed KnowledgeTool binding, Date/DateTime/TimeOfDay target lexical conventions, and string-escaping edge cases remain unproven; A4 remains a deployment precondition.

---

## R7 — Align schema prose with enforceable target contract

Audit descriptions/comments for wording such as:

- MUST;
- required;
- always;

where the formal schema does not enforce the same invariant.

For machine-enforceable invariants, move authority to schema keywords.

For genuinely cross-field Pega invariants, state one exact documentation rule.

For advice only, use heuristic/recommended wording.

No product decision required.

**A7 EXECUTION OUTCOME — TEXTUALLY / STRUCTURALLY VALIDATED:** ordinary Draft-2020-12 keywords now own machine-enforceable constraints; `x-ruleiq-compilerMappings.CM-NAME-001` is the sole naming algorithm owner; `x-ruleiq-crossFieldInvariants` centralizes non-instance relationships; stale Generator-side RuleCrawler/discovery prose and nonexistent `RuleUnderTest.pyDetails.pyClassName` references were removed; bundled examples were reduced to the accepted minimal Scenario/EvidenceSummary surface and now validate with zero local Draft-2020-12 errors. See `A7_SCHEMA_PROSE_FORMAL_CONSISTENCY_VALIDATION.md`.

---

## R8 — Normalize deterministic source-target conflict ownership

Known deterministic representability conflicts should be detected by Generator before Candidate persistence.

Example:

`Rule-Obj-When + rut.singlePage=true`

should fail pre-write rather than depend on schema-first Validator behavior.

Validator conflict handling remains defensive.

No product decision required.

**A8/A8B EXECUTION OUTCOME — TEXTUALLY / STRUCTURALLY VALIDATED:** A8 added the general pre-write representability gate and exact lexical Projection transport. A8B then corrected physical target typing and fixtures: every `pyExpectedValue` is a JSON string, deterministic quoting/bare-string wrappers are explicit, both JsonExamples are exact canonical Generator outputs, and paired standard/When fixtures mechanically satisfy `Candidate == Compile(Projection)` plus Stage-3 schema validation. Current Generator/Validator contain no `CanonicalBareScalar`. See `A8_CAST_LEXICAL_TRANSPORT_AMENDMENT.md`, `A8_FINAL_END_TO_END_TABLETOP_VALIDATION.md`, and `A8B_TARGET_SCHEMA_GENERATOR_ALIGNMENT_VALIDATION.md`.

---

# 5. P2 clarification/documentation

## R9 — Document Author trust boundary

Current proposal:

Author intentionally consumes only:

- Generator `sourceUUID`;
- Generator `groupId`;
- Generator `status`.

Generator owns internal consistency of:

- candidate pointer;
- representedScenarioNames;
- validationAttempts;
- repairAttempts;
- errorMessage.

This should be made an explicit trust boundary if retained.

**DECIDED:** keep the minimal Author trust boundary defined in D4.

---

# 6. Product/design decisions

## D1 — Persist Pending?

**DECIDED: NO.**

A newly created Candidate has no persisted `Pending` lifecycle update.

Interpretation:

- Candidate exists and has not yet received a terminal lifecycle update -> pending/unvalidated by implication.
- After a valid ValidatorReport, Generator performs one exact `UpdateMemory` merge:
  - `OK` -> `Passed / OK`;
  - every non-OK terminal/current route -> `Failed / <exact route>`.

This avoids a redundant write while preserving exact Candidate lifecycle.

---

## D2 — Candidate/test naming uniqueness

**DECIDED: use a frozen physical-group discriminator in UnitTestProjectionV3.**

`testLabel` remains semantic-only.

A separate frozen physical-group discriminator is materialized by Author after physical grouping and before Projection persistence.

Final field name:

`physicalGroupKey`

Example:

```json
{
  "testLabel": "HappyPath",
  "physicalGroupKey": "G001"
}
```

The field name and ownership are fixed:

- Author creates and freezes it after stable physical grouping;
- it is persisted inside the Projection, not inferred later from Memory ordering;
- Generator consumes it only for deterministic target identity/correlation where defined;
- Generator never invents or renumbers it;
- a semantic/grouping rebuild rematerializes the complete Projection and may therefore produce a different frozen key.

The final candidate naming contract must consume:

- `rut.name`;
- semantic `testLabel`;
- frozen `physicalGroupKey`;

under one schema-owned naming algorithm.

This guarantees uniqueness between physical groups without polluting semantic `testLabel`. Author freezes `physicalGroupKey` as `G001`..`G999` from one-based stable physical-group order after grouping. `testLabel` equals the final semantic name of the original first materialized Scenario in the group and is not collision-suffixed.

---

## D3 — Candidate lineage

**DECIDED: NO explicit Candidate lineage field.** The user later requested the rationale for this same lineage question; that request does not reverse the prior explicit decision to keep lineage in the external orchestration/audit layer.

The internal Unit Test Pipeline does not persist a parent/previous Candidate pointer, lineage list, or mutable version counter. In particular, it does not add `supersedesUUID`.

Rationale:
- execution already uses exact Projection and Candidate GUIDs and does not need lineage metadata;
- post-run repair lineage, audit navigation, and run history are explicitly owned by external orchestration/audit facilities;
- duplicating that history inside Candidate Memory rows would add a second owner for the same concern.

Candidate repair semantics remain unchanged: every repair writes a new immutable Candidate with a new GUID, while the executing workflow carries the exact current GUID directly.

---

## D4 — Author trust in GeneratorRunReport

**DECIDED AND RECONFIRMED: keep minimal trust boundary.**

Author validates only:

- `sourceUUID`;
- `groupId`;
- `status`.

Author does not duplicate Generator-owned checks for:

- candidate pointer;
- counters;
- representedScenarioNames;
- errorMessage formatting.

Generator owns internal consistency of its terminal report.

---

# 7. Questions that do NOT require a user answer

The following should be resolved technically by analysis / Pega contract inspection:

1. Exact scalar parameter type requirement.
2. Exact schema/Knowledge mandatory-vs-heuristic rules.
3. Generator-side representability conflict census.
4. Exact source grammar synchronization.
5. Whether deployment JsonExample is dynamically application-specific.
6. Exact canonical scalar serialization proposal (we can prepare and review it).
7. How append-only Memory query/indexes should efficiently resolve current state.

---

# 8. Proposed next stage sequence

With D1–D4 resolved, execute the remediation stages in order:

1. **A1 — Persistence contract repair**
   - WriteMemory create-only semantics;
   - UpdateMemory exact-record partial merge semantics;
   - lifecycle field whitelist;
   - atomic merge behavior;
   - exact update-response correlation.

2. **A2 — Naming contract repair**
   - Author `testLabel`;
   - schema naming source;
   - cross-group uniqueness.

3. **A3 — UnitTestProjectionV3 producer/consumer contract synchronization**
   - exact lexical/shape constraints in Author and Generator.

4. **A4 — Target configuration verification contract**
   - schema key version/content;
   - JsonExample target ruleset/version precondition.

5. **A5 — Scalar canonicalization**
   - exact conversion algorithm;
   - re-enable Validator fidelity rows.

6. **A6 — Parameter typing + Pega Data Casting Matrix — COMPLETED AT CONTRACT LEVEL**
   - authoritative parameter/property typing owned by Author;
   - documented FROM→TO matrix executed by Author with internal `CAST` evidence;
   - Projection freezes final typed values; Generator/Validator do not cast;
   - matrix applicability to Pega 26.x is accepted as authoritative; A9, if run, verifies RuleIQ implementation/integration rather than re-proving Pega conversion semantics.

7. **A7 — Schema prose/formal consistency cleanup — COMPLETED**
   - machine-enforceable constraints moved to ordinary schema keywords;
   - one schema-owned naming mapping and one cross-field invariant registry;
   - examples brought into formal Stage-3 validity.

8. **A8 — Final end-to-end tabletop simulation + A8B corrective target alignment — COMPLETED AT TEXTUAL/STRUCTURAL LEVEL**
   - general pre-write representability gate added;
   - typed Projection scalar transport refined to exact Author-frozen Pega clipboard lexical strings;
   - A5 numeric canonicalization removed from current typed Generator/Validator transport;
   - A1–A8 seams table-top checked; A8B re-audit additionally proves canonical Projection→Candidate fixtures against the current schemas; A4 remains external deployment proof.

9. **A9 — Only then, optional real Claude/Pega runtime trial — NOT RUN**
   - include representative Pega casting-matrix cases (`S`, `C`, `N`, `V`, numeric→TrueFalse, Date/Time notes, invalid/External behavior) to validate RuleIQ implementation/integration; do not treat this as a prerequisite for accepting the matrix as Pega 26.x semantics

Implementation and validation remain separate for every stage.
