# RuleIQ Unit Test Pipeline — A8C High-Impact Example-Driven Prompt Refactoring Plan

**Status:** COMPLETED STATIC/DESIGN — PROMOTED; A4 DEPLOYMENT OPEN; A9 RUNTIME NOT RUN  
**Date:** 2026-09-12  
**Baseline:** A1–A8B design/contract baseline is frozen and remains authoritative until every A8C acceptance gate passes.  
**Scope:** selective prompt compression and shared-example refactoring for Scenario Author, UnitTestGenerator and UnitTestValidator.  
**Out of scope:** business-semantic redesign, Pega Data Casting Matrix redesign, persistence redesign, naming redesign, runtime A9, and any change to already accepted A1–A8B semantics unless A8C regression evidence proves a defect.

The completed A1–A8B plan has been archived as:

`05_HISTORICAL_REFERENCE/UNIT_TEST_PIPELINE_REMEDIATION_PLAN_A1_A8B_COMPLETED_SUPERSEDED.md`

This document **replaces the previous active remediation-plan content**. It does not invalidate the completed A1–A8B decisions; it treats them as the immutable refactoring baseline.

---

# 1. Refactoring objective

A8C optimizes prompt effectiveness by replacing only high-value duplicated/descriptive prose with compact canonical or contrastive examples, while keeping behavioral authority in system prompts and enforceable target structure in schema/compiler contracts.

The optimization target is not maximum prompt compression. The target is:

> **higher or equal first-pass behavioral fidelity + lower permanent context + no increase in example anchoring or authority drift.**

The intended architecture after A8C is:

```text
SYSTEM PROMPT
  hard behavioral invariants
  authority / ownership
  stop and failure gates
  exact tool/retrieval protocol
  compact deterministic procedure
       |
       | explicit KnowledgeTool retrieval
       v
SHARED TARGET KNOWLEDGEAREA
  shared Generator/Validator reference knowledge only
  canonical compiler examples
  contrastive serialization examples
  shared representability examples
       |
       + selected JsonSchema
       + x-ruleiq-compilerMappings
       + x-ruleiq-crossFieldInvariants
       + canonical JsonExample
       v
DETERMINISTIC COMPILE / INDEPENDENT VALIDATION
```

The system prompt remains the behavioral authority. KnowledgeArea is a shared reference source, not a substitute for critical system-level instructions.

---

# 2. Frozen A8B baseline

A8C must begin from these current authorities and may not silently change their semantics:

- Author: `01_CURRENT_WORK/Main_Agent_Prompt_A8_CAST_LEXICAL_REPAIRED.txt`
- Generator: `01_CURRENT_WORK/UnitTestGenerator_Prompt_A8B_TARGET_ALIGNMENT_REPAIRED.txt`
- Validator: `01_CURRENT_WORK/Validator_Prompt_A8B_TARGET_ALIGNMENT_REPAIRED.txt`
- Standard schema: `04_TARGET_CONTRACTS/rule-test-unit-case_JsonSchema_STAGE3.txt`
- Multi-input schema: `04_TARGET_CONTRACTS/rule-test-unit-case_multInpComb-JsonSchema_STAGE3.txt`
- Standard canonical candidate: `04_TARGET_CONTRACTS/rule-test-unit-case_JsonExample(5).txt`
- Multi-input canonical candidate: `04_TARGET_CONTRACTS/rule-test-unit-case_multInpComb-JsonExample(6).txt`
- Paired fixtures:
  - `fixtures/standard_projection.json -> standard_candidate.json`
  - `fixtures/when_projection.json -> when_candidate.json`
- A8B mechanical check: `01_CURRENT_WORK/A8B_CANONICAL_FIXTURE_CHECK.py`

Current prompt size baseline:

| Agent | Baseline words |
|---|---:|
| Scenario Author | 12,717 |
| UnitTestGenerator | 4,460 |
| UnitTestValidator | 3,361 |
| **Total** | **20,538** |

Prompt-size reduction is a secondary metric. No stage passes merely because word count decreases.

---

# 3. Non-negotiable A8C design principles

## P1 — KnowledgeArea is shared reference knowledge only

Move content into KnowledgeArea only when it is consumed by **at least two agents**.

For this refactor the principal shared consumers are Generator and Validator.

Do not create or enlarge KnowledgeArea merely to store:

- Author-only casting examples;
- Author-only dependency/DWL examples;
- Generator-only control-flow examples;
- Validator-only diagnostics examples.

Single-consumer material remains in that agent's system prompt if it is needed at all.

## P2 — Critical behavior must remain in system prompts

The following may never depend solely on KnowledgeArea or examples:

- semantic ownership boundaries;
- MUST / NEVER rules;
- tool allowlists;
- exact persistence protocol;
- stop/failure gates;
- immutable Projection/Candidate rules;
- Author-only Pega casting ownership;
- Generator prohibition on recasting/normalizing;
- Validator independence and prohibition on semantic correction;
- exact GUID correlation;
- repair authority and route precedence;
- pre-write rejection requirement;
- requirement to retrieve the selected target contract before target compilation/validation.

Removing prose from a system prompt is allowed only when the removed content is descriptive/redundant, not when it is the only statement of a behavioral invariant.

## P3 — Explicit KnowledgeArea retrieval contract is mandatory

Generator and Validator system prompts must explicitly state:

1. **when** target KnowledgeArea is retrieved;
2. the exact key/batch selected from immutable source mode/RUTType;
3. that it is retrieved exactly once and frozen for the invocation;
4. which portions are shared normative target reference:
   - target serialization guidance;
   - canonical compiler examples;
   - contrastive serialization examples;
   - shared representability examples;
5. that KnowledgeArea cannot alter Projection semantics;
6. that KnowledgeArea cannot authorize Pega semantic casting;
7. that examples cannot override hard system-prompt behavior or formal schema/compiler mappings;
8. that incomplete, missing, duplicate, internally contradictory or non-unique target knowledge causes the existing failure/review path rather than reconstruction from model memory.

## P4 — No silent fallback to remembered target behavior

If required shared KnowledgeArea cannot be obtained completely and uniquely:

- Generator: use the existing target-knowledge failure path (`KNOWLEDGE_FAILED` / corresponding terminal failure); do not compile from memory.
- Validator: use `AMBIGUOUS/HUMAN_REVIEW`; do not reconstruct target rules from Candidate or remembered examples.

No agent may compensate for missing target KnowledgeArea by guessing from training knowledge, historical prompts, or the current Candidate.

## P5 — Examples demonstrate; rules delimit

Examples may replace verbose descriptions of a deterministic mapping.

Examples may **not** become the sole definition of:

- applicability conditions;
- ownership;
- negative authority boundaries;
- state transitions;
- complete type-conversion behavior;
- failure routing;
- repair authorization.

Rule + example is preferred when the rule defines a boundary and the example demonstrates a transformation inside that boundary.

## P6 — Shared examples must be mechanically consistent artifacts

A shared example is eligible for KnowledgeArea only when its corresponding full fixture is mechanically checked against:

1. the frozen source contract;
2. deterministic compile behavior;
3. the selected Stage-3 schema;
4. relevant `CM-*` mappings;
5. relevant `CF-*` cross-field invariants.

No hand-written illustrative example may become normative shared reference without this linkage.

## P7 — Prevent example anchoring by construction

Do not use one large example as the primary teaching mechanism.

Shared examples must be:

- small and orthogonal;
- deliberately varied in literal names, page names, values, types and group keys;
- paired with contrastive cases when a tempting wrong generalization exists;
- explicit about which fields are variables versus constants;
- free from incidental metadata not needed for the demonstrated rule.

At least one adversarial acceptance case must use values and structures **not present in any example**.

## P8 — Author semantic layer and target compiler layer remain separated

The Pega Data Casting Matrix remains Author-owned semantic execution logic.

Shared Generator/Validator KnowledgeArea begins only from already-frozen Projection facts such as:

```text
formalType = Decimal
value      = "12.50"     // exact post-cast Pega lexical value
```

It may demonstrate target serialization:

```text
pyParametersParamType  = "Decimal"
pyParametersParamValue = "12.50"
```

It must not teach Generator or Validator how to derive `Decimal` or `"12.50"` from a pre-cast source expression.

---

# 4. Authority hierarchy after A8C

The refactor must make authority precedence explicit and consistent in both Generator and Validator.

## 4.1 Semantic/source authority

1. system-prompt behavioral boundaries;
2. exact persisted `UnitTestProjectionV3` for Author-owned source facts;
3. immutable invocation identity and mode.

## 4.2 Target authority

For target representation after source facts are frozen:

1. selected JsonSchema ordinary Draft-2020-12 keywords;
2. selected JsonSchema `x-ruleiq-compilerMappings` for deterministic algorithms owned there;
3. selected JsonSchema `x-ruleiq-crossFieldInvariants` for schema-owned cross-field relationships;
4. normative structural/serialization rules in selected shared KnowledgeArea that are not already owned by 1–3;
5. canonical/contrastive examples as demonstrations of 1–4;
6. JsonExample only for explicitly designated template-owned values and canonical-fixture comparison.

If an example conflicts with a higher authority, the example is defective; the model must not follow it.

If KnowledgeArea itself conflicts materially with schema/compiler mappings or the system-prompt behavioral boundary, fail/review rather than choose one interpretation ad hoc.

---

# 5. Shared KnowledgeArea design

## 5.1 Reuse the existing target KnowledgeArea keys

Preferred implementation: **do not add an extra KnowledgeTool call or a new agent-specific KnowledgeArea.** Extend the existing target KnowledgeAreas already retrieved by both Generator and Validator:

- `Rule-Test-Unit-Case_KnowledgeArea`
- `Rule-Test-Unit-Case_MultInpComb-KnowledgeArea`

This preserves the existing one-call target-contract acquisition model.

If the deployed KnowledgeTool cannot extend those keys safely, a new compiler-contract key may be considered only if:

- it is requested in the same single batch;
- it is consumed by both Generator and Validator;
- it does not duplicate agent-specific behavioral rules;
- A4 deployment verification is updated accordingly.

The default A8C plan is to enrich the existing two target KnowledgeAreas.

## 5.2 Shared Standard KnowledgeArea example set

Add a clearly delimited section, conceptually:

`Canonical Compiler Examples — Shared Generator/Validator Reference`

Only high-impact examples are included.

### EX-STD-01 — typed lexical serialization minimal pair

Purpose: prevent type inference and lexical normalization.

Demonstrate the same-looking lexical content under different authoritative modes/types:

```text
Projection: mode=Text,    expected="12.50"
Candidate:  pyPropertyMode="Text",    pyExpectedValue="\"12.50\""

Projection: mode=Decimal, expected="12.50"
Candidate:  pyPropertyMode="Decimal", pyExpectedValue="12.50"
```

Also show one explicit wrong form:

```text
WRONG Decimal candidate: pyExpectedValue="12.5"
Reason: changes the Author-frozen lexical value.
```

This example demonstrates target wrapping only. It must contain no statement about how Author obtained the type or lexical value.

### EX-STD-02 — one source assertion -> one target block

Purpose: remove repeated Property/Param/Page mapping prose and prevent legacy grouping behavior.

Use literals not used by A8B fixture, e.g. different property/page names.

Demonstrate:

- one Property source assertion becomes one target assertion block;
- one Param source assertion becomes one separate target assertion block;
- Page items remain together only inside the Page assertion representation where the target contract defines that grouping;
- source order is preserved.

### EX-STD-03 — primary page/context mapping

Purpose: prevent accidental reuse of old page ordering.

Use a non-default primary page in the example and explicitly show it first in `pyPagesAndClasses`.

Do not reuse only `RunRecordPrimaryPage`, so the model sees default and explicit-page behavior as variable rather than constant.

### EX-STD-04 — naming variation

Purpose: demonstrate `CM-NAME-001` without anchoring on `G001`.

Use at least two microcases with different values, e.g.:

```text
... + physicalGroupKey=G002 -> ..._G002
... + physicalGroupKey=G017 -> ..._G017
```

The algorithm remains owned by `CM-NAME-001`; examples only show that group key is a variable input and is not always `G001`.

### EX-STD-05 — representability contrast

Purpose: replace the long illustrative conflict list in Generator §3.1.

Show two distinct outcomes:

A. **Impossible while preserving source** -> reject before Candidate persistence.

B. **Target authority incomplete/ambiguous but representation may exist** -> human review, not semantic rejection and not guessing.

Do not encode a long catalog of specific Pega edge cases in the example.

## 5.3 Shared MultiInput KnowledgeArea example set

### EX-WHEN-01 — ordered typed inputs -> ordered target cells

Use at least three input columns with deliberately different types and unfamiliar values.

Demonstrate:

- identical ordered `(path,valueType)` census across rows;
- input order preserved;
- result cell emitted after inputs;
- target Decision cell mode does not replace Author semantic `valueType`;
- exact frozen lexical values are copied/wrapped, not recast.

### EX-WHEN-02 — row/order contrastive failure

Correct and incorrect microcases:

- correct: source row/input order preserved;
- wrong: inputs alphabetically reordered or rows reordered.

Purpose: prevent the model from treating JSON arrays as unordered collections.

### EX-WHEN-03 — absent input value

Demonstrate that an input cell still exists when source `value` is absent, but no expected value is invented.

Purpose: replace verbose prose around absent-vs-empty semantics for the target row representation.

## 5.4 What must NOT be placed in shared target KnowledgeArea

Do not add:

- Data Casting Matrix examples that derive post-cast values;
- DWL/RuleCrawler examples;
- Scenario Compiler examples;
- Author ASSERT/SIM/OMIT/GAP reasoning;
- Generator persistence/lifecycle examples;
- Validator issue-code/route examples used only by Validator;
- repair orchestration examples used only by Generator.

These do not satisfy the multi-agent shared-reference criterion or would blur semantic/target ownership.

---

# 6. Selected high-impact refactoring matrix

Only the following changes are approved for A8C. Lower-ROI opportunities are explicitly excluded.

| ID | Current area | Refactor | Shared example / mechanism | Behavior accuracy effect | Permanent-context effect | Anchoring risk after controls | Decision |
|---|---|---|---|---|---|---|---|
| A8C-R1 | Generator §4.2–§4.4 (~935 words) | remove repeated field-by-field explanations already represented by schema mappings + shared canonical examples; retain compact compile procedure and hard boundaries | EX-STD-01..04 / EX-WHEN-01..03 | **Very High positive** | **Very High positive** | Low | DO |
| A8C-R2 | Generator typed serialization prose inside §4.2–§4.4 | retain one short normative serializer boundary; replace repeated type-by-type prose with contrastive examples | EX-STD-01 | **Very High positive** | **High positive** | Very Low | DO |
| A8C-R3 | Generator §3.1 long illustrative conflict list (~280 words total section) | retain general classification algorithm; replace long list with impossible-vs-ambiguous contrast | EX-STD-05 | **Very High positive** | **High positive** | Very Low | DO |
| A8C-R4 | Validator §4.2–§4.7 (~1,172 words) | replace mirrored mapping catalog with independent reference-compile procedure using same frozen target contract | same shared examples; Validator never trusts Candidate | **Very High positive** | **Very High positive** | Very Low | DO |
| A8C-R5 | Validator repeated typed serialization rules | keep exact-fidelity requirement; remove duplicate serializer prose | EX-STD-01 + EX-WHEN-01 | **Very High positive** | **High positive** | Very Low | DO |
| A8C-R6 | Author §6.1–§6.7 (~890 words) overlaps §6.8 (~992 words) | keep §6.8 as authoritative closed grammar; compress §6.1–§6.7 to materialization procedure + a few Author-local shape examples | Author-local Standard/When/Informational microexamples, **not KnowledgeArea** | **High positive** | **Very High positive** | Low after variation | DO |
| A8C-R7 | Naming explanation duplicated across prompts | prompts retain ownership/source/retrieval boundary; algorithm remains only `CM-NAME-001`; examples vary `Gxxx` | EX-STD-04 | **Very High positive** | **High positive** | Very Low | DO |
| A8C-R8 | Full canonical JSON duplicated or potentially duplicated in prompts | never inline full A8B candidate fixture into multiple system prompts; keep full fixtures as regression artifacts / JsonExample | retrieved shared target artifacts | **High positive** | **Very High positive** | Very Low | DO |

No other prompt compression is approved in this plan without a new explicit review.

---

# 7. Explicit no-change zones

The following remain substantially text/rule driven because example replacement would increase semantic or control-flow risk.

## 7.1 Scenario Author

Do not example-compress:

- KnowledgeTool acquisition protocol;
- DWL / dependency state machine;
- RuleCrawler request/response gates;
- execution/producer/property provenance;
- Data Page simulation eligibility;
- Decision Table semantic reasoning;
- Scenario Compiler `I -> W -> F -> B -> A` state transitions;
- ASSERT/SIM/OMIT/GAP authority;
- Pega Data Casting Matrix and `CAST` evidence algorithm;
- pre-projection semantic gates;
- persistence / Generator orchestration.

Examples may illustrate an already defined rule but must not replace it.

## 7.2 Generator

Do not example-compress:

- invocation parsing;
- exact source GUID read;
- closed source-mode validation;
- semantic immutability boundary;
- WriteMemory/UpdateMemory protocol;
- G7-before-write requirement;
- uncertain-tool-call no-retry behavior;
- Validator invocation correlation;
- repair authorization/lifecycle;
- GeneratorRunReport contract.

## 7.3 Validator

Do not example-compress:

- JsonValidationTool gate;
- exact Projection/Candidate reads;
- group/GUID correlation;
- fidelity safety lock;
- prohibition on replacement semantic values;
- issue/action catalog;
- route precedence;
- ValidatorReport contract.

---

# 8. Target system-prompt retrieval wording

A8C must add an explicit retrieval/authority statement in both Generator and Validator. Exact wording may be refined, but it must preserve the following semantics.

## 8.1 Generator required semantics

The Generator system prompt must state, in compact form:

```text
Before target compilation, retrieve the selected target KnowledgeArea,
JsonSchema and JsonExample exactly once using the mode/RUTType mapping in
this prompt. Freeze that response for the invocation.

The system prompt owns behavioral boundaries. The Projection owns source
semantics. The selected schema/compiler mappings own enforceable target
shape and deterministic algorithms. The shared KnowledgeArea examples are
normative demonstrations of that target contract, not permission to infer,
cast, normalize or modify Projection facts.

If the required target contract is missing, duplicate, contradictory or
cannot define one safe representation where one is required, do not
reconstruct it from memory or from the Candidate/example; follow the
specified failure/review path.
```

The existing exact one-call request matrix remains.

## 8.2 Validator required semantics

The Validator system prompt must state, in compact form:

```text
Retrieve the same selected target contract independently and freeze it.
Use it together with the persisted Projection to derive the expected target
representation. Never use the Generator Candidate as target authority.

Shared examples demonstrate the selected target contract but cannot alter
Projection semantics or override the system-prompt validation boundary,
formal schema/compiler mappings, or cross-field invariants.

If the required shared target reference is missing, ambiguous or
contradictory, do not infer the intended mapping from the Candidate or model
memory; route to HUMAN review under the existing contract.
```

This independent retrieval is essential. Sharing specification authority is allowed; sharing Generator runtime output as validation authority is not.

---

# 9. A8C execution stages

## A8C-0 — Freeze baseline and create measurements

**Goal:** guarantee that prompt optimization is measured against the exact A8B behavior.

Actions:

1. Copy the three A8B current prompts to an immutable A8C baseline directory or historical reference.
2. Record SHA-256 hashes for:
   - three current prompts;
   - two Stage-3 schemas;
   - four paired fixture JSON files;
   - A8B mechanical check.
3. Record current word/character counts per prompt and per target section.
4. Run the existing A8B fixture check and require PASS before edits.
5. Create an A8C regression script shell that can run baseline fixture checks plus new example/adversarial checks.

**Exit criterion:** exact A8B baseline is reproducible and all existing A8B static checks pass.

**No production prompt change yet.**

---

## A8C-1 — Define shared example contract in target KnowledgeAreas

**Goal:** make shared examples reusable by Generator and Validator without moving behavioral authority out of system prompts.

Actions:

1. Draft Standard and MultiInput KnowledgeArea additions described in §5.
2. Assign stable example IDs:
   - `EX-STD-01..05`;
   - `EX-WHEN-01..03`.
3. For each example record:
   - purpose;
   - source fragment;
   - exact expected target fragment or route classification;
   - higher authority it demonstrates (`CM-*`, `CF-*`, schema keyword, normative serializer rule);
   - explicit non-authority statement.
4. Ensure examples use varied literals and group keys.
5. Link every positive compile example to a machine-checked fixture or a deterministic microfixture in the A8C regression harness.
6. Do not include Author-only semantic derivation.

**Exit criterion:** every shared example is used by both Generator and Validator, demonstrates an existing authority, and is mechanically reproducible.

---

## A8C-2 — Add explicit target-KnowledgeArea retrieval contract

**Goal:** make reliance on shared reference explicit and safe before deleting duplicated prose.

### Generator edits

Modify §3 so it explicitly states:

- exact retrieval timing;
- exact one-call batch;
- freeze-once behavior;
- authority precedence;
- examples are target demonstrations only;
- no semantic cast/normalization/inference;
- failure on incomplete/contradictory knowledge;
- no memory fallback.

### Validator edits

Modify the target-contract acquisition block after persisted reads/source-mode establishment so it explicitly states:

- independent retrieval;
- same shared target contract;
- Candidate is never reference authority;
- no source-semantic modification;
- human review on missing/ambiguous/contradictory shared target reference;
- no model-memory fallback.

**Exit criterion:** duplicated mapping prose has not yet been removed, but both agents already contain complete safe retrieval/precedence behavior. Static search proves every critical boundary still exists in the system prompts.

---

## A8C-3 — Generator high-impact compression

**Goal:** reduce deterministic target mapping prose while improving first-pass compile fidelity.

### Keep in Generator system prompt

Keep explicitly:

- Projection immutable semantic authority;
- no Pega semantic casting;
- no lexical normalization;
- exact source order/presence preservation;
- deterministic representation only;
- impossible vs ambiguous representability classification;
- reject before Candidate persistence where source cannot be represented;
- exact KnowledgeArea retrieval/authority rules;
- naming algorithm owner = `CM-NAME-001` only;
- full G7 and persistence/lifecycle contracts.

### Compress

1. §3.1:
   - retain the general two-class decision procedure;
   - remove most enumerated examples;
   - refer to shared `EX-STD-05` for demonstration.

2. §4.2–§4.4:
   - retain a compact deterministic compiler sequence;
   - retain only mappings that are not owned elsewhere and are necessary to execute the compiler;
   - where schema `CM-*`/`CF-*` plus shared example fully define a mapping, replace repeated prose with a concise reference;
   - retain the short `PegaQuotedLiteral` / lexical-preservation boundary if required to prevent recasting;
   - do not repeat the same type table in multiple subsections.

3. Do not inline full JsonExample or full paired fixture.

### Target size

Expected Generator reduction: approximately **650–850 words** (~15–19%).

This is a target, not a pass criterion.

**Exit criterion:** all baseline and adversarial compile fixtures remain exact; no behavioral invariant is present only in KnowledgeArea.

---

## A8C-4 — Validator high-impact compression

**Goal:** remove the mirrored Generator mapping catalog while preserving independent validation.

### Replace §4.2–§4.7 mapping repetition with a reference-compile procedure

Validator should conceptually execute:

```text
Projection
  + independently retrieved target schema/mappings/KnowledgeArea examples
       -> ExpectedCandidateFragment
Candidate
       -> exact presence/count/order/value comparison
```

The new compact section must still define:

- which source coordinates are in fidelity scope;
- exact equality primitives;
- order/presence/cardinality sensitivity;
- lexical-value exactness;
- independent naming reconstruction from `CM-NAME-001`;
- source coordinate -> candidate path diagnostics;
- no Candidate-as-authority behavior.

Do not keep a second prose copy of every Generator transformation when the shared target contract already defines it.

### Target size

Expected Validator reduction: approximately **700–850 words** (~21–25%).

**Exit criterion:** mutation tests prove Validator catches mapping defects not explicitly shown in examples and never accepts Candidate merely because it resembles a canonical example.

---

## A8C-5 — Author conservative Projection-section compression

**Goal:** remove internal duplication without moving Author semantic reasoning to shared target KnowledgeArea.

Current Author §6.1–§6.7 is ~890 words and §6.8 is ~992 words. The major opportunity is duplication between materialization prose and the already authoritative closed grammar.

### Keep unchanged or substantially unchanged

- all semantic reasoning before §6;
- casting matrix / CAST evidence;
- Scenario Compiler;
- semantic assertion ownership;
- §6.8 closed grammar and self-validation;
- persistence/Generator handoff.

### Compress §6.1–§6.7

Replace repeated shape descriptions with:

1. compact materialization procedure;
2. references to the exact §6.8 grammar;
3. at most three **Author-local** microexamples:
   - executable standard Projection shape;
   - executable When Projection shape;
   - informational NotTestable shape.

These examples remain in the Author system prompt, not KnowledgeArea, because they have only one consumer.

Use different literals/group keys across examples to prevent anchoring.

### Target size

Expected Author reduction: approximately **450–600 words** (~4–5%).

**Exit criterion:** producer grammar and self-validation are unchanged; Generator accepts the same valid source domain and rejects the same invalid source domain.

---

## A8C-6 — Example-anchoring controls and adversarial suite

**Goal:** prove the refactor teaches general rules, not literal pattern copying.

Create adversarial cases deliberately outside all examples.

Minimum suite:

### T1 — unseen group key

Use e.g. `G731`, not any example group key. Require correct naming under `CM-NAME-001`.

### T2 — unseen Text content that resembles a number

`formalType=Text`, lexical `"0012.500"`.

Require Text quoting; must not become Decimal or lose zeros.

### T3 — unseen Decimal lexical form

Use a valid lexical value not present in examples, preserving its exact representation. Require no normalization.

### T4 — absent vs empty

Compare absent source `value` with present `value=""`. Require different target presence behavior.

### T5 — unfamiliar primary page

Use an explicit page not present in examples. Require it first in page/class context.

### T6 — assertion sequence permutation

Use Property, Page, Param in an order not shown by examples. Require source-order-preserving deterministic output.

### T7 — When with unseen paths/types/order

Use different property names and row values. Require identical ordered census and exact row/input order.

### T8 — impossible source-target representation not shown in EX-STD-05

Require pre-write semantic rejection based on the general representability rule.

### T9 — ambiguous target rule not shown in examples

Require HUMAN review rather than guessing.

### T10 — Candidate mutation unknown to examples

Mutate a candidate field/order/cardinality that no example explicitly labels as wrong. Validator must detect it through the general contract.

**Exit criterion:** every test outcome follows the underlying rule/schema, not literal example similarity.

---

## A8C-7 — Context and behavior regression review

**Goal:** accept compression only where it is demonstrably beneficial.

For each agent record:

- before/after word count;
- removed sections;
- retained hard invariants;
- examples newly relied upon;
- KnowledgeArea dependencies;
- baseline fixture result;
- adversarial suite result;
- static contradiction/duplication findings.

### Acceptance thresholds

All are mandatory:

1. **100% A8B fixture preservation.**
2. **100% A8C adversarial expected outcomes.**
3. **No hard behavioral invariant moved exclusively to KnowledgeArea.**
4. **No Author-only material added to shared target KnowledgeArea.**
5. **Generator and Validator both explicitly retrieve and independently use the same selected target reference.**
6. **Validator never uses Candidate as specification authority.**
7. **No example contains Pega semantic casting derivation for Generator/Validator.**
8. **No full canonical JSON fixture duplicated in multiple system prompts.**
9. **Every example is linked to an authority and marked demonstrative rather than superseding.**
10. **At least one unseen/adversarial test passes for every major example dimension.**
11. **Net total prompt reduction is positive.** A reduction below the estimate is acceptable; correctness dominates size.
12. **No newly introduced conflicting duplicate rule wording.**

If any acceptance criterion fails, restore the affected A8B prompt section rather than weakening the test.

---

## A8C-8 — Promotion

Only after A8C-0 through A8C-7 pass:

1. create new current prompt authorities, e.g.:
   - `Main_Agent_Prompt_A8C_EXAMPLE_REFACTORED.txt`;
   - `UnitTestGenerator_Prompt_A8C_EXAMPLE_REFACTORED.txt`;
   - `Validator_Prompt_A8C_EXAMPLE_REFACTORED.txt`;
2. create A8C validation report with exact before/after metrics and test evidence;
3. update continuation manifest/current-authority pointers;
4. preserve all A8B prompts as historical/pre-refactor authorities;
5. do not overwrite historical evidence;
6. keep A4 deployment verification open unless the deployed KnowledgeAreas have actually been verified;
7. keep A9 runtime status unchanged unless a real Claude/Pega run is separately performed.

---

# 10. Detailed agent-by-agent change map

## 10.1 Scenario Author

### Change

Compress only §6.1–§6.7.

### Keep as hard prompt instructions

- Author owns semantics and type/casting;
- exact post-cast lexical value ownership;
- `testLabel` / `physicalGroupKey` source obligations;
- exact §6.8 grammar;
- closed-object rules;
- mode/cardinality;
- producer-only validation;
- persistence order.

### Example strategy

Three small local examples maximum. They are not shared KnowledgeArea because only Author consumes them.

### Expected risk

Low if §6.8 remains intact. High if semantic/casting sections are shortened; therefore those sections are excluded.

---

## 10.2 UnitTestGenerator

### Change

Compress §3.1 and §4.2–§4.4 after shared target examples and explicit retrieval are in place.

### Keep as hard prompt instructions

- deterministic compiler role;
- Projection immutability;
- no RuleCrawler/GetCaseData/semantic rediscovery;
- no Pega casting;
- no lexical normalization;
- exact source ordering/presence;
- exact single target-contract retrieval;
- authority precedence;
- failure on missing/ambiguous target reference;
- pre-write representability decision;
- naming delegated only to `CM-NAME-001`;
- G7 before write;
- exact persistence lifecycle;
- Validator correlation and repair limits.

### Shared examples used

- EX-STD-01..05;
- EX-WHEN-01..03.

### Expected benefit

Highest benefit of all three agents: deterministic mappings are exactly the task class where examples are more token-efficient and often more behaviorally precise than repeated prose.

---

## 10.3 UnitTestValidator

### Change

Replace most of §4.2–§4.7 with independent reference compilation + exact comparison.

### Keep as hard prompt instructions

- schema gate first;
- exact persisted reads;
- source/candidate correlation;
- independent KnowledgeArea retrieval;
- Candidate never target authority;
- no source semantic review;
- no replacement values;
- exact fidelity primitives;
- repair issue/action catalog;
- route precedence/report shape.

### Shared examples used

Same shared target examples as Generator, but Validator applies them independently to derive expected target representation.

### Expected benefit

Very high context reduction and lower Generator/Validator prose drift while retaining independent validation.

---

# 11. Anti-drift / anti-anchoring requirements for example authoring

Every shared example must satisfy all of the following:

1. **Single purpose:** demonstrates at most one or two closely related compiler rules.
2. **Literal diversity:** do not repeatedly use the same rule name, page, property, group key, number, boolean or scenario label.
3. **Type contrast:** where lexical content could mislead type inference, show the same/similar content under two authoritative types.
4. **Positive + negative pairing:** use a wrong example only when it targets a known high-risk model shortcut.
5. **Reason attached to authority:** wrong cases state the violated rule, not merely “wrong”.
6. **No incidental constants:** omit fields unrelated to the teaching objective.
7. **No semantic derivation in target examples:** examples begin from frozen Projection facts.
8. **No fixture-as-template assumption:** full fixtures stay regression artifacts; examples are excerpts.
9. **Unseen-test requirement:** every example category has at least one acceptance test with unrelated literals.
10. **Stable IDs:** examples have IDs so prompts can reference them without reproducing their content.

---

# 12. Expected context outcome

These figures are planning estimates, not contractual pass criteria.

| Agent | Baseline | Expected reduction | Expected final range |
|---|---:|---:|---:|
| Author | 12,717 words | 450–600 | ~12,117–12,267 |
| Generator | 4,460 words | 650–850 | ~3,610–3,810 |
| Validator | 3,361 words | 700–850 | ~2,511–2,661 |
| **Total** | **20,538** | **1,800–2,300** | **~18,238–18,738** |

Expected permanent prompt reduction: approximately **9–11% overall**.

This deliberately conservative target is preferred over a 20–40% whole-pipeline compression because the latter would require removing semantic/control rules where examples have higher anchoring risk.

KnowledgeArea response size may grow modestly, but:

- that content is retrieved only at the target-contract stage;
- it is shared by Generator and Validator rather than duplicated permanently in both system prompts;
- examples must replace existing repeated target prose rather than merely add tokens on top.

A8C should record both permanent system-prompt reduction and actual retrieved target-KnowledgeArea size so optimization is assessed on **total invocation context**, not system-prompt size alone.

---

# 13. Total-context acceptance metric

A8C must not optimize only the system prompt while making runtime context larger overall.

For Generator and Validator calculate:

```text
TOTAL_TARGET_CONTEXT =
  system-prompt target-contract words/tokens
  + retrieved target KnowledgeArea words/tokens
  + retrieved JsonSchema words/tokens
  + retrieved JsonExample words/tokens
```

Compare A8B and A8C on equivalent mode.

Desired result:

- permanent system prompt meaningfully smaller;
- total target-contract context no larger unless the additional retrieved tokens produce a demonstrated accuracy benefit;
- duplicate prose across system prompt and KnowledgeArea materially reduced.

If KnowledgeArea examples simply duplicate retained prose and increase `TOTAL_TARGET_CONTEXT`, the corresponding refactor fails and must be revised.

---

# 14. Failure conditions for the refactor itself

A8C must be rejected or partially rolled back if any of the following occurs:

- an agent-specific rule is moved to shared KnowledgeArea without a second legitimate consumer;
- Generator or Validator behavior depends on an example not grounded in schema/mapping/rule authority;
- a critical MUST/NEVER boundary disappears from the system prompt;
- Generator begins casting or normalizing Author values;
- Validator begins accepting Candidate by similarity to example rather than independent derivation;
- examples encourage fixed `G001`, fixed page names, fixed scenario counts or fixed type assumptions;
- examples and schema disagree;
- Standard and MultiInput KnowledgeAreas express inconsistent shared serialization semantics;
- missing KnowledgeArea leads to silent fallback rather than failure/review;
- total context grows with no measurable behavioral benefit;
- any A8B canonical fixture changes without a separately approved contract change.

---

# 15. Deliverables

A completed A8C implementation must produce:

1. three A8C refactored prompt files;
2. updated shared Standard and MultiInput KnowledgeArea source/reference files or deployable change specification;
3. stable shared example IDs and content;
4. A8C regression/adversarial checker;
5. before/after prompt and total-context metrics;
6. A8C validation report;
7. updated continuation manifest/handoff;
8. preserved A8B baseline files and hashes.

If live deployed KnowledgeArea editing is unavailable, A8C may produce proposed KnowledgeArea artifacts and complete all local/static refactor validation, but **A4 remains open** and the new prompts must not be declared deployed-runtime verified.

---

# 16. Final acceptance definition

A8C is complete only when all of the following are true:

> **The prompts are shorter because duplicated deterministic descriptions were replaced by shared mechanically grounded examples; system prompts still contain every critical behavioral boundary; Generator and Validator independently retrieve and apply the same shared target reference; examples do not teach Author semantics; unseen/adversarial cases prove generalization beyond example literals; and every A8B contract fixture remains unchanged and passing.**

Until then, A8B remains the production-contract baseline.

---

# 17. Execution order / exact next action

Current status at creation of this plan:

- A1–A8B: completed static/design baseline;
- A8C: **completed and promoted as static/design baseline**;
- A4: static deployment pack complete; live target-configuration capture remains open;
- A9: runtime not run.

**Exact next action:** A8C and A4 static preparation are complete locally. Obtain the independent live Generator/Validator Standard + MultiInput KnowledgeTool capture, populate `A4_LIVE_CAPTURE_TEMPLATE.json`, and run `A4_DEPLOYMENT_VERIFIER.py`. Only A4 PASS (or an explicitly accepted REVIEW revision) permits runtime A9.


# 18. A8C execution result

A8C-0 through A8C-8 completed locally on 2026-09-12. Evidence: `A8C_EXAMPLE_DRIVEN_REFACTOR_VALIDATION.md` and `A8C_REGRESSION_ADVERSARIAL_CHECK.py`.

Promoted prompt authorities:
- `Main_Agent_Prompt_A8C_EXAMPLE_REFACTORED.txt`;
- `UnitTestGenerator_Prompt_A8C_EXAMPLE_REFACTORED.txt`;
- `Validator_Prompt_A8C_EXAMPLE_REFACTORED.txt`.

Shared target-reference deployment proposals:
- `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_KnowledgeArea_A8C_PROPOSED.txt`;
- `04_TARGET_CONTRACTS/a8c_shared_reference/Rule-Test-Unit-Case_MultInpComb-KnowledgeArea_A8C_PROPOSED.txt`.

Acceptance result:
- A8B canonical fixtures preserved;
- T1–T10 adversarial suite 10/10 PASS;
- permanent prompt context reduced 20,517 -> 18,445 words (-10.1%);
- incremental target context is non-increasing for Standard and MultiInput modes;
- no critical behavioral invariant moved exclusively into KnowledgeArea;
- Author casting semantics remain system-prompt owned;
- Generator/Validator explicitly retrieve the shared target contract independently and never fall back to model memory.

Deployment/runtime boundary remains unchanged: A4 static verifier/capture tooling is complete, but A4 is still open because live KnowledgeTool contents were not available; A9 was not run.
