# Superseded continuation index

The current package is v7: [CURRENT_START_HERE.md](CURRENT_START_HERE.md).
It uses one composite-key WriteMemory upsert and GetMemory. The previous
[v6 source package](07_V6_WORK/RuleIQ_v6/README.md), [Memory-v1 contracts](09_MEMORY_RUNTIME/README.md)
and [specification v1](10_PEGA_IMPLEMENTATION_SPEC/README.md) are preserved as historical
references. Use the current index for active prompts, contracts, specification and release.
