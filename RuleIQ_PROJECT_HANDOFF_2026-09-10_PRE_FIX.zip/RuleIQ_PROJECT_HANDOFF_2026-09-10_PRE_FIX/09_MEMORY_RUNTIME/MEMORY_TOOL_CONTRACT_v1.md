# Memory boundary — v6 caller profile, revision 1

This document consolidates the current v6 contracts for the external Memory
implementation. It does not define backing Pega rules, database schema, locking,
deployment or a replacement service. The user's scope is contracts only.

Authority: Main §1A; Generator G1/G8.1/G8.3/G8.4; Validator V1/V3; accepted D-013
in the v52 ledger. Exact file hashes and current locations are in SOURCE_AUTHORITY.json.
Where this document defines a current caller profile, it does not restrict a
separately authorized future caller's generic metadata API.

## 1. Shared data and caller ownership

Types are exact `ScenarioGroup` and `UnitTestCandidate`. Addresses and payloads
are opaque strings: preserve case, whitespace, Unicode, delimiters and escapes
after exactly one transport JSON decode. Never trim, normalize, interpret a GUID
format, parse/reserialize payload content in Memory, or use a latest-record lookup.
Nonempty strings are required for case, group, GUID and stored payload.

| Caller | WriteMemory | GetMemory | UpdateMemory |
|---|---|---|---|
| Main | ScenarioGroup, one batch | unavailable | unavailable |
| Generator | UnitTestCandidate, immutable versions | ScenarioGroup, exact supplied GUID | current UnitTestCandidate lifecycle |
| Validator | unavailable | UnitTestCandidate, same GUID as successful schema check | unavailable |

Memory stores opaque `pyPayload`. Generator/Validator own JSON-schema and candidate
content checks. A successful storage call never implies an executable test passed.

## 2. WriteMemory

Exact arguments: `pxCaseID`, `Type`, `RequestsJSON`, all strings.
`RequestsJSON` is JSON text encoding exactly:

```json
{"pxResults":[{"pyGroup":"G001","pyPayload":"<exact opaque payload>"}]}
```

The current caller sends a nonempty list, each row with exactly those two fields
and a unique nonempty pyGroup. The caller does not supply pyGUID or lifecycle.
Each successful row creates a new opaque pyGUID, distinct from other created
records and older candidate versions. Candidate records contain the canonical
fields `pyGUID, pxCaseID, Type, pyGroup, pyPayload, pyStatusValue, pyRouterKey`;
the last two are initialized to `Pending` and the empty string.
No lifecycle defaults for ScenarioGroup are introduced by this profile.

Exact outer response fields:

```json
{"Success":true,"ResultsJSON":"<JSON text>","ErrorCode":"","ErrorMessage":""}
```

On outer success, ResultsJSON decodes to exactly `{"pxResults":[...]}` with
one row for each requested group. Each row has exactly:

```json
{"pyGroup":"G001","Success":true,"pyGUID":"<new GUID>","ErrorCode":"","ErrorMessage":""}
```

For row failure, Success is false, pyGUID is empty, ErrorMessage is nonempty,
and ErrorCode is one of `INVALID_INPUT`, `UNSUPPORTED_TYPE`, `WRITE_FAILED`.
Response order is irrelevant. Unknown, missing or duplicate result groups and
reused success GUIDs do not establish a trustworthy result.

Outer Success=true means the row result envelope is usable; it does not mean all
rows succeeded. Valid failures are isolated to their rows. Successful siblings
remain persisted and may be handed off. A malformed outer envelope, outer failure
or invocation exception makes the whole wave untrustworthy to the caller.
The caller neither retries nor infers rollback from an unconfirmed result.

## 3. GetMemory

Exact arguments: `pxCaseID`, `Type`, `pyGUID`, all nonempty strings.
Read only the exact GUID with matching case/type constraints. pyGroup is not a
lookup parameter. On success return the canonical response:

```json
{"Success":true,"pxCaseID":"<case>","Type":"UnitTestCandidate","pyGroup":"G001","pyGUID":"<requested GUID>","pyPayload":"<exact payload>","ErrorCode":"","ErrorMessage":""}
```

Success is a Boolean; all other fields are strings. A successful read requires
empty errors, nonempty payload and exact case/type/GUID equality. The caller
also compares pyGroup to its independently supplied group reference.
Failed/malformed reads, exceptions or mismatches terminate only that group/UT;
there is no retry, source fallback or use of partial payload.

Lifecycle fields do not belong to this response. Observing them for implementation
acceptance requires an independent read-only projection of the stored canonical
record. Do not extend the v6 response silently for this purpose.

## 4. UpdateMemory

Exact arguments: `pxCaseID`, `Type`, `RequestsJSON`. Current Generator uses
Type=UnitTestCandidate. RequestsJSON encodes exactly `{"pxResults":[...]}`.
Each row contains exactly `pyGroup`, `pyGUID`, `pyUpdates`:

```json
{"pyGroup":"G001","pyGUID":"<current candidate GUID>","pyUpdates":{"pyStatusValue":"Passed","pyRouterKey":"OK"}}
```

Address by GUID; verify existing record case/type/group/GUID before applying a
patch. No lookup by group, no new record, and no latest-version fallback.
The nonempty pyUpdates object shallow-replaces explicitly named allowed root
fields only. Omitted fields retain their values. There is no deep merge, path
interpretation, implicit deletion or implicit lifecycle reset.

The service must protect pyGUID, pxCaseID, Type and pyGroup. The current Generator
profile also protects pyPayload and permits only string pyStatusValue/pyRouterKey.
Future additional metadata permissions require an explicit caller contract; they
are not inferred from the word generic. Current waves contain one active version
per group with distinct GUIDs. This caller constraint does not redefine a future
service-wide batch policy. Duplicate/uncorrelatable rows are never emitted by v6.

Exact response outer fields are the same as WriteMemory. On outer success,
ResultsJSON has one pxResults row per requested `(pyGroup,pyGUID)`, with exact
fields `pyGroup,pyGUID,Success,ErrorCode,ErrorMessage`. Both success and failure
echo the requested group and GUID. Successful rows have empty errors; failed rows
have a nonempty stable error code and bounded diagnostic. No new closed update
error vocabulary or numeric diagnostic limit is invented here: the current caller
treats every failed update as LIFECYCLE_UPDATE_FAILED regardless of its text/code.

Validate all changes within a row before exposing its successful result. An
invalid identity/protected-field attempt must not leave a partial metadata patch.
Successful sibling rows remain effective when another row fails. An outer failure
or malformed/uncertain result leaves all wave outcomes unconfirmed to the caller,
even if a server actually committed before losing its response.

## 5. Lifecycle and no-retry caller behavior

| Valid Validator route | Exact Generator patch | Next action after confirmed update |
|---|---|---|
| OK | Passed / OK | candidate is eligible; GR OK |
| GENERATOR_REPAIR | Failed / GENERATOR_REPAIR | new immutable candidate if budget remains |
| SEMANTIC_REJECT | Failed / SEMANTIC_REJECT | terminal group failure |
| HUMAN | Failed / HUMAN | terminal group failure |

Each patch is one attempt. Explicit failure, malformed response and uncertain
outcome do not authorize a retry. All end that group as LIFECYCLE_UPDATE_FAILED,
with no further repair. A malformed/unattributable Validator report has no valid
route and produces zero UpdateMemory calls; candidate remains Pending.

Repair budget is per group: initial validation plus at most two repaired versions.
A repaired candidate has a new GUID and independent Pending initialization; prior
candidate payload and failed lifecycle stay intact. Main may report Completed
when another independently attributable group has a valid GR OK.

## 6. Verification and remaining external work

memory_contract.py is a read-only contract assertion library. It validates requests,
correlated responses and supplied before/after canonical record projections. It
does not store data or establish the provenance of a supplied snapshot. A local
test or synthetic snapshot is never evidence of real Memory persistence.

ACCEPTANCE_CASES.json specifies external cases and their evidence requirements.
Fault-injection cases require both raw call traces and independent record snapshots.
The no-retry cases test the caller, not a hypothetical server retry mechanism.
Durability requires another server request/requestor to read committed state.

C-027/C-028/C-029 remain EXTERNAL_PENDING for implementation/runtime. This stage
can close only the contract specification, caller compatibility review and local
assertion checks. It cannot close storage, isolation, concurrency or runtime work.
