# Memory — completed contract stage

The user confirmed that this workspace maintains prompts and contracts only.
Memory implementation remains external. Pega access is not required for this stage.
All documentation and authored content are in English.

Deliverables:

- MEMORY_TOOL_CONTRACT_v1.md: one specification for WriteMemory, GetMemory and
  UpdateMemory, covering fields, addressing, payload preservation, independent
  row results, lifecycle and no-retry behavior.
- memory_contract.py: read-only assertions for requests, responses and supplied
  canonical record snapshots. It contains no storage or Pega calls.
- test_memory_contract.py: positive/adversarial assertion checks and verification
  against the exact three v6 prompt versions.
- ACCEPTANCE_CASES.json: 24 cases for the external implementation, including 20
  service cases and four caller failure cases. No runtime cases were executed.
- SOURCE_AUTHORITY.json: source hashes and 18 exact current prompt anchors, with
  D-013 as the authority for generic shallow patch semantics.
- STATUS.json and LOCAL_CONTRACT_VERIFICATION.json: actual completion and results.

All 90 local checks passed. C-027/C-028/C-029 remain EXTERNAL_PENDING for external
implementation. Specification and local checking are complete; service behavior,
durability and concurrency were not verified. v6 prompt and tool source bytes are
unchanged by this contract stage.

GetMemory does not return lifecycle metadata. Pending/Passed/Failed acceptance
requires a separate read-only canonical record projection or server trace. Do not
extend GetMemory solely for the acceptance harness. Success=true alone does not
prove durable storage.

Run local checks from the handoff root without third-party dependencies:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 09_MEMORY_RUNTIME/test_memory_contract.py
```

When moving this package separately, provide the v6 source directory:

```sh
python3 test_memory_contract.py /absolute/path/to/RuleIQ_v6/sources
```

In external acceptance requests, {{test_case_id}}, {{other_test_case_id}},
{{candidate_A}}, {{candidate_B}} and {{missing_guid}} are placeholders for a
future dedicated test run. Obtain GUIDs from actual successful Memory responses.
A creation check compares that returned GUID, the original request and an
independent canonical stored-record snapshot.

Next contract task: review the LLM-visible RuleCrawler interface and document its
mapping to the unchanged reference export. Implementation changes, deployment and
runtime execution remain outside this workspace.
