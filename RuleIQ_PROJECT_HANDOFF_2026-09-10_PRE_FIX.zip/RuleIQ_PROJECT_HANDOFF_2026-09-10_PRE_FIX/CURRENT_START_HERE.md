# Current package — RuleIQ v8 / Variant B

Use **12_V8_WORK/RuleIQ_v8/** for current work. One fresh Generator invocation owns one
physical ScenarioGroup, including its validation and repair lifecycle. Author confirms the
complete source batch first, processes groups sequentially, and stops on the first failure.
Memory v3 creates a new immutable GUID per candidate version; UpdateMemory changes lifecycle
metadata only. Both agents use three named inputs and return JSON reports.

- [Current package README](12_V8_WORK/RuleIQ_v8/README.md)
- [Complete v8 archive](08_RELEASE/RuleIQ_v8_Variant_B_Prompts_Contracts_Pega_Spec.zip)
- [Step-by-step tool walkthroughs](12_V8_WORK/RuleIQ_v8/examples/TOOL_CALL_WALKTHROUGHS.md)
- [Pega implementation specification v3](12_V8_WORK/RuleIQ_v8/specification/PEGA_IMPLEMENTATION_SPEC_v3.md)
- [Memory contract v3](12_V8_WORK/RuleIQ_v8/memory_contracts/MEMORY_TOOL_CONTRACT_v3.md)
- [Current state](12_V8_WORK/RuleIQ_v8/CURRENT_STATE.json)
- [Verified release evidence](08_RELEASE/RuleIQ_v8_RELEASE_VERIFICATION.json)

893 local regression checks passed, including after extracting the archive outside the
workspace. Package hashes, embedded prompts, links and archive contents were checked.
Actual Pega configuration, execution and context isolation remain unexecuted external acceptance.
All delivered artifacts are English.

Earlier packages, including **11_V7_WORK/RuleIQ_v7/**, are preserved historical versions.
They do not define the active v8 contracts. Root START_HERE.md/CURRENT_STATE.json and older
version-specific pointers remain historical snapshots. Do not apply v7 upsert behavior to v8.
