# RuleIQ Full-Project Cross-Reference Audit v1

**Final verdict: REOPENED / CORRECTIONS_REQUIRED.**

The current v5 verifier suite still passes, but the pass is not sufficient to certify the entire project. A fresh cross-file review and control-flow simulation found residual contradictions, unimplemented earlier accepted/confirmed corrections, and coverage holes in the verification suite.

## Verification facts

- Existing `risk001` verifier: **PASS**, 49/49, failures=0.
- Existing `architecture` verifier: **PASS**, failures=0.
- Existing `examples` verifier: **PASS**, 84/84, failures=0.
- Existing `multinpcomb_deep` verifier: **PASS**, 212/212, failures=0.
- Change register: 77 rows: VERIFIED_LOCAL=74, EXTERNAL_PENDING=3.
- Package manifest hashes: **PASS**. ZIP CRC: **PASS**.
- Canonical package completeness: **FAIL**; missing `Rule_Crawler_tool.txt`.
- Informational schema mutation experiment: both STANDARD and MULTINPCOMB schemas accept `ReasoningConfidence=High` and `DependencyClosureStatus=Closed` while BlockingGaps remain nonempty. This is a real schema/Validator coverage hole, not a prose-only concern.

## Highest-priority blockers

### FP-001 — HIGH — Canonical project package omits Rule_Crawler_tool.txt

**Impact:** A full-project certification cannot claim the packaged source set was cross-read end-to-end against the RuleCrawler implementation.

**Source evidence:**
```text
v5 sources contains 19 files but canonical 16-file core is missing Rule_Crawler_tool.txt
```
```text
FINAL_SOURCE_MANIFEST_v5 matches those 19 files and ZIP CRC is clean, so this is a completeness gap rather than archive corruption
```
```text
Live GitHub Rule_Crawler_tool exists, but it is outside the v5 local source package.
```
**Correction:** Add the exact intended Rule_Crawler_tool.txt version to the audited package/manifest and rerun cross-reference checks.

### FP-002 — HIGH — Initial identity gate does not fail fast on pyID/TestedRuleKey/full RUT identity

**Impact:** An empty pyID or missing/conflicting TestedRuleKey can survive into semantic work and fail only at storage/materialization.

**Source evidence:**
```text
196: 1. Call `GetCaseData`; read exact `pyID` and parse the RUT RuleJSON.
197: 2. Require non-empty `RuleJSON.pzInsKey` and `RuleJSON.pxObjClass`; otherwise stop before Scenario formation/storage and return bounded Failed status.
198: 3. Lock `pxCaseID=pyID` and immutable original `RUT_TYPE=RuleJSON.pxObjClass`.
```
```text
1719: - `caseKey` is exact GetCaseData.TestedRuleKey. Its first three whitespace-separated components must equal uppercase SG.rutType, SG.rutClass, and SG.rutName. Before freezing, Author verifies this correspondence against the original RuleJSON identity; missing or conflicting identity terminates materialization rather than inventing a key. A linked EVIDENCE with kind=RUT, source=GetCaseData/TestedRuleKey and canonical fact `{"TestedRuleKey":<exactKey>}` preserves the original value.
```
**Correction:** Immediately after GetCaseData require nonempty pyID, parseable nonempty TestedRuleKey, nonempty pzInsKey/pxObjClass/pyClassName/pyRuleName, and early identity agreement.

### FP-004 — HIGH — Rule-Obj-When decision authoring remains unconditional despite NOT_TESTABLE zero-ASSERT rule

**Impact:** A NotTestable When Scenario is simultaneously required to create DecisionInput/DecisionResult ASSERTs and required to have zero ASSERTs.

**Source evidence:**
```text
1637: ### 12.2 Rule-Obj-When cell and result decisions
1638: 
1639: For every Scenario at local row N, create exactly one semantic DecisionInput ASSERT per ordered COLUMN and exactly one DecisionResult ASSERT:
1640: 
1641: - DecisionInput row is N and target/class/mode/value exactly match its physical DECISION_INPUT INPUT;
1642: - an initialized empty cell retains its carrier and uses semantic value `<EMPTY>`;
1643: - DecisionResult row is N, target is Result, mode is text, comparator intent is Is Equals To, and value is typed true or false;
1644: - paths retain namespace, leading dot, indices, keys, spelling, casing, and root exactly;
1645: - no simulated Data Page root becomes a physical input column;
1646: - terminal dependency evidence supports the final Result; critical uncertainty is never guessed or hidden by confidence.
1647: 
1648: Column signature equality is required only among Scenarios inside the same physical group. Different simulation groups may have different signatures.
```
```text
1678: - a blocking gap affecting exact value, branch result, dependency-controlled value, required simulation, or execution feasibility forces Low confidence and PartiallyTestable while at least one meaningful executable ASSERT remains; if none remains, use NotTestable, remove all ASSERT/SIM decisions from that Scenario, retain explicit OMIT/GAP evidence, and place it only with other NOT_TESTABLE Scenarios;
1679: - SomeUnresolved/Blocked dependency state, queued work, or unscanned RuleJSON cannot be hidden by confidence and normally prevents finalization until terminal;
1680: - confidence/testability never removes required coverage, changes frozen membership, or authorizes an unsupported ASSERT.
1681: 
1682: Before handoff, all Scenario summary and decision records must pass count, reference, producer, dependency, simulation, Decision Table, seed, and coverage consistency checks.
1683: ### 12.2 Final pre-materialization semantic gates
1684: 
1685: 
1686: Run these gates over the final semantic records before ScenarioGroup serialization. A correction that changes Scenario inputs, execution, effects, simulation, decisions, root, or grouping returns to WITNESSES, rematerializes the complete affected snapshot, and requires new FROZEN, B, and A phases. Never patch one finished record in place.
1687: 
1688: 1. **When cell and trace gate.** For each EXECUTABLE `Rule-Obj-When` physical group, every Scenario has exactly one DECISION_INPUT INPUT and one DecisionInput ASSERT per ordered COLUMN, plus one DecisionResult ASSERT. Their row equals local Scenario order; path, class, mode, and typed value match. No COLUMN or physical input is rooted in a simulated Data Page. For NOT_TESTABLE groups, every Scenario has zero ASSERT/SIM decisions, at least one OMIT and blocking GAP. Equal `(SIMULATION_GROUP_KEY, EXECUTION_CLASS)` pairs share one group and unequal pairs never mix.
1689: 2. **Dependency evidence gate.** Every unresolved, missing, key-only, limited, or blocked dependency statement resolves to the latest canonical `D` row and terminal DEP/GAP evidence. READY, CTX, requested, fetched-unscanned, queued, or otherwise active work returns to the crawl state machine. No positive exact assertion may depend on unresolved executable behavior.
```
**Correction:** Scope §12.2 DecisionInput/DecisionResult construction to EXECUTABLE groups; define NOT_TESTABLE branch as OMIT/GAP-only.

### FP-005 — CRITICAL — Informational NotTestable path is not reconciled with Main storage/Data Page gates

**Impact:** The new no-RuleCode/zero-SIM outcome can be blocked by a storage gate that still requires final RuleCode audit. If NotTestable is caused by an unresolved required Data Page, the prompt also requires a complete simulation key/DPA pass while forbidding guessed SIM and allowing NO_SIMULATION only when no simulation is required. This is a dead path.

**Source evidence:**
```text
1004: `DWL_CLOSURE_GATE` passes when:
1005: - latest `_DWLState.CHECK.open=0`, `ready=0`, `ctx=0`, and `unscanned=0`;
1006: - every final branch/evaluation claim uses executable dependencies from `_DWLState.CLOSED`, or the claim is omitted/downgraded because of terminal `_DWLState.GAPS`;
1007: - every terminal gap appears in `_DWLState.GAPS` and is non-critical for emitted assertions or reflected in omissions;
1008: - Data Page simulation and producer/list gates pass, including compact `DPA.pass=true` for every reachable/unknown `DP_SIG`.
1009: 
1010: READY, CTX, REQUESTED, FETCHED, unclosed SCANNED, and unscanned rows are work, not final evidence. They require the next crawl/scan/state transition; they cannot be used as a reason to omit/downgrade and then author.
1011: 
1012: `DWL_STORAGE_GATE` passes when `DWL_CLOSURE_GATE`, producer/list gates, and final RuleCode/Data Page audit pass. Final Data Page audit means `DPA.pass=true` for every reachable/unknown `DP_SIG` from latest `_DWLState` and RuleCode. If it fails while `open>0`, READY/CTX/REQUESTED/FETCHED/unclosed SCANNED/unscanned work exists, execute the next crawl/scan/state action and do not call `legacy candidate-write transport`. `DependencyClosureStatus=Incomplete` is internal pre-storage state only and must never be stored as `UnitTestRules`.
```
```text
1070: ### 9.0 Runtime Data Page simulation obligation
1071: 
1072: Every reachable/unknown Data Page access discovered in `MODE=CRAWL` is a simulation obligation in `MODE=AUTHOR`. Keep it in the compact DWL model; do not create a parallel DP ledger.
1073: 
1074: Rules:
1075: 1. `DP_SIG = DP KEY + normalized parameter set` is the identity for simulation. In `MODE=CRAWL`, the normalized set may contain parameter bindings such as `ObjectID=.Objects(1).ID`; in `MODE=AUTHOR`, each Scenario must instantiate those bindings with concrete seeded values. Same Data Page with different concrete parameter values creates separate `SIM` obligations.
1076: 2. Preserve the verbatim Data Page access and every visible bracket parameter. Required parameters must be non-empty unless fetched `Rule-Declare-Pages` metadata proves empty is valid.
1077: 3. Property-expression parameters must be seeded on the exact Scenario page/context. `DPA` matches the crawl-time binding to the Scenario-time concrete `SIM`/`pySimulation` parameter value.
1078: 4. In `MODE=CRAWL`, reachability is `unknown` unless a scenario-independent pre-access exclusion is proven; unknown is a simulation obligation. Scenario-local exclusion in `MODE=AUTHOR` can only become `OMIT_NONCRITICAL` with proof and cannot justify a positive DP-dependent assertion.
1079: 5. `pySimulation` is required for every reachable/unknown `DP_SIG` with resolved Scenario params. Empty/no-match output is valid only when explicitly represented in `pySimulation` for the same `DP_SIG`. Missing `pySimulation` is blocking, not equivalent to empty results.
1080: 6. Data Page rows and simulation audit must not modify non-DP `KEY`s, helper class resolution, `targetClass`, or `pxRuleClassName` for When/Model/Prop rows.
1081: 
1082: Compact final audit:
1083: `DPA|pass=<true|false>|matched=<DP D id->SIM id>|missing=<DP_SIG...>|fix=<return WITNESSES or reserialize frozen payload>`
1084: 
1085: `DPA.pass=true` requires every reachable/unknown `DP_SIG` to have: matching `RuleCode.pySimulation`, same normalized parameters, required/property-expression params seeded, correct page/list shape, and explicit output for empty/no-match cases.
```
```text
1828: - `kind=STANDARD` requires `rutType != Rule-Obj-When`, `scenarioCount=1`, and absent `simulationGroupKey`.
1829: - `kind=WHEN` requires `rutType=Rule-Obj-When`, one or more scenarios, and exactly one key. A no-simulation group uses the literal `NO_SIMULATION`. Otherwise the key is canonical minified typed JSON with exact root shape `{"simulations":[<entry>...]}`. Object keys are recursively sorted and array order is preserved.
1830: - In the complete Author snapshot, `groupOrder` is contiguous. Persistence response order is non-authoritative; a partial successful handoff may omit failed groups. Each successful SG record carries its own `pyGroup` and `pyGUID`, while `groupOrder` remains source metadata used only for deterministic presentation.
1831: 
1832: Each non-empty `simulations` entry has exactly these keys and no others: `itemClass`, `params`, `payload`, `pyClassName`, `pyMockingSupportedRuleTypes`, `pyRuleNameToBeMocked`, `pySimulationMethod`, `pxReferredFromClass`, `setupPages`, `shape`, `sig`, and `target`. Nullable `itemClass` and `pxReferredFromClass` use JSON null. `params` is the canonical typed parameter object and `payload` is the complete typed mock result. `setupPages` is an ordered array of objects containing exactly `pyPageDetails` and `pySetupPageName`; `pyPageDetails` is an ordered array of objects containing exactly `path`, `value`, and `valueType`. The key therefore distinguishes every source-required runtime field, class, shape, method, target, typed parameter, mock payload, setup page, setup path, and setup value. Only the explicitly excluded persisted metadata in the source contract is absent.
```
```text
1913: #### 13.4.5 Simulation decisions
1914: 
1915: `SIM|id=<ID>|rule=<dataPageOrRule>|sig=<DP_SIG>|shape=<page|list>|method=DefineData|class=<class>|itemClass=<itemClassOrAbsent>|params=<normalizedParams>|target=<targetPath>|mockingRuleType=<ruleType>|referredFromClass=<classOrAbsent>|setupPages=<canonicalTypedJSON>|scenario=<ID>|order=<N>|payload=<canonicalTypedJSON>|parameterResolutions=<paramIDsOrAbsent>|evidence=<evidenceIDs>`
1916: 
1917: The leading fields intentionally preserve the canonical cross-agent trace grammar. `sig=<DP_SIG>` and `params=<normalizedParams>` are mandatory, non-empty, exact frozen values. `params`, `setupPages`, and `payload` are canonical minified typed JSON. `setupPages` has the same exact array shape used in the group key. `shape=list` requires non-absent `itemClass`; `shape=page` permits absent `itemClass`. Every resolved executed eligible DP access has a SIM decision; repeated equal signatures may share it with separate access evidence. Unknown accesses or parameters have explicit gaps and no guessed SIM. Excluded-scope Data Pages instead produce an explicit gap/downgrade or a new witness; `NO_SIMULATION` is never a SIM signature.
1918: 
1919: For WHEN, each Scenario's ordered SIM records serialize to the complete `simulationGroupKey` entry set; every declared key field is compared, not only signature and parameters. A `NO_SIMULATION` group contains zero SIM records in every Scenario.
```
**Correction:** Define an informational storage gate that does not require RuleCode. For terminal unresolved DP simulation, define a canonical NOT_TESTABLE grouping identity or isolate each informational Scenario without requiring a resolved simulation payload; allow terminal simulation gaps to pass informational storage without DPA.pass=true.

### FP-006 — HIGH — Rule-Obj-When KnowledgeArea deletes scenarios that new architecture must preserve as informational NotTestable

**Impact:** KW.16.1 says an untestable fixed-column scenario must not be a row and must not appear in Scenarios[], while RISK-001 requires preserving it in a no-RuleCode informational candidate.

**Source evidence:**
```text
103: KW.16.1|I|ColumnSignatureLockAndListSizeFeasibility
104: I: DecisionColumnSignature is fixed from the UNION of all candidate scenario input paths and identical across all rows. Enumerate all scenarios first, collect every discriminating input path, then lock the signature from that union. If a scenario requires an input path not present in Row 0, add it to the signature and backfill all other rows with a present cell and omitted pyExpectedValue for that column. Never derive the signature from Row 0 alone.
105: I: For a PageList accessed via pxPageListLengthCompare or equivalent, the list size seen at runtime equals the COUNT OF SEEDED INDEX CELLS in the column signature, regardless of whether their pyExpectedValue is present or empty (KW.16: empty cell = initialized item, not absent).
106: I: BEFORE selecting column paths, enumerate all candidate scenarios. For each scenario whose distinguishing condition is a list-size boundary (e.g. length <= N), verify that the required list size CAN be represented by a single fixed column signature shared with all other rows.
107: I: If it cannot â€” because other rows require more indexed cells than this scenario's target size â€” the scenario is UNTESTABLE within this MultInpComb. Mark it OMIT reason=schema_incompatible_assertion_target. Do NOT add it as a row. Do NOT describe it in Scenarios[].
108: I: Only after all untestable scenarios are excluded, lock the column signature from the remaining rows.
109: X: Rows need pyConditionList(1) and pyConditionList(2) columns. A "list length=1" scenario requires only pyConditionList(1) to be initialized. But the fixed column signature always initializes pyConditionList(2) (even empty). Runtime length=2, not 1. Scenario is untestable in this MultInpComb -> OMIT.
```
**Correction:** Clarify: exclude it from EXECUTABLE MultInpComb rows, but preserve it as a NOT_TESTABLE physical group/candidate with no RuleCode.

### FP-007 — HIGH — G5/G6 RuleCode projection is not explicitly gated to EXECUTABLE mode

**Impact:** G4 defines INFORMATIONAL_NOT_TESTABLE as no RuleCode, then G5/G6 continue with unconditional parameter/setup/simulation/assertion physical projection. This creates a direct control-flow ambiguity.

**Source evidence:**
```text
66: ## G4. Candidate and Rule Metadata
67: 
68: For each independently ready physical `pyGroup`, create exactly one raw UnitTestCandidate JSON object with the sole root key `UnitTestRules`. Its `UnitTestRules` array contains exactly one entry for that physical group. There are exactly two mutually exclusive candidate modes. **EXECUTABLE**: every Scenario is FullyTestable or PartiallyTestable and the entry contains RuleCode; a non-When entry contains one Scenario, while a Rule-Obj-When entry contains one shared Decision block and one Scenario per retained combination row in original relative order. **INFORMATIONAL_NOT_TESTABLE**: every Scenario is NotTestable and the entry omits RuleCode completely. Never emit RuleCode for NotTestable, never omit RuleCode for FullyTestable/PartiallyTestable, never mix the two modes in one physical group, combine different `pyGroup`s in one candidate, split a When group downstream, merge groups, or collapse Scenarios.
69: 
70: Allow only fields permitted by the selected schema. Do not emit internal ledger tags/IDs, raw RuleJSON, PROFILE, transport addresses, validation reports, analysis, audit ledgers, pz* fields or legacy persistence fields into the candidate. AssertionDecisionTrace is the deliberate schema-approved compact decision projection.
71: 
72: Set Status=New; preserve frozen ScenarioType, confidence and testability (Testable -> FullyTestable; PartiallyTestable and NotTestable unchanged). Format Scenario.Name as its semantic purpose, not a rule name, at most 50 characters from letters/digits/space/underscore, never beginning TC_. Mechanical character cleanup is allowed without changing purpose. Do not introduce RUT-name prefixes. Description and narratives summarize only frozen NARRATIVE/seed/assertion/simulation facts in plain language, at most two sentences per field; no RUF names, step IDs, parameter names, conditions, indices or branch mechanics. Technical facts belong in EvidenceSummary and, only for EXECUTABLE mode, RuleCode.
73: 
74: Use TC_<RUT_BASE_FINAL>_<SCENARIO_LABEL>, at most 53 characters. In EXECUTABLE mode rule-name equality is mandatory: entry.Name = RuleCode.pyPurpose = RuleCode.pyLabel. In INFORMATIONAL_NOT_TESTABLE mode RuleCode is absent, so only entry.Name uses this deterministic naming rule. Remove whitespace from the RUT name, replace other forbidden name characters with underscore, and use a short PascalCase semantic label. Append stable G<original groupOrder> to disambiguate equal purpose labels across physical groups; shorten the semantic label to fit 32 characters including that suffix, then allocate 49 minus label length to the RUT base. Name the physical group from its original first Scenario even after pruning, so unaffected rule identity is stable. Mechanical repairs may correct naming/length/equality but never semantic purpose or membership.
75: 
76: Only in EXECUTABLE mode, RuleCode.pyClassName and pyPrimaryPageForRUT come from ROOT.class/page. pyPagesAndClasses copies the complete exact frozen page/class map, including primary and only evidenced named pages. pyRuleUnderTest.pyDetails copies rutName, rutClass and original rutType. pyRuleUnderTestInsName joins the verified second/third PROFILE.caseKey components as CLASS!NAME. pyIsSinglePageImplementation copies the profile (Model/When false; other types source-evidenced). Do not add schema-forbidden pyDetails.pyClassName despite illustrative wording elsewhere. pyTypeOfSetupPageSelection is CUSTOMPAGES when setup pages are emitted. Omit optional heuristic execution flags unless an authoritative required value exists; do not invent cleanup actions.
77: 
78: ## G5. Parameters, Setup and Simulations
79: 
80: Physical Param namespace INPUT records identify formal RUT arguments, including When DECISION_INPUT Param paths. Match their resolution to exact PARAM and declaration evidence. Never classify an ordinary When input as a formal merely because PARAM.dependency=RUT.
```
```text
82: Use the verified formal-parameter value table: String -> quoted Pega string literal with lossless inner escaping; Integer -> canonical integral text; Decimal -> exact decimal text; Boolean/TrueFalse -> true/false text; PAGE -> evidenced concrete setup page name. Missing/unknown/unsupported/incompatible types cannot be dropped or guessed. STANDARD MethodParam permits pyParametersParamType only for PAGE, so omit that field for scalar parameters while retaining typed value serialization. MultInpComb uses Text/Integer/Decimal/TrueFalse/PAGE labels for these supported formal types; keep formal declarations and carry scalar combination values in Param input cells, omitting shared fixed values for those cells. Only a frozen non-cell PAGE argument gets a shared fixed page value. Equal declarations/shared PAGE values are required within a When group. Use the selected family's same MethodParam schema for ordered setup/cleanup action parameters.
83: 
84: Project physical INPUT and SETUP data to pySetupPages, excluding PARAM and When DECISION_INPUT carriers. ROOT.primarySetup=true includes the primary page with pxObjClass=ROOT.class. Additional pages use frozen page/class evidence; Every Param-namespace INPUT resolves its actual PARAM; formalType=PAGE initializes its concrete evidenced page, including applicable When cell inputs, even with no incidental seed property. PAGE_PARAM is not a wire role. SETUP role PAGE_AND_CLASS declares/initializes its evidenced page without inventing property values. DTA_BEFORE goes to the exact recorded invocation page. Preserve every seeded typed value, including false, zero, empty string, null, arrays and objects. Numeric values must not lose decimal precision.
85: 
86: Decode property paths mechanically: dot-separated properties, one-based numeric collection indices and exact symbolic group keys become nested objects/arrays without renaming, changing depth or duplicating roots. Numeric-index holes and conflicting duplicate seeds are unprojectable; do not fill holes with invented records or overwrite one frozen value with another. Preserve explicit empty initialized carriers; absence is not an empty value. No new physical input may be added after freeze.
87: 
88: PROFILE.actions maps in order to pySetup/pyCleanup, with pyActionType/type, pyActionName/name, optional pyTargetPage/page and typed pyParameters. Validate full ordered action and argument source censuses, even empty arrays. Page seeding is not a substitute for executing an action. A mocked DP must not become LoadDataPage.
89: 
90: Each SIM maps to one pySimulation entry with exact rule name, class, mocking type Rule-Declare-Pages, method DefineData and optional evidenced referred-from class. SIM.setupPages is the exact complete ordered page census. The revision-1.4 EXECUTION SIMULATION_BINDING/<ID> snapshot identifies payloadPage and itemPath, which must be present exactly once in that census. Put the frozen payload only on that page; merge typed page-detail seeds with exact conflict detection, and emit no extra page. The payload carrier need not be first and is never inferred from the DP name or a template. For list shape, itemPath is the exact evidenced payload-root-relative collection path; validate only that selected array and every member against itemClass, both before and after merging frozen page-detail seeds into the final emitted payload page. Newly seeded items require the exact declared class too. An unrelated empty or correctly classed array cannot establish validity. Page-shaped simulations require itemPath=null. Preserve unrelated arrays/fields. For list shape preserve the evidenced wrapper class, domain collection name (Items, pxResults or another recorded name), item classes and navigation depth. Do not invent a root or require a particular collection name. A missing/unevidenced binding is malformed source; an unprojectable payload/seed conflict rejects the affected scope. Each When simulation-group key also includes the exact payloadPage/itemPath binding. Preserve all concrete DP_SIG and params in the canonical SIM trace and cross-check them against PARAM resolutions, group keys and the one-to-one physical mock map. The current schema cannot separately address two different signatures of the same mocked rule within one shared RuleCode; reject that scope rather than collapse or overwrite them. No simulation uses the exact NO_SIMULATION key and omits pySimulation.
91: 
92: ## G6. Assertions and When Rows
93: 
94: For every non-cell ASSERT use its exact PROFILE binding. Preserve the evidenced optional context fields except a field explicitly forbidden by the active schema; do not discard context to pass a narrower pattern. For each accepted ASSERT produce exactly one concrete assertion item/block, and no others. OMIT produces trace only and never a RuleCode assertion. SIM produces exactly one matching simulation, never an assertion or setup action.
95: 
96: Regular Property: block step page/class comes from binding.stepPage/stepClass; child `pyPropertyAbsolutePath` is the complete target relative to that step page and must reconstruct the frozen full path. Keep semantic `ASSERT.page` frozen as Author execution context, but derive physical child `pyPageName` as the immediate page that contains the final asserted leaf: join the block step page with every page/list segment of the relative target before the final property segment. For `.Addresses(1).pyCity` under `CustomerCommunication`, physical `pyPageName` is `CustomerCommunication.Addresses(1)`; for a direct `.Name`, it is the block step page. Never rewrite the semantic trace page merely to match physical serialization. Preserve `pyPropertyApplyToClass=ASSERT.class`; `pyPropertyName` is the final leaf with literal key/index, `pyPropertyRealName` that leaf without key/index, and `pyPropertyMode` the frozen scalar type. Retain ValueList/ValueGroup parentMode when declared; omit it for a scalar. Never replace regular properties with Param paths.
97: 
98: Param Property: exact Param.<Name> in pyPropertyName and pyPropertyAbsolutePath, mode Text, child pyAssertionType=Property; omit child page, real-name and parent-mode fields. Page/PageList item itself: Page block, never Property. A compact Page child containing only comparator and full path is valid for existence/error-state checks; do not invent metadata to make it resemble a scalar.
99: 
100: List: retain InAllInstances for all-items semantics or the evidenced InAnyInstance fallback for proven payload/unknown index. The frozen assertion page identifies the list container relative to the block step page. If no unambiguous container or appearance choice is frozen, reject the Scenario instead of choosing an ancestor. Heterogeneous values remain their frozen indexed Property decisions. ResultCount is only a count block, with comparator/expected count text at block level, the exact top-level list context and all supported optional context. Nested counts unsupported by the existing schema cannot be flattened.
101: 
102: For each non-cell ASSERT, use its binding-linked EXECUTION ASSERTION_VALUE/<ID> snapshot with exact valueType/value. Property mode never determines expected-value type. Preserve typed JSON null, arrays and member order, literal array-looking text, literal "null", literal "<EMPTY>", initialized empty strings, booleans and exact decimal numbers distinctly; never infer JSON from string syntax. ResultCount requires a nonnegative integral number carrier and emits count text at block level. Comparators requiring values retain them: Is Equals To, IS Not Equals TO, Starts With, Ends With, Contains, Is In, Is Not In, has error with message, has error message that contains. Exists, Not exists, Is Empty, Is Not Empty, has errors and has no errors omit expected value when the source has no value. A contradictory value/comparator pair is unprojectable. Before generic array/null handling, enforce that TrueFalse exact assertions use only JSON booleans and Is True/Is False respectively; Text and other string types keep literal "true"/"false" strings and normal string comparators. Existence is never boolean truth. Preserve error message text exactly, including the documented Pega message format. Unsupported expected-value shapes are rejected by the schema/source gate, never stringified speculatively.
103: 
104: When: exactly one Decision block with pyAllowMultipleInputCombinations="true", pyAssertionType=Decision, pyClassContext=original rutClass and pyPropertyType="Decision Result". Each second-level row has pyPageName=rowLevelPage and its third-level cells. Input cells come first in frozen COLUMN/ASSERT order; exactly one Result comes last. Each cell has exact pyPropertyName, pyPropertyAbsolutePath and full-path pyDisplayLabel; pyPropertyMode is lower-case text. Input pyPropertyType=input, Result pyPropertyType=result. Result paths/label are Result and expected value is string true/false. Empty input retains the cell and initialized input meaning but omits only pyExpectedValue; never use null or a page-nonexistence assertion. Preserve leading dots, namespaces, case, spelling, every index/key and nested path. No direct expected values on block/row levels. No simulated DP root becomes a writable input cell or top-level seed. Non-cell ASSERT cannot be dropped to make a When Scenario fit this schema.
```
**Correction:** At G5 entry state EXECUTABLE-only; informational mode skips G5/G6 and goes directly to G7 evidence projection/write.

### FP-009 — HIGH — INFORMATIONAL_NOT_TESTABLE uses batch-ambiguous “return immediately” wording

**Impact:** Validator supports multiple UT siblings, but V4 says to return an informational UT immediately. Literal execution can terminate the invocation before executable siblings are processed.

**Source evidence:**
```text
15: Require exactly one first `VAL` record and at least one `UT` record. Each UT has unique nonempty `pyGroup` and unique nonempty `pyGUID`. `pyGUID` is the canonical candidate Memory address; `pyGroup` is correlation only. `Agent-to-agent transport uses one scalar `question`. Apply this exact field-value encoding everywhere in this pipeline: before placing a value in a field, encode backslash `\` as `\\`, literal pipe `|` as `\|`, CR as `\r`, LF as `\n`, TAB as `\t`, empty string as `\0`, and an exact literal hyphen `-` as `\-`. Structural record/field separators remain literal. An unescaped `-` means absent only in fields that explicitly allow absence. Parse by splitting physical records on LF, then fields on unescaped `|`, then each named field on its first unescaped `=`; decode the listed escapes exactly once left-to-right. Unknown escapes, unknown fields/tags, wrong field order, duplicate fields/records or free prose are invalid.` Preserve decoded values exactly; never trim, normalize, construct, pattern-check, case-fold, substitute an address, fetch latest, or infer RUTType from candidate shape.
16: 
17: Invalid invocation makes zero tool calls and returns one global block:
18: 
19: ```text
20: VR|pyGroup=-|pyGUID=-|route=HUMAN|blocking=1|warnings=0
21: VI|severity=B|code=AMBIGUOUS|action=HUMAN_REVIEW|scenario=-|decision=-|path=/|message=Invalid Validator invocation
22: ```
23: 
24: Validator never repairs or writes/updates Memory, reads ScenarioGroup, calls another agent, discovers dependencies, re-executes/reasons about the RUT, evaluates branches, chooses witnesses, derives expected values, adds coverage, or persists a report/result.
25: 
26: Closed tool allowlist:
27: - `JsonValidationTool(CaseID,UUID,JsonSchema)` — once per UT candidate; map `CaseID=VAL.pxCaseID`, `UUID=UT.pyGUID`.
28: - `GetMemory(pxCaseID,Type,pyGUID)` with `Type="UnitTestCandidate"` — once for that UT only after its schema result is valid.
29: - `KnowledgeTool(KnowledgeAreas)` — at most one shared V4 structural UTC call for all surviving UTs with the same immutable RUTType.
30: 
31: No tool retry. A candidate-specific failure stops only that UT's later calls; siblings continue. A shared Knowledge failure affects only UTs that reached the Knowledge-dependent phase.
32: 
33: ## V2. Exact direct report, routes and coordinates
34: 
35: Return only `VR`/`VI` records. For each attributable UT emit one `VR` followed immediately by zero or more `VI` rows:
```
```text
74: After parse, require exactly one `UnitTestRules` entry. A different cardinality is `COUNT_MISMATCH/FIX_COUNTS`; Generator can rebuild from the unchanged single physical group. Continue siblings independently.
75: 
76: Defensive traversability checks remain transport-consistency guards, not a second JSON Schema validator. Inspect the sole unit and its Scenarios/EvidenceSummary first. Candidate mode is **EXECUTABLE** when `RuleCode` is present and **INFORMATIONAL_NOT_TESTABLE** when `RuleCode` is absent. In EXECUTABLE mode, RuleCode/RUT/expected-result/setup/simulation nodes must be traversable as before. In INFORMATIONAL_NOT_TESTABLE mode those nodes intentionally do not exist and must not be traversed.
77: 
78: ## V4. Candidate-mode gate, executable RUT check and one shared UTC lookup
79: 
80: For every schema/read-surviving INFORMATIONAL_NOT_TESTABLE candidate, check only candidate-visible informational consistency: every Scenario is `NotTestable` with `SupportLevel=NotTestable`; `AssertionCount=0`, `ExactValueAssertionCount=0`, `StructuralAssertionCount=0`, and `SimulatedDependencyCount=0`; `BlockingGaps` is nonempty; `RuleCodeConsistentWithLedger=false`; and `AssertionDecisionTrace` contains one or more canonical OMIT records only, with `OmittedClaimCount` equal to their count. No ASSERT or SIM record is permitted. If consistent, return that UT immediately as `VR ... route=OK|blocking=0|warnings=0` with no VI rows and do not include it in the KnowledgeTool phase. This OK means the stored artifact truthfully represents a non-executable NotTestable outcome; it does not mean a Pega unit test executed. A contradiction uses only existing TRACE_INVALID, COUNT_MISMATCH, or REASONING_CONTRADICTION diagnostics; never invent RuleCode.
81: 
82: For every schema/read-surviving EXECUTABLE candidate inspect its sole `UnitTestRules[0]`. Prefer `RuleCode.pyRuleUnderTest.pyDetails.pyRuleUnderTestType`, with fallback only to an explicitly visible original-type field in that same `pyRuleUnderTest`. A visible conflict with immutable VAL RUTType produces `RUT_TYPE_MISMATCH/FIX_RUT_METADATA` for that candidate and excludes only it from the Knowledge-dependent phase. NotTestable with RuleCode is schema-invalid and must not reach this branch.
83: 
84: Compute UTC_KEYS solely from immutable VAL RUTType. Rule-Obj-When uses `Rule-Test-Unit-Case_MultInpComb-KnowledgeArea,Rule-Test-Unit-Case_MultInpComb-JsonSchema,Rule-Test-Unit-Case_MultInpComb-JsonExample`; all other supported types use `Rule-Test-Unit-Case_KnowledgeArea,Rule-Test-Unit-Case_JsonSchema,Rule-Test-Unit-Case_JsonExample`.
85: 
86: If at least one candidate still requires documented alignment, call KnowledgeTool once for that exact comma-joined list and cache the three texts for every surviving candidate in this invocation. Require every requested Area exactly once with nonempty Description and no unrequested/duplicate row. An exception or unusable shared guidance produces `AMBIGUOUS/HUMAN_REVIEW` independently for every candidate that reached this phase; it does not replace earlier item-specific results.
```
**Correction:** Say “finalize/store this UT result immediately, continue siblings, and emit all VR/VI records once at final return.”

### FP-010 — HIGH — Informational schema/Validator do not enforce Low confidence and Blocked closure

**Impact:** Both schemas accept informational NotTestable candidates with ReasoningConfidence=High and DependencyClosureStatus=Closed despite nonempty BlockingGaps; Validator early mode gate does not reject those states, so contradictory candidates can receive OK.

**Source evidence:**
```text
1630: - blocking gaps equal the terminal GAP census;
1631: - dependency closure is Closed only with no active work or gaps, otherwise Blocked only after all work is terminal;
1632: - queued dependency count and unscanned fetched RuleJSON count are zero;
```
```text
1675: Determine confidence and testability from actual evidence, executable inputs, supported assertions, explicit omissions and semantic gaps. Removing prior caps never promotes a Scenario automatically:
1676: 
1677: - any blocking gap forbids High confidence and full testability;
1678: - a blocking gap affecting exact value, branch result, dependency-controlled value, required simulation, or execution feasibility forces Low confidence and PartiallyTestable while at least one meaningful executable ASSERT remains; if none remains, use NotTestable, remove all ASSERT/SIM decisions from that Scenario, retain explicit OMIT/GAP evidence, and place it only with other NOT_TESTABLE Scenarios;
1679: - SomeUnresolved/Blocked dependency state, queued work, or unscanned RuleJSON cannot be hidden by confidence and normally prevents finalization until terminal;
1680: - confidence/testability never removes required coverage, changes frozen membership, or authorizes an unsupported ASSERT.
```
```text
74:             "else": {
75:               "properties": {
76:                 "Scenarios": {
77:                   "items": {
78:                     "properties": {
79:                       "Testability": {
80:                         "const": "NotTestable"
81:                       },
82:                       "EvidenceSummary": {
83:                         "required": [
84:                           "BlockingGaps"
85:                         ],
86:                         "properties": {
87:                           "SupportLevel": {
88:                             "const": "NotTestable"
89:                           },
90:                           "AssertionCount": {
91:                             "const": 0
92:                           },
93:                           "ExactValueAssertionCount": {
94:                             "const": 0
95:                           },
96:                           "StructuralAssertionCount": {
97:                             "const": 0
98:                           },
99:                           "OmittedClaimCount": {
100:                             "type": "integer",
101:                             "minimum": 1
102:                           },
103:                           "SimulatedDependencyCount": {
104:                             "const": 0
105:                           },
106:                           "BlockingGaps": {
107:                             "minItems": 1
108:                           },
109:                           "AssertionDecisionTrace": {
110:                             "type": "string",
111:                             "pattern": "^(?:OMIT\\|id=[^|\\r\\n]+\\|target=[^|\\r\\n]+\\|reason=(?:unresolved_external_source|unavailable_rulejson_after_limit_exhaustion|unresolvable_runtime_input|inactive_evaluate_all_scalar|inactive_return_values_scalar|schema_incompatible_assertion_target|redundant_iteration_coverage|incorrect_candidate_assertion))(?:\\nOMIT\\|id=[^|\\r\\n]+\\|target=[^|\\r\\n]+\\|reason=(?:unresolved_external_source|unavailable_rulejson_after_limit_exhaustion|unresolvable_runtime_input|inactive_evaluate_all_scalar|inactive_return_values_scalar|schema_incompatible_assertion_target|redundant_iteration_coverage|incorrect_candidate_assertion))*$",
112:                             "description": "INFORMATIONAL_NOT_TESTABLE mode: one or more canonical OMIT records only. ASSERT and SIM are forbidden because RuleCode is absent."
113:                           },
114:                           "InternalChecklist": {
115:                             "properties": {
116:                               "RuleCodeConsistentWithLedger": {
117:                                 "const": false
118:                               },
119:                               "SchemaSelfCheckPassed": {
120:                                 "const": true
121:                               }
122:                             }
123:                           }
124:                         }
```
```text
78: ## V4. Candidate-mode gate, executable RUT check and one shared UTC lookup
79: 
80: For every schema/read-surviving INFORMATIONAL_NOT_TESTABLE candidate, check only candidate-visible informational consistency: every Scenario is `NotTestable` with `SupportLevel=NotTestable`; `AssertionCount=0`, `ExactValueAssertionCount=0`, `StructuralAssertionCount=0`, and `SimulatedDependencyCount=0`; `BlockingGaps` is nonempty; `RuleCodeConsistentWithLedger=false`; and `AssertionDecisionTrace` contains one or more canonical OMIT records only, with `OmittedClaimCount` equal to their count. No ASSERT or SIM record is permitted. If consistent, return that UT immediately as `VR ... route=OK|blocking=0|warnings=0` with no VI rows and do not include it in the KnowledgeTool phase. This OK means the stored artifact truthfully represents a non-executable NotTestable outcome; it does not mean a Pega unit test executed. A contradiction uses only existing TRACE_INVALID, COUNT_MISMATCH, or REASONING_CONTRADICTION diagnostics; never invent RuleCode.
81: 
82: For every schema/read-surviving EXECUTABLE candidate inspect its sole `UnitTestRules[0]`. Prefer `RuleCode.pyRuleUnderTest.pyDetails.pyRuleUnderTestType`, with fallback only to an explicitly visible original-type field in that same `pyRuleUnderTest`. A visible conflict with immutable VAL RUTType produces `RUT_TYPE_MISMATCH/FIX_RUT_METADATA` for that candidate and excludes only it from the Knowledge-dependent phase. NotTestable with RuleCode is schema-invalid and must not reach this branch.
```
```text
Actual schema mutation tests: {'STANDARD': {'baseline': True, 'ReasoningConfidence_High': True, 'DependencyClosureStatus_Closed_with_gap': True, 'both_bad': True}, 'MULTINPCOMB': {'baseline': True, 'ReasoningConfidence_High': True, 'DependencyClosureStatus_Closed_with_gap': True, 'both_bad': True}}
```
**Correction:** In both info schema branches require ReasoningConfidence=Low and DependencyClosureStatus=Blocked; Validator V4 must check both.

### FP-012 — HIGH — Accepted Model WHEN export mapping was not applied

**Impact:** Historical user decision D-001 established pyPropertiesName as the executable condition field for this environment; current Model KnowledgeArea still reads pyCondition.

**Source evidence:**
```text
29: KT.3|L|InvocationPattern
30: P: Operation/condition patterns invoking other rules.
31: M: APPLY_MODEL: pyActionName=="APPLY_MODEL" -> invokes Rule-Obj-Model.
32: M: evaluateWhen: pyActionName=="WHEN" AND pyCondition contains "evaluateWhen(" -> invokes Rule-Obj-When.
33: A: Some Model operations expose multiple invocation patterns; check all patterns before concluding no dependency.
34: X: APPLY_MODEL with pyPropertiesName:"EmbeUnitTestReferenceModelRule". WHEN with pyCondition:"evaluateWhen(\"IsDescriptionMatches\")".
35: 
36: KT.4|F|RuleIdentifierField
37: P: Where invoked rule name is read.
38: M: APPLY_MODEL -> pyPropertiesName.
39: M: evaluateWhen(...) inside pyCondition -> first string argument of evaluateWhen.
40: X: {pyActionName:"APPLY_MODEL",pyPropertiesName:"EnrichCustomerData"} -> EnrichCustomerData.
41: X: pyCondition:"evaluateWhen(\"IsDescriptionMatches\")" -> IsDescriptionMatches.
```
```text
191: KT.25|F|ConditionalConditionField
192: P: Field containing conditional expression.
193: M: Rule-Obj-Model WHEN -> pyCondition.
194: X: pyCondition:"evaluateWhen(\"IsDescriptionMatches\")"; pyCondition:"Param.InputTempPage5 != ''".
195: R: Evaluation protocol lives in KT.17.
```
**Correction:** Update KT.3/KT.4/KT.25 and related examples to pyPropertiesName for Model WHEN in the confirmed environment.

### FP-013 — HIGH — Accepted Model formal-parameter export mapping/type was not fully applied

**Impact:** Current Model KnowledgeArea still uses pyParametersType and String/Integer/... while accepted environment evidence uses pyParametersParamType and uppercase STRING. Main captures pyParametersParamType but its compatibility wording uses String, leaving STRING ambiguous/unsupported.

**Source evidence:**
```text
89: KT.12|F|ParameterNameField
90: P: Field containing parameter name.
91: M: Invocation -> pyParametersParamName.
92: M: Test setup -> pyParametersParamName.
93: M: Model parameter definition -> pyParametersParamName.
94: X: invocation {pyParametersParamName:"Comments",pyParametersParamValue:"'Test'"}; definition {pyParametersParamName:"InputInteger1",pyParametersType:"Integer"}.
95: 
96: KT.13|F|ParameterTypeField
97: P: Field specifying parameter data type.
98: M: Invocation -> pyParametersParamType values: "PAGE", "VALUE", or omitted for scalar.
99: M: Model definition -> pyParametersType values: "PAGE","String","Integer","Decimal","Boolean".
100: X: PAGE invocation {pyParametersParamName:"InputTempPage5",pyParametersParamType:"PAGE"}; scalar invocation omits type; model definition uses pyParametersType.
```
```text
143: KT.19|F|ParameterDefinitionField
144: P: Where invoked rule parameter definitions live, distinct from invocation params.
145: M: Rule-Obj-Model definition -> pyParameters array of {pyParametersParamName,pyParametersType}.
146: I: Definition field = params model expects. Invocation field KT.7 = params caller passes.
147: X: model expects InputInteger1(Integer), Comments(String), InputTempPage5(PAGE). Caller passes InputInteger1=4 and pyPassCurrentParameterPage=false -> Param.InputInteger1=4; Param.Comments=""; Param.InputTempPage5 empty.
```
```text
1871: Formal RUT parameter provenance:
1872: 
1873: - Every INPUT whose path begins with the exact namespace `Param.` is a physical formal RUT parameter carrier and must use `role=PARAM`, or `role=DECISION_INPUT` in a WHEN group. PRIMARY/PAGE roles cannot disguise that namespace; DECISION_INPUT is forbidden in STANDARD. Conversely, every `role=PARAM` INPUT must use that namespace. Every such INPUT resolves to one PARAM with `dependency=RUT` and exact `path=Param.<PARAM.name>`. Each name and resolution occurs once per Scenario. COLUMN `source=PARAM` is equivalent to this namespace; primary/property input bindings and dependency/Data Page parameters are not formal RUT arguments.
1874: - Each formal carrier's PARAM has one `formalEvidence` EVIDENCE ID included in its `evidence` set. Copy `formalType` from the unique exact-name match in original `RuleJSON.pyParameters[].pyParametersParamType`, preserving spelling/case; never infer it from `valueType`, INPUT.mode, a resolved value, a dependency signature, or another parameter. Non-formal PARAM records have absent formalType and formalEvidence.
1875: - The referenced EVIDENCE has `kind=RUT`, `source=RuleJSON/pyParameters/<zeroBasedArrayIndex>`, and a canonical typed JSON fact with exactly `pyParametersParamName` and `pyParametersParamType`. The fact name and type equal PARAM.name and PARAM.formalType. A missing/unusable non-string type is represented as JSON null in the fact and absent formalType; an explicit string, including an unsupported or empty string, is retained exactly. If the complete original array has no unique name match, use source `RuleJSON/pyParameters` and a null type instead of inventing an index. This array-level evidence records failed exact-name resolution, not a successful declaration. One indexed source cannot identify different definitions; one formal name cannot identify different source locations across Scenarios in a group.
1876: - String arguments require a string or initialized-empty value; Integer requires an integral numeric value; Decimal requires a numeric value; Boolean/TrueFalse requires a typed boolean; PAGE requires a nonempty string naming an evidenced page in ROOT.pagesAndClasses. Formal metadata and physical value remain separate immutable facts. PAGE names are carried unchanged and never treated as quoted scalar strings. The complete downstream formatting table remains Generator-owned; this metadata capture does not authorize Scenario Author to serialize RuleCode.
1877: - Missing/unknown/unsupported type, incompatible typed value, or unavailable PAGE carrier is a projection gap. Retain the frozen records and add GAP `code=RUT_PARAMETER_PROJECTION_UNAVAILABLE`, `scope=Param.<name>`, `effect=PARTIAL`, citing formalEvidence. The Scenario cannot be marked Testable; reflect the gap in SUMMARY and its complete blockingGaps census. Even with no external dependencies, any remaining GAP prevents dependencyClosureStatus=Closed. Generator must report that Scenario as unprojectable under its scoped failure contract; it cannot guess a type, omit only the parameter while keeping a runnable Scenario, change its value, or silently use a scalar representation. No coverage target or frozen Scenario is removed by metadata capture.
```
**Correction:** Use the confirmed export field pyParametersParamType and explicitly recognize raw STRING for String semantic compatibility while preserving raw spelling in evidence.

### FP-014 — HIGH — Accepted lowercase Data Page scope value is still rejected

**Impact:** Accepted environment evidence says raw pyScope="thread" represents Thread scope, but KDP.2 accepts exact "Thread" only and rejects every other value.

**Source evidence:**
```text
29: KDP.2|A|ScopeEligibilityGate
30: P: Unified scope enumeration, isolation semantics, and simulation eligibility algorithm.
31: A: 1. Read pyScope from the Data Page RuleJSON.
32:    2. Map pyScope to isolation level, eligibility, and resolvedScope:
33: 
34:    pyScope="Thread"
35:      -> isolation: scoped to current requestor thread; isolated per test run
36:      -> ELIGIBLE; resolvedScope="Thread".
37:    pyScope="Requestor"
38:      -> isolation: scoped to requestor session; shared across threads
39:      -> INELIGIBLE; resolvedScope="Requestor".
40:    pyScope="Node"
41:      -> isolation: scoped to server node; shared across all requestors
42:      -> INELIGIBLE; resolvedScope="Node".
43:    pyScope absent, null, empty, or any other value
44:      -> isolation: cannot be determined; isolation cannot be guaranteed
45:      -> INELIGIBLE; resolvedScope="unresolved".
46: 
47:    3. Produce binary result: ELIGIBLE or INELIGIBLE, plus resolvedScope.
48:    4. All agent responses to that result are defined in the Agent Instructions.
49: I: Only Thread-scope Data Pages are eligible for simulation in unit tests.
50:    This is a hard constraint with no exceptions for any other scope value.
51: I: A pyScope field that is absent, null, empty, or set to any value other than "Thread"
52:    must be treated as INELIGIBLE. Do not default absent pyScope to Thread.
```
**Correction:** Preserve raw value as evidence; normalize accepted environment value thread to Thread only for eligibility comparison.

### FP-016 — HIGH — Accepted simulated-Data-Page hard dependency boundary is absent

**Impact:** The accepted rule says once an eligible Data Page is selected for simulation, do not recursively crawl its loader/source merely because it appears in Data Page RuleJSON. Current Data Page KnowledgeArea does not state that boundary.

**Source evidence:**
```text
11: KDP.1|F|CoreFields
12: P: Rule type, key, and identity fields for Rule-Declare-Pages.
13: M: pxRuleObjClass="Rule-Declare-Pages"; pyRuleName=Data Page name (e.g. D_CustomerList);
14:    pyClassName=apply-to class of the Data Page payload;
15:    pyScope=scope level controlling isolation and simulation eligibility;
16:    pyStructure=structural shape of the Data Page payload (Page or List).
17: S: A Rule-Declare-Pages rule defines a named, reusable clipboard page populated on demand.
18:    It is referenced by name in RUT expressions and dependency rule expressions.
19:    The Data Page is populated by a connector, activity, or data transform defined in the rule.
20: S: Data Pages are the primary mechanism for supplying external or reference data to rules
21:    under test. They are read-only from the perspective of the RUT unless explicitly
22:    written back by the rule.
23: I: pyScope is a blocking field. It must be resolved from the Data Page RuleJSON before
24:    any simulation eligibility decision is made.
25: I: Simulation eligibility is determined solely by pyScope from the Data Page RuleJSON.
26:    It is never inferred from rule name, apply-to class, structural shape, or usage context.
27: R: KDP.2, KDP.3.
```
```text
81: KDP.4|A|CallerInputBinding
82: P: Resolve caller-to-Data-Page parameters in the confirmed RuleIQ environment.
83: I: Parameter declarations require exact RuleJSON field-mapping evidence. A confirmed
84:    empty declaration is parameterless; absent metadata or an unknown export shape
85:    is unresolved, never an empty declaration. No universal declaration field is assumed.
86: A: During dependency discovery capture declaration, access path, explicit expressions,
87:    matching current-Param names and symbolic producers. Do not wait for concrete values
88:    that scenario execution will produce. Resolve metadata independently.
89: A: At each executed access use the state immediately before that access: explicit
90:    argument first; otherwise a present same-name current Param value; otherwise an
91:    evidenced applicable runtime default. An unresolved explicit expression wins as
92:    unresolved and cannot fall back. Unknown current state cannot fall back either.
93: I: This implicit current-Param binding is a confirmed RuleIQ convention, not a claim
94:    about every Pega environment. Null and initialized empty are present values;
95:    absence is distinct. Optional omission needs declaration evidence. Do not coerce
96:    strings, numbers, Boolean values or null into one another.
97: A: Apply earlier executed assignments/overwrites/removals in order. Skipped producers
98:    supply no new value; uncertain execution makes the affected value unknown until
99:    replaced by an executed producer. Retain separate evidence for repeated accesses.
100:    Freeze each concrete map/signature during scenario execution. Equal maps may share
101:    a simulation decision; all associated accesses retain their own evidence.
102: I: Seed external RUT inputs only. Param values produced by RUT steps remain execution
103:    results, never invented formal RUT arguments or setup values. Caller binding is
104:    separate from Data-Page-to-loader pass-current-parameter-page settings.
105: I: Parameter refinement changes existing scenarios and their testability. It cannot
106:    create dependency-only scenarios or remove identified scenarios. KDP.2 remains mandatory.
107: X: An executed Param.pyID assignment before D_GenUT supplies a declared pyID implicitly.
108:    A parameterless page has an evidenced empty map; an unknown declaration does not.
109: R: KDP.1,KDP.2; ScenarioGroup revision 1.4 DP_DECLARATION/DP_ACCESS/DP_EXECUTION evidence.
```
**Correction:** Add the hard boundary explicitly to Rule-Declare-Pages KnowledgeArea and cross-reference it from Main dependency scanning.

### FP-017 — HIGH — Model coverage adapter still loses terminal false edges that suppress observable producers

**Impact:** The confirmed MA-017 case (false branch suppressing APPEND_AND_MAP_TO) is not included in Main’s conditions for a distinct required target.

**Source evidence:**
```text
1311: 1. INVENTORY (`I`). Scan only original RUT RuleJSON forward and reverse; raw ids must match. Census every owner arm/alternative, nested branch, atom, EXIT/error edge, required 0/1/many, and context/index/order dimension. Include row/default only if original `RUT_TYPE=Rule-Declare-DecisionTable`. Ignore comments and all dependency-internal branches/rows/defaults/actions/values. Map every raw source to one or more T; T may cite several, none may be unmapped, and dependencies never own T. T starts R and becomes U only by original-RUT contradiction, E only by exact non-effect/equivalence to canonical R, or B only by a closed census proving all replayable witnesses/carriers impossible. Reachability/materiality/effectiveness classify after census; uncertainty, low confidence, complexity, one invalid carrier, dependency behavior, or equal expected values prove nothing. With no adapter use primary KnowledgeArea; with neither keep baseline R and `MISSING_OWNER_COVERAGE_ADAPTER`. Replace the snapshot with all T and no S.
1312: 
1313: Coverage adapters:
1314: - `Rule-Obj-Model`: R for every reachable original-RUT WHEN and alternative/OTHERWISE arm. A false edge covered by another S needs no T unless it reaches OTHERWISE, EXIT/error, or different later owner execution. Add 0/1/many or joint T only when original-RUT control/index/order/EXIT/error/later execution differs or branches interact. Every reachable `Param.X==literal` arm is R; mutually exclusive arms cannot share S. A dependency row/result/default/intermediate value only selects a witness; variants reaching the same owner arm and later execution never create T. If executable Model has no R, add one root baseline R for complete execution.
1315: - `Rule-Obj-When`: classify final TRUE/FALSE and both MC/DC sides for every atomic condition. Independently effective atoms require a feasible pair; encode pair id, side, atom, and fixed truth vector in `constraint`. A masked/non-effective atom needs E proof; never omit it before census. Never exclude one pair side alone; pair exclusion needs the same universal pair proof for both sides. Typed boundary/empty items are R only when truth changes; never Cartesian-expand.
1316: - Only if original `RUT_TYPE=Rule-Declare-DecisionTable`: classify its rows/default and require R per reachable distinct KDT FINAL class `(mode, scalar state/value, ordered final property-effect vector)`; duplicate class is E, unreachable is U. Never use this adapter for nested/fetched Decision Tables.
```
```text
159: KT.22|S/A|ModificationSemantics
160: P: How each modification operation affects values.
161: M: SET -> OVERWRITE: evaluate expression, replace target with result.
162: M: APPEND -> LIST_APPEND: add element to end of page list.
163: M: APPEND_AND_MAP_TO -> LIST_APPEND: adds element; in WHEN/OTHERWISE/OTHERWISE-WHEN branches, both may execute across iterations, so size equals executed branches, not matched conditions.
164: SET rules: expression evaluated first, then target overwritten. If expression does not read current target, previous target value is lost. If expression reads current target, result can preserve/append via expression, then overwrite.
165: X1: SET .Comments = Param.Comments + ", suffix"; Param.Comments="text" -> .Comments="text, suffix"; current .Comments ignored.
166: X2: SET .Comments = .Comments + ", suffix"; current .Comments="existing" -> .Comments="existing, suffix".
167: X3: SET Primary.Comments = .Comments + ", copied to Primary" overwrites Primary.Comments with current-context .Comments plus suffix; previous Primary.Comments ignored.
168: Forbidden assumptions: empty param does not skip SET; SET does not append unless expression reads current value; empty param does not mean target unchanged.
169: Mandatory tracing for every SET: extract expression via KT.21; identify refs; resolve refs; evaluate complete expression; document result; apply OVERWRITE.
```
**Correction:** A reachable owner outcome is required whenever it executes OR suppresses an observable modifying producer, not only OTHERWISE/EXIT/later-owner differences.

### FP-018 — HIGH — APPEND_AND_MAP_TO source/target child-context semantics remain underspecified

**Impact:** The review resolved MA-019 using Pega documentation, but current Model KnowledgeArea still reduces APPEND_AND_MAP_TO to generic LIST_APPEND and does not define EXISTING_PAGE source versus new appended target child context.

**Source evidence:**
```text
159: KT.22|S/A|ModificationSemantics
160: P: How each modification operation affects values.
161: M: SET -> OVERWRITE: evaluate expression, replace target with result.
162: M: APPEND -> LIST_APPEND: add element to end of page list.
163: M: APPEND_AND_MAP_TO -> LIST_APPEND: adds element; in WHEN/OTHERWISE/OTHERWISE-WHEN branches, both may execute across iterations, so size equals executed branches, not matched conditions.
164: SET rules: expression evaluated first, then target overwritten. If expression does not read current target, previous target value is lost. If expression reads current target, result can preserve/append via expression, then overwrite.
165: X1: SET .Comments = Param.Comments + ", suffix"; Param.Comments="text" -> .Comments="text, suffix"; current .Comments ignored.
166: X2: SET .Comments = .Comments + ", suffix"; current .Comments="existing" -> .Comments="existing, suffix".
167: X3: SET Primary.Comments = .Comments + ", copied to Primary" overwrites Primary.Comments with current-context .Comments plus suffix; previous Primary.Comments ignored.
168: Forbidden assumptions: empty param does not skip SET; SET does not append unless expression reads current value; empty param does not mean target unchanged.
169: Mandatory tracing for every SET: extract expression via KT.21; identify refs; resolve refs; evaluate complete expression; document result; apply OVERWRITE.
```
```text
217: KT.28|F/S|UpdatePageRelationship
218: P: Field specifying UPDATE_PAGE relationship type.
219: M: Rule-Obj-Model UPDATE_PAGE -> pyRelationNameUpdatepage values: "BLANK","WITH_VALUES_FROM".
220: BLANK: sets target/current from pyPropertiesName and preserves inherited source.
221: WITH_VALUES_FROM: sets target/current from pyPropertiesName and replaces source with pyPropertiesValue for the child scope.
222: S: Child write targets resolve against target/current; relative child value refs resolve against active source when present, otherwise target/current.
223: X BLANK: UPDATE_PAGE pyPropertiesName:"TempPage4.pxResults(4)", pyRelationNameUpdatepage:"BLANK"; child SET .Comments="text" -> TempPage4.pxResults(4).Comments="text".
224: X WITH_VALUES_FROM: UPDATE_PAGE pyPropertiesName:"TempPage2", pyRelationNameUpdatepage:"WITH_VALUES_FROM", pyPropertiesValue:"TempPage"; child SET .pyText=.pyText -> left TempPage2.pyText, right TempPage.pyText; copies source to target.
225: X inherited source: FOR_EACH_PAGE_IN .Items with pyUpdateSourceContext:true; nested UPDATE_PAGE .Target with BLANK; child SET .A=.B writes Primary.Target.A from Primary.Items(i).B.
226: I: Resolve inherited source through KT.34 before applying BLANK; WITH_VALUES_FROM replaces source within its child scope.
227: R: KT.18,KT.23,KT.34.
```
**Correction:** Encode the resolved semantics: append new target item; child write targets resolve to it; relative child sources resolve from configured existing source page; materialize only mapped fields; source/target classes may differ.

### FP-019 — HIGH — Simulation seed-depth rule still blocks dependency-required item leaves

**Impact:** A RUT can access a list container while a closed nested dependency operating on each item needs leaf fields. Literal “do not seed nested properties when RUT accesses top-level” forbids those required leaves.

**Source evidence:**
```text
1087: ### 9.1 Simulation seed depth
1088: 
1089: For every RUT operation reading a simulated dependency:
1090: 1. Extract source expression via the relevant property-modification field.
1091: 2. If expression is relative, resolve parent context from UPDATE_PAGE or FOR_EACH_PAGE_IN parent operation.
1092: 3. Build full path from Data Page base plus relative expression.
1093: 4. Count navigation segments after the Data Page name.
1094: 5. Extract exact property names from the RUT expression. Do not use generic placeholders like `Items` when RUT uses a specific name like `Rooms`.
1095: RUT path token lock:
1096: - After the Data Page name, copy every collection/property segment from the RUT source expression into `computedSeedPath` exactly.
1097: - Do not introduce `Items`, `pxResults`, or any generic wrapper token unless that exact token appears in the RUT source expression at the same path position.
1098: - Dependency class structure, Code-Pega-List conventions, examples, or wrapper templates must not rename RUT path tokens.
1099: 
1100: Example:
1101: RUT source `D_X.Rooms(1).Socket`
1102: → `computedSeedPath = pyPageDetails.Rooms(1).Socket`
1103: → final pySimulation must seed `Rooms(1).Socket`
1104: Never rewrite it as `pyPageDetails.Items(1).Socket`.
1105: 
1106: 6. Compute internal seed path:
1107:    - 0 segments → `pyPageDetails.<property>`
1108:    - 1 segment → `pyPageDetails.<collection>(1).<property>`
1109: 7. Track `sourceNavigationSegments`, `computedSeedPath`, and `segmentCountVerification` internally.
1110: 
1111: Segment verification formula:
1112: - `actualDepth = count of "(" characters in computedSeedPath after "pyPageDetails"`
1113: - verification string must prove expression depth equals seed depth.
1114: - `match=true` is forbidden when numbers differ.
1115: 
1116: RUT access depth is authoritative. Do not use Data Page class structure to decide seed depth. Do not seed nested properties when the RUT accesses top-level. If assertion path depth differs from RUT access depth, adjust assertion path or omit; never adjust seed depth away from RUT access.
```
**Correction:** Lock the RUT-evidenced collection carrier/depth but permit leaf fields required by closed executable dependencies inside witness-locked items.

### FP-020 — HIGH — Omission reason-code authority still conflicts inside Main

**Impact:** §5.5 excludes incorrect_candidate_assertion while later sections require/allow it.

**Source evidence:**
```text
496: ### 5.5 Omissions ledger
497: 
498: Omission is allowed only after candidate enumeration and the full assertion ladder. For every omitted claim, internally record:
499: - property path or claim;
500: - allowed reason code: `unresolved_external_source`, `unavailable_rulejson_after_limit_exhaustion`, `unresolvable_runtime_input`, `inactive_evaluate_all_scalar`, `inactive_return_values_scalar`, `schema_incompatible_assertion_target`, or `redundant_iteration_coverage`;
501: - concrete reason;
502: - affected assertion type;
503: - why `Verified` failed;
```
```text
590:   not new mandatory source fields or a new consumer presence-proof contract.
591: 
592: ASSERTION ELIGIBILITY:
593: 1. Apply the existing upstream-producer, input-only, assertion-support and target-
594:    representability gates. A setup/input value with no later executing RUT/dependency
595:    write or removal is input-only and does not gain an output assertion merely by
596:    remaining present. An ineligible enumerated claim receives an existing appropriate
597:    OMIT, including incorrect_candidate_assertion for an input-only claim. Unknown
598:    later execution does not prove that no later write occurred; resolve it or use
599:    the unresolved-presence rule rather than labeling the claim input-only.
600: 2. Emit Not exists with Structural support only when final absence is proven and the
```
```text
1940: 
1941: - `unresolved_external_source`
1942: - `unavailable_rulejson_after_limit_exhaustion`
1943: - `unresolvable_runtime_input`
1944: - `inactive_evaluate_all_scalar`
1945: - `inactive_return_values_scalar`
1946: - `schema_incompatible_assertion_target`
1947: - `redundant_iteration_coverage`
1948: - `incorrect_candidate_assertion`
1949: 
1950: Every enumerated final claim has exactly one ASSERT or OMIT. Exact-value ASSERT records use only `Verified` or `PredictedFromRules`. Structural records cannot invent values. DecisionInput paths and empty values remain exact. ASSERT/SIM/OMIT IDs are unique within a Scenario.
1951: 
1952: When UnitTestGenerator creates `AssertionDecisionTrace`, it uses exact tag-specific whitelists rather than subtracting fields. SIM is exactly `SIM|id|rule|sig|shape|method|class|itemClass|params|target`. Standard ASSERT is exactly `ASSERT|id|kind|target|page|class|mode|comparator|value|support`. DecisionInput and DecisionResult ASSERT are exactly `ASSERT|id|kind|row|target|page|class|mode|comparator|value|support`. OMIT is exactly `OMIT|id|target|reason`. ScenarioGroup-only `mockingRuleType`, `referredFromClass`, `setupPages`, `scenario`, `order`, `payload`, `parameterResolutions`, `producer`, and `evidence` never enter the trace. For each trace **field value only**, Generator encodes source `&` as `&amp;`, literal `|` as `&#124;`, CR as `&#13;`, LF as `&#10;`, and double quote as `&quot;`; an absent ledger value becomes `-`. It then joins the tag and named fields with literal structural `|` separators in the declared order and joins records with actual LF in the in-memory trace string. Structural separators are never entity-encoded. Validator first splits records/structural pipes and only then decodes the allowed field-value entities once. The checker proves a positive SIM projection and rejects added non-whitelisted fields. This trace encoding is distinct from outer ledger escaping and is synchronized across Author/Generator/Validator.
```
**Correction:** Use one canonical reason-code set everywhere, including incorrect_candidate_assertion.

### FP-021 — HIGH — OWNER_COVERAGE_OUTPUTS still omits APPEND_AND_MAP_TO

**Impact:** Main hardcodes SET/APPEND/PREPEND/INSERT/REMOVE while the active Model KnowledgeArea recognizes APPEND_AND_MAP_TO as modifying a list.

**Source evidence:**
```text
420: STEP 1 — Build RUT_IO_INVENTORY:
421:   OWNER_COVERAGE_OUTPUTS = {every property path written by SET/APPEND/PREPEND/INSERT/REMOVE
422:                  in the original RUT step tree, keyed by original parent step path; use only
423:                  when applying the original RUT's existing coverage rules}
424:   For each WITNESSES `S` row, RUT_OUTPUTS(S) = {OWNER_COVERAGE_OUTPUTS plus every
425:                  property target actually written by a selected dependency execution,
426:                  keyed by parent step/dependency path and resolved invocation page;
427:                  use only for setup/existence, PropertyTrace, assertions, and RuleCode}
```
```text
159: KT.22|S/A|ModificationSemantics
160: P: How each modification operation affects values.
161: M: SET -> OVERWRITE: evaluate expression, replace target with result.
162: M: APPEND -> LIST_APPEND: add element to end of page list.
163: M: APPEND_AND_MAP_TO -> LIST_APPEND: adds element; in WHEN/OTHERWISE/OTHERWISE-WHEN branches, both may execute across iterations, so size equals executed branches, not matched conditions.
164: SET rules: expression evaluated first, then target overwritten. If expression does not read current target, previous target value is lost. If expression reads current target, result can preserve/append via expression, then overwrite.
```
**Correction:** Derive modifying operations from the active primary KnowledgeArea or at minimum include APPEND_AND_MAP_TO.

### FP-022 — HIGH — Producer catalog payload cannot represent direct SET producers

**Impact:** PC.payload is descendant-only, yet direct SET assertions must bind to immutable producer payload; a direct SET has no descendant row carrying its own RHS.

**Source evidence:**
```text
650: Producer catalog row:
651: `PC|producer=<stepPath>|parentGuard=<guardPathOrNone>|target=<property>|payload=<field:value from descendant rows only>|payloadSourcePaths=<paths>|order=<treeOrder>`
652: 
653: Rules:
654: - `stepPath` must be the original hierarchical RUT step path, not a flat sequence number.
655: - `PC.payload` is immutable after catalog creation.
656: - `PC.payload` may include only descendant `Set`, `MapTo`, or mapping rows under the same producer path.
657: - A parent `When`/guard may control a producer, but it cannot donate payload to it.
658: - A producer cannot use literals from sibling, parent, unrelated, or later producers.
659: - ReasoningTrace, APB, PropertyTrace, EvidenceSummary, and RuleCode must use only payload values from `PC.payload`.
660: - Literal value presence in RuleJSON is not `Verified` unless the exact producer from `PC` executes in the Scenario.
```
**Correction:** Direct producer payload comes from its own evidenced RHS/expression; composite producer may additionally include only descendant mappings inside its target structure.

### FP-023 — HIGH — LPE non-execution can only be proved by terminal guard, not prior EXIT/termination

**Impact:** A later producer skipped because an earlier EXIT_MODEL terminated execution can remain unknown even though the Model KnowledgeArea recognizes EXIT_MODEL non-execution.

**Source evidence:**
```text
668: Scenario producer execution rows:
669: This extends the immutable `PC` catalog with Scenario-specific execution proof. For every Scenario and every list with emitted or candidate assertions, create one execution row for every `PC` producer that can modify that list. This is the only valid execution-status input for APB/LIC.
670: 
671: `LPE|scenario=<id>|list=<path>|producer=<PC.producer>|rx=<RX.path>|guard=<conditionOrNone>|guardState=<true|false|unknown>|executes=<true|false|unknown>|mutation=<add|remove|clear|overwrite|unknown>|delta=<n|unknown>|proof=<short>`
672: 
673: Rules:
674: - Every relevant `PC` row linked from `SI` must have an `LPE` row before APB, LIC, indexed Property/Page, List, or ResultCount assertions are selected.
675: - If no `SI` row exists for a relevant modifying operation, treat producer execution as `unknown`.
676: - `LPE.executes=true` only when the producer action `RX.actionState=executes`.
677: - `LPE.executes=false` only when the producer action `RX.actionState=skipped` with terminal guard proof.
678: - If the controlling `RX` row is missing or unknown, set `LPE.executes=unknown`.
679: - Do not collapse producer status into ranges such as `Steps 7-14 false`.
680: - Terminal guard proof requires all dependencies, functions, Data Pages, Decision Tables, RUFs, and rule logic needed to evaluate the guard to be resolved and evaluated.
681: - Unsupported DecisionTable, unsupported RUF, unavailable RuleJSON, omitted guard dependency, unresolved Data Page, unknown function, or unknown branch makes `guardState=unknown` and `executes=unknown`.
```
**Correction:** Allow executes=false from any terminal control-flow exclusion proof: false guard, prior EXIT/termination, unreachable alternative, or KnowledgeArea-defined non-execution.

### FP-024 — HIGH — PROFILE binding provenance still requires PROPERTY_DEFINITION for every binding

**Impact:** Param assertions and runtime named-page structural assertions need not have a Rule-Obj-Property definition, so literal materialization can fail valid bindings.

**Source evidence:**
```text
1728: PROFILE.evidence resolves in the same Scenario and includes the case-key proof and one GATE EVIDENCE at source SCENARIO_SNAPSHOT/PROFILE whose canonical fact equals PROFILE.data exactly. This records the final audited source-profile census. All nested evidence references resolve to actual acquisition/execution evidence; the census is not a substitute for that source evidence. Freeze the profile together with INPUT/SETUP/ASSERT/SIM/OMIT and re-audit it after any semantic change. No existing coverage, expected value, simulation, or stable Scenario ID may change merely to make the profile serializable.
1729: 
1730: Nested acquisition snapshots are mandatory and cannot cite the PROFILE census as their provenance. Keep exact original acquisition values before building PROFILE; do not create a snapshot by reverse-copying a completed profile. Same-Scenario EVIDENCE facts use canonical JSON and the following sources:
1731: 
1732: - For each binding, DEPENDENCY source `PROPERTY_DEFINITION/<assertionID>` captures `path`, `pyPropertyMode`, and `pyStringType` from the resolved property definition and its lookup path. They equal fullPath, structure, and scalarType. EXECUTION source `ASSERTION_CONTEXT/<assertionID>` captures exactly stepPage, stepClass, fullPath, parentMode, context, producerIndex (Known, Unknown, NotApplicable), and payloadProven (boolean) from the audited APB/producer state. All five common fields equal the binding. Both IDs occur in binding.evidence. A List with unknown producer index requires proven payload and InAnyInstance; its uncertain index must never be turned into an all-items or positional assertion.
1733: - EXECUTION source `EXECUTION_ACTIONS` is the complete ordered array of action identities, each with exactly phase, type, name, and page, captured during witness execution. PROFILE.evidence links it even when empty; every action.evidence links the same snapshot. For each action argument, DEPENDENCY source `ActionRule/<type>/<name>/pyParameters` captures the complete original declaration array. Select exactly one declaration with the exact pyParametersParamName and matching pyParametersParamType; duplicate/missing names fail. EXECUTION source `ACTION_ARGUMENTS/<zero-based-action-index>` captures the complete ordered resolved argument array with name, valueType, and value. PROFILE.evidence links every ACTION_ARGUMENTS snapshot, including a genuinely empty array. Validate that complete ordered array once per action before iterating its parameters; removing all parameters cannot bypass the source census. Each parameter.evidence additionally links both snapshots. Nested value is a decoded ledger carrier: string for every non-absent valueType, JSON null only for absent. It still obeys the typed-value/formal-type table; a JSON number, boolean, array, or object cannot masquerade as a string literal.
```
**Correction:** Define evidence alternatives by binding kind: property definition for property leaves; formal parameter definition for Param; page creation/class context for named Page; owning property + execution context for list structure.

### FP-025 — CRITICAL — Accepted canonical DEP.kind solution D-003 was not applied

**Impact:** Canonical DWL keys include When/DTable/Model/Prop/RUF/DP, but ScenarioGroup DEP.kind still permits only RUF|DP|HELPER|DT|NOT_APPLICABLE. A complete ScenarioGroup cannot truthfully encode closed When/Prop/Model dependencies.

**Source evidence:**
```text
230: Canonical key:
231: `KEY = <kind>@<applyToClass>@<name>` where `kind` is `When`, `DTable`, `Model`, `Prop`, `RUF`, `DP`, or another exact Pega rule type shortened consistently. Same name on different classes is a different `KEY`.
232: 
233: Data Page identity:
234: - `KEY=DP@<applyToClass>@<dataPageName>` tracks the Data Page rule/access as a dependency row.
235: - Simulation identity is `DP_SIG = KEY + normalized parameter set`. RuleCrawler metadata may deduplicate by `KEY`; `pySimulation` obligations deduplicate by `DP_SIG`.
236: - In `MODE=CRAWL`, `DP_SIG` may use normalized parameter bindings, e.g. `ObjectID=.Objects(1).ID`. In `MODE=AUTHOR`, each Scenario instantiates the binding with concrete seeded values in `SIM`/`RuleCode.pySimulation`; `DPA` matches crawl-time bindings to scenario-time concrete params.
```
```text
1879: #### 13.4.3 Execution and evidence
1880: 
1881: `RX|scenario=<ID>|id=<ID>|order=<N>|source=<sourceID>|operation=<operation>|context=<context>|guard=<guardOrAbsent>|inputs=<inputIDsOrAbsent>|result=<result>|writes=<pathsOrAbsent>|evidence=<evidenceIDs>`
1882: 
1883: `DEP|scenario=<ID>|id=<ID>|order=<N>|kind=<RUF|DP|HELPER|DT|NOT_APPLICABLE>|identity=<canonicalIdentity>|state=<CLOSED|KEYONLY|MISSING|LIMIT|OMIT_NONCRITICAL|NOT_APPLICABLE>|parameters=<canonicalTypedJSONOrAbsent>|proof=<proof>|evidence=<evidenceIDs>`
1884: 
1885: `BRANCH|scenario=<ID>|id=<ID>|order=<N>|source=<sourceID>|logic=<exactLogic>|inputs=<inputIDsOrAbsent>|result=<TRUE|FALSE|UNKNOWN|NOT_APPLICABLE>|writes=<pathsOrAbsent>|evidence=<evidenceIDs>`
```
**Correction:** Use kind=<canonicalDWLKind>, require kind to equal the first component of identity, use DTable not DT, and remove HELPER alias unless it is itself a canonical DWL kind. Apply identically in Main and Generator ScenarioGroup grammar.

### FP-026 — HIGH — DWL physical request deduplication and examples remain ambiguous/stale

**Impact:** Multiple READY occurrence rows can share one canonical KEY, but OUT uniqueness and SCAN mapping are not normatively defined. Examples also use noncanonical forms such as When:IsAlpha@Demo-Data-A instead of When@Demo-Data-A@IsAlpha.

**Source evidence:**
```text
300: - `_DWLState` is the visible source of truth for dependency traversal across RuleCrawler calls.
301: - `_DWLPlan.OUT` is mechanically derived from `_DWLState.READY`.
302: - `_DWLPlan.ACT` is mechanically derived from actual `InterestedRules[].pxRuleReferences[]`.
303: - `CHK=PASS` means `OUT == ACT`, `BLK` is disjoint from `ACT`, and no READY item is omitted.
304: - `_DWLPlan.BLK` may contain only rows currently in `CTX` or terminal `_DWLState.GAPS`. A row with a concrete requestable `KEY` is repaired to `READY` and must appear in `OUT`, not `BLK`.
305: - Every `FETCHED` item is scanned before closure. Scanning creates new `D` rows for executable dependencies and context providers.
306: - No steady-state `DISCOVERED` rows are allowed after scan reconciliation. Every newly discovered row immediately becomes `READY`, `CTX`, `CLOSED`, or terminal `GAPS`; otherwise `STATECHECK.postResponse=FIX`.
307: - A `D` row closes only by exact `KEY`. Same `pyRuleName` on a different class never closes the row.
```
```text
948: ### 7.6 Compact examples
949: 
950: Long-chain continuation:
951: `RootCheck -> evaluateWhen(DeepCheck)` creates `D|...|When@Demo-Data-A@DeepCheck|...|READY|...|REQUEST`.
952: W3 requests and scans `DeepCheck`. If scan finds `evaluateWhen(IsAlpha)` and `evaluateWhen(IsBeta)`, write:
953: `DWLDELTA|W3|scanned=When@Demo-Data-A@DeepCheck extracted=2|new=D31:When@Demo-Data-A@IsAlpha,D32:When@Demo-Data-A@IsBeta|ready=D31,D32|next=CRAWL`.
954: Next request is W4 with `OUT=When:IsAlpha@Demo-Data-A,When:IsBeta@Demo-Data-A` unless either exact key is already CLOSED.
955: 
956: Concrete W4 request after W3 discovery:
957: ```json
958: {
959:   "_DWLState": "W=4;CLOSED=[When@Demo-Data-A@RootCheck,When@Demo-Data-A@DeepCheck];READY=[D31:When@Demo-Data-A@IsAlpha,D32:When@Demo-Data-A@IsBeta];CTX=[];GAPS=[];CHECK=open=0,ready=2,ctx=0,unscanned=0,gaps=0",
960:   "_DWLPlan": "W4|SCAN=D31,D32|OUT=When:IsAlpha@Demo-Data-A,When:IsBeta@Demo-Data-A|BLK=none|ACT=When:IsAlpha@Demo-Data-A,When:IsBeta@Demo-Data-A|CHK=PASS|FIX=none",
961:   "InterestedRules": [
962:     {
963:       "pyItemRuleId": "RULE-OBJ-WHEN DEMO-DATA-A DEEPCHECK #DEMO",
964:       "pxRuleReferences": [
965:         {"pxObjClass":"Embed-Reference-Rule","pxRuleClassName":"Demo-Data-A","pyRuleName":"IsAlpha","pxRuleObjClass":"Rule-Obj-When","pxRuleFamilyName":"ISALPHA"},
966:         {"pxObjClass":"Embed-Reference-Rule","pxRuleClassName":"Demo-Data-A","pyRuleName":"IsBeta","pxRuleObjClass":"Rule-Obj-When","pxRuleFamilyName":"ISBETA"}
967:       ]
968:     }
969:   ]
970: }
971: ```
972: 
973: Concrete W5 continuation:
974: `DWLDELTA|W4|scanned=When@Demo-Data-A@IsAlpha extracted=1|new=D41:When@Demo-Data-A@IsGamma|ready=D41|closed=D32|next=CRAWL`.
975: ```json
976: {
977:   "_DWLState": "W=5;CLOSED=[When@Demo-Data-A@RootCheck,When@Demo-Data-A@DeepCheck,When@Demo-Data-A@IsBeta,When@Demo-Data-A@IsAlpha];READY=[D41:When@Demo-Data-A@IsGamma];CTX=[];GAPS=[];CHECK=open=0,ready=1,ctx=0,unscanned=0,gaps=0",
978:   "_DWLPlan": "W5|SCAN=D41|OUT=When:IsGamma@Demo-Data-A|BLK=none|ACT=When:IsGamma@Demo-Data-A|CHK=PASS|FIX=none",
979:   "InterestedRules": [
980:     {
981:       "pyItemRuleId": "RULE-OBJ-WHEN DEMO-DATA-A ISALPHA #DEMO",
982:       "pxRuleReferences": [
983:         {"pxObjClass":"Embed-Reference-Rule","pxRuleClassName":"Demo-Data-A","pyRuleName":"IsGamma","pxRuleObjClass":"Rule-Obj-When","pxRuleFamilyName":"ISGAMMA"}
984:       ]
985:     }
986:   ]
987: }
988: ```
989: 
990: Context-derived same-name rules:
991: `When@RBG-Data-LegalRep@IsLiquidator` and `When@RBG-Data-RelShip@IsLiquidator` are different keys. A closed LegalRep rule never closes the RelShip rule. `.LegalRep.LegalRepList.pyPageClass` resolves LegalRep occurrences; `.RelationshipList.pyPageClass` resolves RelShip occurrences.
992: 
993: RelationshipList sequencing:
994: Before `RelationshipList.pyPageClass` is scanned, plan `OUT=Prop:RelationshipList@RBG-Data-LegalRep` and keep `When:IsRelationshipTypeValid` in `CTX`. After scan proves `RBG-Data-RelShip`, promote `When@RBG-Data-RelShip@IsRelationshipTypeValid` to READY for the next wave.
995: 
996: Helper invocation extraction example:
997: Holder `When@Demo-Work@RootCheck` contains one of these equivalent forms: `@IsInPageListWhen(InnerCheck,.Items)`, `@IsInPageListWhen("InnerCheck",.Items)`, or `@IsInPageListWhen('InnerCheck', .Items)`. All normalize `arg1` to `InnerCheck`. The scan must produce the provider and executable rows, not only the helper name:
998: `DWLDELTA|W2|scanned=When@Demo-Work@RootCheck extracted=2|new=D21:Prop@Demo-Work@Items,D22:When@?@InnerCheck|ctx=D22:.Items.pyPageClass|ready=D21|next=CRAWL`.
999: After `Prop@Demo-Work@Items` returns `pyPageClass=Demo-Data-Item`, update `D22` to `When@Demo-Data-Item@InnerCheck`, set `state=READY`, and the next `_DWLPlan.OUT` includes `When:InnerCheck@Demo-Data-Item`. A cached helper contract does not close `D22`.
```
**Correction:** Define OUT as stable ordered unique canonical-KEY projection of READY occurrence rows, define SCAN mapping for duplicate occurrences, and rewrite every example in canonical key syntax.

### FP-027 — HIGH — SCENARIO_SNAPSHOT.given and DP_SIG still lack exact canonical serialization

**Impact:** Both values participate in equality/sorting/grouping but root shape, typed carriers, delimiters/escaping and parameter ordering are not fully normative. Two compliant models can create different frozen ordering or group identities.

**Source evidence:**
```text
230: Canonical key:
231: `KEY = <kind>@<applyToClass>@<name>` where `kind` is `When`, `DTable`, `Model`, `Prop`, `RUF`, `DP`, or another exact Pega rule type shortened consistently. Same name on different classes is a different `KEY`.
232: 
233: Data Page identity:
234: - `KEY=DP@<applyToClass>@<dataPageName>` tracks the Data Page rule/access as a dependency row.
235: - Simulation identity is `DP_SIG = KEY + normalized parameter set`. RuleCrawler metadata may deduplicate by `KEY`; `pySimulation` obligations deduplicate by `DP_SIG`.
236: - In `MODE=CRAWL`, `DP_SIG` may use normalized parameter bindings, e.g. `ObjectID=.Objects(1).ID`. In `MODE=AUTHOR`, each Scenario instantiates the binding with concrete seeded values in `SIM`/`RuleCode.pySimulation`; `DPA` matches crawl-time bindings to scenario-time concrete params.
```
```text
1300: The authoritative pre-materialization state is one internal `SCENARIO_SNAPSHOT` complete replacement ledger bound to the current RUT. It is not a tool call. A missing, malformed, partial, or mismatched snapshot requires a new INVENTORY snapshot; never fall back to an older version. Every phase fully replaces prior state. Scenario formation facts (`T`, `S`, covers, membership) exist only here until they are materialized into complete immutable ScenarioGroups.
1301: 
1302: `SCENARIO_SNAPSHOT` is a compact internal newline ledger with these positional rows:
1303: `P|<phase:I/W/F/B/A>|<pyID>|<pzInsKey>|<RUT_TYPE>`
1304: `T|<id>|<source>|<behavior>|<constraint-or->|<state:R/B/U/E>|<proof-or->`
1305: `S|<id>|<given>|<owner>|<covers>|<simulation>|<name-or->|<at-or->`
1306: `A|<required>|<blocked>|<unreachable>|<equivalent>|<actualCovered>|<missing>|<extra>|<materialized>|<PASS-or-FAIL>`
1307: `P` is first and unique; `A` exists only in phase A. T state is `R=required`, `B=blocked`, `U=unreachable`, or `E=equivalent/non-effective`; E proof names a canonical R id and exact equivalence fact, with no E chains/cycles. S.covers contains only actually executed R ids. `T.id` is original-RUT path plus outcome/constraint; `source` is its sorted raw-source-id set. Use `[A-Za-z0-9._:-]` ids, T source order, sorted id sets, and `-` for absent values. W may use `W1..`; after final F materialization merge identical keys, sort by canonical `given+simulation`, assign `S1..Sn`, and preserve them through B/A. `given` is canonical minified typed JSON for all RUT parameters, setup inputs, and Rule-Obj-When cells; `simulation` is the complete canonical resolved payload. Join rows with raw LF. Inside fields encode backslash as `\\`, pipe as `\|`, CR as `\r`, and LF as `\n`; split only on unescaped pipes and ledger-decode before parsing inner JSON. This is internal state, not a tool parameter, and receives no outer serializer encoding. One S is one physical Scenario and may cover many T.
1308: 
1309: Each phase replaces the complete internal snapshot. Parse only the current complete version; require typed positional grammar/arity `P5,T7,S8,A10` and stable T id/source through I/W/F, otherwise rebuild and replace it from the earliest invalid phase.
```
**Correction:** Define exact canonical typed JSON shapes for given and DP_SIG (or exact textual grammar), including ordering, absence/null/empty handling, and escaping.

## Medium/open findings

- **FP-003 — Scenario Author ownership lock is contradicted by lower legacy RuleCode/pySimulation authoring language:** Top-level ownership says Author never creates RuleCode/pySimulation/EvidenceSummary JSON, but lower operational text still describes them as Author/storage-gate objects. A literal model has conflicting instructions. Correction: Replace lower RuleCode/pySimulation references with frozen semantic SIM/ASSERT/SUMMARY source facts, and reserve physical RuleCode terminology for explicitly non-executable downstream reference sections.
- **FP-008 — Informational candidates remain coupled to full UTC Knowledge/example batch:** A valid informational outcome can fail KNOWLEDGE_FAILED because the Generator requests UTC RuleCode documentation/example/target carriers even though no RuleCode is produced and Validator correctly skips UTC Knowledge for informational mode. Correction: Split structural acquisition by mode: informational candidates need only the schema/fields truly required for their informational projection; executable candidates require UTC docs/example target carriers.
- **FP-011 — Both schemas retain RuleCode-era documentation after RuleCode became optional:** Descriptions still define NotTestable as “RuleCode harness-only or minimal”, counts as RuleCode-based, and MultInpComb comment still describes simulation differences as separate UnitTestRules entries instead of separate physical candidates. Correction: Make descriptions conditional by candidate mode and update title/$comment to the one-candidate physical-group architecture.
- **FP-015 — Accepted RUF pyLabel fallback evidence is absent:** The accepted fallback allows a concrete nonempty pyLabel when stronger behavior fields are empty and the label is unambiguous; KRUF.5/KRUF.12 still omit pyLabel. Correction: Add pyLabel as last-resort fetched semantic evidence with the accepted strict fallback conditions.
- **FP-028 — Skipped-output unknown-initial-presence policy remains an open design ambiguity:** Mutually exclusive branch outputs can create BlockingGaps/PartiallyTestable outcomes even when branch behavior itself is deterministic, depending on unknown initial property presence. Correction: Make a product decision: either require controlled initial absence for candidate outputs, or retain omission/gap semantics explicitly. Do not silently choose during implementation.
- **FP-029 — Change register/log overstate completion and contain stale semantics:** Restart/recovery can select the wrong authority and conclude the project is clean when it is not. Correction: Regenerate one current authoritative register after corrections; mark old logs historical/superseded and downgrade affected change IDs until reverified.

## Simulation matrix

| ID | Scenario | Result | Trace conclusion |
|---|---|---|---|
| SIM-01 | Standard executable happy path | **PASS_PROMPT_ONLY** | Author executable group -> ScenarioGroup -> GEN/SG -> exact GetMemory -> RuleCode candidate -> VAL/UT -> schema/read/Knowledge -> VR OK -> Update Passed/OK -> GR OK -> Main Completed. C-027..029 runtime remains external. |
| SIM-02 | Rule-Obj-When, multiple rows, same simulation key + EXECUTABLE | **PASS** | One physical group -> one candidate -> one UnitTestRules -> multiple Decision rows. Current executable examples/deep verifier support this. |
| SIM-03 | Rule-Obj-When, different simulation keys | **PASS** | Different (SIMULATION_GROUP_KEY, EXECUTABLE) pairs -> distinct physical groups/candidates. |
| SIM-04 | Standard informational NotTestable, no Data Page issue | **AMBIGUOUS** | Schema + Generator G4/G7 + Validator V4 support no-RuleCode candidate, but Main DWL_STORAGE_GATE still requires final RuleCode audit; Generator G3 also requires full UTC Knowledge/example. |
| SIM-05 | When same simulation key: one executable Scenario, one NotTestable Scenario | **FAIL_CONFLICT** | §1.3 intends split by EXECUTION_CLASS, but §12.2 still requires Decision ASSERTs for every Scenario and KW.16.1 says untestable Scenario must not appear in Scenarios[]. |
| SIM-06 | NotTestable caused by unresolved required Data Page simulation | **FAIL_DEADLOCK** | No guessed SIM allowed; NotTestable requires zero SIM/no RuleCode; but reachable/unknown DP requires DPA pass and When grouping requires a complete simulation key or NO_SIMULATION only when no simulation is required. |
| SIM-07 | Validator batch contains informational UT followed by executable UT | **AMBIGUOUS** | V1/V2 require sibling continuation/all VR blocks, while V4 says “return that UT immediately”; literal return can omit later sibling. |
| SIM-08 | Informational candidate mutated to ReasoningConfidence=High | **FAIL_CONSISTENCY** | Main requires Low for blocking NotTestable; both actual schemas ACCEPT the mutation; Validator informational gate does not inspect confidence. |
| SIM-09 | Informational candidate with nonempty BlockingGaps but DependencyClosureStatus=Closed | **FAIL_CONSISTENCY** | Main says Closed only with no gaps; both actual schemas ACCEPT the mutation; Validator informational gate does not inspect closure status. |
| SIM-10 | Malformed/unattributable Validator response | **PASS** | Generator leaves candidate Pending, makes no lifecycle UpdateMemory, returns FAILED/VALIDATOR_RESPONSE_INVALID; siblings remain independent. |
| SIM-11 | UpdateMemory failure after VR OK | **PASS_PROMPT_ONLY** | One no-retry lifecycle attempt; affected group fails LIFECYCLE_UPDATE_FAILED while successful sibling can keep Main Completed. Runtime implementation is C-027..029 external. |
| SIM-12 | Two READY dependency occurrences with same canonical KEY | **AMBIGUOUS** | D rows are occurrence-based but _DWLPlan.OUT uniqueness and SCAN-to-occurrence mapping are not defined. |
| SIM-13 | GetCaseData has valid RuleJSON identity but empty pyID / missing TestedRuleKey | **FAIL_GUARD** | Initial gate passes pzInsKey+pxObjClass then locks empty pxCaseID; TestedRuleKey failure is discovered only at PROFILE/materialization. |
| SIM-14 | Confirmed environment Model WHEN exports condition in pyPropertiesName | **FAIL_KA_DRIFT** | Current Model KA reads pyCondition, so dependency/branch discovery can miss the actual condition. |
| SIM-15 | Confirmed environment formal parameter type is pyParametersParamType="STRING" | **FAIL_KA_DRIFT** | Current Model KA still reads pyParametersType and Main compatibility says String; strict projection can create an unsupported-type gap. |
| SIM-16 | Confirmed environment Data Page pyScope="thread" | **FAIL_KA_DRIFT** | KDP.2 treats every value other than exact Thread as ineligible, contradicting accepted runtime evidence. |
| SIM-17 | Fetched RUF has useful pyLabel but empty stronger descriptions | **FAIL_KA_DRIFT** | Accepted pyLabel fallback is absent, so return semantics remain unknown and dependent assertions are unnecessarily downgraded. |
| SIM-18 | Eligible simulated Data Page exposes underlying loader reference | **FAIL_DRIFT** | Accepted hard simulation boundary is absent from the Data Page KA; a literal dependency scan may crawl loader work that simulation should replace. |
| SIM-19 | Model false edge suppresses APPEND_AND_MAP_TO producer | **FAIL_COVERAGE** | Current coverage adapter may treat false edge as covered because no OTHERWISE/EXIT/later owner differs, despite observable absence of the list mutation. |
| SIM-20 | APPEND_AND_MAP_TO ... EXISTING_PAGE with child .X=.X | **AMBIGUOUS** | Current KA says generic LIST_APPEND but not that left .X targets the newly appended page while right .X reads the configured source page. |
| SIM-21 | RUT reads Data Page list container; nested closed When needs item leaf | **FAIL_CONFLICT** | Seed-depth rule forbids deeper item leaves even though closed dependency requires them for deterministic execution. |
| SIM-22 | Input-only candidate assertion must be omitted as incorrect_candidate_assertion | **FAIL_CONTRACT** | Later Main sections allow this reason, but §5.5 canonical omission list rejects it. |
| SIM-23 | Direct SET producer Param.X = expression | **FAIL_PROJECTION** | PC.payload permits descendant rows only, so the producer cannot carry its own RHS required by assertion binding. |
| SIM-24 | Later producer skipped because prior EXIT_MODEL executed | **FAIL_CONTROL_FLOW** | LPE.executes=false requires terminal guard proof; prior terminal EXIT is not a false guard, leaving the later producer unknown. |
| SIM-25 | Param or named-page structural ASSERT requires PROFILE binding | **FAIL_OR_AMBIGUOUS** | PROFILE mandates PROPERTY_DEFINITION evidence for every binding even when target is Param or runtime page rather than Rule-Obj-Property. |
| SIM-26 | ScenarioGroup contains closed When/Prop/Model dependencies | **FAIL_SELF_PARSE** | Canonical DWL supports those kinds, but DEP.kind grammar cannot encode them without illegal HELPER/DT remapping. |
| SIM-27 | Two models serialize equivalent given/DP_SIG state | **AMBIGUOUS** | Exact serialization grammar is incomplete; equivalent semantics can sort/group differently. |
| SIM-28 | Skipped branch output has unknown initial property presence | **OPEN_DECISION** | Current omission/gap policy may downgrade otherwise deterministic scenario; no final product decision is recorded. |

## Interpretation

The A2A/Memory-addressing/lifecycle refactor is substantially present and its targeted tests still pass. The failure of full certification comes from cross-layer consistency: Scenario Author, ScenarioGroup grammar, KnowledgeAreas, conditional NotTestable semantics, schemas, Validator batching, and recovery artifacts are not yet one coherent contract.

The most important discovery is that several defects recorded and accepted/confirmed during the original full simulation were never incorporated into the later C-001..C-077 change register. In particular the Model export mappings, Data Page scope, RUF fallback, simulation boundary, Model coverage/producer rules, canonical DEP.kind, and canonicalization gaps remain in source. Therefore `C-001..C-077` passing cannot be treated as proof that the entire earlier review plan was applied.

C-027/C-028/C-029 remain intentionally deferred. They are not classified as regressions, but runtime Memory behavior cannot be certified until those tool implementations are reviewed.

## Recommended correction order

1. Fix the two **critical contract blockers**: informational NotTestable storage/DP dead path (FP-005) and canonical ScenarioGroup DEP.kind (FP-025).
2. Reconcile RISK-001 end-to-end: Main §12.2, When KA, Generator G5/G6, Validator batch semantics, schema confidence/closure constraints, and schema documentation.
3. Apply the omitted accepted KnowledgeArea/environment corrections: Model WHEN/params, Data Page `thread`, RUF pyLabel fallback, simulated-DP loader boundary, APPEND_AND_MAP_TO semantics.
4. Apply the remaining Main execution correctness corrections: owner coverage, producer payload, EXIT non-execution, seed depth, omission code set, PROFILE binding evidence, initial identity gate.
5. Define canonical `given`, `DP_SIG`, `_DWLPlan.OUT` dedup/SCAN mapping; resolve MA-028 product policy.
6. Add `Rule_Crawler_tool.txt` to the final package and regenerate a single authoritative change register/log. Then rerun the full simulation matrix plus existing regression suites.

No source changes were made during this audit.
