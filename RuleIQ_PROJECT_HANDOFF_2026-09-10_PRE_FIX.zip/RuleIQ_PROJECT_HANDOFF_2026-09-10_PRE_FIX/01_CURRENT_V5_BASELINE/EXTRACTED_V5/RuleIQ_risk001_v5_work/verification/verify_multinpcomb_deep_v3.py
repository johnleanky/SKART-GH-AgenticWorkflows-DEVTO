#!/usr/bin/env python3
from pathlib import Path
import json, sys, re
import jsonschema
SRC=Path(sys.argv[1]); checks=[]
def ck(n,o,d=""): checks.append({"check":n,"status":"PASS" if o else "FAIL","detail":d})
schema=json.loads((SRC/"rule-test-unit-case_multInpComb-JsonSchema.txt").read_text())
files=[SRC/"rule-test-unit-case_multInpComb-JsonExample.txt"]+sorted(SRC.glob("rule-test-unit-case_multInpComb-JsonExample_0[2-5]_*.txt"))
for p in files:
    d=json.loads(p.read_text()); e=list(jsonschema.Draft202012Validator(schema).iter_errors(d))
    ck(p.name+" schema-valid",not e,"; ".join(x.message for x in e[:3]))
    ck(p.name+" exactly one unit",len(d["UnitTestRules"])==1,str(len(d["UnitTestRules"])))
    u=d["UnitTestRules"][0]; rc=u["RuleCode"]
    pc={x["pyPagesAndClassesPage"]:x["pyPagesAndClassesClass"] for x in rc.get("pyPagesAndClasses",[])}
    ck(p.name+" primary in P&C",rc["pyPrimaryPageForRUT"] in pc,str(pc))
    rows=rc["pyExpectedResults"][0]["pyExpectedResults"]
    ck(p.name+" Scenario/row count",len(u["Scenarios"])==len(rows),f"{len(u['Scenarios'])}/{len(rows)}")
    sig0=None
    for si,(s,row) in enumerate(zip(u["Scenarios"],rows)):
        cells=row["pyExpectedResults"]; sig=[(x["pyPropertyType"],x["pyPropertyName"],x["pyPropertyAbsolutePath"],x["pyDisplayLabel"]) for x in cells]
        if sig0 is None: sig0=sig
        ck(f"{p.name} s{si} signature",sig==sig0)
        ck(f"{p.name} s{si} result last",cells[-1]["pyPropertyType"]=="result" and cells[-1]["pyPropertyName"]=="Result")
        trace=s["EvidenceSummary"]["AssertionDecisionTrace"].splitlines()
        assertions=[x for x in trace if x.startswith("ASSERT|")]
        sims=[x for x in trace if x.startswith("SIM|")]
        omits=[x for x in trace if x.startswith("OMIT|")]
        ck(f"{p.name} s{si} assertion count",s["EvidenceSummary"]["AssertionCount"]==len(assertions))
        ck(f"{p.name} s{si} sim count",s["EvidenceSummary"]["SimulatedDependencyCount"]==len(sims))
        ck(f"{p.name} s{si} omit count",s["EvidenceSummary"]["OmittedClaimCount"]==len(omits))
        # Exact row/cell correspondence.
        for ci,cell in enumerate(cells):
            line=assertions[ci] if ci<len(assertions) else ""
            expected_kind="DecisionResult" if cell["pyPropertyType"]=="result" else "DecisionInput"
            expected_val=cell.get("pyExpectedValue","<EMPTY>")
            ck(f"{p.name} s{si} c{ci} trace target/value",
               f"kind={expected_kind}" in line and f"row={si+1}" in line and
               f"target={cell['pyPropertyAbsolutePath']}" in line and f"value={expected_val}" in line,line)
            if cell["pyPropertyType"]=="input":
                target=cell["pyPropertyAbsolutePath"]
                if not target.startswith(".") and not target.startswith("Param."):
                    root=target.split(".",1)[0]
                    if root in pc:
                        f=dict(x.split("=",1) for x in line.split("|")[1:])
                        ck(f"{p.name} s{si} c{ci} named-page class",f["class"]==pc[root],f"{f['class']} vs {pc[root]}")
        waves=s["EvidenceSummary"]["MaxDependencyWaveReached"]
        dct=s["EvidenceSummary"]["DependencyClosureTrace"]
        if waves==0:
            ck(f"{p.name} s{si} zero-wave trace",dct=="No RuleCrawler waves occurred.",dct)
        else:
            ck(f"{p.name} s{si} wave trace",
               all(k in dct for k in ["STATE W1","PLAN W1","DELTA W1","state=CLOSED","not recovered runtime history"]),dct[:300])
failed=[x for x in checks if x["status"]=="FAIL"]
result={"status":"PASS" if not failed else "FAIL","checks_total":len(checks),"checks_passed":len(checks)-len(failed),"checks_failed":len(failed),"checks":checks}
print(json.dumps(result,indent=2,ensure_ascii=False)); sys.exit(1 if failed else 0)
