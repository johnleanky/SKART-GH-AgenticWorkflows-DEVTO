# RuleIQ Prompt Refactor — Factual Change Implementation Log

Purpose: restart-safe checklist for implementing the accepted Scenario Author → UnitTestGenerator → UnitTestValidator architecture.

## Status model

- `DESIGNED` — accepted design exists, but no concrete edit has been staged.
- `STAGED` — the guarded refactor script contains the concrete edit, but it has **not** been applied to the repository/source file.
- `APPLIED` — the exact target source file was changed and reread from that changed source.
- `VERIFIED` — a separate post-edit pass proved the new contract is present and conflicting old wording is absent.
- `EXTERNAL_PENDING` — contract is frozen, but implementation belongs to the Pega Memory tool rather than the three reviewed prompt files.
- `BLOCKED` — implementation cannot proceed without a missing decision/tool contract.

Never infer `APPLIED` from a patch/script. A restart must treat every `STAGED` row as unapplied until the actual target file is changed.
Never mark `VERIFIED` without rereading the actual modified source independently.

## Change register

| ID | Target | Required factual change | Status | Short evidence / recovery note |
|---|---|---|---|---|
| C-001 | Main `§1A` | Replace sequential one-group `WriteMemory(CaseID,Type,Payload)` with batch-shaped `WriteMemory(pxCaseID,Type,RequestsJSON)`; rows independent. | STAGED | D-005/D-007: ScenarioGroups persisted as independent `pxResults[]` rows; successful siblings survive failures. |
| C-002 | Main `§1A` | Remove all-or-nothing ScenarioGroup write gate; hand off every successfully persisted group. | STAGED | User accepted partial progress; Main external failure only when zero groups succeed. |
| C-003 | Main `§1A` | Replace 3-parameter Generator invocation with single `question` using `GEN` + `SG` line protocol. | STAGED | D-008/D-009; invoked agent accepts only `question`. |
| C-004 | Main `§1A` | Main correlates Generator result rows by `pyGroup`, never response order. | STAGED | D-007/D-012. |
| C-005 | Main `§1A` | External `Completed` when ≥1 group returns final usable `GR status=OK`; `Failed` only when zero successful groups. | STAGED | User decision resolving MA-041. |
| C-006 | Main `§1.4/§1A` | Keep external visible response contract unchanged; never expose GUIDs/internal reports. | STAGED | Existing visible-output lock retained. |
| C-007 | Generator `G1` | Replace direct inputs `CaseID,RUTType,ScenarioGroupUUIDs` with one scalar `question`; parse `GEN` header + `SG` records. | STAGED | D-008/D-009; MA-039. |
| C-008 | Generator `G1/G2` | For every `SG`, call exact `GetMemory(pxCaseID,"ScenarioGroup",pyGUID)`; verify returned `pyGroup`, `pxCaseID`, `Type`, `pyGUID`. | STAGED | Address by `pyGUID`; `pyGroup` is correlation only. |
| C-009 | Generator `G1/G8` | Persist one immutable `UnitTestCandidate` per physical `pyGroup`, not one combined candidate. | STAGED | D-007. |
| C-010 | Generator `G1/G8` | Candidate writes use batch-shaped `WriteMemory(pxCaseID,"UnitTestCandidate",RequestsJSON)` with independent row outcomes. | STAGED | D-007; successful candidate rows proceed independently. |
| C-011 | Generator `G7` | Fix AssertionDecisionTrace encoding: encode field values only; keep structural `|` delimiters literal. | STAGED | MA-036 accepted; required by Validator split-before-decode parser and live JSON example. |
| C-012 | Generator `G6/G7` | For nested ordinary Property assertions derive physical containing page from semantic context + target; do not force semantic `ASSERT.page` to equal physical `pyPageName`. | STAGED | MA-035 accepted; live schema describes containing-page behavior. |
| C-013 | Generator `G8` | Invoke Validator through one `question` using `VAL` + `UT` records; pass only `pyGroup` + candidate `pyGUID`, never candidate payload. | STAGED | D-008/D-009. |
| C-014 | Generator `G1/G8` | Add generic `UpdateMemory(pxCaseID,Type,RequestsJSON)` to allowlist for lifecycle metadata. | STAGED | D-013; supersedes proposed `UpdateMemoryStatus`. |
| C-015 | Generator `G8` | After Validator `OK`, exactly one `UpdateMemory` attempt sets same candidate `pyStatusValue=Passed`, `pyRouterKey=OK`. No retry. | STAGED | D-010/D-013; MA-043 resolved: no retry. |
| C-016 | Generator `G8` | On `GENERATOR_REPAIR`, exactly one lifecycle update marks current candidate `Failed/GENERATOR_REPAIR`, then create a new immutable candidate with new `pyGUID`. | STAGED | D-015 repair simulation. |
| C-017 | Generator `G8` | Repair budget is per `pyGroup`: 1 initial validation + max 2 repaired candidates = max 3 Validator attempts. | STAGED | MA-042 accepted. |
| C-018 | Generator `G9` | Remove singular top-level candidate/UUID report; return compact per-group `GR|pyGroup|pyGUID|status=OK|FAILED|reason`. | STAGED | MA-037/D-012. |
| C-019 | Generator `G9` | Do not repeat Scenario Testability in `GR`; candidate payload remains authoritative for `Scenarios[].Testability` and `EvidenceSummary.BlockingGaps`. | STAGED | D-012/D-014; live schema confirms locations. |
| C-020 | Validator `V1` | Replace direct `CaseID,RUTType,UnitTestCandidateUUID` inputs with one scalar `question`; parse `VAL` + `UT` records. | STAGED | D-008/D-009; MA-034/MA-039. |
| C-021 | Validator `V3` | For each UT row use exact candidate `pyGUID` for JsonValidationTool and then `GetMemory(pxCaseID,"UnitTestCandidate",pyGUID)`; candidate content never comes from A2A. | STAGED | D-009. |
| C-022 | Validator `V3` | Verify retrieved `pyGUID`, `pxCaseID`, `Type`, `pyGroup` before parsing `pyPayload`. | STAGED | D-009 correlation invariant. |
| C-023 | Validator `V5` | Preserve split-lines → split literal `|` → decode field values once; align wording with corrected Generator encoding. | STAGED | MA-036 accepted. |
| C-024 | Validator `V6` | For nested ordinary properties compare RuleCode child `pyPageName` to derived physical containing page, not literal semantic `ASSERT.page`. | STAGED | MA-035 accepted. |
| C-025 | Validator `V1/V2` | Return compact direct A2A `VR` + optional `VI` lines; no persisted Validator result and no new Validator GUID. | STAGED | D-007/D-008. |
| C-026 | Validator `V2/V6` | Treat legitimate `PartiallyTestable/NotTestable` + faithful BlockingGaps as candidate content that can still validate `OK`; reserve semantic rejection for contradiction/misrepresentation. | STAGED | D-017: G001 `PartiallyTestable` + 2 BlockingGaps → synthetic `VR route=OK`; D-018: ASSERT+OMIT same target → current V6 `REASONING_CONTRADICTION/REJECT_SEMANTICS`. |
| C-027 | Memory tool contract | `WriteMemory` creates `UnitTestCandidate` with `pyStatusValue=Pending`, empty `pyRouterKey`; canonical fields include `pyGUID,pxCaseID,Type,pyGroup,pyPayload`. | EXTERNAL_PENDING | D-010/D-013. |
| C-028 | Memory tool contract | `UpdateMemory` shallow-replaces explicitly named allowed root fields in `pyUpdates`; protected identity fields cannot change; current Generator cannot mutate `pyPayload`. | EXTERNAL_PENDING | D-013. |
| C-029 | Memory tool contract | `UpdateMemory` rows are independent and have no retry. | EXTERNAL_PENDING | D-013 + MA-043 user decision. |
| C-030 | Cross-prompt | Canonical A2A escaping/record grammar must be identical on sender and receiver prompts. | STAGED | D-008; prevents sender/receiver drift. |


| C-031 | Main `§13` | Replace repeated legacy per-group UUID persistence paragraph/envelope with the same batch `pyGroup/pyGUID` contract as §1A. | STAGED | Live §13 still said once per group/all writes succeed; guarded replacement included. |
| C-032 | Main `§14.1` | Replace final sequence with one ScenarioGroup batch, partial successful handoff, GEN/SG question, and ≥1 GR OK aggregate. | STAGED | Live §14.1 repeated sequential/all-or-nothing contract. |
| C-033 | Generator `G2` | Remove positional `groupOrder == supplied one-based position` and invocation-wide source failure; groupOrder is metadata and source failures are per pyGroup. | STAGED | Required by partial upstream writes and future singleton fan-out. |
| C-034 | Generator `G10 + App. B/C` | Remove legacy raw ValidatorReport/GeneratorRunReport schemas and four-interface wording; replace with VR/VI + GR A2A contracts. | STAGED | Live G10/App. B/C contradicted D-008/D-012. |
| C-035 | Validator `V4` | Batch semantics: RUT check per candidate; one shared UTC lookup only for surviving candidates; failure does not rewrite prior item outcomes. | STAGED | Current one-candidate V4 generalized without cross-item semantics. |
| C-036 | Validator `V9/V10 + App. B/C` | Replace single raw JSON report/output schema/examples with per-candidate VR/VI line blocks. | STAGED | Required by one-question A2A contract. |
| C-037 | Generator/Validator | Enforce one persisted UnitTestCandidate per pyGroup with exactly one `UnitTestRules` entry; When group may still contain multiple Scenarios. | STAGED | D-007 plus current UTC schema keeps UnitTestRules array. |
| C-038 | Generator `G8` | `SEMANTIC_REJECT` is terminal for that candidate/group after Failed/SEMANTIC_REJECT lifecycle update; no semantic pruning/re-authoring. | STAGED | D-018 simulation; legitimate testability gaps can still Validator-OK. |
| C-039 | Generator `G8` | `HUMAN` is terminal for that group after Failed/HUMAN lifecycle update; no repair. | STAGED | D-019 simulation. |
| C-040 | Main/Generator/Validator | Rename address terminology from transport UUID semantics to canonical `pyGUID`; `pyGroup` never becomes an address. | STAGED | D-005/D-009 canonical identity decision. |

| C-041 | Main `§15` | Remove legacy GeneratorRunReport JSON schema/consistency checks; replace with compact GR contract and ≥1 OK aggregate. | STAGED | Pre-apply contradiction sweep found live §15 still authoritative under old report model. |
| C-042 | Main `§14.2` | Replace legacy combined-candidate/direct-Validator downstream preservation bullets with one-candidate-per-pyGroup and VAL/UT → VR/VI ownership. | STAGED | Sweep found old combined candidate and direct CaseID/RUTType/UUID Validator wording. |
| C-043 | Main `§13` + Generator Appendix A | Replace “UUID order equals group order” invariant; complete snapshot groupOrder stays contiguous, partial successful handoff uses explicit pyGroup+pyGUID. | STAGED | Required because failed persistence rows may be omitted from Generator handoff. |
| C-044 | Main `§1.4` | Remove obsolete `GeneratorRunReport` terminology from visible-output prohibition without changing the external two-field response. | STAGED | Terminology-only cleanup after deleting GeneratorRunReport contract. |

| C-045 | Main `§1A + §15` | Parse Generator results per expected `pyGroup`; malformed/missing/duplicate sibling result cannot erase another independently valid `GR status=OK`. | STAGED | Required by user aggregate rule: external Failed only when there are no successful groups. |

| C-046 | Main `§13.4.6` | Make trace encoding explicit: entity-encode field values only; keep structural pipes literal; Validator splits structure before decoding. | STAGED | Full blob review found downstream trace contract needed explicit MA-036 synchronization. |
| C-047 | `UnitTestGenerator.txt` | Replace embedded `pySystemPrompt` with exact transformed Generator prompt and replace JSON-only `pyResponseStylePrompt` with GR-only line protocol. | STAGED | Live agent config independently forces raw GeneratorRunReport JSON. |
| C-048 | `UnitTestGenerator.txt` `pzKnowledgeTools` | Add configured `UpdateMemory` tool exactly once. | STAGED | Live Generator config contains KnowledgeTool/GetMemory/WriteMemory but no UpdateMemory. |
| C-049 | `JsonValidator_tool.txt` | Replace embedded UnitTestValidator `pySystemPrompt` with exact transformed Validator prompt and replace raw-JSON response style with VR/VI-only line protocol. | STAGED | Live Pega agent rule independently forces one raw JSON object. |
| C-050 | Generator/Validator runtime configs | Guard that decoded embedded system prompt exactly equals its standalone final prompt; Validator must remain without UpdateMemory. | STAGED | Prevent standalone/runtime prompt drift and preserve read-only Validator ownership. |

| C-051 | Generator `G8.2` | If Validator output is malformed/unattributable, do not invent a lifecycle route or call UpdateMemory; leave candidate `Pending` and report group `FAILED/VALIDATOR_RESPONSE_INVALID`. | STAGED | No valid Validator route exists to persist truthfully. |
| C-052 | Generator `G8.3` | Define exact generic UpdateMemory outer envelope and independent per-row response validation; still no retry. | STAGED | D-013/MA-043 needed a concrete result contract. |
| C-053 | Validator `V1/V3` | Preserve existing JsonValidationTool API argument names `CaseID`, `UUID`, `JsonSchema`; map `CaseID=VAL.pxCaseID`, `UUID=UT.pyGUID`. | STAGED | Live Validator contract exposes these tool parameter names; no accepted decision changed JsonValidationTool itself. |

| C-054 | `rule-test-unit-case_JsonSchema.txt` + `rule-test-unit-case_multInpComb-JsonSchema.txt` | Clarify AssertionDecisionTrace description: encode reserved characters only inside field values; structural `|`/record LF remain structural and are split before decode. | STAGED | Both live schemas still contain the ambiguous `encode ... pipe as &#124;, newline as &#10;` wording. |

## Mandatory post-edit verification gate

After prompt edits are applied, run a fresh verification pass against the actual modified files.

For every `C-*` item:

1. reread the exact target section from the repository/file;
2. quote or identify the precise section/paragraph that implements it;
3. search the same prompt for obsolete/conflicting wording;
4. mark `VERIFIED` only if both are true:
   - required new contract is present;
   - conflicting old contract is absent or explicitly superseded;
5. record a one-line factual evidence reference in this table.

Verification must also perform these cross-file checks:

- Main sender grammar == Generator receiver grammar.
- Generator sender grammar == Validator receiver grammar.
- Validator response grammar == Generator parser grammar.
- `WriteMemory/GetMemory/UpdateMemory` signatures use the same parameter names everywhere.
- `pyGUID` is always address; `pyGroup` is always correlation.
- candidate `pyPayload` never appears in A2A `question`.
- no singular candidate UUID/report remains in Generator/Main contracts.
- repair budget is per `pyGroup`.
- no `UpdateMemory` retry language remains.
- Main returns external Failed only when zero successful groups remain.
- Testability/BlockingGaps are not duplicated into Memory lifecycle metadata or `GR`.
- Validator cannot mutate Memory.
- Generator cannot mutate candidate `pyPayload`.

A final refactor may be declared complete only when every non-blocked C-item is `VERIFIED`.


## Simulation evidence checkpoints

These do **not** change any C-item from DESIGNED to APPLIED. They only show that the accepted design was
exercised before prompt editing.

| Evidence ID | Result |
|---|---|
| D-017 | Legitimate G001 `PartiallyTestable` candidate with BlockingGaps remains Validator-acceptable (`OK`). |
| D-018 | Contradictory final decisions (ASSERT + OMIT same target) route `SEMANTIC_REJECT`; no repair. |

Current source implementation status remains:
`0 APPLIED / 0 VERIFIED`

Guarded staging status: prompt-side C-items are now encoded in `apply_prompt_refactor_v8.py`, but the production prompt files have not yet been modified. Memory-tool C-027..C-029 remain external implementation work.


## Staging evidence

- Script: `apply_prompt_refactor_v8.py`
- Baseline Git blob guards:
  - Main_Agent_Prompt.txt `9a21effb28e9b5a2ff84449a581be305cc12a3b3`
  - UnitTestGenerator_Prompt.txt `b77183356797d50a2d069da7ca7eaa398c163011`
  - Validator_Prompt.txt `9d5e550bf2ebe02646cb2deca1fb9fda69064a48`
- Script syntax check: PASS.
- Canonical A2A escape round-trip test (pipe, backslash, LF, literal `-`, empty): PASS.
- No C-item is APPLIED or VERIFIED merely because this staging artifact exists.


## Pre-apply contradiction sweep — pass 1

The first staged script was **not** promoted because the sweep found additional live old-contract surfaces:
- Main §15 legacy GeneratorRunReport schema and report-only checks;
- Main §14.2 combined candidate/direct Validator wording;
- Main §13 and Generator Appendix A `UUID order equals group order` invariant.

These are now staged as C-041..C-044 in `apply_prompt_refactor_v8.py`.

Source status remains:
`0 APPLIED / 0 VERIFIED`

This is intentional: staging evidence is not source evidence.


## Pre-apply contradiction sweep — pass 2

Cross-contract review of the newly staged Main logic found one internal contradiction: a single malformed/missing GR row would have invalidated the whole Generator response. C-045 corrects this to per-`pyGroup` evidence, consistent with the accepted ≥1-success aggregate.

Current source status remains:
`0 APPLIED / 0 VERIFIED`

Latest guarded staging script:
`apply_prompt_refactor_v8.py`


## Runtime-agent configuration discovery

Live evidence:
- `UnitTestGenerator.txt` response style still requires one raw GeneratorRunReport JSON object and its embedded system prompt is the old direct-parameter Generator contract.
- `JsonValidator_tool.txt` is the Pega UnitTestValidator agent rule/config despite its filename; its response style still requires one raw JSON object and embeds the old Validator prompt.
- Generator configured tools currently include KnowledgeTool, GetMemory and WriteMemory; UpdateMemory is absent.
- Validator configured tools include GetMemory, JsonValidationTool and KnowledgeTool; it must remain read-only.

`apply_prompt_refactor_v8.py` now SHA-guards and transforms all five whitelisted targets:
1. Main_Agent_Prompt.txt
2. UnitTestGenerator_Prompt.txt
3. Validator_Prompt.txt
4. UnitTestGenerator.txt
5. JsonValidator_tool.txt

Current source status remains:
`0 APPLIED / 0 VERIFIED`

## Apply-channel status

Attempted to create isolated branch `ruleiq-a2a-memory-refactor` from `main`. GitHub returned HTTP 403 `Resource not accessible by integration`. No branch, commit, file update, or PR was created.

Therefore repository status remains factually:
`0 APPLIED / 0 VERIFIED`

Do not treat staged scripts as repository changes.

## Pre-apply contradiction sweep — pass 3

Additional corrections staged:
- preserve the existing JsonValidationTool parameter names instead of silently refactoring a non-target tool API;
- malformed/unattributable Validator output leaves the candidate Pending, because there is no truthful route to persist;
- UpdateMemory result validation now has an explicit outer + per-row contract.

No new accepted semantic ownership change was introduced.

## Open edge case — UI representation of zero-assertion NotTestable groups

`RISK-001` — **not silently changed**.

The standard UTC schema requires `UnitTestRules[*].RuleCode` and `RuleCode.pyExpectedResults` has `minItems: 1`. Therefore a source Scenario that is genuinely `NotTestable` and has zero valid assertions cannot be represented as a schema-valid UnitTestCandidate solely to show `Scenarios[].Testability=NotTestable` and `BlockingGaps`.

Current staged behavior remains conservative: such a group ends without a fake executable candidate. This does not affect PartiallyTestable/NotTestable Scenarios that still have at least one valid structural/assertable result.

Resolving RISK-001 would require an explicit product/schema decision (for example a non-executable candidate variant or a separate UI source), not a prompt-only assumption.

## Pre-apply contradiction sweep — pass 4

Both UTC schema descriptions were added to the MA-036 synchronization surface as C-054. No structural schema relaxation was made.

Current repository status remains `0 APPLIED / 0 VERIFIED` because GitHub write permission is still 403.

## Staging implementation tests

`apply_prompt_refactor_v8.py` helper tests: **PASS**
- standard schema trace-description replacement occurs exactly once;
- rich-text `pySystemPrompt` encode/decode round-trip preserves markup-sensitive prompt text;
- runtime config replacement updates the embedded prompt deterministically;
- Generator runtime config receives exactly one `UpdateMemory` pzKnowledgeTools row;
- response-style replacement works even when the prior Validator style uses `<ol>...` markup.

`verify_prompt_refactor_v4.py` syntax/compile check: **PASS**.

These are staging tests only. They do not change source status from `0 APPLIED / 0 VERIFIED`.

## Apply-start checkpoint — 2026-09-10

User explicitly instructed to start the apply phase.

### Live source-version verification

The seven current `main` blob SHAs were reread from GitHub and all exactly match
the guarded baselines encoded in `apply_prompt_refactor_v8.py`:

- Main_Agent_Prompt.txt — `9a21effb28e9b5a2ff84449a581be305cc12a3b3`
- UnitTestGenerator_Prompt.txt — `b77183356797d50a2d069da7ca7eaa398c163011`
- Validator_Prompt.txt — `9d5e550bf2ebe02646cb2deca1fb9fda69064a48`
- UnitTestGenerator.txt — `2126224898a361e203a37455e7266a4ea7871918`
- JsonValidator_tool.txt — `e137d40aca7a765b51b013275b32ebdd0bf051c4`
- rule-test-unit-case_JsonSchema.txt — `58f62043066aa21c5a6a5a2690b77d9fafca1598`
- rule-test-unit-case_multInpComb-JsonSchema.txt — `17ec9e3596961ba0706e3c235e8304a491cab66a`

Evidence artifact:
`LIVE_BASELINE_SHA_CHECK_2026-09-10.json`

Result:
`BASELINE_FRESHNESS = PASS`

### GitHub write attempt

Branch creation was retried:

`ruleiq-a2a-memory-refactor` from `main`

GitHub again returned:
HTTP 403 `Resource not accessible by integration`.

Result:
`REPOSITORY_WRITE = BLOCKED_BY_CONNECTOR_PERMISSION`

No repository source changed.
No branch/commit/PR exists from this attempt.

Factual repository state remains:
`0 APPLIED / 0 VERIFIED`

### Machine-readable recovery register

The Markdown factual register was converted to:
`REFACTOR_CHANGE_REGISTER_v1.json`

It contains:
- 54 unique C-* records;
- 51 `STAGED`;
- 3 `EXTERNAL_PENDING`;
- 0 `APPLIED`;
- 0 `VERIFIED`.

The JSON register is authoritative for machine recovery because Markdown descriptions legitimately
contain literal pipe characters and therefore should not be parsed with naive table splitting.

### Ready-to-apply package

Created:
`RuleIQ_A2A_Memory_Refactor_ReadyToApply.zip`

Contains:
- guarded apply script v8;
- independent verifier v4;
- factual Markdown log;
- machine-readable JSON register;
- simulation/recovery ledger;
- current live SHA evidence;
- exact apply/verification instructions.

The package being ready does not change source status.


## 2026-09-10 local apply completion

The user supplied all source files. After normalizing CRLF to LF in the two Pega runtime XML exports, all seven guarded target Git blob SHAs matched the reviewed live baseline exactly.

The first v8 apply attempt aborted before write because two post-transform verification anchors were stale. `apply_prompt_refactor_v9.py` corrects only those verification needles; transformation content is unchanged. `verify_prompt_refactor_v5.py` corrects the matching capitalization needle.

Local source-copy result:
- 51 previously STAGED prompt/config/schema changes -> `VERIFIED_LOCAL`.
- C-027..C-029 Memory-tool implementation -> `EXTERNAL_PENDING`.
- independent verifier -> PASS, 0 failures.
- independent source reread -> PASS, 45/45.
- both schema JSON files parse.
- both runtime agent XML files parse.

GitHub repository status remains separate: no repository write is claimed in this session.
