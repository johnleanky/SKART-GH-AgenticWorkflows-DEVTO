#!/usr/bin/env python3
from pathlib import Path
import json, copy, re, sys, html
import jsonschema
from xml.etree import ElementTree as ET

SRC=Path(sys.argv[1])
VER=Path(sys.argv[2])
checks=[]
def ck(n,o,d=""): checks.append({"check":n,"status":"PASS" if o else "FAIL","detail":d})
def errs(s,o): return list(jsonschema.Draft202012Validator(s).iter_errors(o))

std_schema=json.loads((SRC/"rule-test-unit-case_JsonSchema.txt").read_text())
mul_schema=json.loads((SRC/"rule-test-unit-case_multInpComb-JsonSchema.txt").read_text())
std_exec=json.loads((SRC/"rule-test-unit-case_JsonExample.txt").read_text())
mul_exec=json.loads((SRC/"rule-test-unit-case_multInpComb-JsonExample.txt").read_text())
std_info=json.loads((VER/"FIXTURE_STANDARD_INFORMATIONAL_NOT_TESTABLE.json").read_text())
mul_info=json.loads((VER/"FIXTURE_MULTINPCOMB_INFORMATIONAL_NOT_TESTABLE.json").read_text())

for n,s,o in [("standard executable",std_schema,std_exec),("multi executable",mul_schema,mul_exec),
              ("standard informational",std_schema,std_info),("multi informational",mul_schema,mul_info)]:
    e=errs(s,o); ck(n+" schema-valid",not e,"; ".join(x.message for x in e[:3]))

bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["Testability"]="FullyTestable"
ck("no RuleCode + FullyTestable rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_exec); bad["UnitTestRules"][0]["Scenarios"][0]["Testability"]="NotTestable"; bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["SupportLevel"]="NotTestable"
ck("RuleCode + NotTestable rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["AssertionCount"]=1
ck("informational AssertionCount>0 rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["SimulatedDependencyCount"]=1
ck("informational SimulatedDependencyCount>0 rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["BlockingGaps"]=[]
ck("informational empty BlockingGaps rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["AssertionDecisionTrace"]="ASSERT|id=A001|kind=Property|target=.X|page=Primary|class=X|mode=Text|comparator=Is Equals To|value=1|support=Verified"
ck("informational ASSERT trace rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["AssertionDecisionTrace"]="SIM|id=S001|rule=D_X|sig=X|shape=page|method=DefineData|class=X|itemClass=-|params={}|target=.X"
ck("informational SIM trace rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["OmittedClaimCount"]=0
ck("informational OmittedClaimCount=0 rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["InternalChecklist"]["RuleCodeConsistentWithLedger"]=True
ck("informational RuleCodeConsistentWithLedger=true rejected",bool(errs(std_schema,bad)))
bad=copy.deepcopy(std_info); bad["UnitTestRules"][0]["Scenarios"][0]["EvidenceSummary"]["InternalChecklist"]["SchemaSelfCheckPassed"]=False
ck("informational SchemaSelfCheckPassed=false rejected",bool(errs(std_schema,bad)))

partial=copy.deepcopy(std_exec); partial["UnitTestRules"][0]["Scenarios"][0]["Testability"]="PartiallyTestable"; partial["UnitTestRules"][0]["Scenarios"][0]["ReasoningConfidence"]="Low"
ck("PartiallyTestable + RuleCode valid",not errs(std_schema,partial))
partial_no=copy.deepcopy(partial); partial_no["UnitTestRules"][0].pop("RuleCode")
ck("PartiallyTestable without RuleCode rejected",bool(errs(std_schema,partial_no)))

main=(SRC/"Main_Agent_Prompt.txt").read_text()
gen=(SRC/"UnitTestGenerator_Prompt.txt").read_text()
val=(SRC/"Validator_Prompt.txt").read_text()

anchors=[
("Main execution class","EXECUTION_CLASS=NOT_TESTABLE" in main),
("Main pair grouping","count(distinct (SIMULATION_GROUP_KEY, EXECUTION_CLASS))" in main),
("Main NotTestable zero decisions","A final NotTestable Scenario has zero ASSERT and zero SIM decisions" in main),
("Main downstream no RuleCode","Downstream projects NotTestable groups without RuleCode" in main),
("Main source WHEN conditional","In a NOT_TESTABLE WHEN group" in main and "no DecisionInput/DecisionResult ASSERT or SIM record is allowed" in main),
("Generator informational mode","INFORMATIONAL_NOT_TESTABLE" in gen),
("Generator omits RuleCode","entry omits RuleCode completely" in gen),
("Generator zero counts","AssertionCount=0, ExactValueAssertionCount=0, StructuralAssertionCount=0 and SimulatedDependencyCount=0" in gen),
("Generator checklist false","RuleCodeConsistentWithLedger=false" in gen),
("Generator source homogeneity","Every physical group is execution-class homogeneous" in gen),
("Generator source WHEN conditional","In a NOT_TESTABLE WHEN group" in gen),
("Generator informational OK","truthfully represents a non-executable outcome" in gen),
("Validator candidate mode","Candidate mode is **EXECUTABLE** when `RuleCode` is present and **INFORMATIONAL_NOT_TESTABLE** when `RuleCode` is absent" in val),
("Validator no Knowledge for informational","do not include it in the KnowledgeTool phase" in val),
("Validator informational OK","truthfully represents a non-executable NotTestable outcome" in val),
("Validator NotTestable no RuleCode","NotTestable is reserved for the no-RuleCode informational mode" in val),
]
for n,o in anchors: ck(n,o)

for label,needle,text in [
("old SOURCE_NO_ASSERTIONS","A NotTestable source with no assertions produces SOURCE_NO_ASSERTIONS",gen),
("old Generator combined testability OK","A faithful `PartiallyTestable`/`NotTestable` Scenario",gen),
("old Validator combined testability OK","A faithful `PartiallyTestable` or `NotTestable` Scenario",val),
("old Main pairless formula","ScenarioGroup count = count(distinct SIMULATION_GROUP_KEY)",main),
("old Main unit-per-key","create exactly one UnitTestRules entry per distinct SIMULATION_GROUP_KEY",main),
("old Main unconditional WHEN assertions","Each WHEN Scenario has exactly one DECISION_INPUT INPUT",main),
("old Generator unconditional WHEN assertions","Each WHEN Scenario has exactly one DECISION_INPUT INPUT",gen),
]:
    ck(label+" absent",needle not in text)

for n,s in [("standard",std_schema),("multi",mul_schema)]:
    item=s["properties"]["UnitTestRules"]["items"]
    ck(n+" base RuleCode optional",item["required"]==["Name","Scenarios"],repr(item["required"]))
    ck(n+" conditional branch exists",len(item.get("allOf",[]))==1)
    ck(n+" maxItems=1",s["properties"]["UnitTestRules"].get("maxItems")==1)

def dec(inner):
    lines=[]; pos=0; pat=re.compile(r"<p>(.*?)</p>",re.S)
    for m in pat.finditer(inner):
        if inner[pos:m.start()].strip(): return None
        lines.append(html.unescape(m.group(1))); pos=m.end()
    if inner[pos:].strip(): return None
    return "\n".join(lines)

for cfg,prompt in [("UnitTestGenerator.txt","UnitTestGenerator_Prompt.txt"),("JsonValidator_tool.txt","Validator_Prompt.txt")]:
    text=(SRC/cfg).read_text()
    m=re.search(r"<pySystemPrompt>(.*?)</pySystemPrompt>",text,re.S)
    ck(cfg+" embedded prompt equality",m is not None and dec(m.group(1)).rstrip()==(SRC/prompt).read_text().rstrip())
    try: ET.fromstring(text); ok=True; detail=""
    except Exception as e: ok=False; detail=str(e)
    ck(cfg+" XML parses",ok,detail)

failed=[x for x in checks if x["status"]=="FAIL"]
result={"status":"PASS" if not failed else "FAIL","checks_total":len(checks),"checks_passed":len(checks)-len(failed),"checks_failed":len(failed),"checks":checks}
print(json.dumps(result,indent=2,ensure_ascii=False))
sys.exit(1 if failed else 0)
