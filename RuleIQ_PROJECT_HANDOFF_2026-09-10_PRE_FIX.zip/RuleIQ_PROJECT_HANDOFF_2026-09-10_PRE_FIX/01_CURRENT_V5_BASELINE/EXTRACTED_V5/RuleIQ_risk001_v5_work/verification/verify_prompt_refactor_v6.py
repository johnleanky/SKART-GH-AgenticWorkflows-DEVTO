#!/usr/bin/env python3
"""
Independent post-refactor verifier for the three RuleIQ agent prompts.

This script does NOT edit files and does NOT import the apply script.
It checks final-source presence, obsolete-contract absence, ownership,
cardinality, A2A compatibility, lifecycle metadata and report framing.
LLM/source reread is still required before any CHG item is marked VERIFIED.
"""
from pathlib import Path
import hashlib, html, json, re, sys

FILES = ("Main_Agent_Prompt.txt","UnitTestGenerator_Prompt.txt","Validator_Prompt.txt","UnitTestGenerator.txt","JsonValidator_tool.txt","rule-test-unit-case_JsonSchema.txt","rule-test-unit-case_multInpComb-JsonSchema.txt")

def blob_sha(data: bytes):
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()

def check_contains(report, file, text, needle, cid, anchor):
    ok = needle in text
    report.append({"change":cid,"file":file,"check":"presence","anchor":anchor,"status":"PASS" if ok else "FAIL"})
    return ok

def check_absent(report, file, text, needle, cid, anchor):
    ok = needle not in text
    report.append({"change":cid,"file":file,"check":"absence","anchor":anchor,"status":"PASS" if ok else "FAIL"})
    return ok

def decode_html_prompt(inner):
    pat=re.compile(r"\s*<p>(.*?)</p>",re.S)
    pos=0; lines=[]
    while pos < len(inner):
        m=pat.match(inner,pos)
        if not m:
            if inner[pos:].strip():
                raise ValueError("non-paragraph embedded system prompt markup")
            break
        lines.append(html.unescape(m.group(1)))
        pos=m.end()
    return "\n".join(lines)

def extract_one(pattern,text,label):
    ms=list(re.finditer(pattern,text,re.S))
    if len(ms)!=1:
        raise ValueError(f"{label}: expected exactly one match, got {len(ms)}")
    return ms[0].group(1) if ms[0].lastindex else ms[0].group(0)

def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
    t={}
    meta={}
    for fn in FILES:
        p=root/fn
        if not p.is_file():
            raise SystemExit(f"Missing {p}")
        b=p.read_bytes()
        t[fn]=b.decode("utf-8")
        meta[fn]={"blob_sha":blob_sha(b),"bytes":len(b)}

    m=t["Main_Agent_Prompt.txt"]; g=t["UnitTestGenerator_Prompt.txt"]; v=t["Validator_Prompt.txt"]
    gc=t["UnitTestGenerator.txt"]; vc=t["JsonValidator_tool.txt"]
    r=[]

    # Main
    check_contains(r,FILES[0],m,'WriteMemory(pxCaseID=<exact pyID>, Type="ScenarioGroup", RequestsJSON=<JSON string>)',"C-001","§1A batch WriteMemory")
    check_contains(r,FILES[0],m,'Rows are independent',"C-001","§1A independent rows")
    check_contains(r,FILES[0],m,'GEN|pxCaseID=<encoded exact pyID>|RUTType=<encoded immutable original RUTType>',"C-002","§1A GEN header")
    check_contains(r,FILES[0],m,'SG|pyGroup=<encoded group>|pyGUID=<encoded ScenarioGroup Memory GUID>',"C-002","§1A SG row")
    check_contains(r,FILES[0],m,'when at least one expected group has one independently valid `GR status=OK`',"C-003","§1A aggregate")
    check_contains(r,FILES[0],m,'## 15. Generator direct report contract',"C-041","§15 new heading")
    check_contains(r,FILES[0],m,'missing/duplicate/malformed/unknown rows cannot create success and do not invalidate another independently valid expected-group row',"C-045","§15 per-group malformed handling")
    check_contains(r,FILES[0],m,'For each trace **field value only**, Generator encodes source `&` as `&amp;`',"C-046","§13.4.6 field-value-only trace encoding")
    check_contains(r,FILES[0],m,'Structural separators are never entity-encoded',"C-046","§13.4.6 literal structural pipes")
    for needle,cid in [
        ("ScenarioGroupUUIDs","C-002"),
        ("## 15. Generator terminal report contract","C-041"),
        ("sourceUUID","C-041"),
        ("one combined schema-governed candidate","C-042"),
        ("UUID order equals group order","C-043"),
        ("GeneratorRunReport details","C-044"),
        ("Call `WriteMemory` sequentially exactly once per group","C-032"),
    ]:
        check_absent(r,FILES[0],m,needle,cid,"old Main contract removed")

    # Generator
    check_contains(r,FILES[1],g,'It receives exactly one scalar parameter: `question`',"C-004","G1 question")
    check_contains(r,FILES[1],g,'GetMemory(pxCaseID=<GEN pxCaseID>, Type="ScenarioGroup", pyGUID=<exact SG pyGUID>)',"C-006","G2 SG GetMemory")
    check_contains(r,FILES[1],g,'returned `pyGroup=SG.pyGroup`',"C-006","G2 correlation")
    check_contains(r,FILES[1],g,'one raw UnitTestCandidate JSON object with the sole root key `UnitTestRules`',"C-007","G4 candidate per group")
    check_contains(r,FILES[1],g,'Its `UnitTestRules` array contains exactly one entry for that physical group',"C-037","G4 one unit")
    check_contains(r,FILES[1],g,'physical child `pyPageName` as the immediate page that contains the final asserted leaf',"C-009","G6 MA-035")
    check_contains(r,FILES[1],g,'Encode trace **field values only**',"C-008","G7 MA-036")
    check_contains(r,FILES[1],g,'VAL|pxCaseID=<encoded GEN pxCaseID>|RUTType=<encoded immutable GEN RUTType>',"C-010","G8 VAL header")
    check_contains(r,FILES[1],g,'UT|pyGroup=<encoded group>|pyGUID=<encoded current UnitTestCandidate GUID>',"C-010","G8 UT row")
    check_contains(r,FILES[1],g,'UpdateMemory(pxCaseID=<GEN pxCaseID>, Type="UnitTestCandidate", RequestsJSON=<JSON string>)',"C-012","G8 UpdateMemory")
    check_contains(r,FILES[1],g,'There is **no UpdateMemory retry**',"C-012","G8 no retry")
    check_contains(r,FILES[1],g,'the candidate remains `Pending` and is ineligible for downstream selection',"C-051","G8 malformed Validator leaves Pending")
    check_contains(r,FILES[1],g,'Its outer result must contain exact `Success` boolean plus string `ResultsJSON`, `ErrorCode`, `ErrorMessage`',"C-052","G8 exact UpdateMemory result envelope")
    check_contains(r,FILES[1],g,'Budget is per `pyGroup`',"C-011","G8 repair budget")
    check_contains(r,FILES[1],g,'`SEMANTIC_REJECT`: after successful `Failed/SEMANTIC_REJECT` UpdateMemory, stop that group',"C-038","G8 semantic reject")
    check_contains(r,FILES[1],g,'`HUMAN`: after successful `Failed/HUMAN` UpdateMemory, stop that group',"C-039","G8 human")
    check_contains(r,FILES[1],g,'## G9. Direct Generator report',"C-013","G9 GR")
    for needle,cid in [
        ("ScenarioGroupUUIDs","C-004"),
        ("UnitTestCandidateUUID","C-010"),
        ("## G9. Runtime GeneratorRunReport","C-013"),
        ("Appendix C. GeneratorRunReport Structural Schema","C-034"),
        ("Preserve child pyPageName=ASSERT.page","C-009"),
        ("Apply trace encoding once: ampersand -> &amp;, pipe -> &#124;","C-008"),
        ("UUID order equals group order","C-043"),
        ("sourceUUID","C-034"),
    ]:
        check_absent(r,FILES[1],g,needle,cid,"old Generator contract removed")

    # Validator
    check_contains(r,FILES[2],v,'You receive exactly one scalar `question`',"C-014","V1 question")
    check_contains(r,FILES[2],v,'VAL|pxCaseID=<encoded exact case id>|RUTType=<encoded immutable original RUTType>',"C-014","V1 VAL")
    check_contains(r,FILES[2],v,'UT|pyGroup=<encoded group>|pyGUID=<encoded UnitTestCandidate Memory GUID>',"C-014","V1 UT")
    check_contains(r,FILES[2],v,'JsonValidationTool(CaseID=<VAL pxCaseID>, UUID=<exact UT pyGUID>, JsonSchema=<ExpectedJsonSchema>)',"C-015","V3 exact schema address")
    check_contains(r,FILES[2],v,'GetMemory(pxCaseID=<VAL pxCaseID>, Type="UnitTestCandidate", pyGUID=<same exact UT pyGUID>)',"C-015","V3 exact Memory address")
    check_contains(r,FILES[2],v,'returned `pyGroup == UT.pyGroup`',"C-015","V3 group correlation")
    check_contains(r,FILES[2],v,'split the trace on actual LF record separators',"C-016","V5 split order")
    check_contains(r,FILES[2],v,'Derive the expected physical `pyPageName` deterministically',"C-017","V6 MA-035")
    check_contains(r,FILES[2],v,'A faithful PartiallyTestable EXECUTABLE candidate may validate `OK`',"C-035","V4 executable partial testability")
    check_contains(r,FILES[2],v,'INFORMATIONAL_NOT_TESTABLE candidate may also validate `OK`',"C-070","V4 informational NotTestable OK")
    check_contains(r,FILES[2],v,'## V10. Final output lock',"C-036","V10")
    check_contains(r,FILES[2],v,'Return only the compact A2A `VR`/`VI` records',"C-018","V10 output")
    for needle,cid in [
        ("UnitTestCandidateUUID","C-014"),
        ("Return exactly one compact raw ValidatorReport JSON object","C-018"),
        ("## Appendix B. Complete ValidatorReport schema","C-036"),
        ("Mass rebuild always means the same unchanged ScenarioGroups and consumes Generator's existing shared two-repair budget","C-011"),
    ]:
        check_absent(r,FILES[2],v,needle,cid,"old Validator contract removed")

    # UTC schema descriptions must encode only trace field values, never structural separators.
    schema_sentence = "Structural fields remain separated by literal | and trace records by actual LF in the in-memory trace before normal JSON serialization; never entity-encode structural separators."
    old_schema_sentence = "Values must be encoded safely for a JSON string: do not wrap values in unescaped double quotes; encode double quote as &quot;, pipe as &#124;, and newline as &#10;."
    for fn in ("rule-test-unit-case_JsonSchema.txt","rule-test-unit-case_multInpComb-JsonSchema.txt"):
        check_contains(r,fn,t[fn],schema_sentence,"C-054","AssertionDecisionTrace field-value-only schema description")
        check_absent(r,fn,t[fn],old_schema_sentence,"C-054","ambiguous old trace schema description")

    # Ownership
    check_absent(r,FILES[0],m,"`UpdateMemory(pxCaseID","C-005","Main must not own UpdateMemory")
    check_contains(r,FILES[0],m,"Scenario Author never retries UnitTestGenerator, never calls GetMemory/UpdateMemory/Validator","C-005","Main ownership")
    check_contains(r,FILES[2],v,"Validator never repairs or writes/updates Memory","C-018","Validator read-only")
    check_contains(r,FILES[1],g,'`UpdateMemory(pxCaseID,Type,RequestsJSON)`',"C-005","Generator owns UpdateMemory")

    # Common A2A encoding must be identical in all 3 prompts.
    phrase = r"before placing a value in a field, encode backslash `\` as `\\`, literal pipe `|` as `\|`, CR as `\r`, LF as `\n`, TAB as `\t`, empty string as `\0`, and an exact literal hyphen `-` as `\-`"
    for fn in ("Main_Agent_Prompt.txt","UnitTestGenerator_Prompt.txt","Validator_Prompt.txt"):
        check_contains(r,fn,t[fn],phrase,"C-030","canonical A2A escaping")

    # Runtime agent configurations must embed exact final prompts and compatible response styles/tools.
    try:
        gen_inner=extract_one(r"<pySystemPrompt>(.*?)</pySystemPrompt>",gc,"Generator pySystemPrompt")
        val_inner=extract_one(r"<pySystemPrompt>(.*?)</pySystemPrompt>",vc,"Validator pySystemPrompt")
        gen_dec=decode_html_prompt(gen_inner)
        val_dec=decode_html_prompt(val_inner)
        ok=gen_dec.rstrip()==g.rstrip()
        r.append({"change":"C-047/C-050","file":"UnitTestGenerator.txt","check":"embedded_prompt_equals_standalone","anchor":"pySystemPrompt","status":"PASS" if ok else "FAIL"})
        ok=val_dec.rstrip()==v.rstrip()
        r.append({"change":"C-049/C-050","file":"JsonValidator_tool.txt","check":"embedded_prompt_equals_standalone","anchor":"pySystemPrompt","status":"PASS" if ok else "FAIL"})
    except Exception as e:
        r.append({"change":"C-047/C-049/C-050","file":"RUNTIME_CONFIG","check":"embedded_prompt_parse","anchor":str(e),"status":"FAIL"})

    check_contains(r,"UnitTestGenerator.txt",gc,
                   "Return only the exact compact GR line protocol defined by the system prompt.",
                   "C-047","Generator pyResponseStylePrompt")
    check_absent(r,"UnitTestGenerator.txt",gc,
                 "Return exactly one raw GeneratorRunReport JSON object",
                 "C-047","old Generator response style")
    check_contains(r,"JsonValidator_tool.txt",vc,
                   "Return only the exact compact VR/VI line protocol defined by the system prompt.",
                   "C-049","Validator pyResponseStylePrompt")
    check_absent(r,"JsonValidator_tool.txt",vc,
                 "Return exactly one raw JSON object and nothing else.",
                 "C-049","old Validator response style")

    try:
        gtools=extract_one(r'<pzKnowledgeTools REPEATINGTYPE="PageList">(.*?)</pzKnowledgeTools>',gc,"Generator pzKnowledgeTools")
        vtools=extract_one(r'<pzKnowledgeTools REPEATINGTYPE="PageList">(.*?)</pzKnowledgeTools>',vc,"Validator pzKnowledgeTools")
        gps=re.findall(r"<pyPurpose>([^<]+)</pyPurpose>",gtools)
        vps=re.findall(r"<pyPurpose>([^<]+)</pyPurpose>",vtools)
        expected_g={"KnowledgeTool","GetMemory","WriteMemory","UpdateMemory"}
        expected_v={"GetMemory","JsonValidationTool","KnowledgeTool"}
        ok=set(gps)==expected_g and len(gps)==len(expected_g)
        r.append({"change":"C-048/C-050","file":"UnitTestGenerator.txt","check":"configured_knowledge_tools",
                  "anchor":",".join(gps),"status":"PASS" if ok else "FAIL"})
        ok=set(vps)==expected_v and len(vps)==len(expected_v) and "UpdateMemory" not in vps
        r.append({"change":"C-050","file":"JsonValidator_tool.txt","check":"validator_read_only_tool_inventory",
                  "anchor":",".join(vps),"status":"PASS" if ok else "FAIL"})
    except Exception as e:
        r.append({"change":"C-048/C-050","file":"RUNTIME_CONFIG","check":"tool_inventory_parse","anchor":str(e),"status":"FAIL"})

    # Cross-agent tag field orders.
    sender_receiver = [
        ("GEN|pxCaseID=", m, g, "C-002/C-004"),
        ("SG|pyGroup=", m, g, "C-002/C-004"),
        ("VAL|pxCaseID=", g, v, "C-010/C-014"),
        ("UT|pyGroup=", g, v, "C-010/C-014"),
        ("VR|pyGroup=", v, g, "C-018/C-010"),
        ("VI|severity=", v, g, "C-018/C-010"),
        ("GR|pyGroup=", g, m, "C-013/C-002"),
    ]
    for tag,a,b,cid in sender_receiver:
        ok=tag in a and tag in b
        r.append({"change":cid,"file":"CROSS","check":"sender_receiver_tag","anchor":tag,"status":"PASS" if ok else "FAIL"})

    # Lifecycle field ownership.
    for field in ("pyStatusValue","pyRouterKey"):
        ok=field in g
        r.append({"change":"C-019/C-020","file":"UnitTestGenerator_Prompt.txt","check":"lifecycle_field","anchor":field,"status":"PASS" if ok else "FAIL"})

    # Validator and Generator issue/action catalogs must contain the same table row set.
    row_re=re.compile(r"^\|\s*([A-Z0-9_]+)\s*\|\s*([A-Z0-9_, ]+)\s*\|$",re.M)
    gc=set(row_re.findall(g))
    vc=set(row_re.findall(v))
    # limit to action-ish rows by requiring known action prefixes
    action_tokens=("FIX_","REBUILD_","HUMAN_REVIEW","REJECT_SEMANTICS","ADD_","REMOVE_","MOVE_")
    gc={x for x in gc if any(tok in x[1] for tok in action_tokens)}
    vc={x for x in vc if any(tok in x[1] for tok in action_tokens)}
    catalogs_ok=bool(gc) and gc==vc
    r.append({"change":"C-018/C-034","file":"CROSS","check":"issue_action_catalog_equality",
              "anchor":f"generator={len(gc)} validator={len(vc)}",
              "status":"PASS" if catalogs_ok else "FAIL",
              "generator_only":sorted(gc-vc),"validator_only":sorted(vc-gc)})

    failed=[x for x in r if x["status"]!="PASS"]
    result={"overall":"PASS" if not failed else "FAIL","files":meta,
            "checks":r,"failed_count":len(failed)}
    print(json.dumps(result,indent=2))
    return 0 if not failed else 1

if __name__=="__main__":
    raise SystemExit(main())
