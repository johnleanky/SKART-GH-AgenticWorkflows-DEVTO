# JsonExample Alignment Audit v2

**Verdict: VERIFIED_LOCAL**

The standard and MultInpComb examples are now aligned with the refactored one-candidate-per-physical-group architecture and the canonical trace grammar.

## Approved decisions applied

- `UnitTestRules` is hard-limited to exactly one item by `minItems: 1` + `maxItems: 1` in both schemas.
- Validator was not changed because it already explicitly requires exactly one `UnitTestRules` entry after parse and routes a different cardinality to `COUNT_MISMATCH/FIX_COUNTS`.
- The standard JsonExample keeps only `TC_EntityMap_PageDP`; the old second unit was removed as requested.
- The standard `AssertionDecisionTrace` now uses the exact refactored ASSERT/SIM/OMIT field grammar.
- Missing SIM identity facts were added only as explicitly synthetic deterministic reference-fixture facts; they are not represented as recovered historical ScenarioGroup provenance.
- The five old MultInpComb units were split into five one-candidate files. The first remains the canonical `rule-test-unit-case_multInpComb-JsonExample.txt`; four supplemental files preserve the other units.
- Simulated MultInpComb fixture traces now include `itemClass`, encoded DP signature delimiter, and canonical typed JSON params.
- User-facing narratives were rewritten in plain language; technical identifiers remain only in technical evidence fields.
- Standard EvidenceSummary counts are now `25 / 16 / 9`, and `SupportLevel=OmittedClaimsPresent`.

## Verification

- Example/cardinality verifier: **84/84 PASS**.
- Independent architecture verifier: **PASS, 0 failures**.
- Corrected standard example: JSON Schema PASS.
- All five split MultInpComb examples: JSON Schema PASS.
- Old 2-unit standard and old 5-unit MultInpComb examples are rejected by the new cardinality constraint.
- RuleCode payloads for all retained examples are unchanged from their pre-correction units.

## Scope

This is a local verified source package. GitHub remains unchanged. Memory runtime implementation changes C-027, C-028 and C-029 remain EXTERNAL_PENDING.
