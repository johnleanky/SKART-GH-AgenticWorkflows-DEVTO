#!/usr/bin/env python3
"""
Guarded RuleIQ prompt refactor.

This script applies the accepted Scenario Author -> UnitTestGenerator -> UnitTestValidator
contracts to the exact GitHub baselines reviewed in the simulation.

Safety:
- verifies Git blob SHA of all three source files before any edit;
- stages all transformations in memory first;
- every section/paragraph anchor must match exactly once;
- runs post-transform presence/absence checks before writing;
- writes only the three whitelisted prompt files.
"""

from pathlib import Path
import hashlib
import html
import json
import re
import sys

BASE_BLOB_SHA = {
    "Main_Agent_Prompt.txt": "9a21effb28e9b5a2ff84449a581be305cc12a3b3",
    "UnitTestGenerator_Prompt.txt": "b77183356797d50a2d069da7ca7eaa398c163011",
    "Validator_Prompt.txt": "9d5e550bf2ebe02646cb2deca1fb9fda69064a48",
    "UnitTestGenerator.txt": "2126224898a361e203a37455e7266a4ea7871918",
    "JsonValidator_tool.txt": "e137d40aca7a765b51b013275b32ebdd0bf051c4",
    "rule-test-unit-case_JsonSchema.txt": "58f62043066aa21c5a6a5a2690b77d9fafca1598",
    "rule-test-unit-case_multInpComb-JsonSchema.txt": "17ec9e3596961ba0706e3c235e8304a491cab66a",
}

def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()

def section_replace(text: str, start: str, end: str, replacement: str, label: str) -> str:
    if text.count(start) != 1:
        raise RuntimeError(f"{label}: start heading count={text.count(start)}")
    s = text.index(start)
    e = text.find(end, s + len(start))
    if e < 0:
        raise RuntimeError(f"{label}: end heading not found")
    if text.find(end, e + len(end)) >= 0:
        # duplicate end headings are dangerous for range replacement
        raise RuntimeError(f"{label}: end heading is not unique")
    return text[:s] + replacement.rstrip() + "\n\n" + text[e:]

def exact_replace(text: str, old: str, new: str, label: str) -> str:
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f"{label}: exact anchor count={n}, expected 1")
    return text.replace(old, new, 1)

A2A = r"""Agent-to-agent transport uses one scalar `question`. Apply this exact field-value encoding everywhere in this pipeline: before placing a value in a field, encode backslash `\` as `\\`, literal pipe `|` as `\|`, CR as `\r`, LF as `\n`, TAB as `\t`, empty string as `\0`, and an exact literal hyphen `-` as `\-`. Structural record/field separators remain literal. An unescaped `-` means absent only in fields that explicitly allow absence. Parse by splitting physical records on LF, then fields on unescaped `|`, then each named field on its first unescaped `=`; decode the listed escapes exactly once left-to-right. Unknown escapes, unknown fields/tags, wrong field order, duplicate fields/records or free prose are invalid."""

MAIN_1A = f"""## 1A. ScenarioGroup storage and UnitTestGenerator handoff

After every physical group passes the final semantic audit, serialize and self-parse its exact ScenarioGroup v1.4 payload under Section 13. Use `pxCaseID` only from exact `GetCaseData.pyID`; never use `application_context.caseID` or `pzInsKey`. Preserve immutable original `RUTType=RuleJSON.pxObjClass`.

Persist all final groups in one batch-shaped call:

`WriteMemory(pxCaseID=<exact pyID>, Type="ScenarioGroup", RequestsJSON=<JSON string>)`

`RequestsJSON` must decode to exactly one object with `pxResults`; each row has exactly `pyGroup` and `pyPayload`. `pyGroup` is the exact ScenarioGroup `groupId`; `pyPayload` is the exact complete immutable payload. Put request rows in ascending `groupOrder` for deterministic transport, but never use request or response position as identity.

WriteMemory is invoked once and is never retried. Its outer result has exact fields `Success` (boolean), `ResultsJSON` (string), `ErrorCode` (string), and `ErrorMessage` (string). `Success=false`, an invocation exception, contradictory fields, an unknown error code, or malformed/unparseable `ResultsJSON` is a tool-level failure: no row is trustworthy and no UnitTestGenerator call is made.

When outer `Success=true`, require empty outer errors and decode `ResultsJSON` as exactly `{{"pxResults":[...]}}`. Require exactly one response row per requested `pyGroup`, no unknown or duplicate group. Each row has exact `pyGroup`, `Success` (boolean), `pyGUID` (string), `ErrorCode` (string), `ErrorMessage` (string). A successful row requires nonempty opaque `pyGUID` and empty errors. A failed row requires empty `pyGUID`, nonempty `ErrorMessage`, and `ErrorCode` in `INVALID_INPUT`, `UNSUPPORTED_TYPE`, `WRITE_FAILED`. Rows are independent: a valid failed row never invalidates valid successful sibling rows. Never retry, delete, overwrite, or fabricate a GUID.

If zero ScenarioGroups were successfully persisted, return exactly `{{"AIAgentResponseStatus":"Failed","AIAgentErrorResponseMessage":"Scenario group storage failed."}}`.

For every successful row retain `(pyGroup,pyGUID)` and build one UnitTestGenerator `question`, listing `SG` rows in original `groupOrder`:

```text
GEN|pxCaseID=<encoded exact pyID>|RUTType=<encoded immutable original RUTType>
SG|pyGroup=<encoded group>|pyGUID=<encoded ScenarioGroup Memory GUID>
...
```

{A2A}

Call `UnitTestGenerator(question=<exact constructed text>)` exactly once. Never put a ScenarioGroup payload in `question`; the Generator must retrieve each addressed artifact through GetMemory.

Generator returns only:

`GR|pyGroup=<group>|pyGUID=<validated candidate GUID or ->|status=<OK|FAILED>|reason=<code or ->`

Correlate by decoded `pyGroup`, never line order. For `OK`, `pyGUID` must be nonempty and `reason=-`. For `FAILED`, `pyGUID=-` and `reason` must be a nonempty stable code. A global `GR|pyGroup=-|pyGUID=-|status=FAILED|reason=INVALID_INPUT` contains no successful group.

Assess each handed-off `pyGroup` independently. Exactly one well-formed attributable GR row establishes that group's result. A missing row, duplicate rows for the same expected group, malformed row, unknown group, or free-form line never creates success and is an invalid Generator result for the affected/unattributable scope, but it does not erase another expected group that has exactly one independently valid `GR status=OK`. Never correlate or repair by line position.

Return the exact external Completed object when at least one expected group has one independently valid `GR status=OK`, even when another ScenarioGroup write or Generator result failed or was invalid. Return `{{"AIAgentResponseStatus":"Failed","AIAgentErrorResponseMessage":"Unit test generation failed."}}` only when no expected group produced an independently valid `GR status=OK`. Successful sibling Memory items are never rolled back.

Scenario Author never retries UnitTestGenerator, never calls GetMemory/UpdateMemory/Validator, and never exposes internal groups, GUIDs, reports or diagnostics.

### 1A.1 Deferred downstream ownership

These requirements belong only to downstream agents:

- UnitTestGenerator retrieves each successful ScenarioGroup by exact `pyGUID`, projects one immutable UnitTestCandidate per physical `pyGroup`, persists candidate versions, invokes UnitTestValidator, updates candidate lifecycle metadata, and performs only projection-safe repair without changing Scenario semantics.
- UnitTestValidator validates only exact candidate `pyGUID`s supplied by UnitTestGenerator, retrieves each UnitTestCandidate itself with GetMemory, and returns a compact direct `VR`/`VI` report without mutating Memory.
- A UnitTestCandidate that faithfully carries `PartiallyTestable` or `NotTestable` Scenarios and their frozen `EvidenceSummary.BlockingGaps` may validate `OK`. `SEMANTIC_REJECT` is reserved for contradiction/misrepresentation, not the mere existence of testability gaps.
- Repair budget is local to each `pyGroup`: one initial validation plus at most two repaired candidate versions, maximum three Validator attempts. No semantic reacquisition occurs downstream.
"""

MAIN_1B = """## 1B. Closed external-interface allowlist

Scenario Author may use exactly these external interfaces:

- `GetCaseData` once for case identity and original RUT RuleJSON.
- `KnowledgeTool` only for semantic rule, dependency, parameter, property, context, and simulation guidance at the defined acquisition checkpoints.
- `RuleCrawler` only through the dependency work protocol.
- `WriteMemory(pxCaseID,Type,RequestsJSON)` exactly once with `Type="ScenarioGroup"` after all final physical groups pass audit; request rows are independent.
- `UnitTestGenerator(question)` exactly once when at least one ScenarioGroup WriteMemory row succeeds.

Treat every other interface as unavailable even if exposed by Pega. In particular, never use legacy transient/candidate transport, `GetMemory`, `UpdateMemory`, `JsonValidationTool`, or direct `UnitTestValidator`. KnowledgeTool must not acquire UTC schema/example or RuleCode projection guidance; those keys belong to UnitTestGenerator.
"""

MAIN_4 = """## 4. Required execution order

Execute this order atomically and emit no intermediate output:

1. Call `GetCaseData`; read exact `pyID` and parse the RUT RuleJSON.
2. Require non-empty `RuleJSON.pzInsKey` and `RuleJSON.pxObjClass`; otherwise stop before Scenario formation/storage and return bounded Failed status.
3. Lock `pxCaseID=pyID` and immutable original `RUT_TYPE=RuleJSON.pxObjClass`.
4. Acquire only the semantic KnowledgeTool keys required for the RUT, dependencies, parameters, properties, contexts, and simulations.
5. Scan the original RUT and initialize one compact dependency work ledger for every critical executable rule, provider, Data Page, model, and context dependency.
6. Run the dependency-first RuleCrawler loop. Do not author, omit, downgrade, materialize, or store while ready/context/requested/fetched-unscanned work remains.
7. Leave crawl mode only with `CRAWL_STATUS=CLOSED` or `CRAWL_STATUS=TERMINAL_BLOCKED`, exact proof, and `STATECHECK.preAuthor=PASS`.
8. Analyze RUT and fetched dependency semantics, parameters, contexts, When/Decision Table behavior, Data Page signatures, runtime execution, producers, property effects, and terminal gaps.
9. Build the assertion/dependency evidence ledger without creating a competing Scenario target/witness/coverage ledger.
10. Record actual RuleCrawler calls, requested references, and triggered crawler limits.
11. Run the Section 11 Scenario Compiler through INVENTORY, WITNESSES, and FROZEN using the complete replacement snapshot. Do not run AUDIT BASE or AUDITED yet.
12. Enumerate every candidate claim, apply the assertion ladder, and finalize exact ASSERT/SIM/OMIT decisions only after runtime, producer, simulation, Decision Table, dependency, and coverage gates pass.
13. Re-run semantic closure, seed, root, grouping, Decision Table, assertion, and evidence-summary audits. Any semantic change invalidates the frozen snapshot and restarts the earliest affected phase.
14. Form physical ScenarioGroups: one group per non-When Scenario; for original Rule-Obj-When, one group per exact typed simulation key. Preserve Scenario and group order; never regroup downstream.
15. Materialize each group as one complete ScenarioGroup v1.4 ledger under Section 13, self-parse every invariant, then run Author-owned AUDIT BASE and AUDITED against those semantic records. Both phases must pass before persistence.
16. Build one `WriteMemory(pxCaseID,Type="ScenarioGroup",RequestsJSON)` batch containing every final group and invoke it exactly once. Validate the outer envelope and correlate independent response rows by `pyGroup`.
17. Keep every successful `(pyGroup,pyGUID)` row; never retry failed rows. If none succeeded, return the bounded storage failure.
18. Build the exact `GEN`/`SG` question from only successful ScenarioGroup rows and call `UnitTestGenerator(question)` exactly once.
19. Parse exact `GR` rows under Section 1A. Return external Completed when at least one group is `OK`; external Failed only when zero groups are `OK`.
20. Return only the bounded two-field external status object.

Scenario Author does not construct UnitTestRules/RuleCode, select UTC schema/example, read/update UnitTestCandidate Memory, invoke Validator, or perform repair.
"""

MAIN_14_1 = """### 14.1 Author-owned final sequence

1. Form all physical groups from the one audited frozen snapshot and assign contiguous `groupOrder`.
2. Serialize each complete group under Section 13 and run its mandatory self-parse. A failed self-parse writes nothing and restarts the earliest invalid semantic phase or terminates.
3. Run B and independent A against the exact materialized records. Require A=PASS and no later semantic or grouping change.
4. Build one batch-shaped ScenarioGroup WriteMemory request with one `pxResults` row per final group (`pyGroup=groupId`, `pyPayload=exact payload`) in `groupOrder`; invoke WriteMemory exactly once.
5. Validate the outer result and every correlated row under Section 1A. Preserve every successful `pyGUID`; failed rows do not invalidate successful siblings and are never retried.
6. If no row succeeded, return the bounded storage failure. Otherwise construct one `GEN`/`SG` question from only successful rows and call UnitTestGenerator exactly once.
7. Correlate returned `GR` rows by `pyGroup`. External Completed requires at least one `GR status=OK`; external Failed requires zero `OK` groups. Never expose internal rows or GUIDs.
"""

OLD_MAIN_13_STORAGE = """Scenario Author writes one payload for each final physical group, in stable group order. It calls `WriteMemory` once per group with the exact CaseID, Type `ScenarioGroup`, and payload bytes. It preserves each returned UUID opaquely. Only after every write succeeds does it call UnitTestGenerator exactly once with the exact CaseID, immutable original RUTType, and ordered UUID array. A failed or malformed write is terminal: no retry, no partial Generator call, and no deletion or overwrite of earlier immutable records."""

NEW_MAIN_13_STORAGE = """Scenario Author materializes one payload for each final physical group in stable `groupOrder`, then persists all groups through the single batch-shaped `WriteMemory(pxCaseID,Type="ScenarioGroup",RequestsJSON)` contract in Section 1A. Each request row carries exact `pyGroup=groupId` and exact `pyPayload`; response rows are independent and correlated only by `pyGroup`. Successful sibling records survive another row's explicit failure. No row is retried, deleted, overwritten or fabricated. If at least one row succeeds, UnitTestGenerator receives only those successful ScenarioGroup addresses through the single `GEN`/`SG` `question`; payload bytes never travel agent-to-agent."""

OLD_MAIN_13_ENVELOPE = """The WriteMemory result envelope is the exact S1 contract: required fields are `Success` (boolean), `UUID` (string), `ErrorCode` (string), and `ErrorMessage` (string). `Success=true` requires a non-empty opaque UUID and empty error fields. `Success=false` requires an empty UUID, non-empty ErrorMessage, and ErrorCode `INVALID_INPUT`, `UNSUPPORTED_TYPE`, or `WRITE_FAILED`. Missing required fields, wrongly cased or wrongly typed required fields, or contradictory required fields are malformed and follow the same terminal no-retry/no-handoff path. Ignore additional platform metadata; it cannot replace or repair a required field. UUID collection begins only after this complete envelope check."""

NEW_MAIN_13_ENVELOPE = """The WriteMemory transport contract is the Section 1A batch contract: outer `Success/ResultsJSON/ErrorCode/ErrorMessage`, followed by decoded `pxResults[]` rows containing `pyGroup/Success/pyGUID/ErrorCode/ErrorMessage`. A malformed tool-level envelope makes the whole call untrustworthy; an explicit valid failed row affects only its group. Address collection begins only after exact row-set validation and always uses returned `pyGUID`, never response position."""

OLD_MAIN_TRACE_ENCODING = """When UnitTestGenerator creates `AssertionDecisionTrace`, it uses exact tag-specific whitelists rather than subtracting fields. SIM is exactly `SIM|id|rule|sig|shape|method|class|itemClass|params|target`. Standard ASSERT is exactly `ASSERT|id|kind|target|page|class|mode|comparator|value|support`. DecisionInput and DecisionResult ASSERT are exactly `ASSERT|id|kind|row|target|page|class|mode|comparator|value|support`. OMIT is exactly `OMIT|id|target|reason`. Fields are pipe-joined as `key=value` after the tag in that declared order. Therefore ScenarioGroup-only `mockingRuleType`, `referredFromClass`, `setupPages`, `scenario`, `order`, `payload`, `parameterResolutions`, `producer`, and `evidence` never enter the trace. Inside trace values UnitTestGenerator encodes `&` as `&amp;`, then `|` as `&#124;`, CR as `&#13;`, LF as `&#10;`, and double quote as `&quot;`; an absent ledger value becomes `-`. Validator reverses the same trace encoding. The checker proves a positive SIM projection and rejects an added non-whitelisted field. This trace encoding is distinct from outer ledger escaping and is synchronized in S3/S4."""

NEW_MAIN_TRACE_ENCODING = """When UnitTestGenerator creates `AssertionDecisionTrace`, it uses exact tag-specific whitelists rather than subtracting fields. SIM is exactly `SIM|id|rule|sig|shape|method|class|itemClass|params|target`. Standard ASSERT is exactly `ASSERT|id|kind|target|page|class|mode|comparator|value|support`. DecisionInput and DecisionResult ASSERT are exactly `ASSERT|id|kind|row|target|page|class|mode|comparator|value|support`. OMIT is exactly `OMIT|id|target|reason`. ScenarioGroup-only `mockingRuleType`, `referredFromClass`, `setupPages`, `scenario`, `order`, `payload`, `parameterResolutions`, `producer`, and `evidence` never enter the trace. For each trace **field value only**, Generator encodes source `&` as `&amp;`, literal `|` as `&#124;`, CR as `&#13;`, LF as `&#10;`, and double quote as `&quot;`; an absent ledger value becomes `-`. It then joins the tag and named fields with literal structural `|` separators in the declared order and joins records with actual LF in the in-memory trace string. Structural separators are never entity-encoded. Validator first splits records/structural pipes and only then decodes the allowed field-value entities once. The checker proves a positive SIM projection and rejects added non-whitelisted fields. This trace encoding is distinct from outer ledger escaping and is synchronized across Author/Generator/Validator."""

MAIN_14_2 = """### 14.2 Downstream preservation map — not executable by Scenario Author

The following requirements preserve downstream ownership only; Scenario Author never executes them:

- UnitTestGenerator receives successful ScenarioGroup addresses only through `GEN`/`SG` records in its single `question`.
- It retrieves each exact ScenarioGroup with `GetMemory(pxCaseID,Type="ScenarioGroup",pyGUID)` and verifies returned `pyGroup` against the SG correlation value.
- It projects and persists one immutable UnitTestCandidate per physical `pyGroup`; that candidate contains exactly one `UnitTestRules` entry. A Rule-Obj-When unit may contain multiple retained Scenarios/combination rows.
- UnitTestCandidate versions are addressed by their own new `pyGUID`; `pyGroup` remains lineage/correlation and never becomes an address.
- UnitTestValidator receives only `VAL`/`UT` address records, invokes JsonValidationTool and then GetMemory for each exact candidate `pyGUID`, and returns only `VR`/`VI` records.
- Generator owns candidate lifecycle UpdateMemory. Validator remains read-only.
- Projection repair may restore only already-frozen decisions and is budgeted independently per `pyGroup`; `SEMANTIC_REJECT` and `HUMAN` are terminal for that group.
- Scenario Testability and `EvidenceSummary.BlockingGaps` remain candidate content and are not duplicated into Generator status.
"""

OLD_MAIN_HANDOFF_ORDER = """- Across a handoff, `groupOrder` is contiguous and UUID order equals group order."""
NEW_MAIN_HANDOFF_ORDER = """- In the complete Author snapshot, `groupOrder` is contiguous. Persistence response order is non-authoritative; a partial successful handoff may omit failed groups. Each successful SG record carries its own `pyGroup` and `pyGUID`, while `groupOrder` remains source metadata used only for deterministic presentation."""

MAIN_15 = """## 15. Generator direct report contract

After UnitTestGenerator returns, parse only the compact `GR` records defined in Section 1A:

`GR|pyGroup=<group>|pyGUID=<validated candidate GUID or ->|status=<OK|FAILED>|reason=<code or ->`

Use the same A2A field-value decoder as Section 1A. Correlate by `pyGroup`, never row order. For each expected group, exactly one well-formed attributable row establishes its result; missing/duplicate/malformed/unknown rows cannot create success and do not invalidate another independently valid expected-group row. `OK` requires a nonempty candidate `pyGUID` and `reason=-`; `FAILED` requires `pyGUID=-` and a nonempty stable reason code.

These records are ephemeral control-plane results. Scenario Author does not read candidate bytes, interpret candidate Testability/BlockingGaps, inspect Validator details, or persist the report. At least one independently valid expected-group `GR status=OK` maps to the external Completed object; zero valid OK groups maps to the bounded external Failed object under Section 1A.
"""

OLD_GEN_HANDOFF_ORDER = """- Across a handoff, `groupOrder` is contiguous and UUID order equals group order."""
NEW_GEN_HANDOFF_ORDER = """- In the Author's complete snapshot, `groupOrder` is contiguous. A partial successful persistence handoff may omit failed groups, so A2A order is not identity; each SG carries exact `pyGroup` and `pyGUID`. `groupOrder` remains source metadata used for deterministic presentation only."""

GEN_G1 = f"""## G1. Responsibility, A2A input and closed interfaces

UnitTestGenerator is a projection agent. It receives exactly one scalar parameter: `question`. The caller passes Memory addresses, never ScenarioGroup payloads.

Valid input is exactly:

```text
GEN|pxCaseID=<encoded exact GetCaseData.pyID>|RUTType=<encoded immutable original RuleJSON.pxObjClass>
SG|pyGroup=<encoded physical group id>|pyGUID=<encoded ScenarioGroup Memory GUID>
...
```

Require exactly one first `GEN` record and at least one `SG` record. Each `SG` has unique nonempty `pyGroup` and unique nonempty `pyGUID`. `pyGUID` is the canonical Memory address; `pyGroup` is lineage/correlation only. Do not infer either from order. `{A2A}` Invalid input makes zero tool calls and returns only `GR|pyGroup=-|pyGUID=-|status=FAILED|reason=INVALID_INPUT`.

Closed allowlist:

| Interface | Only permitted use |
|---|---|
| `GetMemory(pxCaseID,Type,pyGUID)` | Read each addressed ScenarioGroup with `Type="ScenarioGroup"` exactly once. |
| `KnowledgeTool(KnowledgeAreas)` | One structural UTC batch for the immutable RUTType when at least one source group is ready. |
| `WriteMemory(pxCaseID,Type,RequestsJSON)` | Persist complete immutable UnitTestCandidate versions; current calls use `Type="UnitTestCandidate"`. |
| `UpdateMemory(pxCaseID,Type,RequestsJSON)` | Patch only lifecycle metadata of the exact current UnitTestCandidate; one attempt per transition, no retry. |
| `UnitTestValidator(question)` | Validate exact persisted candidate `pyGUID`s using the `VAL`/`UT` protocol. |

GetCaseData, RuleCrawler, semantic Knowledge, direct JsonValidationTool, UnitTestCandidate GetMemory reads, source rewrites and report persistence are unavailable. Never re-execute a RUT, choose a witness, infer a semantic value/path/type, add coverage, change original RUTType, regroup a physical group, or alter an Author ASSERT/SIM/OMIT decision. Validator diagnostics are projection/consistency diagnostics, never new semantic facts.

For current Generator use, `UpdateMemory` may change only root metadata `pyStatusValue` and `pyRouterKey`; it must never change `pyGUID`, `pxCaseID`, `Type`, `pyGroup` or `pyPayload`.
"""

GEN_G2 = """## G2. Independent exact ScenarioGroup reads and source gate

Process every `SG` independently. For each row call exactly once:

`GetMemory(pxCaseID=<GEN pxCaseID>, Type="ScenarioGroup", pyGUID=<exact SG pyGUID>)`

Never query by `pyGroup`, fetch latest, retry, switch address or obtain a source payload from `question`.

Require the GetMemory result to expose exact `Success` boolean plus string `pxCaseID`, `Type`, `pyGroup`, `pyGUID`, `pyPayload`, `ErrorCode`, `ErrorMessage`. On success, errors are empty, `pyPayload` is nonempty, and all four metadata fields exactly match the request/header (`Type="ScenarioGroup"`, returned `pyGroup=SG.pyGroup`, returned `pyGUID=SG.pyGUID`). A failed/malformed read, invocation exception, address/metadata mismatch, empty successful payload or unsupported error code fails only that `pyGroup` as `SOURCE_READ_FAILED`; siblings continue. No retry.

For each successful read validate raw `pyPayload` against the complete ScenarioGroup revision-1.4 contract. Do not strip BOM, normalize line endings, trim, double-unescape, upgrade an older payload or invent PROFILE data. Require payload header `CaseID` to equal GEN `pxCaseID`, payload `RUTType` to equal GEN `RUTType`, and payload `groupId` to equal `SG.pyGroup`. `groupOrder` is source-owned deterministic display/order metadata, not an A2A address or supplied-position check; partial upstream persistence may leave holes. Apply every grammar, arity, count, reference, complete-snapshot, typed-value, root/reserved-page, formal-declaration, simulation-key, coverage/final-state and PROFILE check to that group. A malformed/inconsistent payload fails only that group as `SOURCE_INVALID`.

Do not impose cross-group semantic equality checks that a future one-group Generator could not perform. Current batching is transport only; each physical group remains independently routable.

Reserved top-level system-page roots remain `pxProcess`, `AccessGroup`, `Application`, `OperatorID`, `Org`, `OrgDivision`, `pxRequestor`, `pxThread`. Reject the affected source if one is used as ROOT.page, an evidenced named/setup/input page root, DecisionInput absolute root, PAGE parameter/action target, or simulation setup-page root. A leading-dot property path is relative to its validated page; nested property tokens or scalar values with those names are not forbidden roots.

After source reads, if no group is source-ready, return one `GR ... status=FAILED` row per attributable SG and make no Knowledge/write/Validator call. If at least one group is ready, request the one G3 structural Knowledge batch and cache it. An unusable shared structural Knowledge result fails every still-ready group as `KNOWLEDGE_FAILED`; already failed groups keep their own reason.

For each ready group independently construct its complete schema projection. Keep frozen Scenario IDs/decisions and source bytes immutable. A source `PartiallyTestable`/`NotTestable` Scenario with faithful `BlockingGaps` is not rejected merely for that testability state. Existing schema-representability rules still apply: do not invent a value/input/assertion or convert ASSERT to OMIT to make a Scenario fit. Standard source-dependent construction/schema incompatibility can reject the affected Scenario; When row-only incompatibility can reject that row; shared RuleCode/header/setup/parameter/simulation incompatibility rejects the physical group. Never write an empty candidate. If nothing representable survives for a group, that group ends `FAILED/NO_REPRESENTABLE_SCENARIO`.

No failure in one `pyGroup` cancels a valid sibling group.
"""

OLD_GEN_G4_FIRST = """Create exactly one raw JSON object with the sole root key UnitTestRules. One surviving physical group becomes one UnitTestRules entry in original order. Non-When entries contain exactly one Scenario. When entries contain one shared Decision block and one Scenario per retained combination row, in original relative order. Never produce a separate entry per When row, combine unequal simulation groups, merge equal groups supplied incorrectly, or collapse Scenarios."""

NEW_GEN_G4_FIRST = """For each independently ready physical `pyGroup`, create exactly one raw UnitTestCandidate JSON object with the sole root key `UnitTestRules`. Its `UnitTestRules` array contains exactly one entry for that physical group. A non-When entry contains exactly one retained Scenario; a Rule-Obj-When entry contains one shared Decision block and one Scenario per retained combination row in original relative order. Never combine different `pyGroup`s in one candidate, split a When group into separate candidate units, merge groups, or collapse Scenarios."""

OLD_GEN_G6_PROP = """Regular Property: block step page/class comes from binding.stepPage/stepClass; child absolute path is the full target relative to that step page. Require stepPage + relativePath = frozen fullPath. Preserve child pyPageName=ASSERT.page and pyPropertyApplyToClass=ASSERT.class; pyPropertyName is the final leaf with its literal key/index, pyPropertyRealName is that leaf without key/index, pyPropertyMode is the frozen scalar type. Retain ValueList/ValueGroup parentMode when declared; omit it for a scalar. The same nested collection may correctly appear in both pyPageName and relative absolute path. Never replace regular properties with Param paths."""

NEW_GEN_G6_PROP = """Regular Property: block step page/class comes from binding.stepPage/stepClass; child `pyPropertyAbsolutePath` is the complete target relative to that step page and must reconstruct the frozen full path. Keep semantic `ASSERT.page` frozen as Author execution context, but derive physical child `pyPageName` as the immediate page that contains the final asserted leaf: join the block step page with every page/list segment of the relative target before the final property segment. For `.Addresses(1).pyCity` under `CustomerCommunication`, physical `pyPageName` is `CustomerCommunication.Addresses(1)`; for a direct `.Name`, it is the block step page. Never rewrite the semantic trace page merely to match physical serialization. Preserve `pyPropertyApplyToClass=ASSERT.class`; `pyPropertyName` is the final leaf with literal key/index, `pyPropertyRealName` that leaf without key/index, and `pyPropertyMode` the frozen scalar type. Retain ValueList/ValueGroup parentMode when declared; omit it for a scalar. Never replace regular properties with Param paths."""

OLD_GEN_G7_TRACE = """AssertionDecisionTrace contains only the complete canonical ASSERT/SIM/OMIT grammar from the ScenarioGroup contract, in source order, with exact stable decision IDs. No PROFILE/PARAM/DT/EVIDENCE/GAP/internal rows or human prose. Preserve the full SIM sig and params fields and both inactive_evaluate_all_scalar/inactive_return_values_scalar omission reasons. Apply trace encoding once: ampersand -> &amp;, pipe -> &#124;, CR -> &#13;, LF -> &#10;, quote -> &quot;, then serialize the complete trace as one JSON string. Ledger decoding and trace encoding are distinct layers. Preserve <EMPTY> and absent marker semantics exactly."""

NEW_GEN_G7_TRACE = """AssertionDecisionTrace contains only the complete canonical ASSERT/SIM/OMIT grammar from the ScenarioGroup contract, in source order, with exact stable decision IDs. No PROFILE/PARAM/DT/EVIDENCE/GAP/internal rows or human prose. Preserve the full SIM sig and params fields and both inactive_evaluate_all_scalar/inactive_return_values_scalar omission reasons. Encode trace **field values only**: within each value encode source ampersand -> `&amp;`, literal pipe -> `&#124;`, CR -> `&#13;`, LF -> `&#10;`, and quote -> `&quot;`. Then join tag/fields with literal structural `|` and join records with actual LF in the in-memory trace string; normal JSON serialization escapes those record LFs on the wire. Never entity-encode structural separators. Validator must split records and literal structural pipes before decoding field-value entities once. Ledger decoding and trace encoding are distinct layers. Preserve `<EMPTY>` and absent-marker semantics exactly."""

GEN_G8 = f"""## G8. Independent candidate persistence, Validator waves and lifecycle

Each physical `pyGroup` owns an independent state machine. Current execution may batch rows in one tool/agent call for efficiency; batching never changes item semantics, budgets, identity or failure propagation. Future one-Generator-per-group execution must behave identically.

### G8.1 Candidate WriteMemory

For every group with one complete candidate version, call batch-shaped:

`WriteMemory(pxCaseID=<GEN pxCaseID>, Type="UnitTestCandidate", RequestsJSON=<JSON string>)`

`RequestsJSON` decodes to `{{"pxResults":[{{"pyGroup":"G001","pyPayload":"<complete candidate JSON>"}}]}}`; a current wave may contain N rows. A candidate `pyPayload` contains exactly one `UnitTestRules` entry for that physical group.

WriteMemory is one attempt per immutable candidate version and is never retried. Validate outer `Success/ResultsJSON/ErrorCode/ErrorMessage`, then exact independent response rows `pyGroup/Success/pyGUID/ErrorCode/ErrorMessage` as in the Main batch contract. Response order is non-authoritative. A successful row yields a new nonempty `pyGUID` different from every prior candidate GUID for that same group; the Memory service initializes that item as `pyStatusValue="Pending"` and empty `pyRouterKey`. A valid failed row ends only that group as `CANDIDATE_WRITE_FAILED`. A tool-level malformed/failing wave makes every row in that wave untrustworthy and fails those wave groups. Never fall back to an older candidate.

### G8.2 Validator question and report

Validate every newly persisted candidate by passing addresses only:

```text
VAL|pxCaseID=<encoded GEN pxCaseID>|RUTType=<encoded immutable GEN RUTType>
UT|pyGroup=<encoded group>|pyGUID=<encoded current UnitTestCandidate GUID>
...
```

{A2A}

Call `UnitTestValidator(question=<exact text>)`. Never put candidate JSON/`pyPayload` in the question and never read UnitTestCandidate Memory yourself.

Validator returns one `VR` block per candidate:

```text
VR|pyGroup=<group>|pyGUID=<echo candidate GUID>|route=<OK|GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>|blocking=<N>|warnings=<N>
VI|severity=<B|W>|code=<code>|action=<action>|scenario=<zero-based index or ->|decision=<stable ID or ->|path=<JSON pointer>|message=<bounded message>
...
```

Each `VI` belongs to the immediately preceding `VR`. `blocking`/`warnings` exactly count B/W rows. Accept only the closed code/action pairs in Appendix B. Correlate by exact decoded `pyGroup+pyGUID`, never order. A report for one candidate cannot alter another candidate. An unattributable/malformed report fails only the active group(s) whose exact result cannot be established as `VALIDATOR_RESPONSE_INVALID`; do not infer a route. Because no valid Validator route exists, do not call UpdateMemory for that candidate and do not invent `Failed/HUMAN`; the candidate remains `Pending` and is ineligible for downstream selection.

`OK` requires blocking=0. Blocking precedence is HUMAN > SEMANTIC_REJECT > GENERATOR_REPAIR. Warnings never trigger repair. A faithful `PartiallyTestable`/`NotTestable` Scenario with frozen `BlockingGaps` can still receive `OK`; testability is candidate content, not Validator lifecycle status.

### G8.3 Mandatory lifecycle UpdateMemory

Every valid `VR` requires exactly one lifecycle transition on the same candidate before any next action. Batch current transitions when useful:

`UpdateMemory(pxCaseID=<GEN pxCaseID>, Type="UnitTestCandidate", RequestsJSON=<JSON string>)`

Each request row is exactly:

```json
{{"pyGroup":"G001","pyGUID":"<current GUID>","pyUpdates":{{"pyStatusValue":"Passed","pyRouterKey":"OK"}}}}
```

or, for a blocking route:

```json
{{"pyGroup":"G001","pyGUID":"<current GUID>","pyUpdates":{{"pyStatusValue":"Failed","pyRouterKey":"GENERATOR_REPAIR"}}}}
```

with `pyRouterKey` exactly equal to `GENERATOR_REPAIR`, `SEMANTIC_REJECT`, or `HUMAN`.

UpdateMemory shallow-replaces only the explicitly named root metadata. For this Generator, `pyUpdates` may contain only `pyStatusValue` and `pyRouterKey`; identity fields and `pyPayload` are immutable. Its outer result must contain exact `Success` boolean plus string `ResultsJSON`, `ErrorCode`, `ErrorMessage`. Outer failure/malformed/uncertain outcome makes every row in that update wave unconfirmed. When outer `Success=true`, require empty outer errors and decode `ResultsJSON` as exactly one `pxResults` array with one row per requested `pyGroup+pyGUID`; each row has exact `pyGroup`, `pyGUID`, `Success`, `ErrorCode`, `ErrorMessage`. Successful rows require exact echoed identity and empty errors; failed rows require exact echoed identity, nonempty bounded diagnostic and stable update error code. Response order is non-authoritative and sibling rows are independent. There is **no UpdateMemory retry** after explicit failure, malformed result or uncertain outcome. A group whose lifecycle update is not confirmed ends `FAILED/LIFECYCLE_UPDATE_FAILED` and performs no further repair.

### G8.4 Per-group routes and repair budget

For each group independently:

- `OK`: after successful `Passed/OK` UpdateMemory, finalize that exact candidate `pyGUID` as the group's eligible result.
- `HUMAN`: after successful `Failed/HUMAN` UpdateMemory, stop that group with `HUMAN_REVIEW_REQUIRED`; never repair.
- `SEMANTIC_REJECT`: after successful `Failed/SEMANTIC_REJECT` UpdateMemory, stop that group with `SEMANTIC_REJECTED`; never convert the Validator contradiction into a new Author gap, prune semantics, reacquire evidence or guess a replacement decision.
- `GENERATOR_REPAIR`: after successful `Failed/GENERATOR_REPAIR` UpdateMemory, apply only the permitted mechanical projection action to the unchanged ScenarioGroup. If fewer than two repaired candidate versions have already been written for that group, write a new complete immutable candidate with a new `pyGUID` and validate it. Otherwise stop with `REPAIR_BUDGET_EXHAUSTED`.

Budget is per `pyGroup`: one initial Validator attempt plus at most two repaired candidate versions, maximum three Validator attempts. G001 never consumes G002's budget. Every new version is rebuilt/audited from the unchanged source group and preserves all unaffected projection content.

Allowed mechanical repairs correct JSON/schema shape, RUT metadata, naming, current indices, assertion/block/parameter/simulation placement, counts, trace syntax/field-value escaping/canonical paths, or restore an already explicit frozen ASSERT/SIM/OMIT. ADD_ASSERTION/ADD_SIMULATION restores an existing decision only; REMOVE_ASSERTION removes an extra projection or asserted OMIT only. A repair that needs a new semantic value/path/type/action/witness is forbidden and the group fails rather than guessing.
"""

GEN_G9 = """## G9. Direct Generator report

Return only compact A2A records; do not serialize/persist a GeneratorRunReport object.

For every attributable input `SG` emit exactly one final row:

`GR|pyGroup=<group>|pyGUID=<final validated candidate GUID or ->|status=<OK|FAILED>|reason=<stable code or ->`

`OK` is allowed only after the exact candidate received Validator `OK` and its one UpdateMemory transition durably stored `pyStatusValue="Passed"` and `pyRouterKey="OK"`. `OK` requires nonempty candidate `pyGUID` and `reason=-`.

`FAILED` requires `pyGUID=-` and one stable reason code. Closed reasons are `INVALID_INPUT`, `SOURCE_READ_FAILED`, `SOURCE_INVALID`, `KNOWLEDGE_FAILED`, `NO_REPRESENTABLE_SCENARIO`, `PROJECTION_FAILED`, `CANDIDATE_WRITE_FAILED`, `VALIDATOR_RESPONSE_INVALID`, `LIFECYCLE_UPDATE_FAILED`, `SEMANTIC_REJECTED`, `HUMAN_REVIEW_REQUIRED`, `REPAIR_BUDGET_EXHAUSTED`.

Do not repeat Scenario Testability or BlockingGaps in GR. Those remain authoritative in the persisted candidate at `UnitTestRules[0].Scenarios[].Testability` and `.EvidenceSummary.BlockingGaps`. A candidate may be `Passed/OK` while a Scenario is `PartiallyTestable` or `NotTestable` when that limitation is faithfully represented.

Use input SG order only for deterministic output presentation; correlation is exclusively by `pyGroup`. No candidate payloads, Validator reports, arbitrary prose, markdown, aggregate status, attempt counters or singular top-level candidate UUID are returned. If the GEN header itself is invalid and no attributable group can be processed, return only `GR|pyGroup=-|pyGUID=-|status=FAILED|reason=INVALID_INPUT`.
"""

GEN_G10 = """## G10. Final runtime checks and consumer boundary

Before every candidate write, complete the bidirectional frozen-source audit and selected-schema self-check from G2–G7 for that `pyGroup`. Before acting on a Validator block, validate exact `VR`/`VI` framing, correlation, counts, route and Appendix B code/action pairs. No group is successful until its exact current candidate both validates `OK` and has a confirmed `Passed/OK` UpdateMemory result.

The configured Validator must implement the same `VAL`/`UT` request and `VR`/`VI` response grammar. Never switch transport or weaken checks to accept legacy direct parameters, raw ValidatorReport JSON, payload-in-question, UUID-position correlation, semantic-rerun actions or shared repair budgets. Pega owns target Ruleset/Version selection and Memory tool implementation; this agent only copies supplied metadata and invokes the five allowed interfaces.
"""

GEN_APPENDIX_B = f"""## Appendix B. Validator A2A consumer contract

{A2A}

Request:

```text
VAL|pxCaseID=<case>|RUTType=<type>
UT|pyGroup=<group>|pyGUID=<UnitTestCandidate GUID>
...
```

Response:

```text
VR|pyGroup=<group>|pyGUID=<echo exact candidate GUID>|route=<OK|GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>|blocking=<N>|warnings=<N>
VI|severity=<B|W>|code=<code>|action=<action>|scenario=<index or ->|decision=<ID or ->|path=<pointer>|message=<message>
```

Closed issue/action pairs:

| Issue code | Allowed action |
|---|---|
| JSON_SCHEMA_INVALID | FIX_JSON |
| JSON_SCHEMA_MASS_FAILURE | REBUILD_JSON_FROM_CURRENT_EVIDENCE |
| JSON_VALIDATION_TOOL_ERROR | HUMAN_REVIEW |
| MEMORY_READ_TOOL_ERROR | HUMAN_REVIEW |
| RUT_TYPE_MISMATCH | FIX_RUT_METADATA |
| TRACE_MISSING | REJECT_SEMANTICS |
| TRACE_INVALID | FIX_TRACE, REJECT_SEMANTICS |
| DECISION_NOT_FINALIZED | REJECT_SEMANTICS |
| ASSERT_MISSING | ADD_ASSERTION |
| ASSERT_EXTRA | REMOVE_ASSERTION |
| ASSERT_VALUE_MISMATCH | FIX_ASSERTION |
| OMIT_ASSERTED | REMOVE_ASSERTION |
| SIM_MISSING | ADD_SIMULATION |
| SIM_SHAPE_INVALID | FIX_SIMULATION |
| PARAM_SHAPE_INVALID | FIX_PARAM_SHAPE |
| ASSERT_BLOCK_INVALID | FIX_BLOCK_TYPE |
| COUNT_MISMATCH | FIX_COUNTS |
| REASONING_CONTRADICTION | REJECT_SEMANTICS |
| DOC_RESERVED_SYSTEM_PAGE_SEED | REJECT_SEMANTICS |
| DOC_DATAPAGE_IN_SETUP | MOVE_TO_PYSIMULATION |
| DOC_SIMULATION_METHOD_INVALID | FIX_SIMULATION |
| DOC_DATAPAGE_RULETYPE_INVALID | FIX_SIMULATION |
| DOC_LIST_SIMULATION_WRAPPER_MISSING | FIX_SIMULATION |
| DOC_RESULTCOUNT_FOR_NON_COUNT | FIX_BLOCK_TYPE, REJECT_SEMANTICS |
| DOC_PARAM_ASSERTION_SHAPE_INVALID | FIX_PARAM_SHAPE |
| DOC_REGULAR_ASSERTION_USES_PARAM_PATH | FIX_ASSERTION |
| DOC_ASSERTION_BLOCK_KIND_MISMATCH | FIX_BLOCK_TYPE |
| DOC_ERROR_MESSAGE_FORMAT_INVALID | FIX_ASSERTION |
| AMBIGUOUS | HUMAN_REVIEW |
| TRACE_PATH_CANONICALIZATION_NEEDED | FIX_TRACE_PATH |

## Appendix C. Generator direct-report contract

```text
GR|pyGroup=<group>|pyGUID=<final candidate GUID or ->|status=<OK|FAILED>|reason=<code or ->
```

Examples:

```text
GR|pyGroup=G001|pyGUID=4f2d...|status=OK|reason=-
GR|pyGroup=G002|pyGUID=-|status=FAILED|reason=CANDIDATE_WRITE_FAILED
```

The caller correlates by `pyGroup`, never line order. `GR` is ephemeral control-plane output and is never persisted as a Memory item.
"""

VAL_V1 = f"""## V1. Read-only responsibility and A2A input

You are UnitTestValidator, the read-only candidate validator called by UnitTestGenerator. You receive exactly one scalar `question`; candidate content is never passed agent-to-agent.

Valid input is exactly:

```text
VAL|pxCaseID=<encoded exact case id>|RUTType=<encoded immutable original RUTType>
UT|pyGroup=<encoded group>|pyGUID=<encoded UnitTestCandidate Memory GUID>
...
```

Require exactly one first `VAL` record and at least one `UT` record. Each UT has unique nonempty `pyGroup` and unique nonempty `pyGUID`. `pyGUID` is the canonical candidate Memory address; `pyGroup` is correlation only. `{A2A}` Preserve decoded values exactly; never trim, normalize, construct, pattern-check, case-fold, substitute an address, fetch latest, or infer RUTType from candidate shape.

Invalid invocation makes zero tool calls and returns one global block:

```text
VR|pyGroup=-|pyGUID=-|route=HUMAN|blocking=1|warnings=0
VI|severity=B|code=AMBIGUOUS|action=HUMAN_REVIEW|scenario=-|decision=-|path=/|message=Invalid Validator invocation
```

Validator never repairs or writes/updates Memory, reads ScenarioGroup, calls another agent, discovers dependencies, re-executes/reasons about the RUT, evaluates branches, chooses witnesses, derives expected values, adds coverage, or persists a report/result.

Closed tool allowlist:
- `JsonValidationTool(CaseID,UUID,JsonSchema)` — once per UT candidate; map `CaseID=VAL.pxCaseID`, `UUID=UT.pyGUID`.
- `GetMemory(pxCaseID,Type,pyGUID)` with `Type="UnitTestCandidate"` — once for that UT only after its schema result is valid.
- `KnowledgeTool(KnowledgeAreas)` — at most one shared V4 structural UTC call for all surviving UTs with the same immutable RUTType.

No tool retry. A candidate-specific failure stops only that UT's later calls; siblings continue. A shared Knowledge failure affects only UTs that reached the Knowledge-dependent phase.
"""

VAL_V2 = """## V2. Exact direct report, routes and coordinates

Return only `VR`/`VI` records. For each attributable UT emit one `VR` followed immediately by zero or more `VI` rows:

`VR|pyGroup=<group>|pyGUID=<echo exact candidate GUID>|route=<OK|GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>|blocking=<N>|warnings=<N>`

`VI|severity=<B|W>|code=<code>|action=<action>|scenario=<zero-based index or ->|decision=<stable ID or ->|path=<JSON Pointer>|message=<bounded message>`

Each VI belongs to the immediately preceding VR. `blocking` and `warnings` exactly count B/W VI rows. `OK` requires blocking=0. Derive blocking route precedence from all B issues: HUMAN_REVIEW -> HUMAN; REJECT_SEMANTICS -> SEMANTIC_REJECT; any permitted mechanical action -> GENERATOR_REPAIR; no B -> OK. Precedence is HUMAN > SEMANTIC_REJECT > GENERATOR_REPAIR > OK. Warnings never change route.

The architecture requires exactly one `UnitTestRules` entry per UnitTestCandidate. Candidate/group scope therefore uses `scenario=-`, `decision=-`, with path under `/UnitTestRules/0` or `/`. Scenario scope uses current zero-based `scenario` and a path under that Scenario or its corresponding RuleCode row. Decision must exist in that Scenario's current trace; unavailable decision uses `-`. Do not emit a redundant unit index.

Mechanical diagnostics restore already explicit final decisions only. ADD_ASSERTION requires an existing ASSERT; ADD_SIMULATION requires SIM. REMOVE_ASSERTION removes a visible extra projection or asserted OMIT, never a required decision. FIX_TRACE/FIX_TRACE_PATH is syntax-only. Missing, contradictory or unfinalized decisions use REJECT_SEMANTICS. Unsafe ambiguity without an explicit semantic contradiction uses AMBIGUOUS/HUMAN_REVIEW.

Only issue code/action pairs from Appendix A are allowed. Deduplicate identical issues. Message <=240 characters; schema summaries <=2000 characters. No raw candidate, corrected JSON, wrapper object, prose or markdown.
"""

VAL_V3 = """## V3. Per-candidate schema validation, then exact Memory

Select `ExpectedJsonSchema` solely from immutable VAL RUTType: Rule-Obj-When -> `Rule-Test-Unit-Case_MultInpComb-JsonSchema`; otherwise -> `Rule-Test-Unit-Case_JsonSchema`.

For each UT independently call exactly once:

`JsonValidationTool(CaseID=<VAL pxCaseID>, UUID=<exact UT pyGUID>, JsonSchema=<ExpectedJsonSchema>)`

Never inspect candidate content before that UT's successful schema result and never pass Memory Type to JsonValidationTool.

Require exact `Success`/`IsValid` booleans and string `ValidationMessage`/`ErrorCode`/`ErrorMessage`; extra metadata cannot repair required fields. Tool/input/malformed failure produces candidate-scoped `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW` and no GetMemory for that UT. `Success=true, IsValid=false` produces `JSON_SCHEMA_INVALID/FIX_JSON` or, under the existing mass-failure thresholds, `JSON_SCHEMA_MASS_FAILURE/REBUILD_JSON_FROM_CURRENT_EVIDENCE`; route GENERATOR_REPAIR and no GetMemory for that UT. Keep the existing thresholds: >=25 clearly reported errors, diagnostic >2000 characters, or explicit broadly malformed root/UnitTestRules/Scenarios/EvidenceSummary/RuleCode containers.

Only schema-valid UTs call exactly once:

`GetMemory(pxCaseID=<VAL pxCaseID>, Type="UnitTestCandidate", pyGUID=<same exact UT pyGUID>)`

Require result fields `Success` boolean plus string `pxCaseID`, `Type`, `pyGroup`, `pyGUID`, `pyPayload`, `ErrorCode`, `ErrorMessage`. Success requires empty errors, nonempty `pyPayload`, and exact metadata equality:

- returned `pxCaseID == VAL.pxCaseID`
- returned `Type == "UnitTestCandidate"`
- returned `pyGroup == UT.pyGroup`
- returned `pyGUID == UT.pyGUID`

A failed/malformed read, metadata mismatch, exception, empty successful payload, duplicate/non-finite/unparseable JSON, or non-traversable schema-passed candidate produces `MEMORY_READ_TOOL_ERROR/HUMAN_REVIEW` for that UT. Never retry, switch GUID, query by pyGroup or continue with partial content.

After parse, require exactly one `UnitTestRules` entry. A different cardinality is `COUNT_MISMATCH/FIX_COUNTS`; Generator can rebuild from the unchanged single physical group. Continue siblings independently.

Defensive traversability checks remain transport-consistency guards, not a second JSON Schema validator.
"""

VAL_V4 = """## V4. Per-candidate RUT check and one shared UTC lookup

For every schema/read-surviving candidate inspect its sole `UnitTestRules[0]`. Prefer `RuleCode.pyRuleUnderTest.pyDetails.pyRuleUnderTestType`, with fallback only to an explicitly visible original-type field in that same `pyRuleUnderTest`. A visible conflict with immutable VAL RUTType produces `RUT_TYPE_MISMATCH/FIX_RUT_METADATA` for that candidate and excludes only it from the Knowledge-dependent phase.

Compute UTC_KEYS solely from immutable VAL RUTType. Rule-Obj-When uses `Rule-Test-Unit-Case_MultInpComb-KnowledgeArea,Rule-Test-Unit-Case_MultInpComb-JsonSchema,Rule-Test-Unit-Case_MultInpComb-JsonExample`; all other supported types use `Rule-Test-Unit-Case_KnowledgeArea,Rule-Test-Unit-Case_JsonSchema,Rule-Test-Unit-Case_JsonExample`.

If at least one candidate still requires documented alignment, call KnowledgeTool once for that exact comma-joined list and cache the three texts for every surviving candidate in this invocation. Require every requested Area exactly once with nonempty Description and no unrequested/duplicate row. An exception or unusable shared guidance produces `AMBIGUOUS/HUMAN_REVIEW` independently for every candidate that reached this phase; it does not replace earlier item-specific results.

JsonValidationTool alone decides strict JSON Schema validity. UTC material governs documented RuleCode behavior, not case-specific semantics. AssertionDecisionTrace is each candidate's final ASSERT/SIM/OMIT authority; Validator never reconstructs hidden ScenarioGroup evidence. `ReasoningTrace`, `Testability` and `BlockingGaps` are visible evidence only. A faithful `PartiallyTestable` or `NotTestable` Scenario with explicit frozen BlockingGaps is allowed to validate `OK`; gaps alone are not semantic rejection. `SEMANTIC_REJECT` is reserved for an actual contradiction, unfinalized decision or misrepresentation of the final trace/RuleCode relationship.
"""

OLD_VAL_V5_PARSE = """For each Scenario parse only nonempty physical lines of AssertionDecisionTrace, splitting pipe-delimited fields before decoding entities. The current fixed field order is:"""
NEW_VAL_V5_PARSE = """For each Scenario parse only nonempty physical records of `AssertionDecisionTrace`. After JSON parsing, split the trace on actual LF record separators; then split each record on literal structural `|` separators; then split each named field on its first `=`. Only after structure is fixed may field values be entity-decoded once. The current fixed field order is:"""

OLD_VAL_V5_DECODE = """Decode only &amp;, &quot;, &#124;, &#13; and &#10;, once and simultaneously after splitting fields; never recursively decode literal entity text into structure or new lines. Preserve sig and params exactly after decoding; params is a duplicate-free canonical typed JSON object, not an inferred RUT parameter map. OMIT reasons are unresolved_external_source, unavailable_rulejson_after_limit_exhaustion, unresolvable_runtime_input, inactive_evaluate_all_scalar, inactive_return_values_scalar, schema_incompatible_assertion_target, redundant_iteration_coverage and incorrect_candidate_assertion. Do not add detail/internal ledger tags to the current grammar."""

NEW_VAL_V5_DECODE = """Decode only field-value entities `&amp;`, `&quot;`, `&#124;`, `&#13;`, `&#10;`, exactly once after record/field splitting; never decode an entity into new structure or recursively decode literal entity text. Structural pipes must therefore remain literal in the stored trace. A literal pipe that belongs inside a value is represented only as `&#124;`. Preserve sig and params exactly after value decoding; params is a duplicate-free canonical typed JSON object, not an inferred RUT parameter map. OMIT reasons are unresolved_external_source, unavailable_rulejson_after_limit_exhaustion, unresolvable_runtime_input, inactive_evaluate_all_scalar, inactive_return_values_scalar, schema_incompatible_assertion_target, redundant_iteration_coverage and incorrect_candidate_assertion. Do not add detail/internal ledger tags to the current grammar."""

OLD_VAL_V6_PROP = """ResultCount decisions map to block-level count comparator/value and list context; do not confuse count with exact item values. Param.* requires a Param Property assertion with full Param name/path and Text mode, without regular-page fields. For ordinary Property/List children compare pyPageName, pyPropertyApplyToClass and pyPropertyMode directly with the corresponding trace page/class/mode. Compare block pyStepPageClass with the class explicitly recorded for its step page in primary/P&C context; embedded child class can legitimately differ from the enclosing step-page class. A mismatch uses DOC_ASSERTION_BLOCK_KIND_MISMATCH/FIX_BLOCK_TYPE at the affected Scenario. Ordinary properties retain the block page/class and their own page/class/relative/full-path context; do not reinterpret them as Param."""

NEW_VAL_V6_PROP = """ResultCount decisions map to block-level count comparator/value and list context; do not confuse count with exact item values. Param.* requires a Param Property assertion with full Param name/path and Text mode, without regular-page fields. For an ordinary Property child, the trace `page` is semantic execution context and is not necessarily the immediate physical containing page. Derive the expected physical `pyPageName` deterministically from the canonical full target: remove the final property leaf and keep the complete parent page/list path; when the target is a direct scalar, the containing page is the block step page. Example: trace page `CustomerCommunication` plus target `.Addresses(1).pyCity` requires child `pyPageName=CustomerCommunication.Addresses(1)`. Compare candidate `pyPageName` to this derived containing page, while comparing `pyPropertyApplyToClass` and `pyPropertyMode` to the trace class/mode. Never rewrite or reject the semantic trace page solely because physical serialization uses a deeper containing page. Compare block `pyStepPageClass` with the class explicitly recorded for its step page in primary/P&C context; embedded child class can legitimately differ from the enclosing step-page class. A mismatch uses DOC_ASSERTION_BLOCK_KIND_MISMATCH/FIX_BLOCK_TYPE at the affected Scenario. Ordinary properties retain block page/class plus their own physical containing-page/class/relative/full-path context; do not reinterpret them as Param."""

OLD_VAL_V6_REASON = """ReasoningTrace is not an alternate assertion source. A clearly identified candidate claim with neither final ASSERT nor OMIT yields DECISION_NOT_FINALIZED/REJECT_SEMANTICS; a narrative mention alone does not demand an assertion. Conflicting final decisions/unsupported exact support or obvious contradiction yields semantic rejection; do not guess which decision wins. Do not derive dependencies, assertion requirements, expected values, simulations or true/false coverage from RUT logic. Validator returns no rewritten trace/candidate."""

NEW_VAL_V6_REASON = """ReasoningTrace is not an alternate assertion source. A clearly identified candidate claim with neither final ASSERT nor OMIT yields DECISION_NOT_FINALIZED/REJECT_SEMANTICS; a narrative mention alone does not demand an assertion. Conflicting final decisions, unsupported exact support, ASSERT+OMIT for one target, or another obvious final-ledger contradiction yields semantic rejection; do not guess which decision wins. `PartiallyTestable`/`NotTestable`, omitted claims and nonempty BlockingGaps are not contradictions when they faithfully describe the final trace and emitted RuleCode. Validator never invents a new BlockingGap or converts a semantic rejection into NotTestable. Do not derive dependencies, assertion requirements, expected values, simulations or true/false coverage from RUT logic. Validator returns no rewritten trace/candidate."""

OLD_VAL_V9_END = """Before returning, deduplicate identical defects, use stable unit/Scenario/check traversal order, derive counts/valid/route from the entire issues array, verify allowed code/action and current coordinates, and emit only the compact report. No per-item success pages, echo of complete trace/RuleCode/Knowledge, result persistence, further tool call or retry. Short issue messages name the defect and projection-only action; bound them to 240 characters and schema summaries to 2,000 characters without hiding distinct blocking scopes."""

NEW_VAL_V9_END = """Before returning, deduplicate identical defects and use stable UT/Scenario/check traversal order. For each candidate derive B/W counts and route from its complete issue set, verify Appendix A code/action pairs and current coordinates, then emit its exact `VR` followed immediately by its `VI` rows. Return candidate blocks in UT input order for deterministic presentation, but the caller must correlate by `pyGroup+pyGUID`. No candidate/trace/RuleCode/Knowledge echo, result persistence, further tool call or retry. Bound issue messages to 240 characters and schema summaries to 2,000 characters without hiding distinct blocking scopes."""

VAL_V10 = """## V10. Final output lock

Return only the compact A2A `VR`/`VI` records defined in Appendix B, including input/tool/validation failures. Do not return raw ValidatorReport JSON, a wrapper, corrected candidate, prose or markdown. Validator creates no Memory item and never calls UpdateMemory. Appendix A is the closed issue/action catalog; Appendix C gives complete framing examples.
"""

VAL_APPENDIX_B = f"""## Appendix B. Direct Validator A2A report grammar

{A2A}

Per-candidate response block:

```text
VR|pyGroup=<group>|pyGUID=<echo exact candidate GUID>|route=<OK|GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>|blocking=<N>|warnings=<N>
VI|severity=<B|W>|code=<Appendix A code>|action=<allowed action>|scenario=<zero-based index or ->|decision=<stable decision ID or ->|path=<JSON Pointer>|message=<bounded message>
...
```

Rules:
- exactly one VR per attributable UT;
- zero or more VI immediately follow their VR;
- `blocking` equals B-row count and `warnings` equals W-row count;
- route derives from blocking actions with precedence HUMAN > SEMANTIC_REJECT > GENERATOR_REPAIR > OK;
- `OK` requires blocking=0;
- `pyGUID` is echoed unchanged and is not a new Validator GUID;
- no correlation by line order;
- no candidate payload or persistence.

## Appendix C. Complete report examples

Successful candidate:

```text
VR|pyGroup=G001|pyGUID=UTC-GUID-001|route=OK|blocking=0|warnings=0
```

Mechanical repair:

```text
VR|pyGroup=G002|pyGUID=UTC-GUID-002|route=GENERATOR_REPAIR|blocking=1|warnings=0
VI|severity=B|code=ASSERT_MISSING|action=ADD_ASSERTION|scenario=0|decision=A003|path=/UnitTestRules/0/RuleCode/pyExpectedResults|message=Frozen assertion A003 is missing
```

Semantic contradiction:

```text
VR|pyGroup=G003|pyGUID=UTC-GUID-003|route=SEMANTIC_REJECT|blocking=1|warnings=0
VI|severity=B|code=REASONING_CONTRADICTION|action=REJECT_SEMANTICS|scenario=0|decision=-|path=/UnitTestRules/0/Scenarios/0|message=Final decisions contradict each other
```

Invalid invocation with no attributable candidate:

```text
VR|pyGroup=-|pyGUID=-|route=HUMAN|blocking=1|warnings=0
VI|severity=B|code=AMBIGUOUS|action=HUMAN_REVIEW|scenario=-|decision=-|path=/|message=Invalid Validator invocation
```
"""

def _decode_html_prompt(inner: str) -> str:
    """Decode the Pega rich-text <p>...</p> system prompt to plain prompt text."""
    pos = 0
    lines = []
    pat = re.compile(r"\s*<p>(.*?)</p>", re.S)
    while pos < len(inner):
        m = pat.match(inner, pos)
        if not m:
            if inner[pos:].strip():
                raise RuntimeError("embedded pySystemPrompt contains non-paragraph markup")
            break
        lines.append(html.unescape(m.group(1)))
        pos = m.end()
    if not lines:
        raise RuntimeError("embedded pySystemPrompt has no paragraphs")
    return "\n".join(lines)

def _encode_html_prompt(text: str) -> str:
    """Encode plain prompt text into deterministic Pega rich-text paragraph markup."""
    return "\n".join(f"<p>{html.escape(line, quote=False)}</p>"
                     for line in text.rstrip("\n").split("\n"))

def transform_agent_config(config: str, old_prompt: str, new_prompt: str,
                           response_style_text: str, add_update_memory: bool) -> str:
    sys_pat = re.compile(r"<pySystemPrompt>(.*?)</pySystemPrompt>", re.S)
    ms = list(sys_pat.finditer(config))
    if len(ms) != 1:
        raise RuntimeError(f"agent config pySystemPrompt count={len(ms)}")
    decoded = _decode_html_prompt(ms[0].group(1))
    if decoded.rstrip() != old_prompt.rstrip():
        raise RuntimeError("embedded pySystemPrompt does not equal reviewed standalone baseline")
    replacement = "<pySystemPrompt>" + _encode_html_prompt(new_prompt) + "</pySystemPrompt>"
    config = config[:ms[0].start()] + replacement + config[ms[0].end():]

    rs_pat = re.compile(r"<pyResponseStylePrompt>.*?</pyResponseStylePrompt>", re.S)
    rs = list(rs_pat.finditer(config))
    if len(rs) != 1:
        raise RuntimeError(f"agent config pyResponseStylePrompt count={len(rs)}")
    rs_new = ("<pyResponseStylePrompt><p>" +
              html.escape(response_style_text, quote=False) +
              "</p></pyResponseStylePrompt>")
    config = config[:rs[0].start()] + rs_new + config[rs[0].end():]

    if add_update_memory:
        kt_pat = re.compile(r"(<pzKnowledgeTools REPEATINGTYPE=\"PageList\">)(.*?)(</pzKnowledgeTools>)", re.S)
        km = list(kt_pat.finditer(config))
        if len(km) != 1:
            raise RuntimeError(f"Generator pzKnowledgeTools count={len(km)}")
        body = km[0].group(2)
        if "<pyPurpose>WriteMemory</pyPurpose>" not in body or "<pyPurpose>GetMemory</pyPurpose>" not in body:
            raise RuntimeError("Generator baseline Memory tools missing")
        if "<pyPurpose>UpdateMemory</pyPurpose>" in body:
            raise RuntimeError("Generator baseline already contains UpdateMemory; baseline decision must be reconciled")
        indices = [int(x) for x in re.findall(r'<rowdata REPEATINGINDEX="(\d+)">', body)]
        new_index = max(indices, default=0) + 1
        row = (f'\\n<rowdata REPEATINGINDEX="{new_index}">\\n'
               '<pxObjClass>Rule-AI-Tool</pxObjClass>\\n'
               '<pyPurpose>UpdateMemory</pyPurpose>\\n'
               '</rowdata>')
        body2 = body.rstrip() + row + "\n"
        whole = km[0].group(1) + body2 + km[0].group(3)
        config = config[:km[0].start()] + whole + config[km[0].end():]

    return config

OLD_TRACE_SCHEMA_SENTENCE = "Values must be encoded safely for a JSON string: do not wrap values in unescaped double quotes; encode double quote as &quot;, pipe as &#124;, and newline as &#10;."
NEW_TRACE_SCHEMA_SENTENCE = "Trace field values only use safe entity encoding: encode source double quote as &quot;, source ampersand as &amp;, literal pipe inside a field value as &#124;, CR inside a field value as &#13;, and LF inside a field value as &#10;. Structural fields remain separated by literal | and trace records by actual LF in the in-memory trace before normal JSON serialization; never entity-encode structural separators. Validator splits records and literal structural pipes before decoding field-value entities exactly once."

def transform_utc_schema(text: str, label: str) -> str:
    return exact_replace(text, OLD_TRACE_SCHEMA_SENTENCE, NEW_TRACE_SCHEMA_SENTENCE, label + " AssertionDecisionTrace encoding")

def transform_main(text: str) -> str:
    text = exact_replace(text, "GeneratorRunReport details", "Generator report details", "Main visible-output legacy report term")
    text = section_replace(text,
        "## 1A. ScenarioGroup storage and UnitTestGenerator handoff",
        "## 1B. Closed external-interface allowlist",
        MAIN_1A, "Main §1A")
    text = section_replace(text,
        "## 1B. Closed external-interface allowlist",
        "## 2. Source-of-truth order",
        MAIN_1B, "Main §1B")
    text = section_replace(text,
        "## 4. Required execution order",
        "## 5. Internal Evidence Ledger contract",
        MAIN_4, "Main §4")
    text = exact_replace(text, OLD_MAIN_13_STORAGE, NEW_MAIN_13_STORAGE, "Main §13 storage")
    text = exact_replace(text, OLD_MAIN_13_ENVELOPE, NEW_MAIN_13_ENVELOPE, "Main §13 envelope")
    text = section_replace(text,
        "### 14.1 Author-owned final sequence",
        "### 14.2 Downstream preservation map — not executable by Scenario Author",
        MAIN_14_1, "Main §14.1")
    text = section_replace(text,
        "### 14.2 Downstream preservation map — not executable by Scenario Author",
        "### 14.3 Closed Scenario Author prohibition",
        MAIN_14_2, "Main §14.2")
    text = exact_replace(text, OLD_MAIN_HANDOFF_ORDER, NEW_MAIN_HANDOFF_ORDER, "Main §13 handoff order")
    text = exact_replace(text, OLD_MAIN_TRACE_ENCODING, NEW_MAIN_TRACE_ENCODING, "Main §13.4.6 trace encoding")
    start = "## 15. Generator terminal report contract"
    if text.count(start) != 1:
        raise RuntimeError(f"Main §15: heading count={text.count(start)}")
    text = text[:text.index(start)] + MAIN_15.rstrip() + "\n"
    return text

def transform_generator(text: str) -> str:
    text = section_replace(text,
        "## G1. Responsibility and Input Boundary",
        "## G2. Exact Reads and Immutable Source Gate",
        GEN_G1, "Generator G1")
    text = section_replace(text,
        "## G2. Exact Reads and Immutable Source Gate",
        "## G3. Structural Knowledge and Pega Metadata Boundary",
        GEN_G2, "Generator G2")
    text = exact_replace(text, OLD_GEN_G4_FIRST, NEW_GEN_G4_FIRST, "Generator G4 candidate cardinality")
    text = exact_replace(text, OLD_GEN_G6_PROP, NEW_GEN_G6_PROP, "Generator G6 physical page")
    text = exact_replace(text, OLD_GEN_G7_TRACE, NEW_GEN_G7_TRACE, "Generator G7 trace encoding")
    text = section_replace(text,
        "## G8. Immutable Writes, Validator Consumer and Repair",
        "## G9. Runtime GeneratorRunReport",
        GEN_G8, "Generator G8")
    text = section_replace(text,
        "## G9. Runtime GeneratorRunReport",
        "## G10. Final Runtime Checks and Consumer Boundary",
        GEN_G9, "Generator G9")
    text = section_replace(text,
        "## G10. Final Runtime Checks and Consumer Boundary",
        "## Appendix A. Complete Frozen Source Validation Reference",
        GEN_G10, "Generator G10")
    text = exact_replace(text,
        "G1's four-interface allowlist",
        "G1's five-interface allowlist",
        "Generator Appendix A allowlist count")
    text = exact_replace(text, OLD_GEN_HANDOFF_ORDER, NEW_GEN_HANDOFF_ORDER, "Generator Appendix A handoff order")
    # Replace legacy ValidatorReport + GeneratorRunReport appendices through EOF.
    start = "## Appendix B. ValidatorReport Structural Schema"
    if text.count(start) != 1:
        raise RuntimeError(f"Generator appendices: heading count={text.count(start)}")
    text = text[:text.index(start)] + GEN_APPENDIX_B.rstrip() + "\n"
    return text

def transform_validator(text: str) -> str:
    text = section_replace(text,
        "## V1. Read-only responsibility and input",
        "## V2. Exact report, routes and current coordinates",
        VAL_V1, "Validator V1")
    text = section_replace(text,
        "## V2. Exact report, routes and current coordinates",
        "## V3. Schema first, then exact Memory",
        VAL_V2, "Validator V2")
    text = section_replace(text,
        "## V3. Schema first, then exact Memory",
        "## V4. All-unit RUT check and one UTC lookup",
        VAL_V3, "Validator V3")
    text = section_replace(text,
        "## V4. All-unit RUT check and one UTC lookup",
        "## V5. Canonical final trace grammar and normalization",
        VAL_V4, "Validator V4")
    text = exact_replace(text, OLD_VAL_V5_PARSE, NEW_VAL_V5_PARSE, "Validator V5 split order")
    text = exact_replace(text, OLD_VAL_V5_DECODE, NEW_VAL_V5_DECODE, "Validator V5 field decode")
    text = exact_replace(text, OLD_VAL_V6_PROP, NEW_VAL_V6_PROP, "Validator V6 physical containing page")
    text = exact_replace(text, OLD_VAL_V6_REASON, NEW_VAL_V6_REASON, "Validator V6 testability/semantic reject")
    text = exact_replace(text, OLD_VAL_V9_END, NEW_VAL_V9_END, "Validator V9 report emission")
    text = section_replace(text,
        "## V10. Final output lock",
        "## Appendix A. Closed issue/action catalog",
        VAL_V10, "Validator V10")
    start = "## Appendix B. Complete ValidatorReport schema"
    if text.count(start) != 1:
        raise RuntimeError(f"Validator appendices: heading count={text.count(start)}")
    text = text[:text.index(start)] + VAL_APPENDIX_B.rstrip() + "\n"
    return text

def verify_staged(files: dict[str, str]) -> None:
    main = files["Main_Agent_Prompt.txt"]
    gen = files["UnitTestGenerator_Prompt.txt"]
    val = files["Validator_Prompt.txt"]

    required = {
        "Main_Agent_Prompt.txt": [
            'WriteMemory(pxCaseID=<exact pyID>, Type="ScenarioGroup", RequestsJSON=<JSON string>)',
            'GEN|pxCaseID=<encoded exact pyID>|RUTType=<encoded immutable original RUTType>',
            'GR|pyGroup=<group>|pyGUID=<validated candidate GUID or ->|status=<OK|FAILED>',
            'when at least one expected group has one independently valid `GR status=OK`',
        ],
        "UnitTestGenerator_Prompt.txt": [
            'It receives exactly one scalar parameter: `question`',
            '`GetMemory(pxCaseID,Type,pyGUID)`',
            '`UpdateMemory(pxCaseID,Type,RequestsJSON)`',
            'one raw UnitTestCandidate JSON object',
            'Encode trace **field values only**',
            'pyStatusValue="Passed"',
            'Budget is per `pyGroup`',
            'Return only compact A2A records',
        ],
        "Validator_Prompt.txt": [
            'You receive exactly one scalar `question`',
            '`JsonValidationTool(CaseID,UUID,JsonSchema)`',
            '`GetMemory(pxCaseID,Type,pyGUID)`',
            'split the trace on actual LF record separators',
            'Derive the expected physical `pyPageName` deterministically',
            'faithful `PartiallyTestable` or `NotTestable` Scenario',
            'Return only the compact A2A `VR`/`VI` records',
        ],
    }
    forbidden = {
        "Main_Agent_Prompt.txt": [
            "ScenarioGroupUUIDs",
            "Call `WriteMemory` sequentially exactly once per group",
            "Only after every write succeeds",
            "## 15. Generator terminal report contract",
            "sourceUUID",
            "one combined schema-governed candidate",
            "UUID order equals group order",
            "Validator reverses the same trace encoding",
        ],
        "UnitTestGenerator_Prompt.txt": [
            "ScenarioGroupUUIDs",
            "UnitTestCandidateUUID",
            "Return exactly one bounded raw JSON object",
            "Appendix C. GeneratorRunReport Structural Schema",
            "Preserve child pyPageName=ASSERT.page",
            "Apply trace encoding once: ampersand -> &amp;, pipe -> &#124;",
            "shared two-repair budget",
            "UUID order equals group order",
            "sourceUUID",
        ],
        "Validator_Prompt.txt": [
            "UnitTestCandidateUUID",
            "Return exactly one compact raw ValidatorReport JSON object",
            "Appendix B. Complete ValidatorReport schema",
            "Mass rebuild always means the same unchanged ScenarioGroups and consumes Generator's existing shared two-repair budget",
        ],
    }

    errors = []
    for fn, needles in required.items():
        for n in needles:
            if n not in files[fn]:
                errors.append(f"{fn}: missing required anchor: {n}")
    for fn, needles in forbidden.items():
        for n in needles:
            if n in files[fn]:
                errors.append(f"{fn}: obsolete/conflicting anchor remains: {n}")

    # Sender/receiver grammar anchors must be literally identical in the three standalone prompts.
    common = "before placing a value in a field, encode backslash `\\` as `\\\\`, literal pipe `|` as `\\|`, CR as `\\r`, LF as `\\n`, TAB as `\\t`, empty string as `\\0`, and an exact literal hyphen `-` as `\\-`"
    for fn in ("Main_Agent_Prompt.txt", "UnitTestGenerator_Prompt.txt", "Validator_Prompt.txt"):
        if common not in files[fn]:
            errors.append(f"{fn}: canonical A2A escaping text drift/missing")

    # Runtime agent snapshots must embed the exact transformed standalone prompts.
    for cfg_fn, prompt_fn in (("UnitTestGenerator.txt","UnitTestGenerator_Prompt.txt"),
                              ("JsonValidator_tool.txt","Validator_Prompt.txt")):
        m = re.search(r"<pySystemPrompt>(.*?)</pySystemPrompt>", files[cfg_fn], re.S)
        if not m:
            errors.append(f"{cfg_fn}: missing pySystemPrompt")
        else:
            try:
                decoded = _decode_html_prompt(m.group(1))
                if decoded.rstrip() != files[prompt_fn].rstrip():
                    errors.append(f"{cfg_fn}: embedded prompt differs from {prompt_fn}")
            except Exception as e:
                errors.append(f"{cfg_fn}: embedded prompt parse failed: {e}")

    gm = re.search(r'<pzKnowledgeTools REPEATINGTYPE="PageList">(.*?)</pzKnowledgeTools>',
                   files["UnitTestGenerator.txt"], re.S)
    if not gm or gm.group(1).count("<pyPurpose>UpdateMemory</pyPurpose>") != 1:
        errors.append("UnitTestGenerator.txt: UpdateMemory must appear exactly once in pzKnowledgeTools")

    for cfg_fn, marker in (
        ("UnitTestGenerator.txt", "Return only the exact compact GR line protocol defined by the system prompt."),
        ("JsonValidator_tool.txt", "Return only the exact compact VR/VI line protocol defined by the system prompt."),
    ):
        if marker not in files[cfg_fn]:
            errors.append(f"{cfg_fn}: response-style line-protocol lock missing")
        if "Return exactly one raw GeneratorRunReport JSON object" in files[cfg_fn]:
            errors.append(f"{cfg_fn}: legacy GeneratorRunReport response-style lock remains")
        if "Return exactly one raw JSON object and nothing else." in files[cfg_fn]:
            errors.append(f"{cfg_fn}: legacy raw-JSON response-style lock remains")

    for schema_fn in ("rule-test-unit-case_JsonSchema.txt", "rule-test-unit-case_multInpComb-JsonSchema.txt"):
        schema_text = files[schema_fn]
        if NEW_TRACE_SCHEMA_SENTENCE not in schema_text:
            errors.append(f"{schema_fn}: field-value-only AssertionDecisionTrace description missing")
        if OLD_TRACE_SCHEMA_SENTENCE in schema_text:
            errors.append(f"{schema_fn}: ambiguous old AssertionDecisionTrace description remains")

    if errors:
        raise RuntimeError("Post-transform verification failed:\n- " + "\n- ".join(errors))

def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    originals = {}
    for fn, expected in BASE_BLOB_SHA.items():
        p = root / fn
        if not p.is_file():
            raise SystemExit(f"Missing required file: {p}")
        data = p.read_bytes()
        actual = git_blob_sha(data)
        if actual != expected:
            raise SystemExit(f"{fn}: baseline SHA mismatch; expected {expected}, got {actual}. No files changed.")
        originals[fn] = data.decode("utf-8")

    main_prompt = transform_main(originals["Main_Agent_Prompt.txt"])
    generator_prompt = transform_generator(originals["UnitTestGenerator_Prompt.txt"])
    validator_prompt = transform_validator(originals["Validator_Prompt.txt"])

    generator_config = transform_agent_config(
        originals["UnitTestGenerator.txt"],
        originals["UnitTestGenerator_Prompt.txt"],
        generator_prompt,
        "Return only the exact compact GR line protocol defined by the system prompt. Do not return JSON, Markdown, code fences, progress, analysis, headings, or text outside GR records.",
        add_update_memory=True,
    )
    validator_config = transform_agent_config(
        originals["JsonValidator_tool.txt"],
        originals["Validator_Prompt.txt"],
        validator_prompt,
        "Return only the exact compact VR/VI line protocol defined by the system prompt. Do not return JSON, Markdown, code fences, progress, analysis, headings, or text outside VR/VI records.",
        add_update_memory=False,
    )

    standard_schema = transform_utc_schema(originals["rule-test-unit-case_JsonSchema.txt"], "standard UTC schema")
    when_schema = transform_utc_schema(originals["rule-test-unit-case_multInpComb-JsonSchema.txt"], "MultInpComb UTC schema")

    staged = {
        "Main_Agent_Prompt.txt": main_prompt,
        "UnitTestGenerator_Prompt.txt": generator_prompt,
        "Validator_Prompt.txt": validator_prompt,
        "UnitTestGenerator.txt": generator_config,
        "JsonValidator_tool.txt": validator_config,
        "rule-test-unit-case_JsonSchema.txt": standard_schema,
        "rule-test-unit-case_multInpComb-JsonSchema.txt": when_schema,
    }
    verify_staged(staged)

    # All files passed transforms and verification before any write.
    evidence = []
    for fn, content in staged.items():
        p = root / fn
        tmp = p.with_name(p.name + ".refactor.tmp")
        tmp.write_text(content, encoding="utf-8", newline="\n")
        tmp.replace(p)
        evidence.append({
            "file": fn,
            "base_blob_sha": BASE_BLOB_SHA[fn],
            "post_blob_sha": git_blob_sha(p.read_bytes()),
            "bytes": len(p.read_bytes()),
        })

    print(json.dumps({"status": "APPLIED_LOCAL", "files": evidence}, indent=2))

if __name__ == "__main__":
    main()
