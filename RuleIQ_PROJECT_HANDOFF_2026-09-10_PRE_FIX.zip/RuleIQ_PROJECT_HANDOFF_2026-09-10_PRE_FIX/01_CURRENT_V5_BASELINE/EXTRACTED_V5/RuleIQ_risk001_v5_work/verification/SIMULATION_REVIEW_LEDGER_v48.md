# Session Resume Instructions

## User goal

Simulate, step by step, how the agent defined by `Main_Agent_Prompt.txt` would execute when the underlying model is **Claude Opus 4.8**. Use current official Anthropic prompt-writing / model-behavior guidance to reason about how Claude Opus 4.8 is likely to interpret the system prompt. This is a **controlled simulation**, not an actual Claude execution.

The simulation must begin with the Main Agent in `Main_Agent_Prompt.txt` and walk through its instructions in execution order. At every major instruction boundary, and especially before handing work to a tool or another agent, pause and expose for review:

1. what the simulated Claude has established so far;
2. the exact data/state being carried forward;
3. the exact payload and format that would be passed to the next tool/agent;
4. which prompt instructions authorize that step;
5. any inconsistency, ambiguity, illogical instruction, ownership conflict, ordering conflict, or format-contract violation discovered;
6. any assumption required to continue the simulation.

Do **not** silently repair defects. Stop at major checkpoints so the user can review/correct the prompt semantics before continuing. When a defect must be bypassed only to continue the simulation, record it explicitly as a simulation assumption; do not treat the repository prompt as amended.

Do not preload all repository context. Read files incrementally as execution reaches them in order to reduce context rot and to reveal contract problems at the point they become operationally relevant.

## Repository access boundary

Repository: `johnleanky/RuleIQ-UnitTestGenerator-Refactor`

The user authorized reading/working with **only** the following repository files, plus this ledger file. Never read, search, inspect, create, modify, or infer from any other repository file unless the user explicitly authorizes it later:

- `JsonValidator_tool.txt`
- `Main_Agent_Prompt.txt`
- `Rule_Crawler_tool.txt`
- `rule-declare-decisiontable_knowledgearea.txt`
- `rule-declare-pages_knowledgearea.txt`
- `rule-obj-model_knowledgearea.txt`
- `rule-obj-property_knowledgearea.txt`
- `rule-obj-when_knowledgearea.txt`
- `rule-test-unit-case_JsonExample.txt`
- `rule-test-unit-case_JsonSchema.txt`
- `rule-test-unit-case_multInpComb-JsonExample.txt`
- `rule-test-unit-case_multInpComb-JsonSchema.txt`
- `rule-utility-function_knowledgearea.txt`
- `UnitTestGenerator_Prompt.txt`
- `UnitTestGenerator.txt`
- `Validator_Prompt.txt`
- `SIMULATION_REVIEW_LEDGER.md` (explicitly authorized later as the durable review ledger)

If needed information cannot be established from these files plus the user's supplied input, state the gap instead of opening another repository file.

## Review strategy

Keep the repository prompts **frozen during the first simulation pass**. Collect all confirmed defects, ambiguities, and decisions in this ledger rather than editing `Main_Agent_Prompt.txt` immediately. After the first complete pass, consolidate the accepted corrections into one coherent edit pass, then rerun the simulation from the beginning against the corrected prompt to verify that the fixes do not introduce new contradictions.

Use stable issue IDs (for example `MA-001`) and never erase earlier findings. Update their status when later evidence resolves or invalidates them. This ledger is the durable source of truth for resuming the review in a new chat.

## Context-preservation rule

Update this ledger at major checkpoints and before context-heavy transitions. Preserve:

- current execution position;
- simulation input and locked facts;
- files actually read;
- unresolved/open findings;
- accepted/rejected user decisions;
- active simulation assumptions;
- exact next boundary/tool handoff.

The purpose is to allow a new chat to resume directly from this file without reconstructing the earlier discussion from memory.

## Important simulation-input rule

The user supplied the RUT RuleJSON directly in chat. Treat that JSON as `GetCaseData.RuleJSON`. The user did **not** supply `GetCaseData.pyID`, so simulated `CaseID` remains unknown unless the user provides it later. Never substitute `pzInsKey` or `application_context.caseID` for `GetCaseData.pyID`.

---

# Scenario Author Simulation Review Ledger

## Purpose

Durable review ledger for a controlled simulation of the agent defined by `Main_Agent_Prompt.txt`, using Claude Opus 4.8 prompting behavior as the interpretation model.

The repository prompt remains frozen during the first simulation. Findings are collected here and corrections are intended to be applied coherently after the first complete simulation pass.

## Repository boundary

Authorized repository files for this review are the user-approved whitelist plus this explicitly authorized ledger file. No other repository files may be read, searched, created, or modified unless the user explicitly authorizes them.

## Baseline

- Repository: `johnleanky/RuleIQ-UnitTestGenerator-Refactor`
- Branch: `main`
- System prompt under review: `Main_Agent_Prompt.txt`
- Baseline blob SHA observed for `Main_Agent_Prompt.txt`: `9a21effb28e9b5a2ff84449a581be305cc12a3b3`
- Simulation target model behavior: Claude Opus 4.8
- Simulation method: step-by-step controlled interpretation; not an actual Claude execution

## Simulation input

RUT supplied directly by the user and treated as `GetCaseData.RuleJSON`:

- `pxObjClass = Rule-Obj-Model`
- `pyClassName = RuleIQ-Data-TestRefLib`
- `pyRuleName = PrepareCustomerCommunication`
- `pyLabel = Prepare Customer Communication`
- `pzInsKey = RULE-OBJ-MODEL RULEIQ-DATA-TESTREFLIB PREPARECUSTOMERCOMMUNICATION #20260430T104351.201 GMT`
- Formal parameter: `CustomerID`, direction `IN`, type `STRING`
- Named page / Pages & Classes entry: `CustomerCommunication : Data-Customer`
- `GetCaseData.pyID` was not supplied, therefore simulated `CaseID` remains unknown and must never be inferred from `pzInsKey`.

## Current execution position

`Main Agent -> GetCaseData conceptually completed -> RUT identity checked -> structural discovery scan completed -> PAUSED before first KnowledgeTool handoff`

No RuleCrawler call, Scenario formation, assertion decision, simulation decision, storage, UnitTestGenerator handoff, or Validator activity has occurred in the simulation.

## Current structural discovery

Observed executable Model structure:

1. `UPDATE_PAGE CustomerCommunication WITH_VALUES_FROM D_CustomerTestRef`
2. Nested `WHEN !@IsInPageListWhen("IsValidCity",D_CustomerTestRef.Addresses)`
   - `SET Param.ExitCode = "-1 City Not valid"`
   - `EXIT_MODEL`
3. `SET Param.AddressIndex = @IndexInPageListWhen("IsValidPostalAddress",D_CustomerTestRef.Addresses)`
4. `WHEN Param.AddressIndex>0`
   - `APPEND_AND_MAP_TO .Addresses` from `D_CustomerTestRef.Addresses(Param.AddressIndex)`
   - nested setters for `.pyCity`, `.pyPostalCode`, `.pyStreet`
   - `SET Param.StreetName = @String.stripNonAlphabeticChars(@TrimNumber(@toUpperCase(.pyStreet)))`

Provisional semantic KnowledgeArea needs discovered structurally:

- `Rule-Obj-Model_KnowledgeArea`
- `Rule-Declare-Pages_KnowledgeArea`
- `Rule-Obj-Property_KnowledgeArea`
- `Rule-Utility-Function_KnowledgeArea`
- candidate `Rule-Obj-When_KnowledgeArea` based on syntactic When-name arguments in page-list RUF calls; whether this key is legally requestable at the first checkpoint is under review in MA-002.

## Review status vocabulary

- `OPEN` — finding requires resolution.
- `CONFIRMED_DEFECT` — prompt defect confirmed by authoritative prompt contracts.
- `AMBIGUITY` — multiple plausible literal interpretations remain.
- `RESOLVED_BY_EXISTING_CONTRACT` — later/higher-authority text resolves it; no edit needed unless simplification desired.
- `FALSE_POSITIVE` — finding invalidated by later evidence.
- `NEEDS_USER_DECISION` — intended semantics cannot be established from current contracts alone.
- `PROPOSED_FIX_ACCEPTED` — user accepted correction for later consolidated edit.
- `PROPOSED_FIX_REJECTED` — user rejected correction.
- `NON_BLOCKING` — issue exists but should not alter semantic execution.

## Canonical-status rule

For every `MA-*` item, the status and user decision written inside that item's own canonical entry are authoritative. Later checkpoint/history sections may preserve how the decision was reached but must not override or contradict the canonical entry.

## Decision / defect ledger

### MA-001 — First KnowledgeTool acquisition order conflicts with initial scan prerequisite

- Location: `Main_Agent_Prompt.txt` Section 3.3 versus Section 4 steps 4-5
- Type: execution-order contradiction
- Status: `CONFIRMED_DEFECT`
- Problem: Section 3.3 permits the first KnowledgeTool call only after GetCaseData and the initial RUT scan have produced concrete semantic needs and request-ready dependency rows. Section 4 orders KnowledgeTool acquisition before scanning the original RUT.
- Likely intended semantics: `GetCaseData -> validate/lock identity -> discovery scan -> first KnowledgeTool batch -> semantic reconciliation -> crawl preparation`.
- Proposed correction: distinguish a structural `DISCOVERY SCAN` from a post-KnowledgeTool semantic scan/reconciliation and order the first KnowledgeTool call between them.
- Simulation assumption if needed: follow Section 3.3 as the more specific tool-call checkpoint and perform structural discovery before the first KnowledgeTool call. This assumption does not amend the repository prompt.

### MA-002 — First-batch Rule-Obj-When KnowledgeArea dead-zone risk

- Location: Sections 3.2-3.4
- Type: acquisition-checkpoint ambiguity
- Status: `OPEN`
- Problem: syntactic calls such as `@IsInPageListWhen("IsValidCity",...)` and `@IndexInPageListWhen("IsValidPostalAddress",...)` strongly suggest Rule-Obj-When dependencies. But Section 3.4 says KnowledgeTool guidance interprets When references in operations/string parameters. If the discovery scan refuses to classify those strings until RUF guidance is returned, `Rule-Obj-When_KnowledgeArea` may only become known immediately after the first KnowledgeTool call. Section 3.3 provides no second pre-crawl KnowledgeTool checkpoint, producing a potential dead zone.
- Proposed correction: explicitly allow strong syntactic indicators during discovery to enqueue a semantic KnowledgeArea key without treating the underlying semantics as resolved.
- User decision pending: whether `Rule-Obj-When_KnowledgeArea` is intended to be legal in the first KnowledgeTool batch for this RUT.

### MA-003 — Scenario Author text refers to RuleCode.pySimulation despite ownership prohibition

- Location: Section 5.0 Data Page identity / MODE=AUTHOR language
- Type: ownership contradiction
- Status: `CONFIRMED_DEFECT`
- Problem: Section 5.0 says scenario-time values are instantiated in `SIM/RuleCode.pySimulation`, while Sections 1/1.1/1.3 explicitly prohibit Scenario Author from creating RuleCode or pySimulation.
- Proposed correction: Scenario Author owns only the semantic `SIM` obligation; UnitTestGenerator later projects it into `RuleCode.pySimulation`.

### MA-004 — Author-side preFinal gate references downstream RuleCode/EvidenceSummary

- Location: Section 5.0
- Type: ownership contradiction / misleading residual legacy wording
- Status: `CONFIRMED_DEFECT`
- Problem: `STATECHECK.preFinal` is described as a storage gate over final RuleCode/EvidenceSummary, but Scenario Author does not own or inspect either artifact under the higher-authority contract.
- Proposed correction: redefine the Author-side final gate exclusively over ScenarioGroup semantic records, or mark the RuleCode/EvidenceSummary gate as downstream-only.

### MA-005 — Canonical KEY representation for classless RUF dependencies is undefined

- Location: Section 5.0 canonical `KEY = <kind>@<applyToClass>@<name>`
- Type: format ambiguity
- Status: `OPEN`
- Problem: RUF references in the supplied RuleJSON have empty `pxRuleClassName`, but closure requires exact canonical KEY identity. The prompt does not state whether an empty middle component is valid or whether a canonical sentinel/library identity must be used.
- Next evidence to inspect: `rule-utility-function_knowledgearea.txt` when the simulation reaches the first KnowledgeTool stage.
- Do not invent a convention before checking that allowed file.

### MA-006 — `GetCaseData.pyID` lacks an explicit initial non-empty guard

- Location: Section 4 steps 1-3 and Section 1A
- Type: missing guard
- Status: `OPEN`
- Problem: the prompt explicitly rejects missing `RuleJSON.pzInsKey` and `RuleJSON.pxObjClass`, but does not equally require non-empty `GetCaseData.pyID`, despite requiring all later storage/handoff CaseID values to come exactly from pyID.
- Proposed correction: initial validation should require non-empty `GetCaseData.pyID`, `RuleJSON.pzInsKey`, and `RuleJSON.pxObjClass`.

### RUT-001 — Description says DT while authoritative type is Model

- Source: user-supplied RUT
- Type: stale/non-authoritative metadata inconsistency
- Status: `NON_BLOCKING`
- Problem: `pyDescription` says "unit-test generation for DT" although `pxObjClass` is `Rule-Obj-Model`.
- Disposition: do not alter semantics; structural RuleJSON type is authoritative under source-of-truth order.

## Provisional first KnowledgeTool handoff

If MA-002 is resolved in favor of syntactic enqueueing, the exact sorted first-batch semantic keys should be:

`Rule-Declare-Pages_KnowledgeArea,Rule-Obj-Model_KnowledgeArea,Rule-Obj-Property_KnowledgeArea,Rule-Obj-When_KnowledgeArea,Rule-Utility-Function_KnowledgeArea`

If MA-002 is resolved against syntactic enqueueing, the first batch would omit `Rule-Obj-When_KnowledgeArea`, but the prompt currently appears to lack a legal immediate checkpoint to acquire it after RUF semantics expose the When references.

## Simulation assumptions

### A-001 — Discovery scan before first KnowledgeTool call

- Status: active only if simulation continues without editing the prompt.
- Reason: necessary to reconcile MA-001.
- Interpretation: treat Section 3.3's explicit tool-call precondition as governing the first KnowledgeTool invocation; perform structural discovery first.
- This does not modify `Main_Agent_Prompt.txt`.

## Review method going forward

1. Keep `Main_Agent_Prompt.txt` frozen for the first pass.
2. Read only authorized files as they become relevant to the simulated control flow.
3. Before every major tool/agent handoff, record:
   - execution state,
   - exact data/payload shape to be handed off,
   - evidence source,
   - ambiguities/violations,
   - any explicit simulation assumption required to continue.
4. Never silently repair a prompt defect during simulation.
5. Update this ledger at major checkpoints and before especially context-heavy transitions.
6. After the first complete pass, consolidate accepted corrections and then rerun from the beginning against the corrected prompt.


## Checkpoint decisions after first KnowledgeTool reconciliation

### User decision D-001 — Rule-Obj-Model WHEN step condition field

- Applies specifically to a `WHEN` step inside `Rule-Obj-Model`.
- The supplied RUT is authoritative for this environment.
- The condition expression is read from `pyPropertiesName`.
- `rule-obj-model_knowledgearea.txt` mappings that state Rule-Obj-Model WHEN uses `pyCondition` are incorrect for this environment.
- MA-007 status: `PROPOSED_FIX_ACCEPTED`.
- Later correction target: update KT.17 / KT.25 and any related Rule-Obj-Model WHEN mappings so the WHEN-step condition comes from `pyPropertiesName`.

### User decision D-002 — Rule-Obj-Model formal parameter export shape

- Treat the supplied RUT as a correct example of the RuleJSON export contract.
- Formal parameter `CustomerID` is represented with `pyParametersParamName="CustomerID"` and `pyParametersParamType="STRING"`.
- KnowledgeArea guidance using only `pyParametersType` with values such as `String` is not sufficient for this environment.
- MA-008 status: `CONFIRMED_DEFECT`.
- Later correction must preserve the actual export field/value shape instead of normalizing it from memory.

### Simulation assumption A-002 — accepted for first-pass continuation

For this supplied RUT and environment, a `Rule-Obj-Model` WHEN step stores its executable condition in `pyPropertiesName`. Use that field during the first-pass simulation even though the current Model KnowledgeArea incorrectly points to `pyCondition`. This assumption records the user-confirmed intended runtime contract and does not amend repository files during the frozen first pass.

## Current execution position after decisions

`Main Agent -> GetCaseData conceptually completed -> structural discovery scan -> first semantic KnowledgeTool batch reconciled -> MA-007/MA-008 decisions recorded -> PAUSED before RuleCrawler tool-contract inspection and first crawl-wave construction`


## Checkpoint — RuleCrawler contract inspection before wave 1

### MA-009 — Main Agent RuleCrawler response contract versus allowed tool implementation

- Location: `Main_Agent_Prompt.txt` Section 7.3 versus `Rule_Crawler_tool.txt`.
- Type: interface/response-contract mismatch.
- Status: `OPEN` pending user confirmation of whether an unseen wrapper exists.
- Main Agent expectation: returned requested dependencies can be classified as parseable `RuleJSON`, `keyOnly`, or `missing`; fetched RuleJSON must then be scanned immediately.
- Observed allowed tool implementation: `ResolveCrawlerBatch--(String,String)` takes names of input/output clipboard pages, resolves supported `pxRuleReferences[]`, and copies them to output with `resolvedKey` populated when direct lookup succeeds. No `RuleJSON`, `keyOnly`, or `missing` payload production was found in the allowed file.
- Impact if this file is the complete RuleCrawler implementation: Main Agent cannot execute Section 7.3 dependency scanning/closure as written.
- Do not assume an unseen wrapper or post-processing step.

### MA-010 — Main Agent RuleCrawler request envelope versus tool parameter contract

- Location: Main Agent Section 5/7 request examples versus `Rule_Crawler_tool.txt` declared parameters.
- Type: interface/input-contract ambiguity.
- Status: `OPEN` pending user confirmation of wrapper/tool configuration.
- Main Agent constructs an object containing `_DWLState`, `_DWLPlan`, and `InterestedRules[]`.
- `Rule_Crawler_tool.txt` declares two String parameters: `inBatchPageName` and `outBatchPageName`; implementation reads `InterestedRules()` from the named clipboard page. `_DWLState` and `_DWLPlan` are not consumed by the observed function implementation.
- Possible explanation: a higher-level Pega agent-tool wrapper materializes the JSON object onto a clipboard page and later fetches RuleJSON. That wrapper is not evidenced by the currently allowed file, so it must not be assumed.

### MA-011 — Multiple occurrence D rows versus unique request-key projection

- Location: Main Agent dependency discovery and Section 7.2 planning.
- Type: clarity/format ambiguity.
- Status: `OPEN`, non-blocking for conceptual continuation if OUT is treated as unique canonical KEY projection.
- Prompt requires one D row per executable occurrence and says to use the same canonical KEY to deduplicate requests. The supplied RUT accesses `D_CustomerTestRef` multiple times, so multiple D rows can share one DP KEY.
- `_DWLPlan.OUT` is said to be mechanically derived from READY rows, but the exact uniqueness/count rule for duplicate READY occurrence keys is not stated explicitly.
- Likely intended semantics: `_DWLState` preserves occurrence rows, while `_DWLPlan.OUT` and actual RuleCrawler references are unique canonical KEYs.
- Suggested later clarification: state explicitly that OUT is the stable unique canonical-KEY projection of READY occurrence rows; ACT is compared against that unique-key set/list.

### First-wave dependency intent before interface resolution

Unique requestable dependency keys currently identified:

- `DP@Data-Customer@D_CustomerTestRef`
- `Prop@Data-Customer@Addresses`
- `Prop@Data-Address-Postal@pyCity`
- `Prop@Data-Address-Postal@pyPostalCode`
- `Prop@Data-Address-Postal@pyStreet`
- `RUF@@UTILITIES!ISINPAGELISTWHEN`
- `RUF@@UTILITIES!INDEXINPAGELISTWHEN`
- `RUF@@STRING!STRIPNONALPHABETICCHARS`
- `RUF@@STRING!TRIMNUMBER`
- `RUF@@STRING!TOUPPERCASE`

Context-blocked dependency currently known:

- `When@?@IsValidCity`, blocked until `Prop@Data-Customer@Addresses` proves its embedded PageList/PageGroup item class.

`IsValidPostalAddress` must not yet be materialized as a When dependency because the concrete `IndexInPageListWhen` RUF contract has not yet established the semantic role of its first argument.

## Current execution position

`Main Agent -> GetCaseData -> structural discovery -> first KnowledgeTool reconciliation -> user decisions for Model export fields -> RuleCrawler tool contract inspected -> PAUSED before constructing/sending wave 1 because MA-009/MA-010 require interface clarification`


---

## Checkpoint update — supplied real RuleCrawler dependency RuleJSON

Source: user-supplied real RuleCrawler-style response for the exact RUT holder
`RULE-OBJ-MODEL RULEIQ-DATA-TESTREFLIB PREPARECUSTOMERCOMMUNICATION #20260430T104351.201 GMT`.

The supplied response establishes concrete RuleJSON for:

- `RUF@@UTILITIES!ISINPAGELISTWHEN`
- `RUF@@UTILITIES!INDEXINPAGELISTWHEN`
- `RUF@@STRING!TRIMNUMBER`
- `RUF@@STRING!TOUPPERCASE`
- `RUF@@STRING!STRIPNONALPHABETICCHARS`
- `Prop@Data-Customer@Addresses` lookup, resolving to inherited rule
  `RULE-OBJ-PROPERTY @BASECLASS ADDRESSES ...`
- `DP@Data-Customer@D_CustomerTestRef`

No unavailable dependency content may be invented. Missing When/loader/scalar-property RuleJSON is a limitation of the external simulation evidence, not proof that the real Pega rules are missing.

### MA-009 — RuleCrawler does not return RuleJSON

- Previous status: OPEN.
- New status: `FALSE_POSITIVE / RESOLVED_BY_RUNTIME_EVIDENCE`.
- User supplied a real RuleCrawler conversation response where each resolved `pxRuleReferences[]` row includes both `resolvedKey` and complete serialized `RuleJSON`.
- Conclusion: the external RuleCrawler interface has enrichment beyond the lower-level resolver code visible in `Rule_Crawler_tool.txt`.
- No Main Agent correction required for expecting returned RuleJSON.

### MA-010 — Main Agent request envelope versus two-string resolver parameters

- Previous status: OPEN.
- New status: `FALSE_POSITIVE AS MAIN-AGENT DEFECT`.
- Runtime evidence proves that the LLM-visible RuleCrawler boundary is higher-level than the `ResolveCrawlerBatch--(String,String)` implementation.
- Retain only as documentation observation: `Rule_Crawler_tool.txt` alone does not describe the complete external agent-tool interface.

### MA-011 — occurrence rows versus unique physical requests

- Status: `CONFIRMED AMBIGUITY`.
- Prompt requires one `D` row per occurrence and also deduplicates requests by canonical KEY.
- Required clarification for later correction:
  `_DWLPlan.OUT` is the stable ordered unique canonical-KEY projection of all READY occurrence rows. Multiple READY D rows with the same canonical KEY produce exactly one physical request / OUT entry.
- `SCAN` semantics also need clarification: whether it lists all affected occurrence IDs or one representative D id per unique physical request.

### MA-012 — `_DWLPlan` example syntax conflicts with canonical KEY syntax

- Location: canonical `KEY = kind@class@name` versus concrete `_DWLPlan.OUT/ACT` examples such as `When:IsAlpha@Demo-Data-A`.
- Type: format inconsistency.
- Status: `CONFIRMED_DEFECT`.
- Required later correction: use exact canonical KEY syntax in `_DWLPlan.OUT` and `_DWLPlan.ACT` everywhere.

### MA-013 — Data Page scope case mismatch

- Source RuleJSON: `D_CustomerTestRef.pyScope = "thread"`.
- KnowledgeArea KDP.2 currently recognizes exact `"Thread"`, `"Requestor"`, `"Node"` and treats every other spelling/value as ineligible/unresolved.
- Type: runtime field-value contract mismatch.
- User decision: **Accepted** — lowercase `thread` is the correct actual Thread-scope export value in this environment.
- Status: `PROPOSED_FIX_ACCEPTED`.
- Impact under the current prompt: real Thread-scope Data Page `"thread"` would be incorrectly classified INELIGIBLE, preventing valid Data Page simulation and changing coverage.
- Accepted correction direction: align KDP.2 with the actual exported scope values used by this environment. Preserve the raw RuleJSON value as evidence; if normalization is used for comparison, it must be explicit and deterministic.

### MA-014 — `stripNonAlphabeticChars` return semantics unavailable under KRUF evidence allowlist

- Supplied RuleJSON:
  - `pyLabel = "Removes non-alphabetic characters in a string"`
  - `pyDescription = ""`
  - `pyUsage = ""`
  - parameter usage empty.
- KRUF.12 currently allows prompt helper, `pyParameterUsage`, `pyDescription`, `pyUsage`, or implementation to establish return behavior; it does not list `pyLabel`.
- User decision: **Yes** — a fetched non-empty `pyLabel` may be used as fallback behavior evidence when stronger concrete fields are empty and the label unambiguously describes the function behavior.
- Status: `PROPOSED_FIX_ACCEPTED`.
- Accepted correction direction: extend the concrete RUF behavior-evidence hierarchy to permit unambiguous `pyLabel` as a fallback after stronger fields are unavailable.
- Simulation effect: `String stripNonAlphabeticChars` is considered semantically sufficient for the continued simulation.

### MA-015 — inherited property resolution versus exact canonical KEY closure

- Requested context/reference is `Data-Customer / Addresses`.
- RuleCrawler response wrapper retains `pxRuleClassName = "Data-Customer"`, but returned `RuleJSON.pyClassName = "@baseclass"` and `resolvedKey` is the inherited @baseclass property.
- Prompt says a D row closes only by exact KEY and the same rule name on a different class never closes the row.
- Status: `AMBIGUITY`.
- Likely intended Pega semantics: canonical dependency KEY class represents lookup/runtime context (`Data-Customer`), while `resolvedKey` may legally identify an inherited ancestor rule. Matching the returned wrapper to the requested KEY plus preserving the actual resolvedKey allows closure.
- Required later clarification: inherited resolution from an ancestor class is valid closure for the original lookup-context KEY only when RuleCrawler returned it for that exact request; do not rewrite the occurrence KEY to the ancestor class merely because RuleJSON.pyClassName differs.

### MA-016 — Simulated Data Page loader should be a hard dependency boundary

- Source: fetched `D_CustomerTestRef` RuleJSON exposes loader/source `Data-Customer.LoadCustomerTestRef`.
- Type: crawl-boundary ambiguity.
- User decision: **Yes** — once an eligible Data Page is selected for simulation, its underlying loader/source rule is outside the runtime dependency crawl solely by virtue of being the Data Page source.
- Status: `PROPOSED_FIX_ACCEPTED`.
- Accepted correction direction: crawl the Data Page metadata required for scope, structure, parameters/signature, context, and simulation; do not recursively crawl its loader merely because it appears in Data Page source metadata when simulation replaces that Data Page boundary.
- Consequence for this simulation: do not create/request `Model@Data-Customer@LoadCustomerTestRef` solely from `D_CustomerTestRef` source metadata.

### Reopened MA-002 — Rule-Obj-When KnowledgeArea checkpoint dead zone

- Previous tentative status: resolved by RUF KnowledgeArea.
- New status: `CONFIRMED AMBIGUITY / likely defect`.
- `Rule-Utility-Function_KnowledgeArea` reveals during the first KnowledgeTool response that `IsInPageListWhen` argument 1 is a Rule-Obj-When.
- Therefore Rule-Obj-When semantic type becomes known AFTER first KnowledgeTool call but BEFORE first RuleCrawler wave.
- Section 3.3 does not permit an immediate second KnowledgeTool batch; its later checkpoint is phrased as after a RuleCrawler wave when newly scanned RuleJSON reveals previously unknown semantic rule types.
- After Wave 1, `Addresses.pyPageClass` makes the When dependency concrete (`When@Data-Address-Postal@IsValidCity`) but the rule type itself was already known before the wave. A literal model can therefore conclude the second KnowledgeTool checkpoint condition is not satisfied.
- If the When is requested without its KnowledgeArea and returned in Wave 2, Section 7.3 requires immediate scan, leaving no legal opportunity to acquire Rule-Obj-When guidance before scanning it.
- Recommended later correction: either allow first-batch syntactic enqueueing of dependency KnowledgeAreas, or allow a KnowledgeTool checkpoint whenever a required semantic key becomes newly pending/concrete after semantic reconciliation or a RuleCrawler wave, not only when a newly scanned RuleJSON reveals a previously unknown type.

## Wave 1 supplied evidence — deterministic scan facts

### Addresses property

Returned property semantics:
- actual resolved rule applies to `@baseclass`
- `pyPropertyMode = PageList`
- `pyPageClass = Data-Address-Postal`

Consequences:
- `D_CustomerTestRef.Addresses` is proven as a PageList context with item class `Data-Address-Postal`.
- The context-blocked dependency becomes:
  `When@Data-Address-Postal@IsValidCity` -> READY for a subsequent RuleCrawler wave.
- Preserve inherited resolution evidence; do not silently replace the original lookup-context KEY.

### D_CustomerTestRef

Returned facts:
- `pyClassName = Data-Customer`
- `pyScope = "thread"`
- `pyStructure = "page"`
- formal `CustomerID` parameter exists with type `STRING`
- loader/data source is Data Transform `LoadCustomerTestRef`
- exact rule reference identifies `Rule-Obj-Model LoadCustomerTestRef` on `Data-Customer`

Consequences:
- symbolic Data Page caller binding is `CustomerID = Param.CustomerID` because the RUT has matching current formal input and the access is bare.
- new executable loader dependency candidate:
  `Model@Data-Customer@LoadCustomerTestRef`
- literal KDP.2 currently misclassifies `"thread"` unless MA-013 is corrected/assumed for simulation.

### IsInPageListWhen RUF

Returned facts:
- description: returns true when any page has the match
- first formal parameter: String, usage = block name for comparison
- second formal parameter: ClipboardProperty, usage = page list to look in

Together with KRUF.10:
- first argument `IsValidCity` is a Rule-Obj-When name
- second argument `D_CustomerTestRef.Addresses` is the page-list context
- return semantics are sufficiently evidenced for Boolean branch use once the nested When result is known.

### IndexInPageListWhen RUF

Returned facts:
- description: returns index of first page-list entry for which the specified when is satisfied
- usage: 1-based index on match, `-1` on no match
- first formal param = String; second = ClipboardProperty; per-parameter usage fields are blank

Status:
- return semantics are evidenced.
- executable-role classification of first argument `IsValidPostalAddress` is semantically strong but not as explicit as IsInPageListWhen because KRUF.10 does not list IndexInPageListWhen and parameter usage is blank.
- Do not silently invent the dependency; review whether the function-level description plus positional contract is considered an unambiguous equivalent named-rule role under KRUF.5/KRUF.6.

### String RUF pipeline

`toUpperCase`:
- usage explicitly establishes uppercase-equivalent return -> sufficient concrete contract.

`TrimNumber`:
- description establishes number removal from strings; exact behavior may still depend on how broadly "numbers" is interpreted, but the function contract supplies concrete transformation semantics.

`stripNonAlphabeticChars`:
- only pyLabel explains behavior; KRUF current evidence allowlist does not include pyLabel -> see MA-014.

## Current execution position

`Main Agent -> GetCaseData -> discovery -> first KnowledgeTool batch -> Wave 1 dependency RuleJSON supplied -> scanning Wave 1 -> PAUSED before finalizing DWLDELTA / second semantic-acquisition decision / Wave 2 plan`.


---

## User decisions after Wave 1 review

The user explicitly accepted the following intended semantics for the correction pass and continued simulation:

### MA-013 — Data Page scope export values

- Decision: accepted.
- Actual environment export uses lowercase `thread` for Thread scope.
- Status: `PROPOSED_FIX_ACCEPTED`.
- Later correction must align KDP.2 with actual exported values. Preserve raw value for evidence; normalize only for eligibility comparison if normalization is used.

### MA-014 — RUF pyLabel fallback evidence

- Decision: `Yes`.
- Status: `PROPOSED_FIX_ACCEPTED`.
- Intended contract: when stronger concrete fields (`pyParameterUsage`, `pyDescription`, `pyUsage`, implementation) do not establish behavior, a non-empty concrete fetched RUF `pyLabel` may serve as fallback semantic evidence when it unambiguously describes the function behavior.
- For supplied `String stripNonAlphabeticChars`, label `Removes non-alphabetic characters in a string` is accepted behavior evidence.

### MA-016 — simulated Data Page is a hard dependency boundary

- Decision: `Yes`.
- Status: `PROPOSED_FIX_ACCEPTED`.
- Intended contract: once a Data Page is eligible and selected for simulation, its underlying loader/source rule is not recursively crawled merely because it appears in the Data Page RuleJSON. Crawl the Data Page metadata needed for scope, shape, parameters/signature, context, and simulation only. Loader dependencies are outside runtime execution because simulation replaces the Data Page boundary.
- Therefore do NOT create `Model@Data-Customer@LoadCustomerTestRef` solely from the simulated `D_CustomerTestRef` source metadata.

## Synthetic-fixture authorization for unavailable dependency content

The user stated that the supplied Wave 1 data is the only real dependency content they can share and that missing content needed to continue should be simulated.

Simulation policy:
- Synthetic RuleJSON may be introduced only when necessary to exercise later prompt/control-flow behavior.
- Every synthetic fixture must be explicitly labeled `SYNTHETIC_SIMULATION_FIXTURE`.
- Synthetic fixture content is not repository evidence, not user-supplied Pega data, and not a factual claim about the real application.
- Prefer minimal fixtures that test the relevant prompt semantics rather than inventing large business rule bodies.
- Repository/tool defects may be concluded only from repository contracts, user-supplied real runtime evidence, or contradictions exposed independently of the synthetic business values.
- Scenario outputs derived from synthetic fixtures remain simulation-only and cannot be represented as expected production unit-test values.

## Current continuation assumptions

- A-003 is now an accepted intended correction rather than merely a temporary assumption: raw `pyScope="thread"` is Thread scope and simulation-eligible.
- A-004 remains the simulation bridge for MA-002: permit acquisition of pending `Rule-Obj-When_KnowledgeArea` after Wave 1 before requesting/scanning concrete When rules.
- Do not recursively crawl `LoadCustomerTestRef` after deciding to simulate `D_CustomerTestRef`.
- Allow fetched non-empty RUF `pyLabel` as fallback behavior evidence when stronger fields are empty and the label is unambiguous.

## Current execution position

`Main Agent -> Wave 1 response processed -> user decisions locked -> pending Rule-Obj-When KnowledgeTool acquisition -> Wave 2 planning`.


---

## Checkpoint — synthetic completion of unavailable dependency content and crawl closure

This checkpoint uses two evidence classes:

1. REAL EVIDENCE:
   - repository prompt / KnowledgeAreas read from GitHub,
   - user-supplied RUT,
   - user-supplied Wave 1 RuleCrawler response.
2. SYNTHETIC_SIMULATION_FIXTURE:
   - only dependency RuleJSON that the user cannot provide and explicitly authorized us to simulate.

Synthetic fixtures test control flow only. They are not factual claims about the real Pega application.

## Synthetic Wave 1 property fixtures

To complete the already-requested scalar property dependencies without re-requesting them:

### SYN-P1
`Prop@Data-Address-Postal@pyCity`

Minimal simulated definition:
- `pxObjClass = Rule-Obj-Property`
- `pyClassName = Data-Address-Postal`
- `pyRuleName = pyCity`
- `pyPropertyMode = Value`
- `pyStringType = Text`
- no executable dependencies.

### SYN-P2
`Prop@Data-Address-Postal@pyPostalCode`

Minimal simulated definition:
- `pxObjClass = Rule-Obj-Property`
- `pyClassName = Data-Address-Postal`
- `pyRuleName = pyPostalCode`
- `pyPropertyMode = Value`
- `pyStringType = Text`
- no executable dependencies.

### SYN-P3
`Prop@Data-Address-Postal@pyStreet`

Minimal simulated definition:
- `pxObjClass = Rule-Obj-Property`
- `pyClassName = Data-Address-Postal`
- `pyRuleName = pyStreet`
- `pyPropertyMode = Value`
- `pyStringType = Text`
- no executable dependencies.

These fixtures are chosen only to permit property typing and When evaluation in the simulation.

## Wave 1 post-scan result under accepted decisions

Closed unique keys:
- `DP@Data-Customer@D_CustomerTestRef`
- `Prop@Data-Customer@Addresses`
- `Prop@Data-Address-Postal@pyCity`
- `Prop@Data-Address-Postal@pyPostalCode`
- `Prop@Data-Address-Postal@pyStreet`
- `RUF@@UTILITIES!ISINPAGELISTWHEN`
- `RUF@@UTILITIES!INDEXINPAGELISTWHEN`
- `RUF@@STRING!TOUPPERCASE`
- `RUF@@STRING!TRIMNUMBER`
- `RUF@@STRING!STRIPNONALPHABETICCHARS`

Data Page:
- raw `pyScope=thread` -> eligible by accepted MA-013 correction.
- `CustomerID` declaration resolved.
- crawl binding `CustomerID=Param.CustomerID`.
- reachable/unknown accesses remain `SIM` obligations for Author mode.
- hard simulation boundary accepted by MA-016: do NOT add/crawl `Model@Data-Customer@LoadCustomerTestRef`.

Promoted/new executable dependencies:
- `When@Data-Address-Postal@IsValidCity` -> READY.
- `When@Data-Address-Postal@IsValidPostalAddress` -> READY.

Pending semantic key:
- `Rule-Obj-When_KnowledgeArea`.

## KnowledgeTool checkpoint 2 under A-004 / MA-002 bridge

Exact request:
`Rule-Obj-When_KnowledgeArea`

After simulated successful KnowledgeTool mapping:
- add `Rule-Obj-When_KnowledgeArea` to `KA`.
- clear it from `PKA`.
- no other pending semantic keys.

This call is logically required but not literally legal under the current Section 3.3 wording; MA-002 remains a confirmed prompt defect requiring a later correction.

## Wave 2 exact dependency request

Unique OUT:
- `When@Data-Address-Postal@IsValidCity`
- `When@Data-Address-Postal@IsValidPostalAddress`

Synthetic non-RUF references under original RUT holder:

```json
{
  "InterestedRules": [
    {
      "pyItemRuleId": "RULE-OBJ-MODEL RULEIQ-DATA-TESTREFLIB PREPARECUSTOMERCOMMUNICATION #20260430T104351.201 GMT",
      "pxRuleReferences": [
        {
          "pxObjClass": "Embed-Reference-Rule",
          "pxRuleClassName": "Data-Address-Postal",
          "pyRuleName": "IsValidCity",
          "pxRuleObjClass": "Rule-Obj-When",
          "pxRuleFamilyName": "ISVALIDCITY"
        },
        {
          "pxObjClass": "Embed-Reference-Rule",
          "pxRuleClassName": "Data-Address-Postal",
          "pyRuleName": "IsValidPostalAddress",
          "pxRuleObjClass": "Rule-Obj-When",
          "pxRuleFamilyName": "ISVALIDPOSTALADDRESS"
        }
      ]
    }
  ]
}
```

For review normalization, `_DWLPlan.OUT` and `ACT` use canonical `kind@class@name` syntax per MA-012's proposed correction.

## Synthetic Wave 2 RuleJSON fixtures

### SYN-W1 — IsValidCity

Purpose: create a deterministic Boolean predicate requiring `pyCity` so the outer `IsInPageListWhen` branch can be simulated.

```json
{
  "pxObjClass": "Rule-Obj-When",
  "pyClassName": "Data-Address-Postal",
  "pyRuleName": "IsValidCity",
  "pzInsKey": "<SYNTHETIC_ISVALIDCITY_PZINSKEY>",
  "pyLogic": "A",
  "pyCondition": [
    {
      "pyConditionLabel": "A",
      "pyConditionValue1": ".pyCity != ''",
      "pyConditionValue1Purpose": "1FreeFormExpressionBoolean"
    }
  ],
  "pxRuleReferences": [
    {
      "pxObjClass": "Embed-Reference-Rule",
      "pxRuleClassName": "Data-Address-Postal",
      "pxRuleFamilyName": "PYCITY",
      "pxRuleObjClass": "Rule-Obj-Property",
      "pyRuleName": "pyCity"
    }
  ],
  "pyParameters": []
}
```

This fixture has no new executable dependency; its property dependency is already CLOSED.

### SYN-W2 — IsValidPostalAddress

Purpose: create a deterministic Boolean predicate requiring `pyPostalCode` so `IndexInPageListWhen` can return either a 1-based matching index or -1.

```json
{
  "pxObjClass": "Rule-Obj-When",
  "pyClassName": "Data-Address-Postal",
  "pyRuleName": "IsValidPostalAddress",
  "pzInsKey": "<SYNTHETIC_ISVALIDPOSTALADDRESS_PZINSKEY>",
  "pyLogic": "A",
  "pyCondition": [
    {
      "pyConditionLabel": "A",
      "pyConditionValue1": ".pyPostalCode != ''",
      "pyConditionValue1Purpose": "1FreeFormExpressionBoolean"
    }
  ],
  "pxRuleReferences": [
    {
      "pxObjClass": "Embed-Reference-Rule",
      "pxRuleClassName": "Data-Address-Postal",
      "pxRuleFamilyName": "PYPOSTALCODE",
      "pxRuleObjClass": "Rule-Obj-Property",
      "pyRuleName": "pyPostalCode"
    }
  ],
  "pyParameters": []
}
```

This fixture also has no new executable dependency; its property dependency is already CLOSED.

## Wave 2 scan result

`IsValidCity`:
- copy `pyLogic="A"` verbatim.
- one condition row A.
- property read `.pyCity`.
- exact property dependency link already CLOSED.
- no nested executable rules/RUFs.
- When can transition FETCHED -> SCANNED -> CLOSED.

`IsValidPostalAddress`:
- copy `pyLogic="A"` verbatim.
- one condition row A.
- property read `.pyPostalCode`.
- exact property dependency link already CLOSED.
- no nested executable rules/RUFs.
- When can transition FETCHED -> SCANNED -> CLOSED.

## Crawl closure

Final unique CLOSED dependency keys for this simulation:
- `DP@Data-Customer@D_CustomerTestRef`
- `Prop@Data-Customer@Addresses`
- `Prop@Data-Address-Postal@pyCity`
- `Prop@Data-Address-Postal@pyPostalCode`
- `Prop@Data-Address-Postal@pyStreet`
- `RUF@@UTILITIES!ISINPAGELISTWHEN`
- `RUF@@UTILITIES!INDEXINPAGELISTWHEN`
- `RUF@@STRING!TOUPPERCASE`
- `RUF@@STRING!TRIMNUMBER`
- `RUF@@STRING!STRIPNONALPHABETICCHARS`
- `When@Data-Address-Postal@IsValidCity`
- `When@Data-Address-Postal@IsValidPostalAddress`

Final state:
- open=0
- ready=0
- ctx=0
- unscanned=0
- gaps=0
- Data Page runtime simulation obligation remains intentionally outside crawl closure.

`STATECHECK.preAuthor = PASS`
`CRAWL_STATUS = CLOSED`

Crawler census for this simulated run:
- RuleCrawler calls = 2
- physical unique requested references = 12
- triggered limits = absent

KnowledgeTool calls = 2 under the intended corrected acquisition semantics.

## Current execution position

`Main Agent -> dependency crawl CLOSED -> STATECHECK.preAuthor PASS -> PAUSED before Section 8+ semantic execution / Section 11 Scenario Compiler inventory`.


---

## Checkpoint — runtime path analysis and Scenario Compiler INVENTORY

### Evidence boundary

REAL:
- original user-supplied Rule-Obj-Model RUT,
- real Wave 1 dependency RuleJSON supplied by the user,
- live repository Main Agent / KnowledgeArea contracts.

SYNTHETIC_SIMULATION_FIXTURE:
- unavailable scalar property definitions,
- unavailable `IsValidCity` and `IsValidPostalAddress` When RuleJSON,
- synthetic CaseID placeholder used only because real `GetCaseData.pyID` was never supplied.

No synthetic dependency behavior creates Scenario targets. Section 11 inventory is original-RUT-only.

### MA-006 — missing initial pyID guard

- Previous status: OPEN.
- Status now: `CONFIRMED_DEFECT`.
- Section 4 initial validation requires only non-empty `RuleJSON.pzInsKey` and `RuleJSON.pxObjClass`.
- Section 11 `SCENARIO_SNAPSHOT` requires `P|phase|pyID|pzInsKey|RUT_TYPE`.
- Section 1A later requires every storage/generator `CaseID` to be exact `GetCaseData.pyID`.
- Therefore the current prompt can proceed deeply with missing pyID and discover the fatal identity gap only much later.
- Accepted proposed correction for later review:
  require non-empty `GetCaseData.pyID`, `RuleJSON.pzInsKey`, and `RuleJSON.pxObjClass` at the initial gate.
- Simulation bridge only:
  use `<SYNTHETIC_pyID>` inside review-only snapshots. Never treat it as actual CaseID.

## Original-RUT runtime control skeleton

Common:
1. `UPDATE_PAGE CustomerCommunication WITH_VALUES_FROM D_CustomerTestRef`.
2. Evaluate Model WHEN step 1.1:
   `!@IsInPageListWhen("IsValidCity", D_CustomerTestRef.Addresses)`.

Path A — invalid/no valid city:
- `IsInPageListWhen` false -> negation true.
- execute step 1.1.1: `Param.ExitCode = "-1 City Not valid"`.
- execute step 1.1.2: `EXIT_MODEL`.
- steps 1.2 and 1.3 are not evaluated.

Path B — valid city exists:
- `IsInPageListWhen` true -> negation false.
- skip 1.1 children.
- execute 1.2:
  `Param.AddressIndex = @IndexInPageListWhen("IsValidPostalAddress", D_CustomerTestRef.Addresses)`.
- evaluate step 1.3 `Param.AddressIndex > 0`.

Path B1 — postal match:
- index is 1-based positive.
- execute APPEND_AND_MAP_TO and its children.
- append/copy selected postal address into `CustomerCommunication.Addresses`.
- copy city/postal/street fields.
- compute `Param.StreetName` through nested `toUpperCase -> TrimNumber -> stripNonAlphabeticChars`.

Path B0 — no postal match:
- IndexInPageListWhen result = -1 under fetched real RUF contract.
- step 1.3 false; APPEND_AND_MAP_TO children do not execute.
- Model ends normally.

## Scenario Compiler INVENTORY interpretation

Section 11 Rule-Obj-Model adapter requires:
- every reachable original-RUT WHEN true arm,
- false edges only when they reach OTHERWISE, EXIT/error, or different later owner execution,
- explicit EXIT/error edges,
- no dependency-only target expansion,
- no new T for dependency result/index variants that reach the same owner arm and later execution.

Therefore the inventory contains four R targets:

### T1 — step 1.1 true arm

- id: `1.1:true`
- source: original RUT steps `1,1.1,1.1.1`
- behavior: first Model WHEN true -> invalid/no valid city arm executes and sets ExitCode.
- state: R
- proof: original RUT branch is reachable with a Data Page payload containing no address satisfying `IsValidCity`.

### T2 — explicit EXIT edge

- id: `1.1.2:exit`
- source: original RUT step `1.1.2`
- behavior: `EXIT_MODEL` terminates execution after invalid-city handling.
- state: R
- proof: T1 true arm reaches the explicit EXIT operation.

### T3 — step 1.1 false continuation edge

- id: `1.1:false:continue`
- source: original RUT steps `1,1.1,1.2,1.3`
- behavior: valid city exists, first WHEN false, execution continues to postal-index calculation and the second WHEN.
- state: R
- proof: Section 11 requires a false edge when it produces different later original-RUT execution.

### T4 — step 1.3 true arm

- id: `1.3:true`
- source: original RUT steps `1.3,1.3.1,1.3.1.1,1.3.1.2,1.3.1.3,1.3.1.4`
- behavior: positive postal-match index executes append/map and nested property/RUF writes.
- state: R
- proof: reachable original-RUT WHEN true arm.

### Why there is no separate `1.3:false` T

Under the literal Rule-Obj-Model adapter:
- a false edge does not require its own T merely because the true child arm is skipped;
- it becomes a target only when it reaches OTHERWISE, EXIT/error, or different later owner execution;
- step 1.3 is terminal and has no later owner execution after its false result;
- there is no ELSE/OTHERWISE or explicit error/EXIT on the false edge.

The no-postal-match path remains a valid possible execution and may be useful for assertion testing later, but it is not an owner-coverage target under the current Section 11 cardinality contract.

### Why index 1 versus index 2 does not create targets

`AddressIndex` is a dependency-produced intermediate result. Section 11 explicitly says dependency result/intermediate variants selecting the same original-RUT arm and later execution never create T. Therefore matching first address vs second/later address is witness detail, not Scenario cardinality.

## INVENTORY snapshot

Because real pyID is unavailable, the review-only P row uses a synthetic placeholder:

```text
P|I|<SYNTHETIC_pyID>|RULE-OBJ-MODEL RULEIQ-DATA-TESTREFLIB PREPARECUSTOMERCOMMUNICATION #20260430T104351.201 GMT|Rule-Obj-Model
T|1.1:true|1,1.1,1.1.1|invalid_city_arm|-|R|original_model_when_true
T|1.1.2:exit|1.1.2|terminate_after_invalid_city|-|R|explicit_exit_model
T|1.1:false:continue|1,1.1,1.2,1.3|continue_to_postal_evaluation|-|R|false_edge_reaches_different_later_owner_execution
T|1.3:true|1.3,1.3.1,1.3.1.1,1.3.1.2,1.3.1.3,1.3.1.4|append_selected_postal_address|-|R|reachable_model_when_true_arm
```

No `S` rows exist in INVENTORY.

## Minimum witness implication

The four R targets are compatible with two physical executions:

- Witness candidate W1 covers `1.1:true` + `1.1.2:exit`.
- Witness candidate W2 covers `1.1:false:continue` + `1.3:true`.

The targets are mutually incompatible across these two paths because W1 terminates the Model before the postal branch, while W2 requires first-WHEN false and later execution.

Therefore the current lower bound and likely frozen cardinality is:
`2 physical Scenarios`.

This is not frozen yet. WITNESSES must still prove both can be represented with safe setup + DP simulation, execute the full original RUT, and pass seed/runtime constraints.

## Current execution position

`crawl CLOSED -> preAuthor PASS -> runtime path analysis complete -> Scenario Compiler INVENTORY complete -> PAUSED before WITNESSES`.


---

## User correction — include the terminal false arm of Model WHEN step 1.3

The user reviewed the INVENTORY and explicitly rejected omission of the `1.3:false` path.

User rationale:
- `Param.AddressIndex <= 0` is a valid original-RUT execution path.
- The guarded `APPEND_AND_MAP_TO .Addresses` does not execute.
- This path can verify the negative behavior that no append occurred.

### Review conclusion

The user is correct. This is not merely a dependency-result variant. It is a distinct original-RUT behavioral outcome because the branch result changes execution of an original-RUT list producer.

The current Section 11 Rule-Obj-Model adapter is too narrow when it says a false edge needs no separate T unless it reaches OTHERWISE, EXIT/error, or different later owner execution. A terminal false edge can still be materially different when it suppresses an original-RUT side-effecting producer or output mutation.

### MA-017 — terminal false Model edge with suppressed producer can be lost

- Location: Section 11 Scenario Compiler, Rule-Obj-Model coverage adapter.
- Type: coverage/cardinality defect.
- Status: `CONFIRMED_DEFECT`.
- Current wording can omit a reachable terminal false edge when no later owner executes.
- In this RUT, step `1.3:false` suppresses `APPEND_AND_MAP_TO .Addresses`, producing a behaviorally distinct final state from `1.3:true`.
- This path is therefore a required Scenario target.

Proposed correction for later consolidated edit:

> For a reachable original-RUT WHEN, create a required target for each outcome that changes original-RUT observable execution: executing or suppressing a modifying producer, reaching OTHERWISE, EXIT/error, or changing later owner execution. A false edge may be treated as covered without its own T only when it is proven behaviorally non-effective: it reaches no distinct alternative/termination/later execution and suppresses no original-RUT producer whose effect or non-effect is observable.

### Assertion nuance for `1.3:false`

The semantic assertion goal is:
`APPEND_AND_MAP_TO .Addresses did not modify the target list`.

Do not automatically equate this with `.Addresses Not exists`.

Under the final-presence rules:
- skipped operations preserve prior state;
- `Not exists` requires proven final absence;
- if the initial/frozen witness proves the target list absent before step 1.3, `Not exists` may be valid;
- if the witness establishes a pre-existing list/count, verify that the list remains unchanged instead;
- exact ResultCount is allowed only when every producer affecting the list has terminal execution proof.

Therefore WITNESSES must freeze enough initial/simulation state to make the non-append observable without inventing absence.

## Revised INVENTORY

Required targets are now:

### T1 — step 1.1 true arm
`1.1:true`
- invalid/no-valid-city branch executes.

### T2 — explicit EXIT edge
`1.1.2:exit`
- Model terminates after invalid-city handling.

### T3 — step 1.1 false continuation
`1.1:false:continue`
- valid city exists; execution continues to postal evaluation.

### T4 — step 1.3 true arm
`1.3:true`
- positive postal-match index; `APPEND_AND_MAP_TO` executes.

### T5 — step 1.3 false non-append arm
`1.3:false:no_append`
- non-positive postal-match index; guarded `APPEND_AND_MAP_TO` is skipped and `.Addresses` receives no mutation from this producer.

Review-only snapshot:

```text
P|I|<SYNTHETIC_pyID>|RULE-OBJ-MODEL RULEIQ-DATA-TESTREFLIB PREPARECUSTOMERCOMMUNICATION #20260430T104351.201 GMT|Rule-Obj-Model
T|1.1:true|1,1.1,1.1.1|invalid_city_arm|-|R|original_model_when_true
T|1.1.2:exit|1.1.2|terminate_after_invalid_city|-|R|explicit_exit_model
T|1.1:false:continue|1,1.1,1.2,1.3|continue_to_postal_evaluation|-|R|false_edge_reaches_different_later_owner_execution
T|1.3:true|1.3,1.3.1,1.3.1.1,1.3.1.2,1.3.1.3,1.3.1.4|append_selected_postal_address|-|R|reachable_model_when_true_arm
T|1.3:false:no_append|1.3,1.3.1|no_postal_append|-|R|false_edge_suppresses_observable_original_rut_producer
```

## Revised minimum witness implication

Minimum physical witness lower bound is now 3:

- W1: `1.1=true` -> ExitCode + EXIT; covers T1,T2.
- W2: `1.1=false`, `1.3=true` -> append/map; covers T3,T4.
- W3: `1.1=false`, `1.3=false` -> no append; covers T3,T5.

W2 and W3 cannot merge because the same execution cannot make the same step 1.3 both true and false.
W1 cannot cover either later branch because EXIT_MODEL terminates before step 1.2/1.3.

Predicted Scenario cardinality entering WITNESSES:
`3`.

This is still not FROZEN until WITNESSES proves all three physical representations are valid and executable.


---

## Checkpoint — Scenario Compiler WITNESSES

### Evidence boundary

REAL:
- original user-supplied Rule-Obj-Model RUT;
- user-supplied real Wave 1 dependency RuleJSON;
- live Main Agent, Rule-Obj-Model, Rule-Declare-Pages, Rule-Obj-When and RUF KnowledgeArea contracts;
- user decisions already recorded in MA-013, MA-014, MA-016, MA-017.

SYNTHETIC_SIMULATION_FIXTURE:
- unavailable scalar property definitions;
- unavailable `IsValidCity` and `IsValidPostalAddress` When RuleJSON;
- concrete test value `CustomerID="CUST-001"`;
- Data Page payload values used only to exercise the three required paths.

No synthetic business value is claimed to exist in the real Pega application.

## Additional defects/ambiguities exposed during WITNESSES

### MA-018 — `SCENARIO_SNAPSHOT.S.given` has no exact canonical JSON schema

- Location: Section 11 `SCENARIO_SNAPSHOT`.
- Status: `CONFIRMED_AMBIGUITY`.
- Contract says `given` is “canonical minified typed JSON for all RUT parameters, setup inputs, and Rule-Obj-When cells”.
- It does not define the exact JSON root shape, field names, ordering model, or typed carrier shape.
- Yet FROZEN cost ordering and exact duplicate comparison use canonical `given+simulation`.
- Two compliant models can serialize identical semantic inputs differently and therefore make different merge/order decisions.

Review-only normalization used below:
```json
{
  "parameters": {
    "CustomerID": {
      "formalType": "STRING",
      "valueType": "string",
      "value": "CUST-001"
    }
  },
  "setup": [],
  "whenCells": []
}
```

This normalization is NOT claimed to be the repository-defined format.

Recommended later correction:
- define an exact `given` schema; preferably make it a canonical projection of the Section 13 PARAM/INPUT/SETUP semantic carriers instead of maintaining a parallel implicit format.

### MA-019 — `APPEND_AND_MAP_TO` child source/target context is underspecified

- Location: `rule-obj-model_knowledgearea.txt` KT.22/KT.23/KT.27.
- Status: `OPEN — semantic assumption required`.
- Current guidance says `APPEND_AND_MAP_TO -> LIST_APPEND`, but does not define:
  - how `pyPropertiesValue`/`EXISTING_PAGE` selects the source page;
  - whether child relative RHS `.pyCity` resolves against the source page;
  - whether child relative LHS `.pyCity` resolves against the newly appended target item;
  - how source context is restored after the operation.
- The supplied correct RUT uses exactly this pattern:
  `APPEND_AND_MAP_TO .Addresses FROM D_CustomerTestRef.Addresses(Param.AddressIndex)`
  followed by `.pyCity=.pyCity`, `.pyPostalCode=.pyPostalCode`, `.pyStreet=.pyStreet`.

Simulation assumption A-005:
- append one new item to `CustomerCommunication.Addresses`;
- child relative write targets resolve to the new appended item;
- child relative value references resolve to the explicit EXISTING_PAGE source item;
- after the child scope, parent context is restored.

This is the only interpretation that makes the user-confirmed RUT mapping pattern semantically meaningful, but it needs explicit KnowledgeArea wording.

### MA-020 — simulation seed-depth rule conflicts with dependency-required page-list item fields

- Location: Main Agent Section 9.1/9.2.
- Status: `CONFIRMED_DEFECT`.
- Original RUT helper accesses `D_CustomerTestRef.Addresses` as a list.
- Closed nested When rules then require item fields such as `.pyCity` and `.pyPostalCode`.
- Section 9.1 says RUT access depth is authoritative and says not to seed nested properties when the RUT accesses top-level.
- Literal application can forbid `Addresses(1).pyCity` / `Addresses(1).pyPostalCode`, making the required nested When evaluation impossible.
- These item fields are not speculative Data Page structure; they are execution inputs of closed dependencies invoked by the RUT helper.

Simulation assumption A-006:
- RUT path tokens and collection navigation are locked by the original RUT (`Addresses`);
- item indexes/count are locked by the selected witness;
- within those evidenced items, seed leaf properties required by closed executable dependencies (`pyCity`, `pyPostalCode`, and when reached `pyStreet`);
- dependency-required leaves do not constitute unauthorized deepening of the original RUT collection path.

Recommended correction:
> RUT access depth locks the Data Page collection/navigation carrier. It does not prohibit leaf fields required by a closed executable dependency invoked on an evidenced collection item. Such dependency-required leaves may be seeded only inside the exact RUT-evidenced collection path and witness-locked items.

### MA-021 — `DP_SIG` has semantic components but no exact serialization grammar

- Location: Sections 5.0, 9.0, 13.4.5.
- Status: `CONFIRMED_AMBIGUITY`.
- Contract defines `DP_SIG = DP KEY + normalized parameter set`, but does not define exact delimiters, ordering syntax, escaping, or typed-value representation for the signature string.
- Section 13 later requires exact frozen `sig=<DP_SIG>`.
- This can affect equality, DPA matching, and deterministic rematerialization.

Review-only signature notation:
`DP@Data-Customer@D_CustomerTestRef|CustomerID=string:CUST-001`

This is NOT claimed to be the repository canonical representation.

Recommended correction:
- define DP_SIG as canonical minified typed JSON or an exact textual grammar, including lexical parameter ordering and typed carriers.

## Common witness carrier facts

Review-only formal RUT input:
- `Param.CustomerID = "CUST-001"`
- formal source type = exact user-supplied `STRING`
- MA-008 later correction must ensure actual uppercase export type `STRING` is recognized as the valid String formal type.

ROOT:
- `ROOT.page = RunRecordPrimaryPage` under the current fallback rule;
- `ROOT.class = RuleIQ-Data-TestRefLib`;
- primary setup is not needed because no primary property is read/seeded;
- named page `CustomerCommunication -> Data-Customer` is permitted by explicit `UPDATE_PAGE` page creation;
- `CustomerCommunication` is created as an empty target shell by KT.24; `WITH_VALUES_FROM` changes the active source but does not copy/init all source properties.

Common Data Page:
- `D_CustomerTestRef`
- class `Data-Customer`
- page-shaped
- actual raw scope `thread`, accepted as Thread/eligible under MA-013;
- parameter `CustomerID` is resolved from current `Param.CustomerID`;
- all repeated executed accesses in one Scenario use the same concrete parameter map and may share one SIM decision;
- loader `LoadCustomerTestRef` is not crawled/executed because MA-016 makes simulation the hard external boundary.

Review-only DP signature:
`DP@Data-Customer@D_CustomerTestRef|CustomerID=string:CUST-001`

## W1 — invalid city / EXIT witness

### Synthetic simulation payload

Minimal payload:
```json
{
  "pxObjClass": "Data-Customer",
  "Addresses": [
    {
      "pxObjClass": "Data-Address-Postal",
      "pyCity": ""
    }
  ]
}
```

Rationale:
- one list item is sufficient;
- synthetic `IsValidCity` evaluates `.pyCity != ''`;
- initialized empty `pyCity` makes the item fail;
- therefore no item satisfies `IsValidCity`;
- no postal/street fields are needed because EXIT occurs before postal evaluation.

### Runtime execution

1. Step 1 `UPDATE_PAGE CustomerCommunication WITH_VALUES_FROM D_CustomerTestRef`
   - DP access executes with `CustomerID=CUST-001`;
   - `CustomerCommunication` empty target shell is created;
   - active source becomes simulated `D_CustomerTestRef`.

2. Step 1.1 condition
   - `IsInPageListWhen(IsValidCity, Addresses)` evaluates FALSE;
   - outer negation makes Model WHEN result TRUE.

3. Step 1.1.1
   - executes;
   - `Param.ExitCode = "-1 City Not valid"`.

4. Step 1.1.2
   - `EXIT_MODEL` executes;
   - no later steps execute.

5. Steps 1.2, 1.3 and 1.3.1 subtree
   - NOT_EXECUTED.

Coverage:
- `1.1:true`
- `1.1.2:exit`

`covers = {T1,T2}` in inventory order terminology.

Observable final facts for later assertion enumeration:
- `Param.ExitCode` exact output is `-1 City Not valid`.
- `CustomerCommunication` page exists from UPDATE_PAGE.
- `CustomerCommunication.Addresses` was never materialized by an executing write; because KT.24 proves the target began as an empty shell and no list write occurs, final list absence is supportable.
- `Param.AddressIndex` and `Param.StreetName` are not produced on this path.

DP runtime:
- executed accesses before EXIT share one SIM;
- later DP occurrences are NOT_EXECUTED and do not require additional SIMs.

## W2 — valid city + valid postal / append witness

### Synthetic simulation payload

```json
{
  "pxObjClass": "Data-Customer",
  "Addresses": [
    {
      "pxObjClass": "Data-Address-Postal",
      "pyCity": "Utrecht",
      "pyPostalCode": "3511AA",
      "pyStreet": "Main 12"
    }
  ]
}
```

### Runtime execution

1. Step 1
   - `CustomerCommunication` target shell created;
   - DP source available.

2. Step 1.1
   - synthetic `IsValidCity`: `"Utrecht" != ""` -> TRUE;
   - `IsInPageListWhen` -> TRUE;
   - outer negation -> FALSE;
   - invalid-city children skipped.

3. Step 1.2
   - synthetic `IsValidPostalAddress`: `"3511AA" != ""` -> TRUE for item 1;
   - fetched real `IndexInPageListWhen` contract returns first matching 1-based index;
   - `Param.AddressIndex = 1`.

4. Step 1.3
   - `Param.AddressIndex > 0` -> TRUE.

5. Step 1.3.1 under A-005
   - APPEND_AND_MAP_TO executes;
   - initial target `.Addresses` is absent on the newly created target page;
   - one target item is appended at index 1;
   - explicit source item is `D_CustomerTestRef.Addresses(1)`.

6. Child mappings under A-005
   - target `CustomerCommunication.Addresses(1).pyCity = "Utrecht"`;
   - target `...pyPostalCode = "3511AA"`;
   - target `...pyStreet = "Main 12"`.

7. Nested RUF pipeline
   - `toUpperCase("Main 12")` -> `"MAIN 12"`;
   - `TrimNumber` -> `"MAIN "` by removing digits;
   - `stripNonAlphabeticChars` -> `"MAIN"` by removing the remaining non-alphabetic space;
   - `Param.StreetName = "MAIN"`.

Coverage:
- `1.1:false:continue`
- `1.3:true`

`covers = {T3,T4}`.

Observable final facts for later assertion enumeration:
- `Param.AddressIndex = 1`;
- `Param.StreetName = "MAIN"`;
- `CustomerCommunication.Addresses` exists;
- exactly one list producer can modify this list and its execution is terminal TRUE;
- initial count is zero/absent and one append executes -> final count 1;
- index 1 is known;
- mapped item fields are deterministic under A-005.

## W3 — valid city + no postal match / no-append witness

### Synthetic simulation payload

```json
{
  "pxObjClass": "Data-Customer",
  "Addresses": [
    {
      "pxObjClass": "Data-Address-Postal",
      "pyCity": "Utrecht",
      "pyPostalCode": ""
    }
  ]
}
```

No `pyStreet` is needed because the append branch is skipped.

### Runtime execution

1. Step 1
   - target `CustomerCommunication` empty shell created;
   - DP source available.

2. Step 1.1
   - city predicate TRUE on item 1;
   - helper TRUE;
   - outer negation FALSE;
   - execution continues.

3. Step 1.2
   - postal predicate FALSE because initialized `pyPostalCode` is empty;
   - no list item satisfies the When;
   - fetched real RUF contract gives `IndexInPageListWhen = -1`;
   - `Param.AddressIndex = -1`.

4. Step 1.3
   - `-1 > 0` -> FALSE.

5. Step 1.3.1 and children
   - SKIPPED with terminal guard proof;
   - list producer execution is terminal FALSE.

Coverage:
- `1.1:false:continue`
- `1.3:false:no_append`

`covers = {T3,T5}`.

Observable final facts for later assertion enumeration:
- `Param.AddressIndex = -1`;
- `Param.StreetName` is not produced;
- `CustomerCommunication` page exists;
- `CustomerCommunication.Addresses` is provably ABSENT:
  - KT.24 proves UPDATE_PAGE creates an empty shell and does not copy/init child lists;
  - no earlier producer writes target `.Addresses`;
  - the only list producer is skipped with terminal false guard proof;
  - Section 6.0-PRE therefore permits Structural `Not exists`.
- This is stronger and safer than asserting ResultCount=0; KT.36 also forbids ResultCount when no list write executed.

## Seed-direction / runtime safety check

No witness seeds a skipped original-RUT output on `CustomerCommunication`.

Physical external setup:
- only formal RUT input `Param.CustomerID`.
- `CustomerCommunication` is not pre-seeded; it is created by the RUT.
- all external customer/address data stays inside Data Page SIM payloads, not top-level SETUP.

Therefore:
- W1: no forbidden skipped-output setup conflict.
- W2: append output is produced by execution, not pre-seeded.
- W3: `.Addresses` is not seeded, so the negative branch remains observable.

`STATECHECK.preSeed = PASS` under A-005/A-006 and the accepted Data Page decisions.

## Data Page execution audit at WITNESSES level

W1:
- one effective SIM for the common DP signature/payload.
- executed access set: initial source access + step 1.1 helper access.
- later occurrences skipped by EXIT.

W2:
- one effective SIM for the common DP signature/payload.
- executed access set: step 1 source + step 1.1 helper + step 1.2 helper + step 1.3.1 source item access.

W3:
- one effective SIM for the common DP signature/payload.
- executed access set: step 1 source + step 1.1 helper + step 1.2 helper.
- step 1.3.1 source item access skipped.

Every executed access has the same concrete map `{CustomerID:"CUST-001"}` within its Scenario and can reference the Scenario's single matching SIM.
No executed access has unresolved parameters.
DPA is semantically satisfiable for all three witnesses.

## WITNESSES coverage snapshot — review normalization

The repository does not define exact `given` and DP_SIG text serialization (MA-018/MA-021), so the following uses review-normalized canonical JSON and signature notation only.

Common review-normalized `given`:
```json
{"parameters":{"CustomerID":{"formalType":"STRING","value":"CUST-001","valueType":"string"}},"setup":[],"whenCells":[]}
```

Witness rows conceptually:

- `W1`: owner=`1.1:true`; covers=`1.1.2:exit,1.1:true`; simulation payload = invalid-city payload.
- `W2`: owner=`1.3:true`; covers=`1.1:false:continue,1.3:true`; simulation payload = valid-city/valid-postal payload.
- `W3`: owner=`1.3:false:no_append`; covers=`1.1:false:continue,1.3:false:no_append`; simulation payload = valid-city/no-postal payload.

Union of actual covers:
`{1.1:true,1.1.2:exit,1.1:false:continue,1.3:true,1.3:false:no_append}`

This equals the complete revised REQUIRED target set.

## WITNESSES result

- W1 valid under current evidence/accepted corrections.
- W2 valid only with A-005 explicit APPEND_AND_MAP_TO mapping semantics and A-006 dependency-leaf simulation allowance.
- W3 valid under current evidence/accepted corrections.
- All REQUIRED targets are covered.
- No dependency-only scenario was created.
- No witness can be merged at W because their branch execution and/or simulation payload differs.

Predicted physical Scenario count entering FROZEN:
`3`.

## Current execution position

`Scenario Compiler INVENTORY -> WITNESSES complete -> PAUSED before FROZEN`.

Before final correction pass, MA-019 should be reviewed because W2 exact output semantics depend on the intended `APPEND_AND_MAP_TO ... EXISTING_PAGE` child source/target behavior.


---

## External official Pega documentation supplied by user — APPEND_AND_MAP_TO resolution

User supplied current Pega documentation URL:
`https://docs.pega.com/bundle/platform/page/platform/app-dev/data-transform-append-map-action.html`

The current docs page itself is dynamically rendered in the web reader, but official Pega documentation mirrors/archive content and Pega Academy establish the same semantics:

- Append and Map to appends a new page to the target Page List.
- The newly appended target page becomes the context for subsequent child actions.
- The new target page starts without embedded properties; child actions create/map them.
- Relation `an existing page` creates a new target-list page and maps properties onto it from the specified source page.
- Source and target may have different Applies To classes.

### MA-019 — APPEND_AND_MAP_TO child source/target context underspecified in Rule-Obj-Model KnowledgeArea

- Previous status: `OPEN — semantic assumption required`.
- New status: `CONFIRMED_KNOWLEDGEAREA_GAP / INTENDED_SEMANTICS_RESOLVED_BY_OFFICIAL_PEGA_DOCS`.

The real Pega semantics for the supplied RUT pattern are now source-backed:

```text
APPEND_AND_MAP_TO
target = .Addresses
relation = EXISTING_PAGE
source = D_CustomerTestRef.Addresses(Param.AddressIndex)

child:
  SET .pyCity       = .pyCity
  SET .pyPostalCode = .pyPostalCode
  SET .pyStreet     = .pyStreet
```

Interpretation:

1. Create a new page at the end of target `CustomerCommunication.Addresses`.
2. Set the child-action target/current context to that newly appended target page.
3. Use `D_CustomerTestRef.Addresses(Param.AddressIndex)` as the existing source page for the mapping scope.
4. Child target references such as left-hand `.pyCity` resolve against the newly appended target page.
5. Child source-side relative values such as right-hand `.pyCity` resolve from the selected existing source page.
6. Child actions materialize only the mapped fields; Append and Map to does not first copy every source property.
7. Source and target page classes may differ.
8. After the nested child scope, restore the parent execution context according to normal data-transform nesting.

### Effect on A-005

`A-005` is no longer needed as an unsupported simulation assumption.

New classification:
`A-005 = RESOLVED_BY_OFFICIAL_PEGA_DOCUMENTATION`

W2 exact mapped values are therefore supported by Pega operation semantics plus the synthetic source payload; they no longer depend on a guessed APPEND_AND_MAP_TO context model.

### Required later KnowledgeArea correction

`rule-obj-model_knowledgearea.txt` should extend the APPEND_AND_MAP_TO semantics beyond the current generic `LIST_APPEND` statement.

Proposed semantic wording:

> APPEND_AND_MAP_TO appends one new page to the target PageList and makes that new page the target/current context for its child mapping actions. With relation EXISTING_PAGE, the configured source expression resolves one existing source page; child write targets resolve on the new appended target page while child relative source-value references resolve on that source page. The append itself creates no embedded child properties; child mappings materialize them. Source and target classes may differ.

This correction is grounded in official Pega documentation, not model inference.

### W2 reclassification

W2 remains valid.

Previously:
`valid only under A-005 + A-006`

Now:
- APPEND_AND_MAP_TO semantics: supported by official Pega documentation.
- dependency-required Data Page leaf seeding: still depends on A-006 / MA-020 correction.

Therefore W2's remaining simulation-only bridge is MA-020/A-006, not MA-019.

## Current execution position

`Scenario Compiler INVENTORY -> WITNESSES complete -> MA-019 resolved by official Pega docs -> PAUSED before FROZEN`.


---

## Checkpoint — WITNESSES canonical-minimal repair and FROZEN

### WITNESSES repair before freeze

During the FROZEN cost check, W1 was found non-minimal.

Previous W1 synthetic Data Page payload:
```json
{
  "pxObjClass": "Data-Customer",
  "Addresses": [
    {
      "pxObjClass": "Data-Address-Postal",
      "pyCity": ""
    }
  ]
}
```

This is valid but not canonical-minimal because the target `1.1:true` only requires
`@IsInPageListWhen("IsValidCity", D_CustomerTestRef.Addresses)` to return false.

The fetched real RUF contract describes `IsInPageListWhen` as true when any page in the
list satisfies the specified When. Therefore an explicitly empty list is a deterministic
no-match carrier and does not require executing the nested When on an item.

Repaired W1 payload:
```json
{
  "pxObjClass": "Data-Customer",
  "Addresses": []
}
```

This preserves:
- explicit no-match output;
- the original RUT token `Addresses`;
- Thread-level Data Page simulation;
- the same `CustomerID` DP signature;
- exact W1 original-RUT execution:
  first Model WHEN true -> ExitCode -> EXIT_MODEL;
- covers exactly `1.1:true` and `1.1.2:exit`.

It removes one unnecessary per-item carrier and is therefore preferred by the
WITNESSES “smallest typed list” rule.

Because this is a physical witness-input change before FROZEN, W1 was re-executed.
Coverage and execution remain unchanged.

### Final W base entering F

W1:
- payload: `{"pxObjClass":"Data-Customer","Addresses":[]}`
- covers: `1.1:true,1.1.2:exit`

W2:
- payload contains one item:
  `pyCity="Utrecht", pyPostalCode="3511AA", pyStreet="Main 12"`
- covers: `1.1:false:continue,1.3:true`

W3:
- payload contains one item:
  `pyCity="Utrecht", pyPostalCode=""`
- covers: `1.1:false:continue,1.3:false:no_append`

All use review-only:
- `Param.CustomerID = "CUST-001"`
- one SIM for `D_CustomerTestRef`
- same review-normalized DP signature:
  `DP@Data-Customer@D_CustomerTestRef|CustomerID=string:CUST-001`

### FROZEN cost ordering

Section 11 cost priority:
`(simulation entries, seeded leaves, non-default parameters, canonical given+simulation)`.

All three have:
- one simulation entry;
- the same one non-default formal input / DP parameter value;
- the same common simulation metadata.

Relative seeded payload cost is therefore:

1. W2 = highest:
   one address item with `pyCity`, `pyPostalCode`, `pyStreet`.
2. W3 = middle:
   one address item with `pyCity`, `pyPostalCode`.
3. W1 = lowest:
   explicit empty `Addresses` list and no address-item leaf values.

Exact numeric “seeded leaves” counting is not separately defined by the prompt, but
the relative ordering is invariant because W3 removes W2's `pyStreet` leaf and W1 removes
the item and all item leaves.

### F removal attempts

#### Attempt 1 — remove W2 (highest cost)

Retained:
- W1 covers `1.1:true`, `1.1.2:exit`
- W3 covers `1.1:false:continue`, `1.3:false:no_append`

Missing required target:
- `1.3:true`

Result:
`REJECT_REMOVAL(W2)`

W2 is mandatory.

#### Attempt 2 — remove W3

Retained:
- W1 covers `1.1:true`, `1.1.2:exit`
- W2 covers `1.1:false:continue`, `1.3:true`

Missing required target:
- `1.3:false:no_append`

Result:
`REJECT_REMOVAL(W3)`

W3 is mandatory.

#### Attempt 3 — remove W1

Retained:
- W2/W3 both cover `1.1:false:continue`
- W2 covers `1.3:true`
- W3 covers `1.3:false:no_append`

Missing required targets:
- `1.1:true`
- `1.1.2:exit`

Result:
`REJECT_REMOVAL(W1)`

W1 is mandatory.

### Fixed point

No witness is removable.
No two witnesses have identical physical execution + simulation.
No duplicate merge is possible.

Final FROZEN cardinality:
`3`.

### Stable S assignment under review normalization

MA-018 and MA-021 remain relevant: the current repository does not fully define the
exact `given` JSON schema or `DP_SIG` string grammar. Therefore the exact lexical S-ID
assignment cannot be claimed production-deterministic from the current prompt alone.

For this review simulation, use the already declared review normalization:
- canonical JSON objects use lexical key order;
- `given` uses the review schema recorded under MA-018;
- the review DP_SIG notation recorded under MA-021 is used consistently.

Under this normalization, canonical `given+simulation` sorts as:

1. W1 — empty `Addresses` array
2. W3 — one item with `pyCity="Utrecht", pyPostalCode=""`
3. W2 — one item with `pyCity="Utrecht", pyPostalCode="3511AA", pyStreet="Main 12"`

Therefore review-only final IDs are:

### S1 = former W1 — invalid-city EXIT

- owner: `1.1:true`
- covers: `1.1.2:exit,1.1:true`
- simulation: empty `Addresses` list
- final execution:
  - update target shell
  - first Model WHEN TRUE
  - set `Param.ExitCode`
  - EXIT_MODEL
  - no postal-index or append execution

### S2 = former W3 — valid city, no postal match

- owner: `1.3:false:no_append`
- covers: `1.1:false:continue,1.3:false:no_append`
- simulation:
  one item with non-empty city and empty postal code
- final execution:
  - first Model WHEN FALSE
  - `Param.AddressIndex=-1`
  - second Model WHEN FALSE
  - append producer skipped

### S3 = former W2 — valid city, postal match, append

- owner: `1.3:true`
- covers: `1.1:false:continue,1.3:true`
- simulation:
  one item with city/postal/street
- final execution:
  - first Model WHEN FALSE
  - `Param.AddressIndex=1`
  - second Model WHEN TRUE
  - APPEND_AND_MAP_TO executes
  - child mappings execute
  - `Param.StreetName="MAIN"` under supported RUF semantics

### Review-normalized F snapshot

`<SYNTHETIC_pyID>` remains review-only because real GetCaseData.pyID was not supplied.

```text
P|F|<SYNTHETIC_pyID>|RULE-OBJ-MODEL RULEIQ-DATA-TESTREFLIB PREPARECUSTOMERCOMMUNICATION #20260430T104351.201 GMT|Rule-Obj-Model
T|1.1:true|1,1.1,1.1.1|invalid_city_arm|-|R|original_model_when_true
T|1.1.2:exit|1.1.2|terminate_after_invalid_city|-|R|explicit_exit_model
T|1.1:false:continue|1,1.1,1.2,1.3|continue_to_postal_evaluation|-|R|false_edge_reaches_different_later_owner_execution
T|1.3:true|1.3,1.3.1,1.3.1.1,1.3.1.2,1.3.1.3,1.3.1.4|append_selected_postal_address|-|R|reachable_model_when_true_arm
T|1.3:false:no_append|1.3,1.3.1|no_postal_append|-|R|false_edge_suppresses_observable_original_rut_producer
S|S1|<review-given>|1.1:true|1.1.2:exit,1.1:true|<review-sim-empty-addresses>|-|-
S|S2|<review-given>|1.3:false:no_append|1.1:false:continue,1.3:false:no_append|<review-sim-no-postal>|-|-
S|S3|<review-given>|1.3:true|1.1:false:continue,1.3:true|<review-sim-postal-match>|-|-
```

This snapshot is semantically FROZEN for the review simulation.
`name` and `at` remain absent until physical ScenarioGroup materialization / audit mapping.

### MA-018 / MA-021 impact escalation

Their practical impact is now demonstrated:

- MA-018 (`given` exact canonical shape unspecified) can alter lexical final Scenario order.
- MA-021 (`DP_SIG` exact grammar unspecified) can alter the canonical simulation representation,
  equality comparison, DPA matching, and potentially lexical final Scenario order.

Both therefore affect stable S IDs / group order and are not merely cosmetic serialization issues.

No new issue ID is needed; retain them as confirmed ambiguities with deterministic-output impact.

## FROZEN result

`FROZEN = PASS` under:
- accepted corrections MA-013/014/016/017;
- official Pega resolution of MA-019;
- simulation bridge A-006 for MA-020;
- review-normalized serialization for MA-018/021.

Final immutable Scenario membership for the first-pass simulation:
`S1,S2,S3`.

Any later semantic change to inputs, simulation payloads, branch execution, target census,
or grouping must invalidate this F snapshot and return to WITNESSES.

## Current execution position

`INVENTORY -> WITNESSES -> FROZEN PASS -> PAUSED before final candidate-claim enumeration and ASSERT/SIM/OMIT decisions`.


---

## Checkpoint — candidate claims, producer binding, ASSERT/SIM/OMIT decisions

### New defects exposed by assertion selection

#### MA-022 — omission reason-code lists are inconsistent

- Location:
  - Section 5.5 Omissions ledger
  - Section 6.0-PRE
  - Section 12.3 / Section 13.4.6
- Status: `CONFIRMED_DEFECT`.
- Section 5.5 allows only:
  `unresolved_external_source`,
  `unavailable_rulejson_after_limit_exhaustion`,
  `unresolvable_runtime_input`,
  `inactive_evaluate_all_scalar`,
  `inactive_return_values_scalar`,
  `schema_incompatible_assertion_target`,
  `redundant_iteration_coverage`.
- Section 6.0-PRE explicitly instructs use of
  `incorrect_candidate_assertion` for an input-only candidate.
- Section 12.3 and executable Section 13.4.6 also allow
  `incorrect_candidate_assertion`.
- A literal model following Section 5.5 can reject an omission that later higher-authority
  sections require.

Later correction:
- add `incorrect_candidate_assertion` to Section 5.5 and keep one authoritative reason-code set.

First-pass simulation uses `incorrect_candidate_assertion` because Sections 6/12 and executable
Section 13 require/allow it.

#### MA-023 — `OWNER_COVERAGE_OUTPUTS` omits APPEND_AND_MAP_TO

- Location: Section 5.3b STEP 1.
- Status: `CONFIRMED_DEFECT`.
- Current set includes writes by:
  `SET/APPEND/PREPEND/INSERT/REMOVE`.
- It omits `APPEND_AND_MAP_TO`.
- The supplied RUT's principal observable collection mutation is
  step `1.3.1 APPEND_AND_MAP_TO .Addresses`.
- The omission can remove `.Addresses` from the owner output inventory, W.outputProps,
  skipped-output analysis, and seed-direction logic even though other contracts correctly
  recognize APPEND_AND_MAP_TO as a list producer.

Later correction:
- include every semantically modifying operation recognized by the active primary KnowledgeArea,
  including `APPEND_AND_MAP_TO`, rather than maintaining a narrower hardcoded list.

First-pass simulation includes step 1.3.1 in OWNER_COVERAGE_OUTPUTS because MA-017 already
establishes the branch as observable and official Pega semantics establish the mutation.

#### MA-024 — direct SET producer payload is incompatible with descendant-only PC payload wording

- Location: Section 6.0 RUT Producer Catalog Lock.
- Status: `CONFIRMED_DEFECT`.
- Assertions derived from `Set` must bind to one immutable `PC`.
- But `PC.payload` is described as `field:value from descendant rows only`, and the rules say
  payload may include only descendant `Set`, `MapTo`, or mapping rows.
- A direct scalar SET such as:
  - `1.1.1 Param.ExitCode = "-1 City Not valid"`
  - `1.2 Param.AddressIndex = @IndexInPageListWhen(...)`
  - `1.3.1.4 Param.StreetName = ...`
  has no descendant row containing its own payload.
- Literal application leaves those direct producers without payload, making `APB.payloadMatch`
  impossible despite the same section requiring SET assertions to bind to a PC.

Later correction:
- direct producer: PC payload comes from that operation's own evidenced RHS/expression;
- composite/list producer: PC payload may additionally contain only descendant mappings whose
  resolved write target belongs to the structure created/mutated by that producer;
- a nested SET writing outside the composite target, e.g. `Param.StreetName`, remains a separate PC
  and must not be absorbed into `.Addresses` payload.

First-pass simulation follows this intended split.

#### MA-025 — RX/LPE cannot represent producer skipped by prior EXIT_MODEL

- Location:
  - Section 5.7 RX rules
  - Section 6.0 LPE rules
  - Rule-Obj-Model KT.35/KT.36
- Status: `CONFIRMED_DEFECT`.
- Model KnowledgeArea KT.35 says `EXIT_MODEL` immediately terminates current rule and no later
  steps execute.
- KT.36 explicitly treats operations skipped by EXIT_MODEL as unreachable writes.
- Main Agent LPE, however, allows `executes=false` only when `RX.actionState=skipped`, and
  RX/LPE wording ties `skipped`/false producer proof to a terminal false controlling guard.
- In S1, step 1.3.1 is not excluded by a false 1.3 guard: step 1.3 is never evaluated because
  step 1.1.2 already exited the Model.
- Literal Main Agent wording can therefore leave the list producer non-terminal/unknown even
  though primary KnowledgeArea proves it unreachable, blocking safe `Not exists` reasoning.

Later correction:
> RX.actionState=skipped and LPE.executes=false may be established by any terminal
> control-flow exclusion proof, including a terminal false guard, prior EXIT_MODEL/termination,
> unreachable OTHERWISE/alternative selection, or another KnowledgeArea-defined non-execution
> condition. Record the exact exclusion source in proof; do not fabricate a false guard.

First-pass simulation applies that intended rule.

## Immutable producer catalog — intended normalization

The exact original-RUT hierarchical paths remain authoritative.

### Direct producers

`PC-EXITCODE`
- producer: `1.1.1`
- operation: SET
- parentGuard: `1.1`
- target: `Param.ExitCode`
- own payload expression: literal `"-1 City Not valid"`

`PC-ADDRESSINDEX`
- producer: `1.2`
- operation: SET
- parentGuard: none; execution may still be suppressed by prior EXIT_MODEL
- target: `Param.AddressIndex`
- own payload expression:
  `@IndexInPageListWhen("IsValidPostalAddress",D_CustomerTestRef.Addresses)`

`PC-CITY`
- producer: `1.3.1.1`
- operation: SET / mapping child
- parentGuard: `1.3`
- target: `CustomerCommunication.Addresses(<APPEND>).pyCity`
- source: `D_CustomerTestRef.Addresses(Param.AddressIndex).pyCity`

`PC-POSTAL`
- producer: `1.3.1.2`
- operation: SET / mapping child
- parentGuard: `1.3`
- target: `CustomerCommunication.Addresses(<APPEND>).pyPostalCode`
- source: `D_CustomerTestRef.Addresses(Param.AddressIndex).pyPostalCode`

`PC-STREET`
- producer: `1.3.1.3`
- operation: SET / mapping child
- parentGuard: `1.3`
- target: `CustomerCommunication.Addresses(<APPEND>).pyStreet`
- source: `D_CustomerTestRef.Addresses(Param.AddressIndex).pyStreet`

`PC-STREETNAME`
- producer: `1.3.1.4`
- operation: SET
- parentGuard: `1.3`
- target: `Param.StreetName`
- own payload expression:
  `@String.stripNonAlphabeticChars(@TrimNumber(@toUpperCase(.pyStreet)))`
  evaluated against the selected EXISTING_PAGE source under official Pega APPEND_AND_MAP_TO semantics.

### Composite list producer

`PC-ADDRESSES`
- producer: `1.3.1`
- operation: APPEND_AND_MAP_TO
- parentGuard: `1.3`
- target: `CustomerCommunication.Addresses`
- mutation: append exactly one item when executing
- payload mappings:
  - pyCity from `1.3.1.1`
  - pyPostalCode from `1.3.1.2`
  - pyStreet from `1.3.1.3`
- `Param.StreetName` is NOT part of this list payload because it targets Param, not the appended item.

`UPDATE_PAGE CustomerCommunication` is page-creation/context behavior rather than a scalar/list PC
under the current PC grammar; page-existence evidence comes from its RX + Model KnowledgeArea KT.24.

## Candidate-claim census

Per the Main Agent, candidate claims include RUT outputs, branch-dependent outputs and
collection structural checks.

Common semantic candidates considered for each Scenario:

1. `CustomerCommunication` page existence.
2. `Param.ExitCode`.
3. `Param.AddressIndex`.
4. `CustomerCommunication.Addresses` collection state/count.
5. `CustomerCommunication.Addresses(1)` item existence when the collection is materialized,
   or non-existence when the collection is proven absent.
6. `CustomerCommunication.Addresses(1).pyCity`.
7. `CustomerCommunication.Addresses(1).pyPostalCode`.
8. `CustomerCommunication.Addresses(1).pyStreet`.
9. `Param.StreetName`.
10. `Param.CustomerID` as an explicitly enumerated input-only candidate to exercise the
    input-only gate; it must never become an output assertion.

The simulated Data Page source fields are SIM/input evidence, not independent final-output claims.
When mapped into `CustomerCommunication`, their target-side values become proper output candidates.

No RUT-controlled error-message candidate exists in this RUT.

## Scenario S1 — invalid city / EXIT

### Assertion-relevant execution

- step 1 UPDATE_PAGE: executes; creates empty `CustomerCommunication` shell.
- step 1.1: TRUE.
- step 1.1.1: executes.
- step 1.1.2 EXIT_MODEL: executes.
- step 1.2: NOT_EXECUTED due terminal prior EXIT.
- step 1.3: NOT_EVALUATED due terminal prior EXIT.
- step 1.3.1 and children: NOT_EXECUTED due terminal prior EXIT.

List producer row under MA-025 intended correction:

`LPE|scenario=S1|list=CustomerCommunication.Addresses|producer=1.3.1|guard=1.3|guardState=not_evaluated_due_exit|executes=false|mutation=add|delta=0|proof=EXIT_MODEL@1.1.2 terminated rule`

This uses explicit termination proof, not a fabricated false 1.3 result.

### Final presence/value decisions

`CustomerCommunication`
- PRESENT by executing UPDATE_PAGE + KT.24.
- decision: ASSERT Structural Page Exists.

`Param.ExitCode`
- producer 1.1.1 executes.
- direct literal value: `-1 City Not valid`.
- decision: ASSERT `Verified`, exact string.

`Param.AddressIndex`
- producer 1.2 never executes.
- no initial Param.AddressIndex presence/value evidence.
- skipped producer preserves UNKNOWN initial state.
- decision: OMIT `unresolvable_runtime_input`.

`CustomerCommunication.Addresses`
- target page begins as KT.24 empty shell.
- no list producer executes; 1.3.1 is terminally excluded by EXIT.
- final list ABSENT.
- ResultCount=0 is not used because KT.36 forbids ResultCount when no list write executed.
- decision: ASSERT Structural `Not exists`.

`CustomerCommunication.Addresses(1)`
- ancestor PageList is proven absent.
- decision: ASSERT Structural `Not exists`.

`...Addresses(1).pyCity`
`...Addresses(1).pyPostalCode`
`...Addresses(1).pyStreet`
- ancestor list/item absence proves descendant absence.
- each is a candidate RUT-mapped output.
- decision: ASSERT Structural `Not exists` for each.

`Param.StreetName`
- nested producer never executes because of prior EXIT.
- initial presence/value unknown.
- decision: OMIT `unresolvable_runtime_input`.

`Param.CustomerID`
- physical external RUT input; no later RUT write/remove.
- input-only and not an output assertion.
- decision: OMIT `incorrect_candidate_assertion`.

### S1 semantic decisions

ASSERT:
1. `CustomerCommunication` — Page Exists — Structural.
2. `Param.ExitCode = "-1 City Not valid"` — Property — Verified.
3. `CustomerCommunication.Addresses` — Not exists — Structural.
4. `CustomerCommunication.Addresses(1)` — Page Not exists — Structural.
5. `CustomerCommunication.Addresses(1).pyCity` — Not exists — Structural.
6. `CustomerCommunication.Addresses(1).pyPostalCode` — Not exists — Structural.
7. `CustomerCommunication.Addresses(1).pyStreet` — Not exists — Structural.

OMIT:
1. `Param.AddressIndex` — `unresolvable_runtime_input`.
2. `Param.StreetName` — `unresolvable_runtime_input`.
3. `Param.CustomerID` — `incorrect_candidate_assertion`.

SIM:
- exactly one `D_CustomerTestRef` SIM for concrete `CustomerID=CUST-001`;
- page payload: `{"pxObjClass":"Data-Customer","Addresses":[]}`;
- all executed equal-signature accesses share this SIM.

DPA:
- PASS under accepted MA-013 + A-006/MA-020 bridge.

## Scenario S2 — valid city / no postal match / no append

### Assertion-relevant execution

- UPDATE_PAGE executes.
- step 1.1 FALSE; invalid-city SET/EXIT children skipped by terminal guard proof.
- step 1.2 executes.
- synthetic IsValidPostalAddress returns false for the one item.
- fetched IndexInPageListWhen contract returns `-1` on no match.
- `Param.AddressIndex = -1`.
- step 1.3 FALSE.
- step 1.3.1 and all children skipped by terminal guard proof.

List producer:

`LPE|scenario=S2|list=CustomerCommunication.Addresses|producer=1.3.1|guard=1.3|guardState=false|executes=false|mutation=add|delta=0|proof=Param.AddressIndex=-1 -> -1>0 false`

### Final decisions

`CustomerCommunication`
- PRESENT from UPDATE_PAGE.
- ASSERT Structural Page Exists.

`Param.ExitCode`
- producer 1.1.1 skipped.
- initial state unknown.
- OMIT `unresolvable_runtime_input`.

`Param.AddressIndex`
- producer 1.2 executes.
- deterministic fetched RUF contract + closed nested When semantics + SIM input -> `-1`.
- ASSERT `PredictedFromRules`, semantic value `-1`.

`CustomerCommunication.Addresses`
- target page starts as empty shell.
- only list producer is terminal FALSE.
- final ABSENT.
- ASSERT Structural `Not exists`; no ResultCount=0.

`CustomerCommunication.Addresses(1)`
- ASSERT Structural `Not exists`.

Mapped child outputs:
- `pyCity`, `pyPostalCode`, `pyStreet`
- ancestor list/item absent.
- ASSERT Structural `Not exists` for each.

`Param.StreetName`
- producer skipped.
- initial state unknown.
- OMIT `unresolvable_runtime_input`.

`Param.CustomerID`
- input-only.
- OMIT `incorrect_candidate_assertion`.

### S2 semantic decisions

ASSERT:
1. `CustomerCommunication` — Page Exists — Structural.
2. `Param.AddressIndex = -1` — Property — PredictedFromRules.
3. `CustomerCommunication.Addresses` — Not exists — Structural.
4. `CustomerCommunication.Addresses(1)` — Page Not exists — Structural.
5. `CustomerCommunication.Addresses(1).pyCity` — Not exists — Structural.
6. `CustomerCommunication.Addresses(1).pyPostalCode` — Not exists — Structural.
7. `CustomerCommunication.Addresses(1).pyStreet` — Not exists — Structural.

OMIT:
1. `Param.ExitCode` — `unresolvable_runtime_input`.
2. `Param.StreetName` — `unresolvable_runtime_input`.
3. `Param.CustomerID` — `incorrect_candidate_assertion`.

SIM:
- one `D_CustomerTestRef` SIM with:
  `Addresses(1).pyCity="Utrecht"`,
  `Addresses(1).pyPostalCode=""`.

DPA:
- PASS under A-006/MA-020.

## Scenario S3 — valid city / postal match / append

### Assertion-relevant execution

- UPDATE_PAGE executes.
- first Model WHEN FALSE.
- step 1.2 executes:
  first postal-matching item is item 1 -> `Param.AddressIndex=1`.
- step 1.3 TRUE.
- APPEND_AND_MAP_TO executes once.
- official Pega semantics establish new target item + EXISTING_PAGE source context.
- child mapping steps execute.
- StreetName RUF pipeline executes.

List producer:

`LPE|scenario=S3|list=CustomerCommunication.Addresses|producer=1.3.1|guard=1.3|guardState=true|executes=true|mutation=add|delta=1|proof=Param.AddressIndex=1 -> 1>0 true`

No other producer can modify this target list.
The target page starts as an empty shell and list initially absent.
Therefore:
- final list count = 1;
- appended item index = 1;
- list order/index is known;
- exact ResultCount and indexed child assertions are safe.

### Final decisions

`CustomerCommunication`
- ASSERT Structural Page Exists.

`Param.ExitCode`
- invalid-city producer skipped;
- initial state unknown.
- OMIT `unresolvable_runtime_input`.

`Param.AddressIndex`
- ASSERT PredictedFromRules exact `1`.

`CustomerCommunication.Addresses`
- one proven append and no competing producer.
- ASSERT `ResultCount = 1`, PredictedFromRules.

`CustomerCommunication.Addresses(1)`
- appended item is proven present.
- ASSERT Structural Page Exists.

`...Addresses(1).pyCity`
- source SIM value `"Utrecht"` mapped by executed child producer.
- ASSERT PredictedFromRules exact `"Utrecht"`.

`...Addresses(1).pyPostalCode`
- source SIM value `"3511AA"` mapped by executed child producer.
- ASSERT PredictedFromRules exact `"3511AA"`.

`...Addresses(1).pyStreet`
- source SIM value `"Main 12"` mapped by executed child producer.
- ASSERT PredictedFromRules exact `"Main 12"`.

`Param.StreetName`
- deterministic RUF pipeline:
  `"Main 12" -> "MAIN 12" -> "MAIN " -> "MAIN"`.
- ASSERT PredictedFromRules exact `"MAIN"`.

`Param.CustomerID`
- input-only.
- OMIT `incorrect_candidate_assertion`.

### S3 semantic decisions

ASSERT:
1. `CustomerCommunication` — Page Exists — Structural.
2. `Param.AddressIndex = 1` — Property — PredictedFromRules.
3. `CustomerCommunication.Addresses` — ResultCount equals 1 — PredictedFromRules.
4. `CustomerCommunication.Addresses(1)` — Page Exists — Structural.
5. `CustomerCommunication.Addresses(1).pyCity = "Utrecht"` — PredictedFromRules.
6. `CustomerCommunication.Addresses(1).pyPostalCode = "3511AA"` — PredictedFromRules.
7. `CustomerCommunication.Addresses(1).pyStreet = "Main 12"` — PredictedFromRules.
8. `Param.StreetName = "MAIN"` — PredictedFromRules.

OMIT:
1. `Param.ExitCode` — `unresolvable_runtime_input`.
2. `Param.CustomerID` — `incorrect_candidate_assertion`.

SIM:
- one `D_CustomerTestRef` SIM with city/postal/street payload.

DPA:
- PASS under A-006/MA-020.

## Assertion support boundary for synthetic fixtures

S2/S3 branch and exact-value outcomes that depend on unavailable real
`IsValidCity` / `IsValidPostalAddress` RuleJSON remain `SYNTHETIC_SIMULATION_FIXTURE`
results in this review.

The labels `PredictedFromRules` above mean:
- this is the support class the Main Agent would assign if those fetched RuleJSON contracts
  exactly matched the synthetic fixtures;
- they are not claims about the real Pega application's expected values.

S1's direct ExitCode result and Model/collection non-execution are less dependent on those
synthetic predicate bodies because an explicitly empty Addresses list makes the helper no-match
deterministically under its fetched contract.

## Semantic SIM census

Each frozen Scenario has exactly one runtime Data Page simulation obligation and one SIM:

- S1 -> empty Addresses.
- S2 -> one city-valid/postal-invalid item.
- S3 -> one city-valid/postal-valid/street item.

All:
- rule = `D_CustomerTestRef`
- shape = page
- class = `Data-Customer`
- method = DefineData
- params = concrete CustomerID map
- Thread eligible under accepted MA-013
- source loader not crawled/executed under accepted MA-016
- target/navigation tokens preserve `Addresses`
- dependency-required leaves are allowed under A-006 / pending MA-020 correction.

No Scenario has a second distinct concrete DP_SIG.

## Semantic decision gate result

Under the accepted corrections and simulation bridges:

- CandidateAssertionsEnumerated = true.
- DependencyResolutionCompleted = true within the synthetic simulation fixture.
- ParametersResolved = true.
- BranchesEvaluated = true.
- PropertyTracesCompleted = true.
- OmissionsResolved = true.
- SimulationNeedsResolved = true.
- ListAssertionsChecked = true.
- SymbolicIndexesResolved = true.
- ContextSwitchesResolved = true.
- UnsupportedAssertionsExcluded = true.
- NoSpeculation = true only when synthetic fixture evidence is explicitly treated as simulation input, not real application evidence.

No decision changes Scenario inputs, execution, effects, simulation payloads, owner or coverage.
Therefore the FROZEN membership remains valid and does not return to WITNESSES.

## Current execution position

`INVENTORY -> WITNESSES -> FROZEN -> candidate census -> producer/list gates -> ASSERT/SIM/OMIT decisions complete -> PAUSED before final semantic re-audits and physical ScenarioGroup formation/materialization`.


---

## Checkpoint — final semantic re-audits, physical grouping, and materialization feasibility

### Evidence classification at this checkpoint

PRODUCTION-EVIDENCED:
- original user-supplied RUT RuleJSON;
- user-supplied real Wave 1 RuleCrawler data;
- live repository Main Agent / KnowledgeArea contracts;
- official Pega APPEND_AND_MAP_TO semantics supplied by user.

SYNTHETIC_REVIEW_ONLY:
- unavailable scalar property definitions;
- unavailable `IsValidCity` / `IsValidPostalAddress` RuleJSON;
- simulated Wave 2 completion;
- review `CustomerID="CUST-001"`;
- review-only `<SYNTHETIC_pyID>`;
- review-only synthetic TestedRuleKey introduced below solely to exercise Section 13 identity grammar.

No review-only synthetic field may be represented as actual `GetCaseData`, RuleCrawler, or Pega runtime evidence.

## Re-audit results before physical grouping

### Dependency evidence gate

Semantic review state:
- no active READY/CTX/FETCHED/unscanned rows under the synthetic completion;
- all executable dependencies needed by S1-S3 are semantically closed in the review model;
- no Decision Table is involved.

Result:
`PASS_FOR_REVIEW_SIMULATION`

Production-evidence qualification:
`NOT_PROVEN`
because the synthetic When/property RuleJSON cannot truthfully be recorded as actual RuleCrawler returns.

### Assertion/setup/seed gate

- formal RUT input: `Param.CustomerID` only.
- no forbidden output property is pre-seeded on `CustomerCommunication`.
- all Data Page external values stay in SIM payloads.
- no DTA_BEFORE setup.
- all exact mapped-value assertions in S3 link to SIM seed values under accepted MA-020/A-006.
- S1/S2 non-append list assertions depend on empty-shell + terminal producer non-execution.

Result:
`PASS_FOR_REVIEW_SIMULATION`

### Primary root gate

Review root:
- `ROOT.page=RunRecordPrimaryPage`
- `ROOT.class=RuleIQ-Data-TestRefLib`
- primarySetup=false
- explicit named runtime page `CustomerCommunication -> Data-Customer` comes from RUT UPDATE_PAGE page creation.

No reserved root is used.

Result:
`PASS_FOR_REVIEW_SIMULATION`

### Decision Table gate

Not applicable.

### Grouping gate

Original RUT type is `Rule-Obj-Model`, therefore Section 11 requires exactly one STANDARD physical group per frozen Scenario.

Physical grouping is therefore fixed:

- `G001` -> `S1`, local scenario order 1
- `G002` -> `S2`, local scenario order 1
- `G003` -> `S3`, local scenario order 1

No simulation-key grouping is performed for a non-When RUT.
Group order preserves frozen S order.

## MA-008 impact escalation — actual formal type `STRING` versus Section 13 compatibility values

Existing MA-008 already records that the supplied correct RUT uses:
`pyParametersParamType="STRING"`.

Section 13 formal RUT provenance says:
- copy the exact formal type spelling/case from original RuleJSON;
- String arguments require a string/empty value;
- missing/unknown/unsupported type creates `RUT_PARAMETER_PROJECTION_UNAVAILABLE`.

The type compatibility wording uses `String`, while the correct environment export is `STRING`.

This makes MA-008 materially affect ScenarioGroup testability:

Literal first-pass:
- formalType = exact `STRING`;
- no explicit equivalence rule says `STRING` is the supported String type;
- a strict model can classify it unsupported;
- each Scenario then receives:
  `GAP code=RUT_PARAMETER_PROJECTION_UNAVAILABLE scope=Param.CustomerID effect=PARTIAL`;
- Scenario cannot be Testable.

MA-008 remains `CONFIRMED_DEFECT`; its later correction must cover BOTH:
1. exported definition field name `pyParametersParamType`;
2. exported type token/case `STRING` as the environment's String formal type.

Review continuation assumption:
- treat exact exported `STRING` as the supported String type in this RuleIQ environment.
- preserve raw `formalType="STRING"` in evidence; normalize only the semantic compatibility classification.

## MA-026 — mandatory TestedRuleKey identity is checked too late / absent from initial gate

- Location: Section 4 initial validation versus Section 13.1.1 PROFILE.
- Status: `CONFIRMED_FAIL_FAST_GAP`.
- Section 13 requires `PROFILE.caseKey = exact GetCaseData.TestedRuleKey`.
- It requires the first three whitespace-separated components to match uppercase
  `SG.rutType`, `SG.rutClass`, `SG.rutName`.
- Missing/conflicting identity terminates materialization; inventing a key is forbidden.
- Section 4 initial gate does not require non-empty/consistent `TestedRuleKey`.
- Therefore the agent can complete crawl, scenario formation, assertion decisions, and grouping
  before discovering a mandatory source identity is absent/conflicting.

This is analogous to MA-006 for `pyID`.

Recommended later correction:
Initial identity gate, immediately after GetCaseData:
- require non-empty `pyID`;
- require parseable non-empty `TestedRuleKey`;
- require non-empty RuleJSON.pzInsKey / pxObjClass / pyClassName / pyRuleName;
- verify TestedRuleKey's RUT identity components against original RuleJSON before semantic work.

### Review-only identity bridge

The user did not supply actual `GetCaseData.pyID` or `GetCaseData.TestedRuleKey`.

Production result from available evidence:
`MATERIALIZATION_IDENTITY_NOT_PROVEN`

To exercise Section 13 grammar only, use:
- caseId: `<SYNTHETIC_pyID>`
- caseKey:
  `RULE-OBJ-MODEL RULEIQ-DATA-TESTREFLIB PREPARECUSTOMERCOMMUNICATION #SYNTHETIC`

This synthetic key is deliberately shaped so its first three tokens satisfy the Section 13
identity comparison. It is NOT a real GetCaseData value and MUST NOT be described as Verified.

## MA-027 — PROFILE binding evidence over-requires Rule-Obj-Property definitions

- Location: Section 13.1.1 `PROFILE.bindings` and nested acquisition snapshots.
- Status: `CONFIRMED_CONTRACT_AMBIGUITY / likely defect`.

Contract:
- one binding exists for every non-cell ASSERT;
- then for **each binding**, EVIDENCE source
  `PROPERTY_DEFINITION/<assertionID>` must capture `path`, `pyPropertyMode`, and `pyStringType`
  from a resolved property definition.

But valid non-cell ASSERT types in this simulation include:
- `Param.ExitCode`, `Param.AddressIndex`, `Param.StreetName` (parameter-page values);
- named page `CustomerCommunication` Page Exists;
- collection/list structural assertions.

A formal Param value is not necessarily backed by a Rule-Obj-Property definition.
A runtime named page created by UPDATE_PAGE is likewise not a Rule-Obj-Property leaf.

The same PROFILE text already treats Param assertions specially (`Text`, no parentMode), but the
mandatory nested PROPERTY_DEFINITION evidence rule does not state an exception or alternative
source for Param/named-page structural bindings.

Literal impact:
- a semantically valid Param or runtime named-page assertion can become unmaterializable solely
  because no Rule-Obj-Property definition exists for that assertion target.

Recommended later correction:
- scalar Rule-Obj-Property assertion -> PROPERTY_DEFINITION evidence required;
- Param assertion -> RUT/dependency formal-parameter definition evidence + assertion context;
- named-page/Page structural assertion -> runtime page/class creation/context evidence;
- list structural assertion -> owning Rule-Obj-Property definition when the list is a property,
  plus runtime producer/context evidence.
Do not fabricate Rule-Obj-Property definitions for Param or named-page targets.

Review materialization uses these intended evidence alternatives and does not invent property rules.

## MA-028 — skipped-branch output omissions create blocking gaps for otherwise deterministic scenarios

- Location: Section 6.0-PRE UNKNOWN-presence rule + Section 12.4 confidence/testability.
- Status: `OPEN DESIGN DEFECT / literal behavior confirmed`.

Current rule:
- a skipped output with UNKNOWN initial presence must be
  `OMIT reason=unresolvable_runtime_input`;
- record a GAP/testability decision;
- any blocking gap affecting an exact value/branch/dependency-controlled value prevents High/full
  and forces Low + PartiallyTestable or NotTestable.

Because candidate enumeration includes every RUT-modified property, mutually exclusive branch
outputs that do not execute in a Scenario still become candidates.

Literal consequences here:

S1:
- `Param.AddressIndex` skipped by prior EXIT -> initial presence unknown -> OMIT + GAP.
- `Param.StreetName` skipped -> OMIT + GAP.

S2:
- `Param.ExitCode` skipped -> OMIT + GAP.
- `Param.StreetName` skipped -> OMIT + GAP.

S3:
- `Param.ExitCode` skipped -> OMIT + GAP.

Thus every Scenario acquires at least one blocking GAP even though:
- the controlling path is terminally known;
- meaningful positive assertions remain;
- dependency closure itself is complete.

Literal first-pass testability:
- S1: PartiallyTestable / Low
- S2: PartiallyTestable / Low
- S3: PartiallyTestable / Low

This appears over-conservative because non-executed mutually-exclusive outputs are not required
to prove the Scenario's positive behavior. A skipped output's unknown pre-existing Param state
can justify **not asserting it**, without necessarily making the Scenario partially testable.

Candidate correction for later review:
- distinguish `NON_APPLICABLE_OUTPUT` / `incorrect_candidate_assertion` style omission for a
  terminally non-executed producer when the pre-existing value is outside the tested rule's
  produced effect and no assertion about absence/unchanged state is required;
- reserve `unresolvable_runtime_input` + blocking GAP for claims whose unresolved runtime state
  actually affects the Scenario's execution, required simulation, expected output, or requested
  assertion.
- Never claim `Not exists` for a skipped Param output unless initial absence is proven.

Do not apply this correction silently in the first pass. The literal first-pass status above is retained.

## Physical group semantic status before Section 13 serialization

### G001 / S1

Scenario:
- frozen membership unchanged.
- owner/covers unchanged.

Semantic decisions:
- ASSERT count = 7
- OMIT count = 3
- SIM count = 1

Literal GAPs under MA-028 current wording:
- GAP for unresolved final presence/value of `Param.AddressIndex`
- GAP for unresolved final presence/value of `Param.StreetName`

Summary implication:
- supportLevel = OmittedClaimsPresent
- dependencyState = AllResolved
- branchState = AllEvaluated
- simulationState = RequiredAndAligned
- dependencyClosureStatus = Blocked because GAP census non-empty
- testability = PartiallyTestable
- confidence = Low

### G002 / S2

Semantic decisions:
- ASSERT count = 7
- OMIT count = 3
- SIM count = 1

Literal GAPs:
- `Param.ExitCode`
- `Param.StreetName`

Summary:
- OmittedClaimsPresent
- AllResolved
- AllEvaluated
- RequiredAndAligned
- Blocked
- PartiallyTestable / Low

### G003 / S3

Semantic decisions:
- ASSERT count = 8
- OMIT count = 2
- SIM count = 1

Literal GAP:
- `Param.ExitCode`

Summary:
- OmittedClaimsPresent
- AllResolved
- AllEvaluated
- RequiredAndAligned
- Blocked
- PartiallyTestable / Low

Input-only `Param.CustomerID` omission with `incorrect_candidate_assertion` is not itself treated
as a blocking runtime GAP.

## Section 13 production self-parse feasibility

From the evidence actually available in this external review:

Cannot truthfully prove PASS because:
1. actual `GetCaseData.pyID` is unavailable;
2. actual `GetCaseData.TestedRuleKey` is unavailable;
3. some dependency RuleJSON is synthetic review-only and cannot be recorded as an actual
   RuleCrawler `returned`/fetched acquisition in PROFILE.EXECUTION_AUDIT;
4. exact production `given` grammar is ambiguous (MA-018);
5. exact production `DP_SIG` grammar is ambiguous (MA-021);
6. Param/named-page binding provenance is ambiguous (MA-027);
7. literal formal type handling may reject actual `STRING` without MA-008 correction.

Therefore:
`PRODUCTION_SCENARIOGROUP_SELF_PARSE = NOT_PROVEN`

This is an evidence/contract result, not a claim that a real Pega run would fail if GetCaseData and
RuleCrawler supply the missing values.

## Review-only materialization continuation

To continue testing the control flow, the review may materialize **synthetic ScenarioGroup-shaped
records** using:
- synthetic identity placeholders;
- explicitly marked synthetic acquisition fixtures;
- accepted/intended resolutions for MA-008, MA-018, MA-020, MA-021, MA-025, MA-027.

Such payloads are review fixtures only.
They MUST NOT be described as valid production ScenarioGroup payloads or sent to WriteMemory.

## Current execution position

`semantic re-audits complete -> physical groups G001/G002/G003 fixed -> production self-parse NOT PROVEN -> review-only materialization may continue -> PAUSED before constructing complete review ScenarioGroup v1.4 records and B/A audit`.


---

## Checkpoint — Section 13 materialization preflight forces a WITNESSES rewind

### Why the previous FROZEN snapshot was incomplete

Section 12.3 says a final `SIM` freezes, among other fields:
- exact rule;
- DP signature;
- shape/method/class;
- normalized parameters;
- target;
- mocking rule type;
- referred-from class;
- **setup pages**;
- complete payload;
- parameter resolutions;
- evidence.

Section 13 revision 1.3 further requires:
- `SIM.setupPages` to be the complete ordered census of actual simulation pages;
- exactly one `SIMULATION_BINDING/<simulationID>` evidence snapshot;
- for `shape=page`, `itemPath=null`;
- a concrete `payloadPage` that identifies exactly one page in that nonempty setupPages census;
- no payload-page name may be invented during downstream materialization by convention.

The prior review F snapshot froze the business payloads but did **not** freeze:
- the exact simulation payload-carrier page;
- the exact `setupPages` census;
- the `SIMULATION_BINDING` payloadPage/itemPath fact;
- the PROFILE `scenarioType` category.

Those are semantic source fields, not downstream formatting.

Therefore:
`FROZEN_v10/v11/v12 = INCOMPLETE_FOR_V1.4_MATERIALIZATION`

Correct prompt behavior is:
`return to WITNESSES`, not patch the missing fields during serialization.

This is a simulation-process defect caught by the prompt's own self-audit, not a new Main-Agent defect.

## WITNESSES repair — review-only synthetic simulation carrier

The user has explicitly authorized synthetic fixtures for dependency/runtime content they cannot provide.

Use one clearly synthetic carrier solely for control-flow testing:

`payloadPage = "ReviewSimPayload"`

This is:
- `SYNTHETIC_SIMULATION_FIXTURE`;
- not a real Pega page name;
- not inferred from the Data Page name;
- not PrimaryPage;
- not evidence about the production application.

For all three page-shaped DP simulations:

```json
{
  "itemPath": null,
  "payloadPage": "ReviewSimPayload"
}
```

Review-only exact setup-page census:

```json
[
  {
    "pyPageDetails": [],
    "pySetupPageName": "ReviewSimPayload"
  }
]
```

Rationale:
- the complete typed mock result remains in `SIM.payload`;
- the setup-page array identifies exactly one payload carrier;
- there are no additional independently typed page-detail overrides in this review fixture;
- the Generator-side revision-1.3 rule says the frozen payload is placed on the payloadPage and explicitly typed page-detail seeds are merged separately.

No DP-named page or PrimaryPage is selected by convention.

### Repaired final SIM semantics

Common:
- rule = `D_CustomerTestRef`
- shape = page
- method = DefineData
- class = `Data-Customer`
- itemClass = absent
- target = `D_CustomerTestRef`
- mockingRuleType = `Rule-Declare-Pages`
- referredFromClass = absent in this review because no exact source value was supplied
- params = review-normalized typed `CustomerID="CUST-001"`
- setupPages = exact census above
- SIMULATION_BINDING = `{"itemPath":null,"payloadPage":"ReviewSimPayload"}`

S1 payload:
```json
{"Addresses":[],"pxObjClass":"Data-Customer"}
```

S2 payload:
```json
{"Addresses":[{"pxObjClass":"Data-Address-Postal","pyCity":"Utrecht","pyPostalCode":""}],"pxObjClass":"Data-Customer"}
```

S3 payload:
```json
{"Addresses":[{"pxObjClass":"Data-Address-Postal","pyCity":"Utrecht","pyPostalCode":"3511AA","pyStreet":"Main 12"}],"pxObjClass":"Data-Customer"}
```

For `parameterResolutions`, freeze the semantic rule:
- select the complete parameter set of the first executed `D_CustomerTestRef` access in each Scenario;
- that access resolves `CustomerID` from current `Param.CustomerID`;
- later equal-map accesses retain their own PARAM rows but share the same SIM.

The eventual deterministic PARAM ID is assigned only during Section 13 materialization.

## WITNESSES repair — PROFILE scenario category

The previous freeze also omitted the required PROFILE semantic category.

Review-only category selection:
- S1 invalid-city/EXIT = `Edge`
- S2 valid-city/no-postal/no-append = `Edge`
- S3 normal successful postal-selection/append = `Baseline`

These categories do not alter owner coverage, execution, inputs, or simulation payload.

## Re-execution after WITNESSES repair

S1:
- empty Addresses -> helper no-match -> first Model WHEN true -> ExitCode -> EXIT.
- covers unchanged: `1.1:true`, `1.1.2:exit`.

S2:
- city-valid/postal-invalid synthetic item -> AddressIndex=-1 -> second Model WHEN false -> no append.
- covers unchanged: `1.1:false:continue`, `1.3:false:no_append`.

S3:
- city-valid/postal-valid item -> AddressIndex=1 -> append/map -> StreetName="MAIN".
- covers unchanged: `1.1:false:continue`, `1.3:true`.

No assertion or omission decision changes.
No seed-direction conflict is introduced.
No physical Scenario can be removed.

## Re-FROZEN result

`FROZEN_REPAIR = PASS_FOR_REVIEW_SIMULATION`

Final membership remains:
- S1 -> G001
- S2 -> G002
- S3 -> G003

The common setupPages carrier adds the same structural cost to every witness and therefore does not
alter relative F cost or the prior review-only S ordering.

The repaired frozen SIM now contains the v1.4 source fields needed for a materialization attempt.

---

## MA-029 — ScenarioGroup DEP.kind cannot represent the authoritative dependency model

### Evidence

Authoritative DWL canonical kinds include:
- `When`
- `DTable`
- `Model`
- `Prop`
- `RUF`
- `DP`
- other exact Pega rule types.

Section 13.4.3, however, defines:

`DEP.kind=<RUF|DP|HELPER|DT|NOT_APPLICABLE>`

It does not permit:
- `When`
- `Prop`
- `Model`
- arbitrary exact dependency rule types.

### Concrete impact on this RUT

Branch/result correctness depends on:
- `When@Data-Address-Postal@IsValidCity`
- `When@Data-Address-Postal@IsValidPostalAddress`

Context/type correctness depends on:
- `Prop@Data-Customer@Addresses`
- `Prop@Data-Address-Postal@pyCity`
- `Prop@Data-Address-Postal@pyPostalCode`
- `Prop@Data-Address-Postal@pyStreet`

The source contract simultaneously requires:
- positive exact claims to be supported by closed dependencies;
- ScenarioGroup to be a complete immutable semantic source;
- dependency evidence/closure to be truthful;
- no invented mapping.

There is no stated legal mapping:
- `When -> HELPER`
- `Prop -> HELPER`
or any other substitute.

Using `HELPER` for these exact Pega rule types would lose canonical dependency kind and would be an
unsupported transformation.

### Status

`MA-029 = CONFIRMED_CONTRACT_DEFECT`

### Required correction

Preferred:
extend `DEP.kind` to carry the authoritative exact dependency category, for example:

`kind=<When|DTable|Model|Prop|RUF|DP|Helper|Other>`

with an additional exact `ruleType` field if `Other` is permitted.

Even cleaner:
make `kind` the exact canonical DWL kind/token used in `KEY`, so ScenarioGroup does not maintain a
second narrower dependency taxonomy.

If backward compatibility requires existing labels:
- retain `DT` only as an explicit canonical alias for `DTable`;
- define any alias mapping normatively;
- never silently collapse `When`/`Prop`/`Model` into `HELPER`.

---

## Section 13 self-parse result under the frozen original prompt

Even after the review-only WITNESSES repair, a **semantically complete** ScenarioGroup v1.4 payload
for this RUT cannot be produced under the literal original grammar without violating MA-029.

A structurally parseable payload could be manufactured by:
- dropping When/Prop dependencies; or
- mislabeling them as HELPER.

Both violate the source-of-truth/completeness rules and are therefore forbidden.

Thus:

`REVIEW_SCENARIOGROUP_SELF_PARSE_ORIGINAL_PROMPT = FAIL`

Primary intrinsic blocker:
`MA-029 DEP kind cannot encode required closed dependencies.`

Additional already-recorded blockers/ambiguities remain:
- MA-008 formal `STRING` compatibility;
- MA-018 exact `given` grammar;
- MA-021 exact DP_SIG grammar;
- MA-025 terminal EXIT non-execution representation;
- MA-027 binding provenance for Param/named-page structural assertions;
- MA-028 skipped-output GAP/testability policy.

External-review-only blockers:
- real `GetCaseData.pyID` unavailable;
- real `GetCaseData.TestedRuleKey` unavailable;
- synthetic Wave 2 dependency acquisition cannot be represented as a real RuleCrawler return.

## First-pass terminal state

The frozen original prompt reaches Section 13 materialization but fails the mandatory self-parse
before WriteMemory.

Therefore the correct simulated first-pass control flow is:

`GetCaseData`
-> semantic acquisition/crawl
-> I/W/F
-> ASSERT/SIM/OMIT
-> grouping
-> v1.4 materialization attempt
-> `SELF_PARSE = FAIL`
-> **no WriteMemory**
-> **no UnitTestGenerator**

This completes the first-pass failure path for the Scenario Author prompt.

The next review phase should be the user-requested coherent correction pass:
1. consolidate accepted fixes and confirmed defects into one consistent prompt/KnowledgeArea patch plan;
2. apply the correction model conceptually without modifying repository files yet;
3. rerun the same baseline RUT from GetCaseData through ScenarioGroup self-parse;
4. verify that the corrected baseline reaches B/A without introducing new contradictions.


---

## D-003 — MA-029 canonical DEP kind solution adopted for current simulation

### Decision

`MA-029 = CONFIRMED_CONTRACT_DEFECT -> SOLUTION_ACCEPTED_FOR_CURRENT_SIMULATION`

Adopt **canonical-kind projection**. Do not use a second ScenarioGroup-only dependency taxonomy.

Corrected record grammar:

`DEP|scenario=<ID>|id=<ID>|order=<N>|kind=<canonicalDWLKind>|identity=<canonicalIdentity>|state=<CLOSED|KEYONLY|MISSING|LIMIT|OMIT_NONCRITICAL|NOT_APPLICABLE>|parameters=<canonicalTypedJSONOrAbsent>|proof=<proof>|evidence=<evidenceIDs>`

Normative rules:

1. `kind=NOT_APPLICABLE` is the only non-DWL special value.
2. Otherwise `identity` MUST equal an exact canonical `KEY` already present in the final Author
   dependency ledger:
   `<kind>@<applyToClass>@<name>`.
3. `DEP.kind` MUST equal the exact first component of `DEP.identity`.
4. No case folding, aliasing, inferred category conversion, or semantic remapping is allowed.
5. Current canonical kinds therefore include:
   - `When`
   - `DTable`
   - `Model`
   - `Prop`
   - `RUF`
   - `DP`
   plus another exact kind only when that kind already exists in an authoritative canonical D row.
6. New Author payloads MUST NOT emit the legacy ScenarioGroup-only aliases `DT` or `HELPER`.
   - Decision Tables use canonical `DTable`.
   - Page/list helper calls remain represented by their actual canonical dependencies:
     RUF / When / Prop as applicable.
7. Generator validates the same exact prefix equality and never translates `kind`.
8. `DEP.identity` remains the semantic authority; `kind` is a mechanically checkable projection.
9. The fix is applied atomically to:
   - `Main_Agent_Prompt.txt` ScenarioGroup producer grammar;
   - `UnitTestGenerator_Prompt.txt` ScenarioGroup consumer grammar.
10. UnitTestValidator requires no corresponding change because it does not read ScenarioGroup.

### Wire revision decision for this refactor

Keep:
`SG.version=1.4`

Reason:
- field order and arity are unchanged;
- existing values remain structurally representable;
- this repairs an internally inconsistent/unimplementable enum in the current refactor contract;
- Main + Generator are treated as one atomically synchronized contract revision in this review.

If revision 1.4 were already an independently deployed/public wire protocol consumed by older parsers,
a new revision would be safer. That is not the assumption used for the current repository simulation.

### Consequence for current RUT

The following dependencies can now be represented losslessly:

- `DP@Data-Customer@D_CustomerTestRef`
- `Prop@Data-Customer@Addresses`
- `Prop@Data-Address-Postal@pyCity`
- `Prop@Data-Address-Postal@pyPostalCode`
- `Prop@Data-Address-Postal@pyStreet`
- `RUF@@UTILITIES!ISINPAGELISTWHEN`
- `RUF@@UTILITIES!INDEXINPAGELISTWHEN`
- `RUF@@STRING!TOUPPERCASE`
- `RUF@@STRING!TRIMNUMBER`
- `RUF@@STRING!STRIPNONALPHABETICCHARS`
- `When@Data-Address-Postal@IsValidCity`
- `When@Data-Address-Postal@IsValidPostalAddress`

Examples:

`kind=When|identity=When@Data-Address-Postal@IsValidCity`

`kind=Prop|identity=Prop@Data-Customer@Addresses`

`kind=RUF|identity=RUF@@STRING!TOUPPERCASE`

`kind=DP|identity=DP@Data-Customer@D_CustomerTestRef`

No dependency is collapsed into `HELPER`.

### Simulation resume point

The MA-029-only self-parse blocker is removed under D-003.

Resume:

`repaired WITNESSES/FROZEN`
-> physical groups G001/G002/G003
-> review-only ScenarioGroup v1.4 materialization
-> mandatory self-parse
-> B
-> independent A

All previously accepted/intended review bridges remain in force and remain clearly non-production:
MA-008, MA-018, MA-020, MA-021, MA-025, MA-027, synthetic case identity, and synthetic Wave 2 fixtures.

No `WriteMemory` or UnitTestGenerator tool call is authorized in this external review.


---

## Checkpoint — D-003 applied; ScenarioGroup review self-parse and B/A now pass

### D-003 validation against current dependency closure

The corrected DEP contract was exercised with the complete current closed dependency census:

1. `DP@Data-Customer@D_CustomerTestRef`
2. `Prop@Data-Customer@Addresses`
3. `Prop@Data-Address-Postal@pyCity`
4. `Prop@Data-Address-Postal@pyPostalCode`
5. `Prop@Data-Address-Postal@pyStreet`
6. `RUF@@UTILITIES!ISINPAGELISTWHEN`
7. `RUF@@UTILITIES!INDEXINPAGELISTWHEN`
8. `RUF@@STRING!TOUPPERCASE`
9. `RUF@@STRING!TRIMNUMBER`
10. `RUF@@STRING!STRIPNONALPHABETICCHARS`
11. `When@Data-Address-Postal@IsValidCity`
12. `When@Data-Address-Postal@IsValidPostalAddress`

For every materialized DEP:

`DEP.kind == first component of DEP.identity`

Examples:

- `kind=DP` / `identity=DP@Data-Customer@D_CustomerTestRef`
- `kind=Prop` / `identity=Prop@Data-Customer@Addresses`
- `kind=When` / `identity=When@Data-Address-Postal@IsValidCity`
- `kind=RUF` / `identity=RUF@@STRING!TOUPPERCASE`

No `HELPER` or `DT` alias was emitted.

Result:

`MA-029_D003_VALIDATION = PASS`

## Review-only ScenarioGroup v1.4 materialization

Important evidence qualification:

`REVIEW_ONLY_SYNTHETIC_FIXTURE`

The materialized records use the already-declared review bridges:
- `<SYNTHETIC_pyID>`;
- synthetic TestedRuleKey;
- synthetic scalar property/When evidence where unavailable;
- synthetic Wave 2 completion;
- accepted/intended review resolutions MA-008, MA-018, MA-020, MA-021, MA-025, MA-027;
- D-003 for MA-029.

They are NOT production ScenarioGroup payloads and MUST NOT be sent to real WriteMemory.

### G001 / S1 record census

- TARGET = 2
- PARAM = 3
- INPUT = 1
- SETUP = 0
- RX = 7
- DEP = 12
- BRANCH = 2
- PRODUCER = 1
- PROPERTY = 10
- SIM = 1
- ASSERT = 7
- OMIT = 3
- EVIDENCE = 63
- GAP = 2
- SUMMARY = 1
- NARRATIVE = 1
- total records including SG/ROOT/CRAWL/SCENARIO/PROFILE/END = 122

### G002 / S2 record census

- TARGET = 2
- PARAM = 4
- INPUT = 1
- SETUP = 0
- RX = 6
- DEP = 12
- BRANCH = 2
- PRODUCER = 1
- PROPERTY = 10
- SIM = 1
- ASSERT = 7
- OMIT = 3
- EVIDENCE = 64
- GAP = 2
- SUMMARY = 1
- NARRATIVE = 1
- total records = 123

### G003 / S3 record census

- TARGET = 2
- PARAM = 5
- INPUT = 1
- SETUP = 0
- RX = 10
- DEP = 12
- BRANCH = 2
- PRODUCER = 6
- PROPERTY = 10
- SIM = 1
- ASSERT = 8
- OMIT = 2
- EVIDENCE = 77
- GAP = 1
- SUMMARY = 1
- NARRATIVE = 1
- total records = 145

### Mandatory self-parse checks exercised

The review parser verified:

- UTF-8/LF record framing and terminal LF;
- exact tag order;
- exact field order/arity for every emitted tag;
- STANDARD group cardinality;
- group/scenario identity;
- contiguous per-tag order fields;
- valid IDs;
- all EVIDENCE references resolve;
- ROOT named-page evidence resolves;
- D-003 exact DEP kind/identity-prefix equality;
- producer -> RX references resolve;
- producer -> BRANCH references resolve when applicable;
- ASSERT -> PRODUCER references resolve;
- SIM.parameterResolutions resolve;
- exactly one SIMULATION_BINDING/M001 exists;
- `shape=page -> itemPath=null`;
- payloadPage occurs exactly once in SIM.setupPages;
- PROFILE has exactly 16 Author-owned checklist facts;
- PROFILE binding census equals ASSERT census;
- all binding evidence references resolve;
- SCENARIO_SNAPSHOT/PROFILE evidence fact exactly equals PROFILE.data;
- SUMMARY counts equal actual ASSERT/OMIT/SIM/GAP records;
- blockingGaps equals exact GAP census;
- END counts equal recomputed payload counts;
- TARGET census equals Scenario covers inside each physical group;
- review synthetic caseKey passes the first-three-token identity comparison.

Result:

`REVIEW_SCENARIOGROUP_SELF_PARSE_WITH_D003 = PASS`

This is a control-flow/contract pass under the declared review fixtures, not production evidence.

---

## AUDIT BASE B

Physical locations are zero-based:

- S1 -> `0:0` -> G001 scenario 0
- S2 -> `1:0` -> G002 scenario 0
- S3 -> `2:0` -> G003 scenario 0

B preserves frozen given/simulation/name/location and intentionally removes owner/covers:

```text
P|B|<SYNTHETIC_pyID>|RULE-OBJ-MODEL RULEIQ-DATA-TESTREFLIB PREPARECUSTOMERCOMMUNICATION #20260430T104351.201 GMT|Rule-Obj-Model
S|S1|<review-given>|-|-|<review-sim-empty-addresses>|Invalid city exit|0:0
S|S2|<review-given>|-|-|<review-sim-no-postal>|No postal match|1:0
S|S3|<review-given>|-|-|<review-sim-postal-match>|Postal match append|2:0
```

`B = PASS_FOR_REVIEW_SIMULATION`

No semantic field changed during B mapping.

---

## Independent AUDITED A reconstruction

A did not reuse F owner/covers.

It reconstructed coverage from the materialized branch/runtime records:

### S1

Materialized execution:
- first Model WHEN = TRUE;
- EXIT_MODEL executes.

Independent owner/covers:

- owner = `1.1:true`
- covers =
  - `1.1:true`
  - `1.1.2:exit`

Matches F exactly.

### S2

Materialized execution:
- first Model WHEN = FALSE;
- second Model WHEN = FALSE.

Independent owner/covers:

- owner = `1.3:false:no_append`
- covers =
  - `1.1:false:continue`
  - `1.3:false:no_append`

Matches F exactly.

### S3

Materialized execution:
- first Model WHEN = FALSE;
- second Model WHEN = TRUE;
- append producer executes.

Independent owner/covers:

- owner = `1.3:true`
- covers =
  - `1.1:false:continue`
  - `1.3:true`

Matches F exactly.

### Independent target union

Reconstructed actual coverage:

- `1.1:true`
- `1.1.2:exit`
- `1.1:false:continue`
- `1.3:true`
- `1.3:false:no_append`

This equals the complete corrected REQUIRED inventory.

No missing targets.
No extra targets.
No dependency-owned target appears.

### Irredundancy check

Remove S1:
- loses `1.1:true`, `1.1.2:exit`.

Remove S2:
- loses `1.3:false:no_append`.

Remove S3:
- loses `1.3:true`.

Therefore no S is removable.

### Materialization bijection

- F S1 <-> exactly one G001 Scenario
- F S2 <-> exactly one G002 Scenario
- F S3 <-> exactly one G003 Scenario

No duplicate or missing materialized Scenario.

Review-normalized A result:

```text
A|required=1.1:false:continue,1.1.2:exit,1.1:true,1.3:false:no_append,1.3:true
 |blocked=-
 |unreachable=-
 |equivalent=-
 |actualCovered=1.1:false:continue,1.1.2:exit,1.1:true,1.3:false:no_append,1.3:true
 |missing=-
 |extra=-
 |materialized=S1,S2,S3
 |PASS
```

Result:

`AUDITED_A = PASS_FOR_REVIEW_SIMULATION`

---

## Current simulation position after D-003

The corrected review path is now:

`GetCaseData review fixture`
-> semantic Knowledge/crawl
-> I
-> W
-> F
-> ASSERT/SIM/OMIT
-> physical grouping
-> ScenarioGroup v1.4 materialization
-> self-parse PASS
-> B PASS
-> independent A PASS
-> **PAUSED BEFORE WriteMemory**

This demonstrates that MA-029 was the immediate intrinsic blocker at the previous boundary and that
D-003 removes it without changing Scenario coverage, membership, assertions, simulations, or grouping.

### Next major boundary

The exact real-agent next action would be sequential:

`WriteMemory(CaseID=<exact GetCaseData.pyID>, Type="ScenarioGroup", Payload=<G001 exact bytes>)`

then G002, then G003, validating each S1 result envelope before continuing.

In this external review:
- real CaseID is unavailable;
- the payloads deliberately contain review-only synthetic acquisition evidence;
- no Pega WriteMemory interface is available here;
- therefore no WriteMemory response may be invented.

Do not simulate a successful UUID.

The next review step, if continuing without real Pega execution, is to inspect the exact intended
WriteMemory call boundary and then separately begin the downstream UnitTestGenerator prompt simulation
only with explicitly synthetic storage-result fixtures if the user authorizes that.


---

## D-004 — atomic batched WriteMemory contract adopted for current simulation

### User requirement

Store all final physical ScenarioGroups as separate immutable Memory records using **one AI tool invocation**.
For the current baseline:
- G001 -> one ScenarioGroup record
- G002 -> one ScenarioGroup record
- G003 -> one ScenarioGroup record
- one WriteMemory invocation returns three opaque UUIDs in group order.

The current prompt contract (`WriteMemory once per physical group`) is therefore superseded.

### MA-030 — single-record WriteMemory contract does not satisfy required one-call batch persistence

Status:
`ARCHITECTURAL_CONTRACT_CHANGE_ACCEPTED`

This is not a semantic Scenario defect. The previous sequential protocol was internally valid, but it
does not satisfy the newly explicit tool-call requirement and increases agent/tool-call exposure.

### Pega-facing design decision

Use a **scalar JSON batch envelope** rather than exposing a Page List/complex object directly as an
AI-tool parameter.

Model-facing tool signature:

`WriteMemory(CaseID=<string>, Type=<string>, RequestsJSON=<string>)`

All three parameters are scalar.
For Scenario Author:
- `CaseID` = exact GetCaseData.pyID
- `Type` = exact literal `ScenarioGroup`
- `RequestsJSON` = canonical minified JSON batch document.

The same generic interface may later be used by UnitTestGenerator with a one-item batch for
`Type=UnitTestCandidate`, keeping one Memory-write contract across agents.

Rationale:
- Pega activity guidance favors scalar parameters over complete page references.
- Pega JSON Data Transforms support object/array deserialization into Clipboard/Page List structures.
- A scalar JSON input keeps the Tool Rule schema small and predictable for the LLM.
- It avoids Base64 expansion and avoids a custom line-framing parser/Java implementation.
- One call also avoids relying on the agent to carry three separate tool responses across calls.

### Exact RequestsJSON v1 grammar

Canonical decoded JSON object:

```json
{
  "atomic": true,
  "requests": [
    {
      "order": 1,
      "payload": "<exact complete payload bytes represented as one JSON string>",
      "requestId": "G001"
    },
    {
      "order": 2,
      "payload": "<exact complete payload bytes represented as one JSON string>",
      "requestId": "G002"
    },
    {
      "order": 3,
      "payload": "<exact complete payload bytes represented as one JSON string>",
      "requestId": "G003"
    }
  ],
  "version": "1"
}
```

Normative rules:
1. root keys are exactly `atomic`, `requests`, `version`;
2. `version` is exact string `"1"`;
3. `atomic` is exact boolean `true`;
4. `requests` is nonempty;
5. every item has exactly `order`, `payload`, `requestId`;
6. `order` is integer, one-based, contiguous, and equals array position;
7. `requestId` is nonempty and unique;
8. Scenario Author uses exact groupId as requestId (`G001`, `G002`, ...);
9. `payload` is nonempty;
10. after exactly one JSON decode, payload bytes/string characters are the exact already-self-parsed
    ScenarioGroup payload, including its final LF;
11. do not trim, normalize CR/LF, perform a second unescape, rewrite ledger escaping, or reserialize
    ScenarioGroup records before persistence;
12. all requests in one call use the same outer `CaseID` and `Type`;
13. Scenario Author batch order equals ascending groupOrder;
14. duplicate requestIds, noncontiguous order, malformed JSON, unsupported Type, or an empty payload
    is `INVALID_INPUT` / `UNSUPPORTED_TYPE` before any persistence.

Canonical serialization for the AI call uses minified JSON with recursively sorted object keys and
preserved request-array order. This gives deterministic request bytes but does not change any nested
ScenarioGroup payload semantics.

### Atomic persistence semantics

The batch tool MUST be all-or-nothing.

Execution:
1. Parse RequestsJSON.
2. Validate the entire envelope and every request before creating/saving anything.
3. Prepare N independent immutable Memory instances, one per request.
4. Persist all N records inside one Pega transaction; do not commit per item.
5. Commit only after every item is prepared/saved successfully.
6. On validation/save failure before commit: rollback/abandon the whole transaction.
7. Return no UUID as successful when the batch is rolled back.
8. Never expose a partially successful batch to the caller.
9. No agent retry after invocation exception/malformed result because commit outcome may be uncertain.
10. If implementation currently performs an independent commit inside each single-record write,
    it must be refactored before D-004 is considered implemented.

Pega built-in transaction handling is the intended mechanism; avoid hand-coded Java when a
Data Transform + transaction-aware save path can implement the contract.

### Exact result envelope

Tool output keeps scalar fields:

- `Success` boolean
- `ResultsJSON` string
- `ErrorCode` string
- `ErrorMessage` string

#### Success

`Success=true` requires:
- nonempty ResultsJSON;
- empty ErrorCode;
- empty ErrorMessage.

Decoded ResultsJSON exact grammar:

```json
{
  "results": [
    {
      "order": 1,
      "requestId": "G001",
      "uuid": "<opaque nonempty UUID>"
    },
    {
      "order": 2,
      "requestId": "G002",
      "uuid": "<opaque nonempty UUID>"
    },
    {
      "order": 3,
      "requestId": "G003",
      "uuid": "<opaque nonempty UUID>"
    }
  ],
  "version": "1"
}
```

Success validation:
1. root keys exactly `results`, `version`;
2. version exactly `"1"`;
3. result count exactly equals request count;
4. result order equals request order;
5. requestId and order match the corresponding request exactly;
6. every uuid is a nonempty string;
7. UUIDs are pairwise distinct;
8. UUIDs are opaque: no trimming, normalization, reconstruction, or format inference.

Only after the complete batch response passes does Author derive:

`ScenarioGroupUUIDs = [uuid(G001), uuid(G002), uuid(G003)]`

and call UnitTestGenerator once.

#### Failure

`Success=false` requires:
- `ResultsJSON=""`;
- nonempty bounded ErrorMessage;
- ErrorCode exactly one of:
  - `INVALID_INPUT`
  - `UNSUPPORTED_TYPE`
  - `WRITE_FAILED`

Atomic invariant:
a failure response means **no record from the batch is committed**.

Missing/wrongly typed/wrongly cased output fields, contradictory success/failure carriers, malformed
ResultsJSON, missing/extra result items, duplicate UUIDs, or request/result mismatch are malformed and
terminal.

### Why not a direct Page List tool parameter?

Do not claim Pega universally forbids complex Tool Rule parameters; the review did not establish
such a hard platform rule.

The design deliberately chooses scalar RequestsJSON because it is:
- closer to Pega activity parameter best practice;
- easier for Tool Rule/function-calling schemas;
- versionable independently;
- parseable by a JSON Data Transform into a Page List;
- easier to validate atomically;
- less likely to vary across Pega Agent/Automation surfaces.

### Why not Base64?

Rejected:
- roughly 33% payload expansion;
- additional token cost;
- LLM generation/copying of large Base64 is fragile;
- hides inspectable ScenarioGroup content;
- unnecessary because JSON strings already preserve LF/backslash content losslessly.

### Why not custom WB/ITEM line framing?

Rejected as default:
- slightly less JSON escaping, but requires a custom parser;
- increases implementation-specific framing rules;
- creates another escaping/boundary protocol;
- JSON overhead for the current fixture is modest and Pega has native JSON Data Transform support.

### Current baseline batch size

Review fixture measurements:
- G001 exact payload: 34,175 UTF-8 bytes / 122 records
- G002 exact payload: 35,382 UTF-8 bytes / 123 records
- G003 exact payload: 43,056 UTF-8 bytes / 145 records
- combined raw payload bytes: 112,613
- canonical RequestsJSON file including JSON escaping/newline: 119,513 bytes

The review did not find an authoritative published Pega GenAI Tool Rule hard input-byte limit.
Do not invent one in the prompt.

Implementation should use configurable server-side limits such as max batch bytes / max record count
and return INVALID_INPUT when exceeded. Scenario Author must not silently split a D-004 atomic batch
because that would change the one-call/all-or-nothing contract.

### Current simulation call boundary under D-004

Review-only input artifact:
`REVIEW_WRITEMEMORY_BATCH_D004.json`

The real call would be:

`WriteMemory(CaseID=<exact GetCaseData.pyID>, Type="ScenarioGroup", RequestsJSON=<exact file content>)`

In this external review the CaseID is unavailable and no real Pega WriteMemory tool is exposed.
Therefore no UUID/result is invented.

Simulation state:
`BATCH_REQUEST_CONSTRUCTION = PASS_FOR_REVIEW_SIMULATION`
`BATCH_WRITE_EXECUTION = NOT_PERFORMED`
`ScenarioGroupUUIDs = unavailable`

The next semantic step after a real successful batch response is unchanged:
call UnitTestGenerator exactly once with exact CaseID, immutable original RUTType, and UUIDs in
G001/G002/G003 order.


---

## D-004 refinement — remove outer `atomic` and `version` fields

User challenged the need for the batch-envelope metadata fields.

Decision:
- remove `"atomic": true`;
- remove outer `"version": "1"`.

Reasoning:
- atomicity is an unconditional server-side WriteMemory invariant, not an agent-selectable request option;
- the Tool Rule/action schema itself defines the batch request contract;
- every individual ScenarioGroup payload already carries its own `SG.version=1.4`;
- adding an independent batch-envelope version creates a second protocol lifecycle without a demonstrated need;
- if the WriteMemory batch contract later changes incompatibly, evolve the Tool Rule/action contract explicitly rather than allowing the LLM to choose a version value.

### Corrected D-004 request grammar

Exact root:

```json
{
  "requests": [
    {
      "order": 1,
      "payload": "<exact G001 ScenarioGroup payload>",
      "requestId": "G001"
    },
    {
      "order": 2,
      "payload": "<exact G002 ScenarioGroup payload>",
      "requestId": "G002"
    },
    {
      "order": 3,
      "payload": "<exact G003 ScenarioGroup payload>",
      "requestId": "G003"
    }
  ]
}
```

Normative root rule:
- root has exactly one field: `requests`.

Per-item rules remain:
- exact fields `order`, `payload`, `requestId`;
- nonempty array;
- order one-based, contiguous, and equal to array position;
- requestId nonempty and unique;
- Scenario Author uses exact groupId as requestId;
- payload nonempty and after one JSON decode equals the exact already-self-parsed ScenarioGroup payload.

Atomicity remains mandatory but lives in the WriteMemory implementation contract:

`Success=true -> every requested record committed`

`Success=false -> no requested record committed`

The agent cannot request or disable another transaction mode.

### Corrected success ResultsJSON grammar

Outer result version is also removed for the same reason.

```json
{
  "results": [
    {
      "order": 1,
      "requestId": "G001",
      "uuid": "<opaque UUID>"
    },
    {
      "order": 2,
      "requestId": "G002",
      "uuid": "<opaque UUID>"
    },
    {
      "order": 3,
      "requestId": "G003",
      "uuid": "<opaque UUID>"
    }
  ]
}
```

Decoded ResultsJSON root has exactly one field: `results`.

All correlation/cardinality/order/UUID validation rules remain unchanged.

Current preferred model-facing signature remains:

`WriteMemory(CaseID=<string>, Type=<string>, RequestsJSON=<string>)`

Current review batch artifact:
`REVIEW_WRITEMEMORY_BATCH_D004_v2.json`


---

## D-004 refinement — stable correlation is mandatory; use `groupId`

Previous proposal to remove the request correlation field is withdrawn.

Reason:
- a Page List / JSON array preserves input order, but the WriteMemory implementation may process
  records in parallel or return result rows in a different order;
- UUIDs are intentionally opaque;
- without a stable echoed key, Author cannot prove which returned UUID belongs to which physical
  ScenarioGroup;
- relying on response position would create an unnecessary hidden ordering dependency.

### Correlation decision

Use the existing semantic physical-group identity as the correlation key:

`groupId`

Do not introduce a generic `requestId`.

Request:

```json
{
  "requests": [
    {"groupId":"G001","payload":"<exact G001 payload>"},
    {"groupId":"G002","payload":"<exact G002 payload>"},
    {"groupId":"G003","payload":"<exact G003 payload>"}
  ]
}
```

Each JSON object deserializes to one Page List element:

- `.Requests(1).GroupId = "G001"`
- `.Requests(1).Payload = <exact G001 ledger>`
- etc.

`groupId` is transport correlation metadata. It does not replace the immutable `SG.groupId`
inside the payload.

Optional defensive validation in WriteMemory:
- if WriteMemory already parses the ScenarioGroup header for validation, require outer
  `groupId == SG.groupId`;
- if WriteMemory deliberately treats Payload as opaque, simply preserve/echo outer groupId;
  the Author has already self-parsed the payload and guaranteed its internal identity.

### Response

Result order is explicitly non-authoritative.

```json
{
  "results": [
    {"groupId":"G003","uuid":"<uuid3>"},
    {"groupId":"G001","uuid":"<uuid1>"},
    {"groupId":"G002","uuid":"<uuid2>"}
  ]
}
```

This response is valid even though rows are reordered.

Author validates:
1. `results` count equals requests count;
2. every requested groupId appears exactly once;
3. no unknown groupId exists;
4. no duplicate groupId exists;
5. every uuid is nonempty;
6. UUIDs are pairwise distinct.

Then build an exact map:

- `G001 -> uuid1`
- `G002 -> uuid2`
- `G003 -> uuid3`

Finally reconstruct `ScenarioGroupUUIDs` in **original groupOrder**, never response order:

`[uuid(G001), uuid(G002), uuid(G003)]`

This ordered array is what UnitTestGenerator receives.

### Why `groupId` instead of `requestId`

- groupId already exists as the physical-group stable identity;
- it has meaning across Author, ScenarioGroup, storage correlation, and Generator input ordering;
- no extra synthetic identifier lifecycle is introduced;
- correlation remains stable even if result rows are reordered;
- duplicate identity can be detected mechanically.

### Current preferred D-004 Page List item

Input item:
- `GroupId` Text
- `Payload` Text

Output item:
- `GroupId` Text
- `UUID` Text

No `order`, `requestId`, `version`, or `atomic` request fields are needed.

Order remains a property of the already-audited ScenarioGroup (`SG.groupOrder`) and is used by Author
when constructing the final UUID array after correlation.


---

## D-004 refinement — use existing Pega properties `pxResults`, `pyGroup`, `pyGUID`

Decision:
replace the generic batch transport field names with existing Pega-style properties.

### Input

Model-facing tool signature remains:

`WriteMemory(CaseID=<string>, Type=<string>, RequestsJSON=<string>)`

Decoded RequestsJSON exact root:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "Payload": "<exact G001 ScenarioGroup payload>"
    },
    {
      "pyGroup": "G002",
      "Payload": "<exact G002 ScenarioGroup payload>"
    },
    {
      "pyGroup": "G003",
      "Payload": "<exact G003 ScenarioGroup payload>"
    }
  ]
}
```

Normative rules:
- root has exactly one field: `pxResults`;
- `pxResults` is a nonempty ordered array/Page List;
- each input item has exactly:
  - `pyGroup`
  - `Payload`
- `pyGroup` is nonempty and unique;
- Scenario Author sets `pyGroup` equal to the physical ScenarioGroup `SG.groupId`;
- `Payload` is the exact already-self-parsed ScenarioGroup ledger string;
- after exactly one JSON decode, Payload content remains byte/character-equivalent to the frozen
  ScenarioGroup payload, including terminal LF;
- WriteMemory may process items in any order;
- input array position is not a correlation mechanism.

Clipboard intent:

`.pxResults(1).pyGroup = "G001"`
`.pxResults(1).Payload = <G001 ledger>`

etc.

### Output

Tool scalar result envelope remains:
- `Success`
- `ResultsJSON`
- `ErrorCode`
- `ErrorMessage`

On success, decoded ResultsJSON exact root:

```json
{
  "pxResults": [
    {
      "pyGroup": "G003",
      "pyGUID": "<opaque GUID for G003>"
    },
    {
      "pyGroup": "G001",
      "pyGUID": "<opaque GUID for G001>"
    },
    {
      "pyGroup": "G002",
      "pyGUID": "<opaque GUID for G002>"
    }
  ]
}
```

Result order is explicitly non-authoritative.

Validation:
1. output `pxResults` count equals input `pxResults` count;
2. every requested `pyGroup` appears exactly once;
3. no unknown/duplicate `pyGroup` exists;
4. every `pyGUID` is a nonempty string;
5. returned `pyGUID` values are pairwise distinct;
6. `pyGUID` is opaque and is never normalized/reconstructed;
7. Author builds map `pyGroup -> pyGUID`;
8. Author reconstructs final `ScenarioGroupUUIDs` in audited `SG.groupOrder`, not response order.

For the current baseline:

`G001 -> pyGUID_A`
`G002 -> pyGUID_B`
`G003 -> pyGUID_C`

and Generator input is:

`[pyGUID_A, pyGUID_B, pyGUID_C]`

regardless of output `pxResults` order.

### Correlation invariant

Outer transport:
`pyGroup`

Inner immutable payload:
`SG.groupId`

Preferred defensive validation when WriteMemory parses the ScenarioGroup header:

`input.pyGroup == parsed SG.groupId`

If WriteMemory stores Payload opaquely and does not parse its grammar, it must still echo the exact
input `pyGroup`; Author already self-parsed and audited the inner SG identity before the call.

### Removed generic transport names

Do not use:
- `requests`
- `results`
- `requestId`
- `groupId`
- `uuid`
- `order`
- `version`
- `atomic`

Use:
- `pxResults`
- `pyGroup`
- `pyGUID`

`Payload` remains unchanged pending any explicit decision to reuse another existing property.

### Current fixture

`REVIEW_WRITEMEMORY_BATCH_D004_v4.json`


---

## D-004 refinement — rename `Payload` to `pyPayload`

Decision:
use the existing Pega-style property name `pyPayload`.

### Input Page List item

Use exactly:
- `pyGroup`
- `pyPayload`

Decoded RequestsJSON:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyPayload": "<exact G001 ScenarioGroup payload>"
    },
    {
      "pyGroup": "G002",
      "pyPayload": "<exact G002 ScenarioGroup payload>"
    },
    {
      "pyGroup": "G003",
      "pyPayload": "<exact G003 ScenarioGroup payload>"
    }
  ]
}
```

Clipboard intent:

`.pxResults(1).pyGroup = "G001"`
`.pxResults(1).pyPayload = <exact G001 ledger>`

etc.

All previous `Payload` references in D-004 are replaced by `pyPayload`.

### Output Page List item remains

- `pyGroup`
- `pyGUID`

Example:

```json
{
  "pxResults": [
    {
      "pyGroup": "G003",
      "pyGUID": "<opaque GUID for G003>"
    },
    {
      "pyGroup": "G001",
      "pyGUID": "<opaque GUID for G001>"
    },
    {
      "pyGroup": "G002",
      "pyGUID": "<opaque GUID for G002>"
    }
  ]
}
```

No other D-004 semantics change.

Current review batch artifact:
`REVIEW_WRITEMEMORY_BATCH_D004_v5.json`


---

## Checkpoint — D-004 synthetic batch write succeeds; UnitTestGenerator source acquisition and first projection

### Synthetic WriteMemory result for ScenarioGroups

To continue the simulation, use this explicitly synthetic response:

```json
{
  "Success": true,
  "ResultsJSON": "{\"pxResults\":[{\"pyGroup\":\"G003\",\"pyGUID\":\"SYNTHETIC-GUID-G003\"},{\"pyGroup\":\"G001\",\"pyGUID\":\"SYNTHETIC-GUID-G001\"},{\"pyGroup\":\"G002\",\"pyGUID\":\"SYNTHETIC-GUID-G002\"}]}",
  "ErrorCode": "",
  "ErrorMessage": ""
}
```

Classification:
`SYNTHETIC_SIMULATION_FIXTURE`

The reordered `pxResults` is intentional.

D-004 validation:
- result count = 3;
- requested pyGroup set = `{G001,G002,G003}`;
- returned pyGroup set = `{G001,G002,G003}`;
- each pyGroup appears exactly once;
- each pyGUID is nonempty;
- pyGUID values are pairwise distinct;
- ErrorCode/ErrorMessage empty.

Correlation map:

- `G001 -> SYNTHETIC-GUID-G001`
- `G002 -> SYNTHETIC-GUID-G002`
- `G003 -> SYNTHETIC-GUID-G003`

Reconstruct in audited SG.groupOrder, not response order:

```text
ScenarioGroupUUIDs=[
  "SYNTHETIC-GUID-G001",
  "SYNTHETIC-GUID-G002",
  "SYNTHETIC-GUID-G003"
]
```

### Exact simulated UnitTestGenerator handoff

```text
UnitTestGenerator(
  CaseID="<SYNTHETIC_pyID>",
  RUTType="Rule-Obj-Model",
  ScenarioGroupUUIDs=[
    "SYNTHETIC-GUID-G001",
    "SYNTHETIC-GUID-G002",
    "SYNTHETIC-GUID-G003"
  ]
)
```

No real Pega call occurred.

### UnitTestGenerator source reads

Synthetic GetMemory mapping:

- `SYNTHETIC-GUID-G001 -> exact review G001 payload`
- `SYNTHETIC-GUID-G002 -> exact review G002 payload`
- `SYNTHETIC-GUID-G003 -> exact review G003 payload`

Each simulated read envelope is treated as:

`Success=true`, exact payload, empty error strings.

G2 source gate:
- CaseID matches input;
- RUTType matches input;
- groupOrder = supplied position 1/2/3;
- groupId unique G001/G002/G003;
- all groups share rutClass/rutName/ruleset/caseKey;
- STANDARD scenarioCount=1;
- D-003 canonical DEP kinds accepted;
- no reserved top-level system root;
- existing Author self-parse/B/A payload remains immutable.

Result:
`GENERATOR_SOURCE_ACQUISITION = PASS_FOR_REVIEW_SIMULATION`

### Structural KnowledgeTool review bridge

The Generator requires one batch:

`Rule-Test-Unit-Case_KnowledgeArea,Rule-Test-Unit-Case_JsonSchema,Rule-Test-Unit-Case_JsonExample`

The KnowledgeArea implementation file is outside the explicit repo whitelist and no actual
KnowledgeTool is available in this external review.

Therefore:
- no KnowledgeArea text is invented;
- a `SYNTHETIC_PRESENCE_ONLY` tool envelope is used solely to exercise the one-call/control-flow gate;
- actual projection facts in this review are derived only from the whitelisted live
  UnitTestGenerator prompt + live JsonSchema + live JsonExample;
- this cannot prove production KnowledgeTool compatibility.

`A-GEN-001 = SYNTHETIC_STRUCTURAL_KT_PRESENCE_BRIDGE`

### Schema/example evidence now legally in stage

Live files read:
- `rule-test-unit-case_JsonSchema.txt`
- `rule-test-unit-case_JsonExample.txt`

Important live schema facts used:
- root = `UnitTestRules`;
- each unit requires Name, Scenarios, RuleCode;
- standard RuleCode supports Property/Page/List/ResultCount assertion blocks;
- Param assertion has dedicated Param.* property form;
- scalar MethodParam omits pyParametersParamType (PAGE only);
- page-shaped Data Page simulation requires pyClassName, Rule-Declare-Pages mocking type,
  rule name, DefineData, and pySetupPages;
- ResultCount uses top-level list context such as `.Addresses`;
- Scenario Testability permits PartiallyTestable;
- EvidenceSummary allows Blocked and BlockingGaps.

### MA-031 — shared WriteMemory interface drift

Status:
`CONFIRMED_DOWNSTREAM_CONTRACT_MISMATCH`

D-004 changes the shared Pega WriteMemory tool to the batch `pxResults/pyPayload` interface.
Current UnitTestGenerator prompt still declares:

`WriteMemory(CaseID, Type, Payload)`

for UnitTestCandidate persistence.

The shared tool cannot have two incompatible signatures.

Recommended generic D-004 extension:
- outer tool signature remains the new batch signature;
- every input record always carries `pyPayload`;
- `pyGroup` is required for multi-record ScenarioGroup writes because correlation is required;
- `Type=UnitTestCandidate` writes exactly one record, so `pyGroup` may be absent;
- successful ScenarioGroup output rows return `pyGroup + pyGUID`;
- successful one-record UnitTestCandidate output returns `pyGUID` (pyGroup absent);
- all writes still use `.pxResults()` internally.

This avoids inventing a fake candidate group identifier.

Do not yet claim this change accepted by user; it is the current simulation bridge required to reach
candidate persistence.

### Review-only candidate projection

A complete candidate was projected from the three immutable ScenarioGroups.

Unit order:
1. G001 / S1
2. G002 / S2
3. G003 / S3

Rule identities:
- `TC_PrepareCustomerCommunication_InvalidCityExit`
- `TC_PrepareCustomerCommunication_NoPostalMatch`
- `TC_PrepareCustomerCommunication_PostalMatchAppend`

No G-order suffix is added because the three semantic purpose labels are already distinct.

Each unit:
- one Scenario;
- exact source ScenarioType / Low confidence / PartiallyTestable;
- RUT class `RuleIQ-Data-TestRefLib`;
- RUT type `Rule-Obj-Model`;
- RUT name `PrepareCustomerCommunication`;
- primary page `RunRecordPrimaryPage`;
- pages/classes include RunRecordPrimaryPage and CustomerCommunication;
- one CustomerID MethodParam;
- one D_CustomerTestRef DefineData simulation;
- assertions project one-to-one from frozen ASSERT;
- omissions exist only in AssertionDecisionTrace/EvidenceSummary, not RuleCode assertions.

Review projection metadata uses the static example target carriers:
- `pyRuleSet="3010067594@"`
- `pyRuleSetVersion="01-01-01"`

Classification:
`SYNTHETIC_TEMPLATE_METADATA`
because the real KnowledgeTool-delivered Pega-selected target is unavailable externally.

Generator literal String serialization is followed in the review candidate:
`pyParametersParamValue="\"CUST-001\""` as the JSON representation of the quoted Pega string literal.

This remains subject to actual KnowledgeArea verification; the static example itself uses an
unquoted-inner scalar value and is illustrative, not authoritative.

### Candidate assertion counts

G001:
- 7 ASSERT projections
- 3 OMIT trace decisions
- 1 SIM

G002:
- 7 ASSERT projections
- 3 OMIT trace decisions
- 1 SIM

G003:
- 8 ASSERT projections
- 2 OMIT trace decisions
- 1 SIM

All RuleCode assertion-block counts match source AssertionCount.

### Local structural projection check

Checked:
- root contains only UnitTestRules;
- Name / RuleCode.pyLabel / RuleCode.pyPurpose equality;
- naming patterns and max lengths;
- Scenario enum/value shapes;
- MethodParam required fields;
- no scalar pyParametersParamType;
- Simulation required fields;
- Param vs regular Property assertion forms;
- ResultCount required fields;
- source assertion/simulation counts.

Result:
`GENERATOR_PROJECTION_LOCAL_STRUCTURE = PASS_FOR_REVIEW_SIMULATION`

This is not a substitute for the real JsonValidationTool/Validator.

Current candidate artifact:
`REVIEW_UNITTESTCANDIDATE_D004_v2.json`

### Current execution position

`D-004 ScenarioGroup batch write synthetic PASS`
-> `UnitTestGenerator handoff`
-> `GetMemory x3 synthetic PASS`
-> `structural KT presence bridge`
-> `candidate projection complete`
-> `local structure PASS`
-> **PAUSED BEFORE UnitTestCandidate WriteMemory**

Next:
1. resolve/apply MA-031 transport shape for the one-record candidate write in simulation;
2. simulate candidate WriteMemory result;
3. enter UnitTestValidator using the whitelisted Validator prompt/schema path.


---

## D-005 — future-proof independently routable work-item exchange

### Architectural direction

Future target:
- multiple UnitTestGenerator agent instances;
- each instance owns exactly one **physical ScenarioGroup** work item;
- each Generator invokes a Validator for exactly its own UnitTestCandidate;
- current implementation may run one Generator instance and one Validator instance over several
  work items, but batching must not change the logical item contract.

Important:
the routable unit is a **physical ScenarioGroup**, not necessarily one semantic Scenario.
For STANDARD it contains one Scenario.
For Rule-Obj-When it may contain multiple Scenario rows that share the exact physical simulation key;
those rows must remain together.

### Core rule

Batching is transport only.

Canonical reference item:

```json
{
  "pyGroup": "G001",
  "pyGUID": "<opaque Memory GUID>"
}
```

Canonical write item:

```json
{
  "pyGroup": "G001",
  "pyPayload": "<opaque payload>"
}
```

Batch wrapper:

```json
{
  "pxResults": [
    { "...one logical item..." },
    { "...one logical item..." }
  ]
}
```

A one-item future invocation uses the exact same wrapper with one pxResults element.
No alternate singleton schema exists.

### Meaning of fields

`pyGroup`
- stable logical physical-group correlation identity;
- assigned by Scenario Author only after final physical grouping/audit;
- copied unchanged through ScenarioGroup storage, Generator processing, UnitTestCandidate storage,
  Validator invocation, and run reporting;
- never inferred from array position or GUID;
- for ScenarioGroup records it equals inner `SG.groupId`.

`pyGUID`
- opaque Memory record address for the current record type;
- at Author -> Generator boundary: ScenarioGroup record GUID;
- at Generator -> Validator boundary: UnitTestCandidate record GUID;
- Type/context determines which record class it addresses;
- never reused as logical group identity.

`pyPayload`
- exact immutable payload for the record being persisted;
- ScenarioGroup write: ScenarioGroup ledger text;
- UnitTestCandidate write: complete candidate JSON for exactly that physical group.

`pxResults`
- transport Page List wrapper only;
- response/input ordering is never semantic or a correlation mechanism.

### Author -> UnitTestGenerator

Replace positional-only:

`ScenarioGroupUUIDs=[...]`

with a JSON Page List parameter, conceptually:

`ScenarioGroupsJSON=<string>`

Decoded:

```json
{
  "pxResults": [
    {"pyGroup":"G001","pyGUID":"<scenario-group-guid-1>"},
    {"pyGroup":"G002","pyGUID":"<scenario-group-guid-2>"},
    {"pyGroup":"G003","pyGUID":"<scenario-group-guid-3>"}
  ]
}
```

Current mode:
one UnitTestGenerator invocation receives all rows.

Future mode:
dispatcher/fan-out sends each Generator the same exact contract with one row:

```json
{
  "pxResults": [
    {"pyGroup":"G002","pyGUID":"<scenario-group-guid-2>"}
  ]
}
```

Generator source validation:
- pyGroup nonempty/unique within invocation;
- pyGUID nonempty/unique within invocation;
- GetMemory by pyGUID;
- parsed source `SG.groupId == input.pyGroup`;
- parsed `SG.groupOrder` remains source ordering metadata, not transport correlation.

### Candidate granularity

To be truly fan-out compatible, UnitTestGenerator SHOULD persist **one UnitTestCandidate record per
physical ScenarioGroup**, even while one Generator instance currently handles multiple groups.

The existing candidate JSON schema already permits `UnitTestRules` with minItems=1, so one candidate
containing exactly one UnitTestRules entry remains schema-compatible.

Current grouped execution therefore becomes:

G001 ScenarioGroup -> Candidate C001
G002 ScenarioGroup -> Candidate C002
G003 ScenarioGroup -> Candidate C003

rather than one persisted candidate containing all three physical groups.

One Generator agent instance may still construct all three sequentially or internally in one run;
logical ownership/persistence remains one candidate per pyGroup.

This is a recommended architecture decision for future-proofing and requires the Generator prompt's
current combined-candidate semantics to change.

### UnitTestCandidate WriteMemory

Use the same D-004 write shape, now with mandatory pyGroup:

```json
{
  "pxResults": [
    {
      "pyGroup":"G001",
      "pyPayload":"<candidate JSON containing exactly G001 unit>"
    },
    {
      "pyGroup":"G002",
      "pyPayload":"<candidate JSON containing exactly G002 unit>"
    },
    {
      "pyGroup":"G003",
      "pyPayload":"<candidate JSON containing exactly G003 unit>"
    }
  ]
}
```

`Type="UnitTestCandidate"`

Successful output may be reordered:

```json
{
  "pxResults": [
    {"pyGroup":"G003","pyGUID":"<candidate-guid-3>"},
    {"pyGroup":"G001","pyGUID":"<candidate-guid-1>"},
    {"pyGroup":"G002","pyGUID":"<candidate-guid-2>"}
  ]
}
```

Generator correlates by pyGroup.

This resolves MA-031 more cleanly than making pyGroup optional:
`MA-031 -> SOLUTION_PROPOSED_BY_D005`

The shared WriteMemory tool has one uniform item contract for both record types.

### UnitTestGenerator -> UnitTestValidator

Replace single-only:
`UnitTestCandidateUUID`

with a future-proof JSON reference batch, conceptually:

`UnitTestCandidatesJSON=<string>`

Decoded:

```json
{
  "pxResults": [
    {"pyGroup":"G001","pyGUID":"<candidate-guid-1>"},
    {"pyGroup":"G002","pyGUID":"<candidate-guid-2>"},
    {"pyGroup":"G003","pyGUID":"<candidate-guid-3>"}
  ]
}
```

Current mode:
one Validator agent invocation receives all rows and validates each independently.

Future mode:
each Generator invokes its own Validator with the exact same one-row envelope.

No inter-group semantic inference is allowed in Validator.
Each row is independently:
- schema validated;
- read by exact pyGUID;
- checked against its own source decisions;
- assigned its own result.

### Validator result correlation

Future-proof Validator response should preserve pyGroup per result.
A generic page-list result carrier can be:

```json
{
  "pxResults": [
    {
      "pyGroup":"G002",
      "pyGUID":"<candidate-guid-2>",
      "pyPayload":"<ValidatorReport JSON for G002>"
    },
    {
      "pyGroup":"G001",
      "pyGUID":"<candidate-guid-1>",
      "pyPayload":"<ValidatorReport JSON for G001>"
    }
  ]
}
```

Result order is non-authoritative.
pyGUID echoes the candidate GUID being validated.
pyPayload carries the exact per-candidate ValidatorReport.
Alternative direct report fields may be used later, but pyGroup must remain the stable correlation key.

### Why this is future-proof

Current:
- one Author
- one Generator invocation with N pxResults rows
- one Validator invocation with N pxResults rows

Future:
- one Author/coordinator
- N Generator invocations, each receiving one unchanged pxResults row
- each Generator invokes one Validator with one unchanged candidate-reference row

The payload/reference schemas do not change.
Only routing/cardinality changes.

### No positional correlation

At every stage:
- pxResults order may change;
- no consumer maps by index;
- pyGroup provides logical identity;
- pyGUID provides record address;
- SG.groupOrder remains ordering metadata for deterministic final presentation only.

### Current simulation consequence

The previous review projection that built one combined three-unit UnitTestCandidate is now retained only
as evidence that all three source groups are individually projectable.

For D-005 simulation, the next step should split that projection into three one-unit candidate payloads,
each keyed by pyGroup, batch-write them through D-004, correlate returned candidate pyGUIDs by pyGroup,
then call the batch-capable Validator contract.

Do not continue with the old one-combined-candidate persistence path if D-005 is accepted.


---

## D-005 correction — `pyGUID` is the canonical E2E Memory address

User correction:
`pyGUID` must be used for end-to-end addressing of any Memory item.

The prior wording that treated pyGUID as merely a stage-local correlation/address is corrected.

### Canonical identity roles

`pyGUID`
- canonical immutable address of one persisted Memory record;
- assigned when that Memory record is created;
- returned by WriteMemory;
- preserved unchanged for the entire lifetime of that record;
- every later GetMemory / Validator / downstream reference to that Memory record uses this exact pyGUID;
- never reconstructed, normalized, inferred from position, or replaced by pyGroup.

`pyGroup`
- logical lineage/group correlation only;
- links related Memory records that belong to the same physical ScenarioGroup workstream;
- is NOT a Memory address;
- may be repeated across different Memory record types/stages for the same logical group.

Example lineage:

```text
pyGroup=G001

ScenarioGroup Memory item
  pyGUID=SG-GUID-001   <- permanent address of this Memory item

UnitTestCandidate Memory item
  pyGUID=UTC-GUID-001  <- permanent address of this different Memory item

Validator/report Memory item (if persisted later)
  pyGUID=VAL-GUID-001  <- permanent address of that item
```

All three may share `pyGroup=G001`, but each Memory item has its own immutable pyGUID.

### WriteMemory request/response

Write request:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyPayload": "<payload>"
    }
  ]
}
```

WriteMemory creates the Memory item and assigns its canonical pyGUID.

Success response:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyGUID": "<canonical persistent Memory address>"
    }
  ]
}
```

The returned pyGUID is not merely a correlation token; it becomes the authoritative E2E address for
that persisted item.

### Read/reference contract

References to existing Memory items use:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyGUID": "<exact canonical Memory address>"
    }
  ]
}
```

`pyGroup` may be used to correlate/reconcile batches, but storage lookup is by pyGUID.

If response order changes, pyGroup helps the caller associate returned pyGUIDs with the logical
workstream at creation time. After creation, pyGUID is the authoritative address.

### Consequence for future fan-out

Author -> Generator:
- each ScenarioGroup Memory record is referenced by its exact ScenarioGroup pyGUID;
- pyGroup is accompanying lineage metadata.

Generator -> Validator:
- each UnitTestCandidate Memory record is referenced by its exact Candidate pyGUID;
- pyGroup again provides lineage metadata.

No stage should attempt to address a Memory item using pyGroup alone.

### D-005 corrected invariant

`pyGUID = persistent identity/address of a Memory record`

`pyGroup = logical lineage/correlation across related Memory records`

`pxResults = batch transport only`

`pyPayload = content written into a new Memory record`

This correction supersedes any D-005 wording implying that pyGUID is only a temporary/stage-local
identifier.


---

## D-006 — `pxCaseID` is a first-class Memory query dimension

### Decision

Every persisted Memory item carries:

- `pyGUID` — canonical immutable E2E address of that Memory item;
- `pxCaseID` — exact RuleIQ case `pyID` that owns/created the item;
- `Type` — Memory item type;
- `pyGroup` — logical workstream/group correlation;
- `pyPayload` — immutable payload content.

`pxCaseID` value is copied exactly from `GetCaseData.pyID`.

It is not inferred from:
- pzInsKey;
- application context;
- pyGroup;
- pyGUID;
- pyPayload content.

### WriteMemory API shape

Because all rows in one batch belong to the same RuleIQ case and Memory type, `pxCaseID` and `Type`
remain outer scalar parameters rather than being repeated inside every `pxResults` row.

Preferred signature:

`WriteMemory(pxCaseID=<string>, Type=<string>, RequestsJSON=<string>)`

Decoded RequestsJSON:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyPayload": "<payload 1>"
    },
    {
      "pyGroup": "G002",
      "pyPayload": "<payload 2>"
    }
  ]
}
```

For every created Memory record, WriteMemory persists the outer scalar values together with the item:

```text
.pyGUID   = newly assigned immutable Memory address
.pxCaseID = exact outer pxCaseID
.Type     = exact outer Type
.pyGroup  = row.pyGroup
.pyPayload= row.pyPayload
```

### Query/read separation

Direct addressing:
- lookup one exact Memory item by `pyGUID`;
- pyGUID remains authoritative E2E address.

Set/query addressing:
- query collections by indexed/filterable fields such as `pxCaseID` and `Type`;
- example intended query:
  `QueryMemory(pxCaseID=<exact case pyID>, Type="ScenarioGroup")`

These should be separate scalar parameters, not encoded in a free-form JSON filter, for the common
case/type query path.

Expected result can use `pxResults`:

```json
{
  "pxResults": [
    {
      "pyGUID": "<guid-1>",
      "pxCaseID": "RQ-123",
      "pyGroup": "G001"
    },
    {
      "pyGUID": "<guid-2>",
      "pxCaseID": "RQ-123",
      "pyGroup": "G002"
    }
  ]
}
```

Whether `pyPayload` is returned by the query should be a separate contract choice:
- metadata/list query should preferably return addresses/metadata only;
- exact payload retrieval remains by pyGUID through GetMemory.

### Why outer scalar parameters are preferred

`pxCaseID` and `Type` describe the whole batch and are intended database/query dimensions.
Keeping them outside `pxResults`:
- avoids duplicate values in every row;
- prevents row-level disagreement inside one atomic batch;
- gives the Pega implementation explicit parameters for indexed/report-definition queries;
- keeps `pyPayload` opaque;
- makes future `QueryMemory(pxCaseID, Type)` natural.

### Identity hierarchy

`pyGUID`
= exact persistent address of one Memory record.

`pxCaseID`
= owning RuleIQ case / query partition.

`Type`
= Memory record type / query partition.

`pyGroup`
= logical lineage/correlation within a case.

`pyPayload`
= stored immutable content.

Example:

```text
pxCaseID = RQ-123
pyGroup  = G001

ScenarioGroup item:
  Type   = ScenarioGroup
  pyGUID = SG-111

UnitTestCandidate item:
  Type   = UnitTestCandidate
  pyGUID = UTC-777
```

Both can be queried by the same pxCaseID, while Type distinguishes the collection.
pyGUID remains the only exact E2E address for either record.

### Implementation note

For efficient querying, `pxCaseID` and `Type` should be persisted as normal queryable/exposed fields
of the Memory data model, not only embedded inside serialized `pyPayload`.


---

## User decisions accepted before continuing simulation

Date/context: accepted after D-006.

### D-007 — final Memory/exchange decisions

1. **One UnitTestCandidate per physical `pyGroup`**
   - ACCEPTED.
   - Current single UnitTestGenerator instance may process multiple groups, but it creates one
     independently persisted UnitTestCandidate Memory item per group.
   - Future fan-out can route one group to one Generator without changing the data contract.

2. **Every Memory item has `pyGroup`**
   - ACCEPTED.
   - `pyGroup` is logical lineage/correlation only, never the Memory address.

3. **Exact GetMemory signature**
   - ACCEPTED:
     `GetMemory(pxCaseID, Type, pyGUID)`
   - `pyGUID` is the canonical E2E address.
   - `pxCaseID` and `Type` are consistency/query dimensions and must match the addressed record.

4. **QueryMemory**
   - ACCEPTED as future data-model/API capability:
     `QueryMemory(pxCaseID, Type)`
   - Do not add it to current Author/Generator/Validator allowlists unless the current flow needs
     discovery. Current exact handoffs use pyGUID.

5. **WriteMemory always uses the batch-shaped contract**
   - ACCEPTED.
   - No alternate singleton `Payload` form.
   - Even one item is represented under `pxResults`.

6. **WriteMemory is NOT atomic across pxResults rows**
   - ACCEPTED and supersedes prior D-004 atomicity wording.
   - Every input row is an independent Memory write.
   - Different rows may succeed or fail independently.
   - A successful row remains committed even when another row fails.
   - Caller handles each row independently.
   - This is required for future independently running Generator/Validator work items.

7. **Author -> Generator input**
   - ACCEPTED:
     use a Page-List-compatible JSON reference batch rather than positional ScenarioGroupUUIDs.

   Conceptual input:

   ```json
   {
     "pxResults": [
       {"pyGroup":"G001","pyGUID":"<scenario-group-guid-1>"},
       {"pyGroup":"G002","pyGUID":"<scenario-group-guid-2>"},
       {"pyGroup":"G003","pyGUID":"<scenario-group-guid-3>"}
     ]
   }
   ```

8. **Generator -> Validator input**
   - ACCEPTED:
     same batch/singleton reference pattern using candidate pyGUIDs.

9. **Validator result persistence**
   - ACCEPTED option A:
     Validator returns its report directly.
   - No ValidatorResult Memory item is created in the current design.

10. **Nested assertion page-context semantics**
    - ACCEPTED recommended approach.
    - Semantic `ASSERT.page` remains the frozen step/root context.
    - Generator mechanically derives the immediate physical containing page from
      `ASSERT.page + ASSERT.target`.
    - Validator performs the same deterministic derivation when comparing the trace to RuleCode.
    - Do not mutate Author semantic ASSERT merely to fit physical UTC projection.

### Corrected WriteMemory contract — independent row outcomes

Preferred signature:

`WriteMemory(pxCaseID=<string>, Type=<string>, RequestsJSON=<string>)`

Decoded input:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyPayload": "<payload-1>"
    },
    {
      "pyGroup": "G002",
      "pyPayload": "<payload-2>"
    }
  ]
}
```

Each row is processed independently.

Preferred decoded result:

```json
{
  "pxResults": [
    {
      "pyGroup": "G002",
      "Success": false,
      "pyGUID": "",
      "ErrorCode": "WRITE_FAILED",
      "ErrorMessage": "<bounded diagnostic>"
    },
    {
      "pyGroup": "G001",
      "Success": true,
      "pyGUID": "<canonical-guid-1>",
      "ErrorCode": "",
      "ErrorMessage": ""
    }
  ]
}
```

Result order is non-authoritative.

Per-row success invariant:
- exact requested `pyGroup`;
- `Success=true`;
- nonempty `pyGUID`;
- empty `ErrorCode`;
- empty `ErrorMessage`.

Per-row failure invariant:
- exact requested `pyGroup`;
- `Success=false`;
- empty `pyGUID`;
- nonempty bounded `ErrorMessage`;
- allowed `ErrorCode` according to operation contract.

Batch-level validation:
- every requested pyGroup has exactly one returned row;
- no unknown or duplicate pyGroup;
- each row envelope is internally valid;
- tool-level malformed/invocation failure is distinct from an individual row failure.

No global atomic success invariant remains.

### Partial progress rule

Because rows are independent:
- successful ScenarioGroup writes may proceed to Generator even when another group write fails;
- failed groups do not proceed;
- successful UnitTestCandidate writes may proceed to Validator even when another candidate write fails;
- failed candidate rows do not proceed to Validator;
- final run report must preserve per-pyGroup outcomes.

This supersedes prior Author wording that any write failure terminates the whole run and forbids
partial handoff. The prompt must be corrected accordingly.

### MA-032 — prior no-partial-handoff semantics conflict with independent Memory writes

Status:
`CONFIRMED_ARCHITECTURAL_CONTRACT_CHANGE`

Affected existing wording:
- Author: any failed/malformed ScenarioGroup write stops all writes/handoff.
- Generator: candidate persistence/validation is combined-run oriented.
- Future-proof contract requires item-level continuation.

Required correction:
- fail/stop only the affected pyGroup work item;
- continue unrelated successful pyGroups;
- aggregate final run status/report across item outcomes;
- never silently retry a failed item unless a future retry policy is explicitly introduced.

### MA-033 — positional ScenarioGroupUUIDs input is obsolete

Status:
`CONFIRMED_CONTRACT_CHANGE`

Replace ordered opaque UUID array with `ScenarioGroupsJSON`/equivalent scalar JSON parameter whose
decoded root is `pxResults` and whose rows contain `pyGroup + pyGUID`.

Ordering for deterministic presentation may still use immutable SG.groupOrder after GetMemory, but
address/correlation never depends on input array position.

### MA-034 — single UnitTestCandidateUUID Validator input is obsolete

Status:
`CONFIRMED_CONTRACT_CHANGE`

Replace with batch/singleton Page-List-compatible candidate references:
`pxResults[].pyGroup + pxResults[].pyGUID`.

Current one Validator instance may receive multiple rows; future one Validator per Generator receives
one row with the same schema.

### MA-035 — nested ASSERT.page physical projection mismatch

Status:
`PROPOSED_FIX_ACCEPTED`

Semantic:
`ASSERT.page` = frozen step/root assertion context.

Projection:
derive immediate containing page and leaf path mechanically from semantic full path.

Validator:
perform identical derivation before comparing physical UTC assertion context.

No Author semantic rewrite is permitted solely for physical schema convenience.


---

## Validator response contract accepted

User accepted the future-proof Validator response carrier:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyGUID": "<exact UnitTestCandidate Memory GUID being validated>",
      "pyPayload": "<exact ValidatorReport JSON>"
    }
  ]
}
```

Rules:
- pyGroup = logical lineage/correlation;
- pyGUID = exact canonical E2E address of the UnitTestCandidate being validated, echoed unchanged;
- pyPayload = ValidatorReport JSON returned directly by Validator;
- Validator creates no new Memory item;
- result order is non-authoritative;
- current one Validator invocation may return N rows;
- future one-validator-per-generator uses the exact same shape with one row.

Status:
`D-007_VALIDATOR_RESPONSE = ACCEPTED`

---

## MA-036 — Generator trace escaping destroys Validator delimiters

Status:
`CONFIRMED_CROSS_AGENT_CONTRACT_DEFECT`
`PAUSED_BEFORE_UNITTESTCANDIDATE_WRITE`

Live Generator G7 states, in substance:
- build AssertionDecisionTrace from canonical ASSERT/SIM/OMIT grammar;
- then apply trace encoding to the complete trace, including `pipe -> &#124;`.

Live Validator V5 states:
- parse physical trace lines;
- split each line on pipe-delimited fields **before** decoding entities;
- only after splitting decode `&amp;`, `&quot;`, `&#124;`, `&#13;`, `&#10;`.

The live JsonExample also uses literal `|` as structural record/field separators in
AssertionDecisionTrace.

Therefore literal Generator wording can transform:

`ASSERT|id=A001|kind=Property|...`

into:

`ASSERT&#124;id=A001&#124;kind=Property&#124;...`

which Validator cannot split into fields.

### Recommended correction

Encoding applies **only to field values**, never to structural trace delimiters.

Canonical construction:
1. construct each field as `key=<encodedValue>`;
2. encode content inside `<encodedValue>`:
   - `& -> &amp;`
   - `| -> &#124;`
   - CR -> `&#13;`
   - LF -> `&#10;`
   - `"` -> `&quot;`
3. join fields using literal `|`;
4. join records using actual LF characters in the in-memory trace string;
5. JSON serialization then represents those LF characters as JSON `\n` escaping on the wire;
6. Validator parses physical lines, splits literal `|`, then decodes field-value entities once.

Example:

`ASSERT|id=A001|kind=Property|target=.Message|...|value=A&#124;B|support=Verified`

Here only the literal pipe inside value `A|B` is encoded; structural pipes remain literal.

Validator algorithm remains:
- split records on physical LF after JSON parse;
- split fields on literal `|`;
- split field on first `=`;
- decode allowed entities in values exactly once.

### Why this is the preferred fix

- matches Validator's existing parser order;
- matches the live JsonExample representation;
- preserves literal delimiter characters inside values without ambiguity;
- does not require changing the trace grammar;
- avoids a second parser/version.

No continuation bridge is silently applied until user accepts/rejects this fix.


---

## MA-036 accepted and applied

User approved the MA-036 correction.

Final trace rule:
- literal `|` separates trace fields;
- actual LF separates trace records after JSON parse;
- reserved characters are encoded only inside field values;
- field-value pipe becomes `&#124;`;
- Validator splits structure first and decodes field values once.

Status:
`MA-036 = PROPOSED_FIX_ACCEPTED`

The current projected candidates already conform to this corrected representation.

---

## D-007 continuation — one UnitTestCandidate per pyGroup

The previous three-unit review candidate was split without semantic changes into:

- `REVIEW_UNITTESTCANDIDATE_G001_D007.json`
- `REVIEW_UNITTESTCANDIDATE_G002_D007.json`
- `REVIEW_UNITTESTCANDIDATE_G003_D007.json`

Each file has exactly one `UnitTestRules` entry and represents exactly one physical ScenarioGroup.

Candidate sizes:
- G001: 10,493 bytes
- G002: 10,755 bytes
- G003: 11,342 bytes

Batch candidate WriteMemory request:
`REVIEW_CANDIDATE_WRITEMEMORY_BATCH_D007.json`

Decoded root:
`pxResults[]`

Each row:
- `pyGroup`
- `pyPayload`

### Local pre-write audit

For every candidate:
- Name == RuleCode.pyPurpose == RuleCode.pyLabel;
- trace grammar parses with literal structural pipes;
- ASSERT count equals physical assertion count;
- SIM count matches;
- OMIT count matches;
- scalar MethodParam shape remains valid;
- MA-035 nested ordinary Property projection derives the immediate physical containing page;
- Param assertions retain dedicated Param shape;
- ResultCount remains block-level;
- simulation rule/method/class align with trace.

Results:
- `G001 LOCAL_VALIDATOR_VISIBLE_AUDIT = PASS_FOR_REVIEW_SIMULATION`
- `G002 LOCAL_VALIDATOR_VISIBLE_AUDIT = PASS_FOR_REVIEW_SIMULATION`
- `G003 LOCAL_VALIDATOR_VISIBLE_AUDIT = PASS_FOR_REVIEW_SIMULATION`

---

## Synthetic UnitTestCandidate WriteMemory result

To continue the control-flow simulation, all three independent writes are synthetic successes.
Response order is deliberately shuffled:

```json
{
  "Success": true,
  "ResultsJSON": "{\"pxResults\":[{\"pyGroup\":\"G003\",\"Success\":true,\"pyGUID\":\"SYNTHETIC-CANDIDATE-GUID-G003\",\"ErrorCode\":\"\",\"ErrorMessage\":\"\"},{\"pyGroup\":\"G001\",\"Success\":true,\"pyGUID\":\"SYNTHETIC-CANDIDATE-GUID-G001\",\"ErrorCode\":\"\",\"ErrorMessage\":\"\"},{\"pyGroup\":\"G002\",\"Success\":true,\"pyGUID\":\"SYNTHETIC-CANDIDATE-GUID-G002\",\"ErrorCode\":\"\",\"ErrorMessage\":\"\"}]}",
  "ErrorCode": "",
  "ErrorMessage": ""
}
```

Classification:
`SYNTHETIC_SIMULATION_FIXTURE`

Correlation:
- G001 -> `SYNTHETIC-CANDIDATE-GUID-G001`
- G002 -> `SYNTHETIC-CANDIDATE-GUID-G002`
- G003 -> `SYNTHETIC-CANDIDATE-GUID-G003`

Each pyGUID is now treated as the canonical immutable E2E Memory address of that candidate item.

Fixture:
`REVIEW_CANDIDATE_WRITEMEMORY_RESULT_D007.json`

---

## Validator invocation under accepted batch/singleton contract

Current one-instance call conceptually:

```text
UnitTestValidator(
  pxCaseID="<SYNTHETIC_pyID>",
  RUTType="Rule-Obj-Model",
  UnitTestCandidatesJSON={
    "pxResults":[
      {"pyGroup":"G001","pyGUID":"SYNTHETIC-CANDIDATE-GUID-G001"},
      {"pyGroup":"G002","pyGUID":"SYNTHETIC-CANDIDATE-GUID-G002"},
      {"pyGroup":"G003","pyGUID":"SYNTHETIC-CANDIDATE-GUID-G003"}
    ]
  }
)
```

Fixture:
`REVIEW_VALIDATOR_INPUT_D007.json`

### Current-batch Validator execution semantics

Because the future architecture executes one Validator per item, the current batch is defined as
N independent item pipelines inside one invocation.

For each item independently:
1. validate invocation row;
2. call JsonValidationTool for exact candidate pyGUID;
3. only if schema-valid, GetMemory using exact `pxCaseID`, `Type=UnitTestCandidate`, `pyGUID`;
4. validate RUTType and candidate traversability;
5. run trace/RuleCode/doc alignment;
6. produce one ValidatorReport for that pyGroup.

A failure of one item does not short-circuit another item.

Structural UTC Knowledge:
- all current rows share the same immutable RUTType;
- current one-instance implementation may call the same three UTC KnowledgeAreas once and cache
  them for all surviving rows;
- future one-validator-per-item calls the same lookup independently;
- a shared KT failure affects only items that reached the KT-dependent phase, not rows already
  terminated by their own schema/read failure.

This is a batching optimization, not shared semantic state.

### Synthetic Validator tool evidence

External Pega JsonValidationTool/GetMemory/KnowledgeTool are unavailable in this review.

For each G001/G002/G003:
- JsonValidationTool result is simulated `Success=true, IsValid=true`;
- GetMemory returns the exact corresponding one-unit review candidate;
- structural KT uses the previously declared presence-only synthetic bridge;
- no runtime/case-specific semantic facts are invented by Validator.

Classification:
`SYNTHETIC_VALIDATOR_TOOL_FIXTURES`

### Validator alignment result

Under accepted MA-035 and MA-036:
- trace grammar valid;
- no missing/extra ASSERT;
- no asserted OMIT target;
- SIM projection present and aligned;
- EvidenceSummary visible counts reconcile;
- Param assertion shape valid;
- nested Property physical page is derived rather than compared literally to semantic ASSERT.page;
- no candidate-visible RUTType conflict;
- no visible reasoning contradiction.

Synthetic per-item ValidatorReport:

```json
{
  "valid": true,
  "route": "OK",
  "blocking": 0,
  "warnings": 0,
  "jsonSchemaValidation": {
    "isValid": true,
    "message": ""
  },
  "issues": []
}
```

for each of G001, G002, G003.

Batch response uses accepted direct-return shape and is deliberately reordered:

```json
{
  "pxResults": [
    {
      "pyGroup":"G002",
      "pyGUID":"SYNTHETIC-CANDIDATE-GUID-G002",
      "pyPayload":"<ValidatorReport OK JSON>"
    },
    {
      "pyGroup":"G003",
      "pyGUID":"SYNTHETIC-CANDIDATE-GUID-G003",
      "pyPayload":"<ValidatorReport OK JSON>"
    },
    {
      "pyGroup":"G001",
      "pyGUID":"SYNTHETIC-CANDIDATE-GUID-G001",
      "pyPayload":"<ValidatorReport OK JSON>"
    }
  ]
}
```

Fixture:
`REVIEW_VALIDATOR_OUTPUT_D007.json`

Validation:
- every requested pyGroup appears exactly once;
- echoed candidate pyGUID matches the exact address supplied for that pyGroup;
- each pyPayload parses as an exact ValidatorReport;
- all three route=OK;
- output order ignored.

Result:
`VALIDATOR_BATCH = PASS_FOR_REVIEW_SIMULATION`

---

## MA-037 — GeneratorRunReport cannot represent multiple independently persisted candidates

Status:
`CONFIRMED_FUTURE_PROOFING_CONTRACT_DEFECT`
`PAUSED_AFTER_VALIDATOR_BEFORE_FINAL_GENERATOR_REPORT`

Current UnitTestGenerator G9 has a singular:

`candidate={CaseID,Type:"UnitTestCandidate",UUID:<current validated UUID>}`

and its success semantics assume one current candidate UUID.

Accepted architecture now has:

- G001 -> candidate pyGUID 1 -> Validator OK
- G002 -> candidate pyGUID 2 -> Validator OK
- G003 -> candidate pyGUID 3 -> Validator OK

There is no single truthful candidate UUID.

The final GeneratorRunReport therefore needs a per-group candidate/result carrier rather than one
candidate object.

The existing `groups[]` structure is a likely natural home because it already represents each source
group, but its current fields do not carry the candidate Memory address or Validator outcome.

### Recommended direction

Evolve each Generator report group to carry:
- source ScenarioGroup `pyGUID`;
- `pyGroup`;
- source/read state;
- UnitTestCandidate `pyGUID` when successfully written;
- validation outcome/route;
- Scenario outcomes.

Then top-level status is only an aggregate:
- Completed: every eligible group succeeded/validated;
- PartiallyCompleted: at least one group succeeded and at least one group failed/rejected/unvalidated;
- Failed: no group produced a validated successful candidate.

No top-level singular candidate address should remain.

This needs user confirmation before final Generator report simulation.


---

## D-008 — single-`question` Agent-to-Agent wire protocol

### Correction

Scenario Author also persists ScenarioGroup Memory items before invoking UnitTestGenerator.

End-to-end:

```text
Scenario Author
  -> WriteMemory(pxCaseID, Type=ScenarioGroup, RequestsJSON)
  <- per-row pyGroup + status + pyGUID
  -> UnitTestGenerator(question=<A2A text>)

UnitTestGenerator
  -> GetMemory(pxCaseID, ScenarioGroup, pyGUID)
  -> WriteMemory(pxCaseID, Type=UnitTestCandidate, RequestsJSON)
  <- per-row pyGroup + status + pyGUID
  -> UnitTestValidator(question=<A2A text>)
  <- direct A2A text report
  -> direct A2A text report to Scenario Author
```

Only persisted Memory payloads use `pyPayload`.
Agent reports are not Memory items and are not wrapped in pyPayload.

### Constraint

An invoked agent accepts exactly one input parameter:

`question`

Therefore all Agent-to-Agent requests use one compact deterministic text grammar inside that scalar.

Do not use prose instructions plus embedded JSON.
The receiving agent's system prompt already defines behavior; `question` carries only operation context and
references.

### Reuse existing escaping

Reuse the ScenarioGroup ledger field-value escaping:
- `\` -> `\\`
- `|` -> `\|`
- CR -> `\r`
- LF -> `\n`
- TAB -> `\t`
- exact literal `-` -> `\-`
- empty -> `\0`
- unescaped `-` means absent where allowed

Structural record fields remain separated by literal `|`.
Records are separated by LF.

### Scenario Author -> UnitTestGenerator question

Exact grammar:

`GEN|pxCaseID=<exactCasePyID>|RUTType=<exactOriginalRUTType>`
`SG|pyGroup=<group>|pyGUID=<ScenarioGroupMemoryGUID>`

One SG line per work item.

Current grouped invocation:

```text
GEN|pxCaseID=<SYNTHETIC_pyID>|RUTType=Rule-Obj-Model
SG|pyGroup=G001|pyGUID=SYNTHETIC-SG-GUID-G001
SG|pyGroup=G002|pyGUID=SYNTHETIC-SG-GUID-G002
SG|pyGroup=G003|pyGUID=SYNTHETIC-SG-GUID-G003
```

Future fan-out invocation uses the same grammar with one SG line.

Do not send Type:
Generator already knows source Memory Type is exactly `ScenarioGroup`.

Do not send groupOrder:
Generator reads authoritative SG.groupOrder from the addressed ScenarioGroup payload.

### UnitTestGenerator -> UnitTestValidator question

Exact grammar:

`VAL|pxCaseID=<exactCasePyID>|RUTType=<exactOriginalRUTType>`
`UT|pyGroup=<group>|pyGUID=<UnitTestCandidateMemoryGUID>`

One UT line per candidate.

Current grouped invocation may have N UT rows.
Future per-generator Validator invocation has one UT row.

Do not send Type:
Validator knows addressed Memory Type is exactly `UnitTestCandidate`.

### UnitTestValidator -> UnitTestGenerator direct report

Summary record per candidate:

`VR|pyGroup=<group>|pyGUID=<echoCandidateGUID>|route=<OK|GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>|blocking=<N>|warnings=<N>`

Zero or more issue records immediately after that VR:

`VI|severity=<B|W>|code=<code>|action=<action>|scenario=<zeroBasedIndexOrAbsent>|decision=<decisionIDOrAbsent>|path=<jsonPointer>|message=<escapedBoundedMessage>`

Rules:
- VI rows belong to the immediately preceding VR;
- no VI before VR;
- exactly `blocking + warnings` VI rows;
- B/W counts must match;
- scenario is `-` for candidate/group scope;
- unit index removed because one UnitTestCandidate now contains exactly one physical group /
  one UnitTestRules entry, so its unit index is invariant 0 and provides no information;
- pyGUID is echoed unchanged; Validator creates no Memory item;
- OK requires blocking=0;
- issue order is deterministic by severity B before W, then scenario/path/code/decision.

Example success:

```text
VR|pyGroup=G001|pyGUID=UTC-GUID-001|route=OK|blocking=0|warnings=0
```

Example repair:

```text
VR|pyGroup=G002|pyGUID=UTC-GUID-002|route=GENERATOR_REPAIR|blocking=1|warnings=0
VI|severity=B|code=ASSERT_MISSING|action=ADD_ASSERTION|scenario=0|decision=A003|path=/UnitTestRules/0/RuleCode/pyExpectedResults|message=Frozen assertion missing
```

### UnitTestGenerator -> Scenario Author direct report

One record per input physical group:

`GR|pyGroup=<group>|pyGUID=<validatedCandidateGUIDOrAbsent>|status=<OK|PARTIAL|FAILED>|successful=<N>|untestable=<N>|reason=<codeOrAbsent>`

Semantics:
- `OK`: final candidate validated OK and every source Scenario in the group is successful;
- `PARTIAL`: final candidate validated OK but one or more source Scenarios in the physical group became Untestable;
- `FAILED`: no validated successful UnitTestCandidate exists for this group;
- pyGUID is the canonical address of the final validated UnitTestCandidate for OK/PARTIAL;
- pyGUID is absent (`-`) for FAILED;
- successful + untestable equals known source Scenario count after source acquisition;
- reason is absent for OK;
- PARTIAL/FAILED use a stable bounded reason code, not arbitrary prose.

Current STANDARD example after three OK validations:

```text
GR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001|status=OK|successful=1|untestable=0|reason=-
GR|pyGroup=G002|pyGUID=SYNTHETIC-CANDIDATE-GUID-G002|status=OK|successful=1|untestable=0|reason=-
GR|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003|status=OK|successful=1|untestable=0|reason=-
```

No aggregate END record is required.
Scenario Author computes aggregate completion from all expected pyGroup rows.

### Why no JSON

A2A requests/reports are ephemeral control-plane messages, not persisted domain artifacts.
A small line grammar:
- avoids JSON escaping/token overhead;
- is easy for an LLM to emit and self-parse;
- is cardinality-independent;
- preserves pyGUID as the E2E Memory address;
- preserves pyGroup as correlation only;
- lets current N-item and future one-item agent invocations use the same contract.

### Strictness

For all A2A messages:
- exact tag/field order;
- unknown/missing/duplicate fields invalid;
- duplicate pyGroup invalid;
- duplicate pyGUID invalid within one request;
- response pyGroup set must equal the subset the invoked agent can truthfully report;
- no correlation by line order;
- no free-form prose outside protocol records.


---

## D-009 — Validator must retrieve UnitTestCandidate via GetMemory

### Decision

UnitTestGenerator never sends UnitTestCandidate payload/content to UnitTestValidator through
agent-to-agent communication.

Generator passes only:
- `pxCaseID` — exact RuleIQ case pyID;
- `RUTType` — immutable original RUT type;
- one or more candidate references:
  - `pyGroup` — logical lineage/correlation;
  - `pyGUID` — canonical E2E Memory address of the UnitTestCandidate item.

Validator independently retrieves each UnitTestCandidate by invoking GetMemory.

### Generator -> Validator `question`

Exact compact request grammar remains:

```text
VAL|pxCaseID=<exactCasePyID>|RUTType=<exactOriginalRUTType>
UT|pyGroup=<group>|pyGUID=<UnitTestCandidateMemoryGUID>
UT|pyGroup=<group>|pyGUID=<UnitTestCandidateMemoryGUID>
...
```

No candidate `pyPayload` is included.

Example:

```text
VAL|pxCaseID=<SYNTHETIC_pyID>|RUTType=Rule-Obj-Model
UT|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001
UT|pyGroup=G002|pyGUID=SYNTHETIC-CANDIDATE-GUID-G002
UT|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003
```

### Validator per-item retrieval

For each UT row independently, Validator invokes exactly:

```text
GetMemory(
  pxCaseID=<exact VAL.pxCaseID>,
  Type="UnitTestCandidate",
  pyGUID=<exact UT.pyGUID>
)
```

`pyGUID` is the actual Memory address.

`pxCaseID` and `Type` are query/consistency constraints and must match the addressed record.

Validator must not:
- query by pyGroup;
- infer a candidate address from pyGroup;
- use row order as an address;
- accept candidate JSON embedded in `question`;
- switch to another GUID after a failed read;
- fetch "latest" candidate.

### Correlation check after read

The retrieved Memory record should expose its persisted metadata:
- `pyGUID`
- `pxCaseID`
- `Type`
- `pyGroup`
- `pyPayload`

Validator verifies:

```text
returned.pyGUID   == requested UT.pyGUID
returned.pxCaseID == VAL.pxCaseID
returned.Type     == "UnitTestCandidate"
returned.pyGroup  == UT.pyGroup
```

Only then may Validator parse/use returned `pyPayload` as the candidate JSON.

A mismatch is a Memory-address/ownership failure, not a semantic candidate defect.

### JsonValidationTool order

The existing Validator architecture performs strict schema validation before candidate inspection.

For each candidate row, preserve the intended order:

1. `JsonValidationTool`
   - `pxCaseID = VAL.pxCaseID`
   - `pyGUID = UT.pyGUID`
   - schema selected solely from immutable `RUTType`

2. only when schema validation succeeds:
   `GetMemory(pxCaseID, Type="UnitTestCandidate", pyGUID)`

3. verify Memory metadata including pyGroup correlation

4. parse candidate `pyPayload`

5. perform RUT metadata / UTC / trace / RuleCode alignment checks

Thus both JsonValidationTool and GetMemory operate on the exact same canonical candidate pyGUID.

### Future fan-out

Current:

```text
one Validator invocation
  UT G001 -> GetMemory(candidate-guid-1)
  UT G002 -> GetMemory(candidate-guid-2)
  UT G003 -> GetMemory(candidate-guid-3)
```

Future:

```text
Validator #1 question contains UT G001 only
  -> GetMemory(candidate-guid-1)

Validator #2 question contains UT G002 only
  -> GetMemory(candidate-guid-2)
```

No protocol change is required.

### Validator response

Validator still returns no candidate payload and creates no new Memory item.

Direct report:

```text
VR|pyGroup=<group>|pyGUID=<echo exact candidate GUID>|route=<...>|blocking=<N>|warnings=<N>
VI|...
```

The echoed `pyGUID` proves which exact UnitTestCandidate Memory item the report applies to.

### Revised boundary invariant

Agent-to-agent request carries **addresses, not artifacts**.

Memory is the source of truth for persisted ScenarioGroups and UnitTestCandidates.

- Author -> Generator: pass ScenarioGroup pyGUIDs; Generator GetMemory retrieves ScenarioGroups.
- Generator -> Validator: pass UnitTestCandidate pyGUIDs; Validator GetMemory retrieves candidates.
- pyPayload travels only through WriteMemory/GetMemory, never through agent invocation `question`.


---

## D-010 — UnitTestCandidate validation metadata field names

User selected Pega-native field names:

- replace `pyValidationStatus` with `pyStatusValue`
- replace `pyValidationRoute` with `pyRouterKey`

Recommended lifecycle values:

`pyStatusValue`
- `Pending`
- `Passed`
- `Failed`

`pyRouterKey`
- `-` while Pending
- `OK`
- `GENERATOR_REPAIR`
- `SEMANTIC_REJECT`
- `HUMAN`

Example initial candidate metadata:

```text
pyGUID       = UTC-123
pxCaseID     = CASE-1
Type         = UnitTestCandidate
pyGroup      = G001
pyStatusValue= Pending
pyRouterKey  = -
pyPayload    = <immutable candidate JSON>
```

After successful Validator result:

```text
pyStatusValue = Passed
pyRouterKey   = OK
```

After unsuccessful Validator result:

```text
pyStatusValue = Failed
pyRouterKey   = <GENERATOR_REPAIR|SEMANTIC_REJECT|HUMAN>
```

The lifecycle update must never mutate:
- pyGUID
- pxCaseID
- Type
- pyGroup
- pyPayload

Only lifecycle metadata is mutable.

This supersedes any earlier references to `pyValidationStatus` and `pyValidationRoute`.


---

## D-010 continuation — lifecycle update on the same UnitTestCandidate Memory item

### Creation defaults

For `WriteMemory(..., Type="UnitTestCandidate", ...)`, the Memory service initializes metadata:

```text
pyStatusValue = Pending
pyRouterKey   = <empty string>
```

The A2A `-` token means "absent" only in the compact line protocol. It is not stored as the actual
Pega `pyRouterKey` value.

The immutable fields remain:
- pyGUID
- pxCaseID
- Type
- pyGroup
- pyPayload

### Metadata-only update bridge used for simulation

Current repo Generator allowlist has no metadata-update interface. Therefore this pass uses an explicitly
proposed simulation bridge:

`UpdateMemoryStatus(pxCaseID=<case>, Type="UnitTestCandidate", RequestsJSON=<string>)`

Decoded request:

```json
{
  "pxResults": [
    {
      "pyGroup":"G001",
      "pyGUID":"<candidate-guid>",
      "pyStatusValue":"Passed",
      "pyRouterKey":"OK"
    }
  ]
}
```

One current invocation may contain N rows; future fan-out contains one row.
Rows are independent, like WriteMemory.

Update lookup is by exact pyGUID.
pxCaseID, Type and pyGroup are consistency constraints/correlation metadata.

The operation MUST NOT modify:
- pyGUID
- pxCaseID
- Type
- pyGroup
- pyPayload

### Per-row result

Conceptual response row:

```json
{
  "pyGroup":"G001",
  "pyGUID":"<same candidate-guid>",
  "Success":true,
  "ErrorCode":"",
  "ErrorMessage":""
}
```

Top-level Success/Error fields, when present, describe invocation/envelope execution only.
They do not collapse individual row outcomes.

### Happy-path synthetic update

After synthetic Validator OK for G001/G002/G003, Generator requested:

- G001 candidate -> Passed / OK
- G002 candidate -> Passed / OK
- G003 candidate -> Passed / OK

Synthetic status-update response deliberately returned G003, G001, G002.
All three rows succeeded and correlated by exact pyGroup + pyGUID.

Fixtures:
- `REVIEW_UPDATEMEMORYSTATUS_REQUEST_D010.json`
- `REVIEW_UPDATEMEMORYSTATUS_RESULT_D010.json`

Classification:
`SYNTHETIC_SIMULATION_FIXTURE`

Result:
`UNITTESTCANDIDATE_LIFECYCLE_COMMIT = PASS_FOR_REVIEW_SIMULATION`

### Repair/rejection lifecycle

For a valid Validator report:

- route=OK:
  current candidate -> `Passed / OK`

- route=GENERATOR_REPAIR:
  current candidate -> `Failed / GENERATOR_REPAIR`
  before a replacement candidate is persisted/validated.

- route=SEMANTIC_REJECT:
  current candidate -> `Failed / SEMANTIC_REJECT`

- route=HUMAN:
  current candidate -> `Failed / HUMAN`

A repaired candidate is a new immutable Memory item with a new pyGUID and starts Pending.
The failed prior candidate is never rewritten or reused.

A malformed/missing Validator response is not silently converted into a successful validation state;
candidate remains ineligible for downstream use.

### Downstream eligibility

A later unit-test creation process discovers eligible artifacts by Memory metadata, conceptually:

```text
pxCaseID=<case>
Type=UnitTestCandidate
pyStatusValue=Passed
```

and then addresses each exact artifact by its canonical pyGUID.

No second `UnitTest` Memory copy is created solely to represent validation success.

---

## MA-038 — Generator lacks lifecycle metadata-update interface

Status:
`CONFIRMED_INTERFACE_GAP`

Live Generator G1 allowlist currently contains only:
- GetMemory(CaseID, Type, UUID)
- KnowledgeTool(KnowledgeAreas)
- WriteMemory(CaseID, Type, Payload)
- UnitTestValidator(CaseID, RUTType, UnitTestCandidateUUID)

It explicitly excludes separate result/report writes and has no interface capable of updating
`pyStatusValue` / `pyRouterKey` on the same candidate Memory record.

Accepted lifecycle requires a metadata-only update capability after each valid Validator outcome.

Required prompt/tool change:
- add the metadata-update interface to UnitTestGenerator's closed allowlist;
- define exact parameters/result validation;
- forbid pyPayload mutation through that interface.

Exact production tool name/signature remains a design item unless the proposed
`UpdateMemoryStatus(pxCaseID, Type, RequestsJSON)` name is accepted.

---

## Current Generator -> Scenario Author report fixture

After all three candidate lifecycle updates succeed:

```text
GR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001|status=OK|successful=1|untestable=0|reason=-
GR|pyGroup=G002|pyGUID=SYNTHETIC-CANDIDATE-GUID-G002|status=OK|successful=1|untestable=0|reason=-
GR|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003|status=OK|successful=1|untestable=0|reason=-
```

Fixture:
`REVIEW_GENERATOR_TO_AUTHOR_REPORT_D010.txt`

Scenario Author correlates rows by pyGroup, not order.

For this happy path:
- every expected group appears exactly once;
- every row status is OK;
- every candidate pyGUID is nonempty;
- all three candidates are durably `Passed / OK`.

Aggregate:
`GENERATOR_TO_AUTHOR = PASS_FOR_REVIEW_SIMULATION`

Scenario Author may therefore return its already-fixed visible external success object:

`{"AIAgentResponseStatus":"Completed","AIAgentErrorResponseMessage":""}`

No candidate GUID or internal report is exposed to the user.

---

## MA-039 — current Main/Generator A2A signatures are obsolete

Status:
`CONFIRMED_CROSS_AGENT_INTERFACE_CHANGE`

Live Main still invokes:
`UnitTestGenerator(CaseID, RUTType, ScenarioGroupUUIDs)`

Live Generator still declares those three direct inputs.

Actual invoked-agent constraint is one scalar `question`.

Accepted D-008/D-009 contract instead requires:
- Author -> Generator: `question` containing GEN + SG records;
- Generator -> Validator: `question` containing VAL + UT records;
- direct compact line reports in the reverse direction.

Both Main and Generator/Validator prompts must be changed together; changing only one side breaks the
pipeline.

---

## Happy-path simulation milestone

The complete current RUT happy path has now reached:

```text
Scenario Author
  -> three ScenarioGroup Memory items
  -> compact GEN/SG A2A handoff

UnitTestGenerator
  -> exact ScenarioGroup GetMemory reads
  -> three one-unit UnitTestCandidate Memory items (Pending)
  -> compact VAL/UT A2A handoff

UnitTestValidator
  -> JsonValidationTool + exact candidate GetMemory per pyGUID
  -> three OK reports

UnitTestGenerator
  -> same three candidate pyGUIDs updated to Passed / OK
  -> compact GR report

Scenario Author
  -> external Completed response
```

Every actual tool success after ScenarioGroup runtime evidence remains explicitly synthetic in this
review; no Pega persistence/validation call was actually executed.


---

## D-011 — mixed independent UnitTestCandidate write simulation

Purpose:
exercise the accepted non-atomic/per-item WriteMemory semantics.

Synthetic candidate-write result:

- G001: success -> new candidate GUID
- G002: failure `WRITE_FAILED` -> no candidate GUID
- G003: success -> new candidate GUID

Response order deliberately shuffled.

Fixture:
`REVIEW_CANDIDATE_WRITEMEMORY_MIXED_D011.json`

Classification:
`SYNTHETIC_SIMULATION_FIXTURE`

### Correct downstream routing

Validator question includes only successfully persisted candidates:

```text
VAL|pxCaseID=<SYNTHETIC_pyID>|RUTType=Rule-Obj-Model
UT|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-N1
UT|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003-N1
```

G002 is not sent to Validator because no UnitTestCandidate Memory item exists for it.

Fixture:
`REVIEW_VALIDATOR_QUESTION_MIXED_D011.txt`

This confirms:
- one item write failure does not cancel successful siblings;
- no fabricated/fallback GUID is used;
- Validator receives only exact canonical addresses of existing candidates.

---

## MA-040 — compact GR report incorrectly conflated technical failure with Untestable

Status:
`PROPOSED_PROTOCOL_DEFECT_CONFIRMED`

The first D-008 GR proposal contained:

- `successful=<N>`
- `untestable=<N>`

For a candidate `WRITE_FAILED`, the source Scenario is not semantically Untestable.
It is simply not validated because no candidate Memory item was created.

Therefore mapping the failed G002 write to `untestable=1` is false.

### Accepted-for-simulation correction

Make the Generator -> Scenario Author report more concise and avoid scenario-state compression:

```text
GR|pyGroup=<group>|pyGUID=<finalValidatedCandidateGUIDOrAbsent>|status=<OK|PARTIAL|FAILED>|reason=<codeOrAbsent>
```

Semantics:

- `OK`
  - a final UnitTestCandidate exists;
  - its exact pyGUID is supplied;
  - it has passed Validator and durable lifecycle update;
  - no source Scenario in the physical group was rejected.

- `PARTIAL`
  - a final UnitTestCandidate exists and is Passed/OK;
  - one or more source Scenarios from the physical group were semantically removed/pruned;
  - applicable primarily to multi-Scenario physical groups such as Rule-Obj-When;
  - exact candidate pyGUID is supplied.

- `FAILED`
  - no final eligible Passed UnitTestCandidate exists for the physical group;
  - pyGUID is absent (`-`);
  - reason is a stable failure code.

This protocol does not label technical failures as Untestable.
Detailed semantic scenario state remains downstream Generator internal logic; Main needs only physical-group
completion for orchestration.

Correct mixed fixture:

```text
GR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-N1|status=OK|reason=-
GR|pyGroup=G002|pyGUID=-|status=FAILED|reason=CANDIDATE_WRITE_FAILED
GR|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003-N1|status=OK|reason=-
```

Fixture:
`REVIEW_GENERATOR_TO_AUTHOR_MIXED_D011_v2.txt`

No correlation by row order.

---

## MA-041 — Main aggregate semantics for mixed group outcomes still require a decision

Status:
`OPEN_MATERIAL_DECISION`

Accepted independent processing now permits a truthful Generator response containing a mix such as:

- G001 = OK
- G002 = FAILED
- G003 = OK

Current live Main maps old Generator `Completed` OR `PartiallyCompleted` to the same visible external
`AIAgentResponseStatus="Completed"`.

That behavior may be inappropriate for a technical group failure because the visible success response has
an empty error message and hides the fact that one required physical ScenarioGroup produced no validated
candidate.

Two possible policies:

A. **Strict aggregate**
- all GR rows OK/PARTIAL and no FAILED -> external Completed
- any FAILED -> external Failed
- successful sibling candidates remain persisted and usable; external Failed means the requested complete
  generation run was not fully successful.

B. **Partial-is-completed aggregate**
- at least one OK/PARTIAL -> external Completed even if another GR row FAILED
- external Failed only when no physical group succeeds.
- maximizes partial progress but hides incomplete requested coverage from the caller's only visible status.

Recommendation:
Policy A (strict aggregate), while retaining successful sibling artifacts in Memory.
This separates transactional rollback from run-level success:
writes remain independent, but the run reports failure if required work was incomplete.

User decision required before the mixed-path Scenario Author final response is simulated.


---

## D-012 — aggregate success, testability/UI semantics, and generic UpdateMemory

### User decision: Scenario Author aggregate result

External `AIAgentResponseStatus="Failed"` only when there are **no successful physical groups at all**.

A physical group is successful when a final UnitTestCandidate Memory item exists for that group and:
- its exact candidate pyGUID was validated;
- Validator route is OK;
- lifecycle metadata update completed to:
  - `pyStatusValue="Passed"`
  - `pyRouterKey="OK"`.

Therefore:

- one or more successful groups -> external `Completed`;
- zero successful groups -> external `Failed`.

Successful siblings are never rolled back because another group fails.

This resolves MA-041 in favor of the prior "partial-is-completed" aggregate policy.

Status:
`MA-041 = RESOLVED_BY_USER_DECISION`

### Candidate lifecycle status is independent of testability

Memory lifecycle metadata answers:
"Did this exact candidate artifact pass validation?"

Candidate payload answers:
"How testable/complete is the represented Scenario?"

These are orthogonal.

Example valid combination:

```text
Memory:
  pyStatusValue = Passed
  pyRouterKey   = OK

Candidate:
  Scenarios[0].Testability = PartiallyTestable
  Scenarios[0].EvidenceSummary.BlockingGaps = [...]
```

This is not contradictory.

`Passed/OK` means the candidate is structurally/semantically consistent with its frozen source decisions
and accepted Validator contract. It does not mean every behavior is FullyTestable.

### Exact existing schema location

The current standard UTC schema places:
- `Testability` on each `UnitTestRules[i].Scenarios[j]`;
- `BlockingGaps` inside each Scenario's `EvidenceSummary`.

`Testability` values:
- FullyTestable
- PartiallyTestable
- NotTestable

`BlockingGaps` is an array of objects with required `pyValue` and optional fixed pxObjClass.

Therefore UI should reuse these existing fields for semantic/testability limitations rather than inventing
a duplicate Generator-report testability state.

### Direct Generator -> Scenario Author report simplification

Because testability is already represented in the persisted candidate, remove `PARTIAL` from the A2A
Generator result.

New exact conceptual row:

`GR|pyGroup=<group>|pyGUID=<validatedCandidateGUIDOrAbsent>|status=<OK|FAILED>|reason=<codeOrAbsent>`

Rules:
- OK:
  - pyGUID nonempty;
  - exact candidate is durably Passed/OK;
  - reason absent (`-`);
  - Scenario testability is intentionally not repeated in GR.
- FAILED:
  - no final eligible Passed/OK candidate exists for that group;
  - pyGUID absent (`-`);
  - reason contains a stable technical/control-flow failure code.

Main aggregates only GR success/failure.
UI/domain consumers inspect candidate `Scenarios[].Testability` and
`Scenarios[].EvidenceSummary.BlockingGaps`.

This supersedes the earlier GR `successful`, `untestable`, and `PARTIAL` fields.

### Important boundary: technical failures

A technical failure that prevents candidate persistence (for example candidate `WRITE_FAILED`) cannot be
represented inside `UnitTestRules[]`, because no UnitTestCandidate Memory item exists.

It remains a GR FAILED orchestration outcome.

If UI must later persist/display such pre-candidate technical failures after the agent invocation ends,
that requires a separate durable status strategy (for example metadata on the source ScenarioGroup).
Do not fabricate a UnitTestCandidate only to store a tool error.

---

## D-013 — generic `UpdateMemory` tool

User selected generic `UpdateMemory` rather than status-specific `UpdateMemoryStatus`.

### Goal

Provide one extensible Memory patch operation that can update allowed fields of existing Memory items
without creating a new Memory record and without changing their pyGUID.

Preferred signature:

`UpdateMemory(pxCaseID=<string>, Type=<string>, RequestsJSON=<string>)`

`pxCaseID` and `Type` apply to the whole invocation/batch.

Decoded RequestsJSON:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyGUID": "UTC-GUID-001",
      "pyUpdates": {
        "pyStatusValue": "Passed",
        "pyRouterKey": "OK"
      }
    }
  ]
}
```

### Identity and addressing

For every row:
- exact existing Memory record is addressed by `pyGUID`;
- `pxCaseID` and `Type` are mandatory ownership/type constraints;
- `pyGroup` is mandatory lineage/correlation and must match persisted metadata;
- no lookup or fallback by pyGroup;
- no "latest" lookup.

Before patching, server validates:

```text
record.pyGUID   == row.pyGUID
record.pxCaseID == outer pxCaseID
record.Type     == outer Type
record.pyGroup  == row.pyGroup
```

### `pyUpdates` semantics

`pyUpdates` is a JSON object containing the fields to replace on the Memory record.

Version-1 semantics are intentionally simple:
- shallow/root-level field replacement only;
- each named field is replaced by the supplied JSON value with its JSON type preserved;
- fields absent from pyUpdates remain unchanged;
- no recursive/deep merge;
- no implicit deletion;
- no path interpretation;
- empty pyUpdates is invalid.

This keeps the wrapper extensible. If nested/path patching is required later, it can be added explicitly
without changing the outer pxResults/pyGUID contract.

### Protected invariants

Even though UpdateMemory is generic, the Memory service must never permit patching canonical identity
fields through this interface:

- `pyGUID`
- `pxCaseID`
- `Type`
- `pyGroup`

For the current UnitTestCandidate lifecycle, Generator is additionally authorized to update only:

- `pyStatusValue`
- `pyRouterKey`

The candidate `pyPayload` remains immutable under the current Generator contract.

A future caller/tool contract may authorize additional non-identity Memory metadata fields without
changing UpdateMemory's transport shape.

### Independent row outcomes

Like WriteMemory, UpdateMemory is not atomic across `pxResults` rows.

Conceptual result:

```json
{
  "pxResults": [
    {
      "pyGroup": "G001",
      "pyGUID": "UTC-GUID-001",
      "Success": true,
      "ErrorCode": "",
      "ErrorMessage": ""
    },
    {
      "pyGroup": "G002",
      "pyGUID": "UTC-GUID-002",
      "Success": false,
      "ErrorCode": "UPDATE_FAILED",
      "ErrorMessage": "<bounded diagnostic>"
    }
  ]
}
```

Result order is non-authoritative.
Each row is correlated by exact pyGroup + pyGUID.

A successful Validator OK is not considered a successful group for Main until the candidate's
UpdateMemory row successfully persists `Passed/OK`, because downstream discovery relies on durable
Memory metadata.

### Generator allowlist change

Replace the prior proposed `UpdateMemoryStatus` bridge with:

`UpdateMemory(pxCaseID, Type, RequestsJSON)`

Current UnitTestGenerator may invoke it only for UnitTestCandidate lifecycle metadata under the
authorization above.

Status:
`MA-038 = RESOLVED_BY_D013_PENDING_PROMPT_EDIT`

---

## D-014 — UI representation policy

For a successfully persisted UnitTestCandidate:
- UI identifies the candidate by `pyGUID`;
- validation lifecycle comes from Memory metadata:
  - pyStatusValue
  - pyRouterKey;
- semantic testability comes from candidate payload:
  - `UnitTestRules[].Scenarios[].Testability`
  - `UnitTestRules[].Scenarios[].EvidenceSummary.BlockingGaps`.

Do not duplicate Testability in Memory metadata or GR transport.

Known semantic gaps should be explicit in BlockingGaps at candidate generation time.
Validator lifecycle failures use pyStatusValue/pyRouterKey and Validator diagnostics; they are not
retroactively rewritten into immutable candidate BlockingGaps.

A later Pega Unit Test rule creation process should select candidates by:

```text
pxCaseID=<case>
Type=UnitTestCandidate
pyStatusValue=Passed
```

and then retrieve each exact artifact by pyGUID. Scenario Testability can be used as an additional UI or
creation-policy filter if desired, but it is not equivalent to validation status.


---

## D-013/D-012 simulation replay — generic UpdateMemory and aggregate Main result

### Generic UpdateMemory happy path

Request fixture:
`REVIEW_UPDATEMEMORY_REQUEST_D013.json`

Decoded request rows:
- G001 candidate -> pyStatusValue=Passed, pyRouterKey=OK
- G002 candidate -> pyStatusValue=Passed, pyRouterKey=OK
- G003 candidate -> pyStatusValue=Passed, pyRouterKey=OK

Tool:
`UpdateMemory(pxCaseID=<exact case pyID>, Type="UnitTestCandidate", RequestsJSON=<fixture>)`

Synthetic response fixture:
`REVIEW_UPDATEMEMORY_RESULT_D013.json`

Response order deliberately shuffled G002, G003, G001.

All three rows:
- exact pyGroup matched;
- exact pyGUID echoed;
- Success=true;
- empty errors.

Classification:
`SYNTHETIC_SIMULATION_FIXTURE`

Result:
`GENERIC_UPDATEMEMORY_LIFECYCLE_COMMIT = PASS_FOR_REVIEW_SIMULATION`

### Simplified Generator -> Author report

All-success fixture:
`REVIEW_GENERATOR_TO_AUTHOR_D012.txt`

```text
GR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001|status=OK|reason=-
GR|pyGroup=G002|pyGUID=SYNTHETIC-CANDIDATE-GUID-G002|status=OK|reason=-
GR|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003|status=OK|reason=-
```

No Testability is repeated in GR.

Current candidate payloads remain scenario-level `PartiallyTestable` with explicit BlockingGaps from the
frozen Author decisions. This is compatible with Memory lifecycle `Passed/OK`.

### Main aggregate — all-success path

At least one successful GR row exists; all three are successful.

Exact visible Main result:

`{"AIAgentResponseStatus":"Completed","AIAgentErrorResponseMessage":""}`

Result:
`MAIN_HAPPY_PATH = PASS_FOR_REVIEW_SIMULATION`

### Main aggregate — mixed technical failure path

Mixed fixture:
`REVIEW_GENERATOR_TO_AUTHOR_MIXED_D012.txt`

```text
GR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-N1|status=OK|reason=-
GR|pyGroup=G002|pyGUID=-|status=FAILED|reason=CANDIDATE_WRITE_FAILED
GR|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003-N1|status=OK|reason=-
```

Under accepted D-012:
- G001 remains usable;
- G003 remains usable;
- G002 failed technically;
- successful sibling artifacts are not rolled back;
- because at least one GR row is OK, Main returns external Completed.

Exact visible result:

`{"AIAgentResponseStatus":"Completed","AIAgentErrorResponseMessage":""}`

Result:
`MAIN_MIXED_PATH = PASS_FOR_REVIEW_SIMULATION`

### Main aggregate — zero-success path

Only when no physical group yields a final Passed/OK candidate:

`{"AIAgentResponseStatus":"Failed","AIAgentErrorResponseMessage":"Unit test generation failed."}`

Result:
`MAIN_ZERO_SUCCESS_POLICY = LOCKED`

### UI/testability note

The current standard schema confirms:
- root `UnitTestRules[]`;
- each unit has `Scenarios[]`;
- each Scenario has required `Testability`;
- each Scenario has `EvidenceSummary`;
- `EvidenceSummary.BlockingGaps[]` carries explicit gap text.

Therefore candidate-visible semantic limitations should use these existing schema fields rather than
introducing duplicate lifecycle/testability fields into GR or Memory metadata.

Technical failures that happen before a candidate exists remain a distinct orchestration case and are not
fabricated into UnitTestRules.


---

## MA-042 — repair budget scope is not future-proof

Status:
`OPEN_MATERIAL_DECISION`

Current live Generator G8 uses one combined-candidate repair loop:
- initial Validator report;
- at most two further attempts;
- every revision/prune/rebuild consumes the same two-repair budget.

Accepted architecture has one independent UnitTestCandidate per physical pyGroup and future execution may
run one UnitTestGenerator agent instance per pyGroup.

If current grouped execution keeps one shared repair budget, behavior changes after fan-out:
- today a repair on G001 can consume budget needed by G002;
- tomorrow G001 and G002 each receive their own two-repair budget.

That violates the goal that current grouped execution and future fan-out differ only in routing/cardinality.

### Recommended correction

Repair/validation budget is per `pyGroup`.

For each independently routable physical group:

```text
initial candidate validation: 1
maximum repair candidate versions: 2
maximum Validator attempts: 3
```

A repair/semantic-prune/rebuild for G001 affects only G001's counters.
It does not consume G002/G003 budget.

Current one Generator instance maintains independent state per pyGroup.
Future one Generator instance per group uses exactly the same local state machine without contract change.

### Candidate lifecycle under repair

Example G001:

```text
C1 pyGUID=A
  Pending
  -> Validator GENERATOR_REPAIR
  -> UpdateMemory A = Failed / GENERATOR_REPAIR

C2 pyGUID=B
  Pending
  -> Validator OK
  -> UpdateMemory B = Passed / OK

GR|pyGroup=G001|pyGUID=B|status=OK|reason=-
```

C1 remains an immutable failed historical candidate.
C2 is the final eligible candidate.

If both allowed repairs are exhausted without a Passed/OK candidate:

```text
GR|pyGroup=G001|pyGUID=-|status=FAILED|reason=REPAIR_BUDGET_EXHAUSTED
```

Successful sibling groups remain unaffected.

### Decision needed

Adopt per-pyGroup two-repair / three-validation-attempt budget now?


---

## MA-042 accepted — repair budget is per pyGroup

User approved the recommended future-proof repair scope.

For every independently routable physical `pyGroup`:

```text
initial candidate validation = 1
maximum repair candidate versions = 2
maximum Validator attempts = 3
```

Counters are local to the pyGroup.

A repair attempt for G001 never consumes G002/G003 budget.
Current grouped execution and future one-Generator-per-group execution therefore have identical item
semantics.

Status:
`MA-042 = PROPOSED_FIX_ACCEPTED`

---

## D-015 — per-pyGroup mechanical repair simulation

Purpose:
exercise one complete `GENERATOR_REPAIR` cycle without affecting sibling groups.

### Controlled synthetic projection defect

Starting source:
`REVIEW_UNITTESTCANDIDATE_G001_D007.json`

Created faulty candidate:
`REVIEW_UNITTESTCANDIDATE_G001_REPAIR_FAULT_D015.json`

Only one physical RuleCode assertion block was removed:

- frozen decision: A005
- kind: Property
- target: `.Addresses(1).pyCity`
- comparator: `Not exists`
- physical containing page: `CustomerCommunication.Addresses(1)`

The immutable AssertionDecisionTrace still contains A005.

Therefore the candidate-visible defect is exactly:
`ASSERT_MISSING`

No source semantic decision changed.

Repaired candidate:
`REVIEW_UNITTESTCANDIDATE_G001_REPAIRED_D015.json`

It restores the original frozen A005 projection and is otherwise identical to the valid G001 projection.

### Initial faulty candidate lifecycle

Synthetic first candidate address:

`SYNTHETIC-CANDIDATE-GUID-G001-R0`

Validator direct report:

```text
VR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-R0|route=GENERATOR_REPAIR|blocking=1|warnings=0
VI|severity=B|code=ASSERT_MISSING|action=ADD_ASSERTION|scenario=0|decision=A005|path=/UnitTestRules/0/RuleCode/pyExpectedResults|message=Frozen assertion A005 is missing
```

Fixture:
`REVIEW_G001_VALIDATOR_REPAIR_REPORT_D015.txt`

Classification:
`SYNTHETIC_SIMULATION_FIXTURE`

The issue is mechanically authorized because:
- decision A005 already exists and is final in immutable source/trace;
- action only restores that projection;
- no new value/path/type/witness is invented.

### Durable failure state of superseded candidate

Before writing the repair version, Generator updates the exact R0 item:

```json
{
  "pxResults": [
    {
      "pyGroup":"G001",
      "pyGUID":"SYNTHETIC-CANDIDATE-GUID-G001-R0",
      "pyUpdates":{
        "pyStatusValue":"Failed",
        "pyRouterKey":"GENERATOR_REPAIR"
      }
    }
  ]
}
```

Fixture:
`REVIEW_G001_UPDATE_FAILED_D015.json`

The candidate payload remains immutable.

### Repaired candidate write

Generator writes the repaired complete candidate as a NEW Memory item.

Synthetic new address:

`SYNTHETIC-CANDIDATE-GUID-G001-R1`

Fixture:
`REVIEW_G001_REPAIRED_WRITE_REQUEST_D015.json`

R1 starts:
- pyStatusValue = Pending
- pyRouterKey = empty

This consumes:
- G001 repairAttempts = 1
- G001 validationAttempts before next call = 1
- G002 repairAttempts = 0
- G003 repairAttempts = 0

### Repaired candidate validation

Validator report for exact R1 address:

```text
VR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-R1|route=OK|blocking=0|warnings=0
```

Fixture:
`REVIEW_G001_VALIDATOR_OK_REPORT_D015.txt`

Generator then updates R1:

```text
pyStatusValue = Passed
pyRouterKey   = OK
```

Fixture:
`REVIEW_G001_UPDATE_PASSED_D015.json`

Final G001 counters:
- validationAttempts = 2
- repairAttempts = 1

G002/G003 counters remain:
- validationAttempts = 1
- repairAttempts = 0

### Final Generator -> Scenario Author report

```text
GR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-R1|status=OK|reason=-
GR|pyGroup=G002|pyGUID=SYNTHETIC-CANDIDATE-GUID-G002|status=OK|reason=-
GR|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003|status=OK|reason=-
```

Fixture:
`REVIEW_GENERATOR_TO_AUTHOR_REPAIR_D015.txt`

Important:
G001 reports only the final eligible Passed candidate R1.
The failed R0 remains addressable historical Memory evidence but is never returned as the successful
candidate.

Result:
`PER_GROUP_MECHANICAL_REPAIR = PASS_FOR_REVIEW_SIMULATION`

---

## Repair-state invariant

For each pyGroup independently:

```text
Pending candidate
  -> Validator OK
     -> UpdateMemory Passed/OK
     -> GR OK with same pyGUID

  -> Validator GENERATOR_REPAIR
     -> UpdateMemory current candidate Failed/GENERATOR_REPAIR
     -> if local repair budget remains:
          write new immutable candidate with new pyGUID
          validate new candidate
        else:
          GR FAILED / REPAIR_BUDGET_EXHAUSTED

  -> Validator SEMANTIC_REJECT
     -> UpdateMemory current candidate Failed/SEMANTIC_REJECT
     -> semantic handling remains source-scope dependent

  -> Validator HUMAN
     -> UpdateMemory current candidate Failed/HUMAN
     -> GR FAILED / HUMAN_REVIEW_REQUIRED
```

Sibling pyGroups continue independently.


---

## D-016 — Validator OK but lifecycle UpdateMemory fails

Purpose:
test the durability boundary between ephemeral Validator success and downstream eligibility.

Synthetic state before update:
- G001 Validator = OK
- G002 Validator = OK
- G003 Validator = OK

Generic UpdateMemory synthetic result:
- G001 update Passed/OK = success
- G002 update Passed/OK = `UPDATE_FAILED`
- G003 update Passed/OK = success

Fixture:
`REVIEW_UPDATEMEMORY_MIXED_D016.json`

Classification:
`SYNTHETIC_SIMULATION_FIXTURE`

### Required interpretation

A Validator `OK` report alone does not make a candidate eligible for future Unit Test creation.

Eligibility requires both:
1. exact candidate pyGUID received Validator route OK;
2. the same Memory item durably stores:
   - pyStatusValue = Passed
   - pyRouterKey = OK.

Therefore G002 cannot be reported upstream with its candidate pyGUID after the failed lifecycle update.

Generator -> Author:

```text
GR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001|status=OK|reason=-
GR|pyGroup=G002|pyGUID=-|status=FAILED|reason=LIFECYCLE_UPDATE_FAILED
GR|pyGroup=G003|pyGUID=SYNTHETIC-CANDIDATE-GUID-G003|status=OK|reason=-
```

Fixture:
`REVIEW_GENERATOR_TO_AUTHOR_UPDATEFAIL_D016.txt`

Under D-012 aggregate policy:
at least one group succeeded, so Main visible result remains Completed.

The G002 candidate may remain Pending if UpdateMemory did not apply.
It must not be consumed by later rule-generation queries filtered on pyStatusValue=Passed.

---

## MA-043 — UpdateMemory retry semantics are undefined

Status:
`OPEN_MATERIAL_DECISION`

Generic UpdateMemory is a root-level replacement patch addressed by exact pyGUID.

For the current lifecycle patches, repeating the exact same request is logically idempotent:

```json
{
  "pyStatusValue":"Passed",
  "pyRouterKey":"OK"
}
```

Applying it twice produces the same final state.

However the existing prompt family generally avoids retrying uncertain writes, and no retry policy has yet
been defined for UpdateMemory.

Two possible policies:

### A. No retry
- any explicit or uncertain UpdateMemory failure terminates the affected pyGroup;
- GR FAILED / LIFECYCLE_UPDATE_FAILED;
- candidate may remain Pending;
- operational reconciliation can handle stale Pending items later.

### B. One idempotent retry
- only retry the exact same pyGUID + exact same pyUpdates;
- no altered patch on retry;
- retry at most once per lifecycle transition;
- an explicit success after retry confirms state;
- if invocation outcome is still uncertain after retry, affected group fails;
- no retry budget interaction with Generator projection repair attempts.

Recommendation:
B, provided UpdateMemory server semantics guarantee root-level replacement is idempotent for these fields.

Reason:
the update does not create a new record and does not change pyPayload; a repeated identical status patch
is safer than leaving a successfully validated candidate indefinitely Pending after a transient update
failure.

User decision required before UpdateMemory failure handling is finalized.


---

## MA-043 resolved — UpdateMemory has no retry

User decision:
`UpdateMemory` must not retry.

Final rule:
- exactly one UpdateMemory attempt per lifecycle transition per pyGroup;
- no automatic retry after explicit failure;
- no retry after malformed/uncertain invocation outcome;
- no altered patch retry;
- no fallback write;
- no attempt to infer whether the update may have partially applied.

If the single UpdateMemory attempt does not return a valid per-row success for the exact pyGroup + pyGUID:
- that pyGroup is treated as lifecycle-update failed for the current run;
- Generator returns:
  `GR|pyGroup=<group>|pyGUID=-|status=FAILED|reason=LIFECYCLE_UPDATE_FAILED`
- the candidate must not be reported as eligible;
- successful sibling groups continue independently;
- Main returns external Failed only if no group succeeds.

The candidate may remain Pending if the update did not apply.
Later reconciliation/query tooling may inspect such stale Pending records, but the Generator does not retry
or repair lifecycle metadata in the same run.

Status:
`MA-043 = RESOLVED_BY_USER_DECISION`


---

## D-017 — legitimate PartiallyTestable candidate validates OK

Source:
`REVIEW_UNITTESTCANDIDATE_G001_D007.json`

Current candidate scenario facts:

```text
Testability = PartiallyTestable
SupportLevel = OmittedClaimsPresent
DependencyClosureStatus = Blocked
BlockingGaps:
  - UNRESOLVABLE_RUNTIME_INPUT:Param.AddressIndex
  - UNRESOLVABLE_RUNTIME_INPUT:Param.StreetName
```

Fixture:
`REVIEW_G001_PARTIAL_TESTABILITY_D017.json`

These limitations are already explicit in the persisted candidate payload and do not make the candidate
structurally/semantically inconsistent.

Synthetic Validator result:

```text
VR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-PARTIAL|route=OK|blocking=0|warnings=0
```

Fixture:
`REVIEW_G001_PARTIAL_VALIDATOR_OK_D017.txt`

After one successful UpdateMemory lifecycle patch:

```text
pyStatusValue = Passed
pyRouterKey   = OK
```

Interpretation:
`Passed/OK` means Validator accepts the exact candidate representation.
It does NOT mean `FullyTestable`.

Result:
`PARTIAL_TESTABILITY_WITH_BLOCKING_GAPS = VALIDATOR_OK`

---

## D-018 — true semantic contradiction routes SEMANTIC_REJECT

Synthetic candidate:
`REVIEW_UNITTESTCANDIDATE_G001_SEMANTIC_CONTRADICTION_D018.json`

Starting from the valid G001 candidate, exactly one additional final decision was appended:

```text
OMIT|id=O004|target=Param.ExitCode|reason=incorrect_candidate_assertion
```

The same trace already contains:

```text
ASSERT|id=A002|kind=Property|target=Param.ExitCode|...
```

Thus the final decision ledger simultaneously ASSERTs and OMITs the same target.

This is not a projection formatting/value mismatch.
The current Validator V6 explicitly classifies ASSERT + OMIT on the same full target as:

```text
REASONING_CONTRADICTION / REJECT_SEMANTICS
```

Synthetic Validator direct report:

```text
VR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-SR0|route=SEMANTIC_REJECT|blocking=1|warnings=0
VI|severity=B|code=REASONING_CONTRADICTION|action=REJECT_SEMANTICS|scenario=0|decision=A002|path=/UnitTestRules/0/Scenarios/0/EvidenceSummary/AssertionDecisionTrace|message=Param.ExitCode is both ASSERT and OMIT
```

Fixture:
`REVIEW_G001_SEMANTIC_REJECT_REPORT_D018.txt`

Generator lifecycle action for the exact rejected candidate:

```text
UpdateMemory:
  pyStatusValue = Failed
  pyRouterKey   = SEMANTIC_REJECT
```

Fixture:
`REVIEW_G001_SEMANTIC_REJECT_UPDATE_D018.json`

No projection repair is attempted because choosing ASSERT vs OMIT would change/resolve semantic authority rather
than restore an already-unambiguous final decision.

Generator report for the affected group:

```text
GR|pyGroup=G001|pyGUID=-|status=FAILED|reason=SEMANTIC_REJECT
```

Fixture:
`REVIEW_G001_SEMANTIC_REJECT_GR_D018.txt`

Sibling pyGroups, when present, remain independent.

Result:
`TRUE_SEMANTIC_CONTRADICTION = SEMANTIC_REJECT`

### Semantic boundary now locked

- Legitimate `PartiallyTestable` / `NotTestable` plus faithful BlockingGaps:
  may still validate `OK`.
- Mechanical mismatch against an unambiguous existing final decision:
  `GENERATOR_REPAIR`.
- Contradictory/missing/unfinalized final semantic decisions:
  `SEMANTIC_REJECT`.
- Validator must not convert SEMANTIC_REJECT into a new BlockingGap or invent which semantic choice is correct.


---

## D-019 — HUMAN route simulation

Purpose:
exercise the final Validator route using a condition explicitly defined by current Validator V4.

Synthetic preconditions:
- invocation valid;
- JsonValidationTool succeeded;
- exact UnitTestCandidate GetMemory succeeded;
- RUT metadata check passed;
- required UTC Knowledge response is unusable.

Current Validator V4 defines unusable UTC guidance as:
`AMBIGUOUS / HUMAN_REVIEW`, route HUMAN.

Synthetic Validator report:

```text
VR|pyGroup=G001|pyGUID=SYNTHETIC-CANDIDATE-GUID-G001-H0|route=HUMAN|blocking=1|warnings=0
VI|severity=B|code=AMBIGUOUS|action=HUMAN_REVIEW|scenario=-|decision=-|path=/|message=Required UTC Knowledge response is unusable
```

Fixture:
`REVIEW_G001_VALIDATOR_HUMAN_D019.txt`

Generator lifecycle action:

```text
UpdateMemory:
  pyStatusValue = Failed
  pyRouterKey   = HUMAN
```

Fixture:
`REVIEW_G001_HUMAN_UPDATE_D019.json`

No repair is attempted.

Generator report:

```text
GR|pyGroup=G001|pyGUID=-|status=FAILED|reason=HUMAN_REVIEW_REQUIRED
```

Fixture:
`REVIEW_G001_HUMAN_GR_D019.txt`

Sibling groups continue independently.
Main returns external Failed only when no sibling/other group succeeds.

Result:
`HUMAN_ROUTE = PASS_FOR_REVIEW_SIMULATION`

---

## Simulation state-machine completion milestone

All intended final routes and durability boundaries have now been exercised:

1. Validator `OK`
   - candidate UpdateMemory -> Passed/OK
   - GR OK

2. Validator `GENERATOR_REPAIR`
   - current candidate UpdateMemory -> Failed/GENERATOR_REPAIR
   - new immutable candidate/new pyGUID
   - repair budget per pyGroup
   - repaired candidate can become Passed/OK

3. Validator `SEMANTIC_REJECT`
   - current candidate -> Failed/SEMANTIC_REJECT
   - no semantic invention/repair
   - GR FAILED

4. Validator `HUMAN`
   - current candidate -> Failed/HUMAN
   - no repair
   - GR FAILED

5. candidate WriteMemory failure
   - no candidate pyGUID
   - affected group not sent to Validator
   - siblings continue

6. lifecycle UpdateMemory failure
   - Validator OK alone is insufficient
   - affected group GR FAILED
   - no UpdateMemory retry

7. legitimate PartiallyTestable + BlockingGaps
   - may validate OK and become Passed/OK

8. Main aggregate
   - >=1 successful group -> external Completed
   - zero successful groups -> external Failed

The simulation phase is complete enough to begin coordinated prompt refactoring.

---

# Refactoring Recovery Protocol

This protocol is now mandatory before and during prompt refactoring.

Its purpose is to prevent:
- accepted architectural decisions being forgotten during a long refactor;
- partial edits being mistaken for completed edits;
- section renumbering causing silent omissions;
- a stopped/restarted agent hallucinating that a change was already applied;
- verification relying on memory instead of file evidence.

## 1. Factual Change Register

Maintain a compact append-only table for every accepted prompt change.

Each row records only factual state:

| Change ID | Target file | Exact section / paragraph | Required change | Status | Evidence |
|---|---|---|---|---|---|
| CHG-001 | Main_Agent_Prompt.txt | §1A | Replace old sequential ScenarioGroup write / all-or-nothing handoff with independent batch WriteMemory + per-row correlation | PLANNED | D-005/D-007/D-012 |
| CHG-002 | Main_Agent_Prompt.txt | §1A | Replace direct UnitTestGenerator(CaseID,RUTType,ScenarioGroupUUIDs) with one `question` using GEN/SG protocol | PLANNED | D-008/D-009 |
| CHG-003 | Main_Agent_Prompt.txt | §1A | Aggregate result: external Failed only when zero groups succeed | PLANNED | D-012 |
| CHG-004 | UnitTestGenerator_Prompt.txt | §G1 | Replace direct input tuple with one `question`; parse GEN/SG records | PLANNED | D-008/D-009 |
| CHG-005 | UnitTestGenerator_Prompt.txt | §G1 allowlist | Add generic UpdateMemory tool; restrict current Generator usage to UnitTestCandidate lifecycle metadata | PLANNED | D-013 |
| CHG-006 | UnitTestGenerator_Prompt.txt | §G1/G2 | Retrieve ScenarioGroups by exact pyGUID via GetMemory; pyGroup is correlation only | PLANNED | D-005/D-008 |
| CHG-007 | UnitTestGenerator_Prompt.txt | §G4/G8/G9 | One UnitTestCandidate Memory item per physical pyGroup; no combined multi-group candidate | PLANNED | D-007 |
| CHG-008 | UnitTestGenerator_Prompt.txt | §G7 | Encode trace field values only; preserve literal structural pipes | PLANNED | MA-036 accepted |
| CHG-009 | UnitTestGenerator_Prompt.txt | §G6 | Derive physical containing page for nested Property assertions; semantic ASSERT.page remains frozen | PLANNED | MA-035 accepted |
| CHG-010 | UnitTestGenerator_Prompt.txt | §G8 | Replace Validator direct tuple call with one `question` using VAL/UT protocol | PLANNED | D-008/D-009 |
| CHG-011 | UnitTestGenerator_Prompt.txt | §G8 | Per-pyGroup repair budget: initial + max 2 repairs / max 3 validations | PLANNED | MA-042 accepted |
| CHG-012 | UnitTestGenerator_Prompt.txt | §G8 | After Validator result, UpdateMemory same candidate pyGUID with pyStatusValue/pyRouterKey; no UpdateMemory retry | PLANNED | D-010/D-013/MA-043 |
| CHG-013 | UnitTestGenerator_Prompt.txt | §G9 | Replace JSON GeneratorRunReport / singular candidate UUID with compact GR rows | PLANNED | D-008/D-012 |
| CHG-014 | Validator_Prompt.txt | §V1 | Replace direct CaseID/RUTType/UnitTestCandidateUUID inputs with one `question`; parse VAL/UT records | PLANNED | D-008/D-009 |
| CHG-015 | Validator_Prompt.txt | §V1/V3 | For each UT row, use exact pyGUID for JsonValidationTool and GetMemory(Type=UnitTestCandidate); verify pyGroup correlation | PLANNED | D-009 |
| CHG-016 | Validator_Prompt.txt | §V5 | Split physical lines and literal structural pipes before decoding field-value entities | PLANNED | MA-036 accepted |
| CHG-017 | Validator_Prompt.txt | §V6 | Validate nested Property physical page using deterministic containing-page derivation | PLANNED | MA-035 accepted |
| CHG-018 | Validator_Prompt.txt | output contract | Replace raw single ValidatorReport JSON with compact VR/VI direct report records | PLANNED | D-008 |
| CHG-019 | Memory tool contract | WriteMemory | UnitTestCandidate creation initializes pyStatusValue=Pending and empty pyRouterKey | PLANNED | D-010 |
| CHG-020 | Memory tool contract | UpdateMemory | Generic shallow root-level patch by exact pyGUID; protected identity fields; independent row outcomes; no retry | PLANNED | D-013/MA-043 |

Rules:
- A change is `PLANNED` until verified in the actual target file.
- After editing, change status to `IMPLEMENTED_UNVERIFIED`.
- Only after rereading the edited file and proving the exact behavior exists may status become `VERIFIED`.
- If partly applied, status is `PARTIAL`, never VERIFIED.
- If a later edit supersedes it, status is `SUPERSEDED` with the replacement Change ID.
- Never infer implementation from an earlier plan/ledger entry.

## 2. Per-file Refactor Evidence

For every modified prompt file, record:

```text
FILE=<exact file>
BASE_SHA=<pre-edit GitHub blob SHA or explicit local baseline hash>
POST_SHA=<post-edit GitHub blob SHA or local hash>
CHANGES=<comma-separated Change IDs>
VERIFICATION=<PASS|FAIL|PARTIAL>
```

For each Change ID, evidence must identify:
- exact section heading;
- paragraph or nearby unique phrase;
- what wording/contract now exists;
- what obsolete wording was removed or superseded.

Section numbers are useful but are not sufficient by themselves because renumbering can occur.
Always include a unique textual anchor.

## 3. Required Verification Pass

After all edits, a separate verification phase must reread all modified files from their actual final source.

It must NOT rely on:
- the simulation ledger;
- assistant memory;
- intended changes;
- patch plans.

For every CHG row, verify both directions:

1. **Presence check**
   - required new wording/contract is present.

2. **Absence/conflict check**
   - obsolete or contradictory old wording is absent or explicitly superseded.

3. **Cross-agent compatibility check**
   - sender format exactly matches receiver parser;
   - sender tool parameters match receiver/tool contract;
   - field names/casing match;
   - pyGUID/pyGroup semantics match;
   - repair and lifecycle semantics match.

4. **Cardinality check**
   - current batched execution and future one-pyGroup fan-out use the same item-level semantics.

5. **Ownership check**
   - Main, Generator, Validator responsibilities remain disjoint.

6. **Status derivation check**
   - Memory lifecycle status, Scenario Testability, BlockingGaps, GR status, and external Main status are not conflated.

## 4. Final Verification Report

Do not declare refactoring complete until producing a compact factual report:

```text
VERIFY|change=CHG-001|status=PASS|file=Main_Agent_Prompt.txt|anchor=<section/phrase>
VERIFY|change=CHG-002|status=PASS|file=Main_Agent_Prompt.txt|anchor=<section/phrase>
...
```

Any FAIL/PARTIAL row blocks the statement "all requested changes completed".

Final completion criteria:

```text
all accepted Change IDs = VERIFIED
AND
no unresolved contradictory old contract remains
AND
cross-agent protocol simulation passes
AND
final files reread from source
```

Only then may the refactor be described as complete.

## 5. Restart / Recovery Procedure

If work stops or context is compacted:

1. read the latest `SIMULATION_REVIEW_LEDGER_v*.md`;
2. locate `Factual Change Register`;
3. trust only rows marked VERIFIED as completed;
4. reread actual target files for every IMPLEMENTED_UNVERIFIED/PARTIAL/PLANNED row;
5. continue from the first non-VERIFIED Change ID;
6. never reconstruct completion status from conversational memory alone.

---

---

## Refactor staging status after contradiction sweep

Semantic route simulations D-017 through D-019 are complete.

Factual refactor register:
`REFACTOR_CHANGE_LOG_v4.md`

Current guarded staging script:
`apply_prompt_refactor_v3.py`

Important source-of-truth state:
- prompt-side accepted changes are STAGED only;
- actual GitHub prompt files remain unchanged;
- `0 APPLIED / 0 VERIFIED`;
- Memory-tool implementation items remain EXTERNAL_PENDING;
- pre-apply sweep found and staged additional C-041..C-044 rather than silently treating the first patch as complete.

Recovery rule:
after restart, read this ledger plus `REFACTOR_CHANGE_LOG_v4.md`; trust only APPLIED/VERIFIED statuses backed by actual changed-source rereads.

---

## Refactor implementation discovery — runtime agent configs

Pre-apply review found that standalone prompt files are not the complete runtime contract.

Live whitelisted `UnitTestGenerator.txt`:
- Pega Rule-AI-Agent for UnitTestGenerator;
- embeds the current old Generator system prompt in `pySystemPrompt`;
- `pyResponseStylePrompt` independently requires exactly one raw GeneratorRunReport JSON object;
- configured Knowledge tools include KnowledgeTool, GetMemory and WriteMemory;
- UpdateMemory is not configured;
- UnitTestValidator is configured as an agent tool.

Live whitelisted `JsonValidator_tool.txt`:
- despite filename, it is the Pega Rule-AI-Agent configuration for UnitTestValidator;
- embeds the current old Validator system prompt;
- its `pyResponseStylePrompt` independently requires exactly one raw JSON object;
- configured tools include GetMemory, JsonValidationTool and KnowledgeTool;
- Validator has no UpdateMemory and remains read-only.

Therefore prompt-only edits would be incomplete at runtime.

Guarded staging was extended to:
- replace both embedded system prompts from the exact transformed standalone prompts;
- replace Generator response style with GR-only line output;
- replace Validator response style with VR/VI-only line output;
- add UpdateMemory exactly once to Generator's `pzKnowledgeTools`;
- keep UpdateMemory absent from Validator;
- verify the decoded embedded prompts equal the final standalone prompts.

Exact live baseline blob SHAs:
- UnitTestGenerator.txt: `2126224898a361e203a37455e7266a4ea7871918`
- JsonValidator_tool.txt: `e137d40aca7a765b51b013275b32ebdd0bf051c4`

Latest guarded staging script:
`apply_prompt_refactor_v6.py`

Latest factual register:
`REFACTOR_CHANGE_LOG_v6.md`

Source status remains:
`0 APPLIED / 0 VERIFIED`.

---

## Refactor staging correction — D-020

Three factual implementation corrections were made during the final live-contract sweep.

### D-020.1 JsonValidationTool API names remain unchanged

The accepted architecture changes the candidate identity semantics to canonical `pyGUID`, but no user decision changed the JsonValidationTool interface itself.

Live Validator contract exposes:
`JsonValidationTool(CaseID, UUID, JsonSchema)`.

Final staged Validator mapping is therefore:

```text
JsonValidationTool(
  CaseID=<VAL.pxCaseID>,
  UUID=<UT.pyGUID>,
  JsonSchema=<schema selected from immutable RUTType>
)
```

This avoids hallucinating a tool API change from `CaseID/UUID` to `pxCaseID/pyGUID`.

GetMemory remains the separately accepted redesigned Memory interface:
`GetMemory(pxCaseID, Type, pyGUID)`.

### D-020.2 malformed Validator output leaves candidate Pending

If UnitTestGenerator cannot establish one valid attributable `VR` block for the exact candidate:
- do not infer HUMAN/SEMANTIC_REJECT/GENERATOR_REPAIR;
- do not call UpdateMemory with invented lifecycle metadata;
- candidate remains `pyStatusValue=Pending`, empty `pyRouterKey`;
- group result is `FAILED / VALIDATOR_RESPONSE_INVALID`;
- candidate is ineligible to downstream queries filtered by `pyStatusValue=Passed`.

### D-020.3 UpdateMemory exact result contract

Generic UpdateMemory now has an explicit batch result contract parallel to WriteMemory:
- outer exact `Success`, `ResultsJSON`, `ErrorCode`, `ErrorMessage`;
- on successful outer invocation, `ResultsJSON` parses as one `pxResults[]`;
- exactly one response row per requested `pyGroup+pyGUID`;
- row exact `pyGroup`, `pyGUID`, `Success`, `ErrorCode`, `ErrorMessage`;
- response order non-authoritative;
- rows independent;
- still exactly one update attempt, with no retry.

These are implementation clarifications, not new Scenario semantics.

---

## GitHub apply status

Attempt to create isolated branch:
`ruleiq-a2a-memory-refactor`

GitHub result:
HTTP 403 `Resource not accessible by integration`.

No branch, commit, prompt update, runtime-config update, or PR was created.

Repository factual state remains:
`0 APPLIED / 0 VERIFIED`.

Latest staged artifacts:
- `apply_prompt_refactor_v7.py`
- `verify_prompt_refactor_v3.py`
- `REFACTOR_CHANGE_LOG_v7.md`

Never infer repository completion from those staging artifacts.

---

## D-021 — Schema trace-description synchronization

Live standard and MultInpComb UTC schemas both contained an ambiguous `AssertionDecisionTrace` description telling values to encode pipe/newline without explicitly distinguishing data characters from structural delimiters.

Accepted MA-036 semantics require one contract everywhere:
- trace record fields are joined with literal structural `|`;
- records are joined with actual LF in the in-memory trace string;
- only characters inside field values are entity-encoded (`&amp;`, `&quot;`, `&#124;`, `&#13;`, `&#10;`);
- Validator splits records and literal structural pipes first, then decodes field values exactly once.

The guarded refactor now updates this description in both:
- `rule-test-unit-case_JsonSchema.txt`
- `rule-test-unit-case_multInpComb-JsonSchema.txt`

Baseline SHAs:
- standard schema: `58f62043066aa21c5a6a5a2690b77d9fafca1598`
- MultInpComb schema: `17ec9e3596961ba0706e3c235e8304a491cab66a`

Change-register ID: `C-054`.

### RISK-001 — zero-assertion NotTestable UI representation

Live standard schema requires:
- each UnitTestRules entry has `RuleCode`;
- `RuleCode.pyExpectedResults` has `minItems: 1`.

Therefore a genuinely NotTestable Scenario with zero valid assertions cannot be made into a schema-valid executable UnitTestCandidate merely to preserve a UI row.

No schema relaxation is being inferred or silently introduced.
Current conservative behavior:
- PartiallyTestable/NotTestable candidate Scenarios with at least one valid assertion can remain and Validator may return OK;
- a zero-assertion NotTestable group cannot produce a fake executable candidate.

Resolving this edge requires an explicit product/schema choice outside the already accepted transport/lifecycle refactor.

Latest staged artifacts:
- `apply_prompt_refactor_v8.py`
- `verify_prompt_refactor_v4.py`
- `REFACTOR_CHANGE_LOG_v8.md`

Repository remains `0 APPLIED / 0 VERIFIED` because GitHub writes are denied by the integration.


---

## Refactor staging test evidence

Latest guarded apply script: `apply_prompt_refactor_v8.py`.
Latest independent verifier: `verify_prompt_refactor_v4.py`.
Latest factual register: `REFACTOR_CHANGE_LOG_v9.md`.

Local static tests passed for:
- schema trace-description exact replacement;
- embedded system-prompt rich-text encode/decode round-trip;
- runtime agent config prompt replacement;
- exact one-row UpdateMemory tool insertion;
- response-style replacement.

Verifier compiles successfully.

No live source file was changed. GitHub branch creation remains denied with HTTP 403.
Repository factual status: `0 APPLIED / 0 VERIFIED`.

---

## D-022 — Apply phase started; repository permission remains the only execution blocker

User instructed: `start`.

Actions completed:
1. revalidated all seven live `main` blob SHAs;
2. confirmed every SHA still equals the guarded apply-script baseline;
3. retried isolated branch creation;
4. received the same HTTP 403 write-permission failure;
5. searched conversation/Library for exact seven baseline source files; no exact complete baseline set was available;
6. created a machine-readable 54-item change register;
7. created a ready-to-apply recovery bundle.

Current factual state:
- baseline drift: NONE;
- refactor scripts: READY;
- staged prompt/config/schema changes: 51;
- external Memory-tool changes: 3;
- repository source changes: 0;
- independently verified repository changes: 0.

The next legitimate state transition is only:
`STAGED -> APPLIED`
after the exact seven baseline bytes are available to the guarded script or GitHub write permission is restored.

Never claim APPLIED/VERIFIED before that event.


---

## D-023 — Exact uploaded baseline recovered; guarded refactor applied and verified locally

Date: 2026-09-10.

User supplied the complete source set as conversation uploads.

### Baseline recovery result

Five guarded target files matched the live reviewed Git blob baseline immediately.
The two runtime agent exports initially differed only because their outer XML regions used CRLF while the GitHub baseline uses LF:
- `UnitTestGenerator.txt`
- `JsonValidator_tool.txt`

Replacing CRLF with LF in isolated working copies produced the exact guarded Git blob SHAs:
- `UnitTestGenerator.txt` -> `2126224898a361e203a37455e7266a4ea7871918`
- `JsonValidator_tool.txt` -> `e137d40aca7a765b51b013275b32ebdd0bf051c4`

Therefore `BASELINE_EXACT_BYTES_READY = PASS (7/7)`.

### Apply-script guard correction

The first `apply_prompt_refactor_v8.py` execution aborted before any write because two post-transform verification needles were stale relative to the transformations already encoded in v8:
1. Main expected old wording `when at least one attributable Generator row is status=OK`, while the transformed Main intentionally contains the accepted independently-valid expected-group wording.
2. Validator expected lowercase `derive`, while transformed V6 begins sentence-case `Derive`.

All seven source blob SHAs were rechecked after the abort and remained pristine.

`apply_prompt_refactor_v9.py` changes only those two verification needles. No transformation payload changed.
`verify_prompt_refactor_v5.py` changes only the corresponding Validator capitalization needle.

### Local apply evidence

`apply_prompt_refactor_v9.py` result: `APPLIED_LOCAL`.

Post-transform Git blob SHAs:
- Main_Agent_Prompt.txt `e2588ad988d3ea1cc6103f8f70e280e1e75296b6`
- UnitTestGenerator_Prompt.txt `1a868248b58cecf86b057633fff7d42faf330ab1`
- Validator_Prompt.txt `c0f3e901073fe025ae23936799cbe6020604a30b`
- UnitTestGenerator.txt `dd526f05a65c72121b8ade46c6affcfc7bd9404d`
- JsonValidator_tool.txt `240faf8bf2f2faa606a3082a116cce2c2662756b`
- rule-test-unit-case_JsonSchema.txt `cba0217ef65276af6feb37cdac8fc1fb3e00bb0c`
- rule-test-unit-case_multInpComb-JsonSchema.txt `f7616295ba7d9d87e39548247e977a39b7efa2a6`

### Independent verification

`verify_prompt_refactor_v5.py` result: `overall=PASS`, `failed_count=0`.

A separate source-reread audit (`SOURCE_REREAD_AUDIT_v2.json`) then checked 45 independent architecture/absence/schema/runtime-config predicates and returned `PASS`, `failed_count=0`.
Both transformed UTC schema files parse as JSON.
Both transformed runtime agent XML files parse as XML.
The independent verifier confirms each runtime `pySystemPrompt` exactly equals its transformed standalone prompt, Generator tool inventory is `KnowledgeTool,GetMemory,WriteMemory,UpdateMemory`, and Validator remains `GetMemory,JsonValidationTool,KnowledgeTool`.

### Status distinction

Local supplied-source copy:
`51 prompt/config/schema C-items = VERIFIED_LOCAL`.

External Memory-tool implementation:
`C-027, C-028, C-029 = EXTERNAL_PENDING`.

GitHub repository:
`UNCHANGED BY THIS SESSION`.
No branch/commit/push/PR is claimed from this local apply.

Canonical continuation artifacts:
- `/mnt/data/SIMULATION_REVIEW_LEDGER_v47.md`
- `/mnt/data/REFACTOR_CHANGE_REGISTER_v2_LOCAL.json`
- `/mnt/data/LOCAL_APPLY_VERIFICATION_2026-09-10.json`
- `/mnt/data/RuleIQ_refactor_verified_package/`

## Checkpoint v48 — JsonExample/cardinality alignment

Status: **VERIFIED_LOCAL**

Approved and applied:
- C-055 standard schema `UnitTestRules.maxItems=1`.
- C-056 MultInpComb schema `UnitTestRules.maxItems=1`.
- C-057 standard example keeps only `TC_EntityMap_PageDP`.
- C-058 standard trace uses exact canonical ASSERT/SIM/OMIT grammar.
- C-059 missing standard SIM identity fields use explicitly synthetic deterministic reference-fixture facts.
- C-060 standard summary counts/support/narratives corrected.
- C-061 legacy five-unit MultInpComb example split into five one-candidate fixtures.
- C-062 simulated MultInpComb traces repaired to the canonical SIM field set and typed params.

Verification:
- example/cardinality verifier: PASS 84/84.
- independent architecture verifier: PASS, 0 failures.
- standard corrected example and all five split MultInpComb examples validate against their current schemas.
- old multi-unit examples are rejected by the new `maxItems=1` constraint.
- retained RuleCode payloads are unchanged.

External/runtime scope remains unchanged:
- C-027, C-028, C-029 = EXTERNAL_PENDING.
- GitHub repository = UNCHANGED_BY_THIS_SESSION.

Exact next action: implement or review the external Memory runtime contracts C-027..C-029, or publish this verified local source set when repository write access is available.

