#!/usr/bin/env python3
from pathlib import Path
import json, sys, re, hashlib
import jsonschema

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
V = Path(__file__).resolve().parent
checks = []

def check(name, ok, detail=""):
    checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": detail})

def canonical_hash(obj):
    b=json.dumps(obj, sort_keys=True, separators=(",",":"), ensure_ascii=False).encode()
    return hashlib.sha256(b).hexdigest()

def parse_trace(line):
    parts=line.split("|")
    tag=parts[0]
    keys=[]; d={}
    for part in parts[1:]:
        if "=" not in part:
            return tag, None, None
        k,v=part.split("=",1); keys.append(k); d[k]=v
    return tag,keys,d

STD_ASSERT=["id","kind","target","page","class","mode","comparator","value","support"]
DEC_ASSERT=["id","kind","row","target","page","class","mode","comparator","value","support"]
SIM=["id","rule","sig","shape","method","class","itemClass","params","target"]
OMIT=["id","target","reason"]
FORBIDDEN_NARRATIVE=["RuleCrawler","DefineData","D_Entity","D_GenericBooleanLookup","Code-Pega-List",
                     "RuleCode","pyExpectedResults","pySimulation","EntityKey=","LookupFlag=","Param."]

std_schema=json.loads((ROOT/"rule-test-unit-case_JsonSchema.txt").read_text())
mul_schema=json.loads((ROOT/"rule-test-unit-case_multInpComb-JsonSchema.txt").read_text())
check("standard schema UnitTestRules maxItems=1",
      std_schema["properties"]["UnitTestRules"].get("maxItems")==1)
check("MultInpComb schema UnitTestRules maxItems=1",
      mul_schema["properties"]["UnitTestRules"].get("maxItems")==1)

vp=(ROOT/"Validator_Prompt.txt").read_text()
check("Validator explicit sole UnitTestRules enforcement",
      "After parse, require exactly one `UnitTestRules` entry." in vp and
      "A different cardinality is `COUNT_MISMATCH/FIX_COUNTS`" in vp and
      "sole `UnitTestRules[0]`" in vp)

std=json.loads((ROOT/"rule-test-unit-case_JsonExample.txt").read_text())
std_old=json.loads((V/"SOURCE_rule-test-unit-case_JsonExample_PRE_CORRECTION.txt").read_text())
errs=list(jsonschema.Draft202012Validator(std_schema).iter_errors(std))
check("standard corrected example schema-valid", not errs, "; ".join(e.message for e in errs[:3]))
check("standard corrected example has one UnitTestRules", len(std["UnitTestRules"])==1)
old_errs=list(jsonschema.Draft202012Validator(std_schema).iter_errors(std_old))
check("old two-unit standard example rejected by new schema", bool(old_errs))
check("standard retained RuleCode unchanged",
      canonical_hash(std["UnitTestRules"][0]["RuleCode"]) ==
      canonical_hash(std_old["UnitTestRules"][0]["RuleCode"]))

u=std["UnitTestRules"][0]
s=u["Scenarios"][0]
es=s["EvidenceSummary"]
lines=es["AssertionDecisionTrace"].splitlines()
bad=[]
for n,line in enumerate(lines,1):
    tag,keys,d=parse_trace(line)
    if tag=="ASSERT":
        exp=DEC_ASSERT if d.get("kind") in ("DecisionInput","DecisionResult") else STD_ASSERT
    elif tag=="SIM": exp=SIM
    elif tag=="OMIT": exp=OMIT
    else: exp=None
    if exp is None or keys!=exp: bad.append((n,line))
check("standard canonical trace grammar", not bad, repr(bad[:2]))
aa=[x for x in lines if x.startswith("ASSERT|")]
oo=[x for x in lines if x.startswith("OMIT|")]
mm=[x for x in lines if x.startswith("SIM|")]
exact=0
for line in aa:
    _,_,d=parse_trace(line)
    if d["kind"]!="ResultCount" and d["support"]!="Structural" and d["value"]!="-":
        exact += 1
struct=len(aa)-exact
check("standard summary counts aligned",
      (es["AssertionCount"],es["ExactValueAssertionCount"],es["StructuralAssertionCount"],
       es["OmittedClaimCount"],es["SimulatedDependencyCount"]) ==
      (len(aa),exact,struct,len(oo),len(mm)),
      f"summary={(es['AssertionCount'],es['ExactValueAssertionCount'],es['StructuralAssertionCount'],es['OmittedClaimCount'],es['SimulatedDependencyCount'])}; calc={(len(aa),exact,struct,len(oo),len(mm))}")
check("standard SupportLevel uses omission precedence", es["SupportLevel"]=="OmittedClaimsPresent")
for field in ["Description","Narrative","InputsNarrative","SimulationsNarrative","AssertionsNarrative"]:
    val=s.get(field,"")
    check(f"standard narrative hygiene: {field}", not any(t in val for t in FORBIDDEN_NARRATIVE), val)

for line in mm:
    _,_,d=parse_trace(line)
    check("standard SIM itemClass field", d["itemClass"]=="-")
    check("standard SIM encoded DP_SIG delimiter", "&#124;" in d["sig"])
    raw=d["params"].replace("&quot;",'"').replace("&amp;","&")
    try: obj=json.loads(raw)
    except Exception: obj=None
    check("standard SIM typed params",
          obj=={"EntityKey":{"value":"ENT_A001","valueType":"string"}}, raw)

old_multi=json.loads((V/"SOURCE_rule-test-unit-case_multInpComb-JsonExample_PRE_CORRECTION.txt").read_text())
old_multi_errs=list(jsonschema.Draft202012Validator(mul_schema).iter_errors(old_multi))
check("old five-unit MultInpComb example rejected by new schema", bool(old_multi_errs))

multi_files=[ROOT/"rule-test-unit-case_multInpComb-JsonExample.txt"] + sorted(
    ROOT.glob("rule-test-unit-case_multInpComb-JsonExample_0[2-5]_*.txt"))
check("five one-unit MultInpComb examples exist", len(multi_files)==5,
      ",".join(p.name for p in multi_files))

for i,p in enumerate(multi_files):
    d=json.loads(p.read_text())
    errs=list(jsonschema.Draft202012Validator(mul_schema).iter_errors(d))
    check(f"{p.name}: schema-valid", not errs, "; ".join(e.message for e in errs[:3]))
    check(f"{p.name}: one UnitTestRules", len(d["UnitTestRules"])==1)
    if len(d["UnitTestRules"])!=1: continue
    u=d["UnitTestRules"][0]
    old_rc = old_multi["UnitTestRules"][i]["RuleCode"]
    if u["Name"] == "TC_CanOpenWorkspace_PermissionTrue":
        current_rc = json.loads(json.dumps(u["RuleCode"]))
        expected_rc = json.loads(json.dumps(old_rc))
        # Approved MC-004 correction: AccessPage is the intended primary-page P&C entry.
        expected_rc["pyPagesAndClasses"] = [{
            "pyPagesAndClassesPage": "AccessPage",
            "pyPagesAndClassesClass": "Data-Security-Access"
        }]
        check(f"{p.name}: RuleCode drift limited to approved MC-004 P&C correction",
              canonical_hash(current_rc)==canonical_hash(expected_rc))
    else:
        check(f"{p.name}: retained RuleCode unchanged",
              canonical_hash(u["RuleCode"])==canonical_hash(old_rc))
    rows=u["RuleCode"]["pyExpectedResults"][0]["pyExpectedResults"]
    check(f"{p.name}: Scenario/Decision-row cardinality",
          len(u["Scenarios"])==len(rows), f"{len(u['Scenarios'])}/{len(rows)}")
    for si,s in enumerate(u["Scenarios"]):
        tr=s["EvidenceSummary"]["AssertionDecisionTrace"]
        bad=[]
        for n,line in enumerate(tr.splitlines(),1):
            tag,keys,fd=parse_trace(line)
            if tag=="ASSERT":
                exp=DEC_ASSERT if fd.get("kind") in ("DecisionInput","DecisionResult") else STD_ASSERT
            elif tag=="SIM": exp=SIM
            elif tag=="OMIT": exp=OMIT
            else: exp=None
            if exp is None or keys!=exp: bad.append((n,line))
        check(f"{p.name} scenario {si}: canonical trace grammar", not bad, repr(bad[:1]))
        nv=" ".join(s.get(k,"") for k in
                    ["Description","Narrative","InputsNarrative","SimulationsNarrative","AssertionsNarrative"])
        check(f"{p.name} scenario {si}: narrative hygiene",
              not any(t in nv for t in FORBIDDEN_NARRATIVE), nv)
        for line in [x for x in tr.splitlines() if x.startswith("SIM|")]:
            _,_,sd=parse_trace(line)
            check(f"{p.name} scenario {si}: SIM itemClass", sd["itemClass"]=="-")
            check(f"{p.name} scenario {si}: SIM encoded DP_SIG delimiter", "&#124;" in sd["sig"])
            raw=sd["params"].replace("&quot;",'"').replace("&amp;","&")
            try: obj=json.loads(raw)
            except Exception: obj=None
            ok=(isinstance(obj,dict) and "LookupFlag" in obj and
                obj["LookupFlag"].get("valueType")=="boolean" and
                isinstance(obj["LookupFlag"].get("value"),bool))
            check(f"{p.name} scenario {si}: SIM typed params", ok, raw)

failed=[c for c in checks if c["status"]=="FAIL"]
result={"status":"PASS" if not failed else "FAIL",
        "checks_total":len(checks),
        "checks_passed":len(checks)-len(failed),
        "checks_failed":len(failed),
        "checks":checks}
print(json.dumps(result, indent=2, ensure_ascii=False))
sys.exit(1 if failed else 0)
