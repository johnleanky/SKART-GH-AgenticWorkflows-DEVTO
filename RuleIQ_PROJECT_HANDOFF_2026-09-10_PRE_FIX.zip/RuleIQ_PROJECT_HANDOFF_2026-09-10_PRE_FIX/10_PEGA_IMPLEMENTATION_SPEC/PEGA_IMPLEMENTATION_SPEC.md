# RuleIQ — Pega Implementation Specification After Refactoring

**Version:** 1.0  
**Contract baseline:** RuleIQ v6; ScenarioGroup wire revision 1.4  
**Language:** English  
**Purpose:** Specify the Pega work needed to support the refactored prompts and contracts.  
**Ownership:** The Pega team implements and configures external components. This workspace maintains prompts, contracts, specifications and local verification only.

## 1. Required outcome

The existing entry point must run this chain:

```text
Case → Scenario Author → persisted ScenarioGroups
     → UnitTestGenerator → persisted UnitTestCandidates
     → UnitTestValidator → direct validation results
     → Generator updates candidate lifecycle → final per-group results
     → Author returns the existing two-field case response
```

Scenario Author owns test semantics. Generator projects those semantics into candidate JSON.
Validator checks the exact persisted candidate. Memory stores immutable payloads and separately
updates permitted lifecycle metadata. The agents do not pass large payloads to each other.

One physical `pyGroup` produces one candidate version containing exactly one `UnitTestRules`
entry. A When candidate may contain several executable combination rows. Different physical
groups remain independently addressable and can succeed or fail separately.

**Minimum Pega work:** adapt WriteMemory and GetMemory to the current contract; provide
UpdateMemory; configure Generator and Validator as callable agents using one `question`
parameter; make JsonValidationTool validate the exact candidate GUID; publish the required
KnowledgeTool content; and make any existing candidate consumer respect informational outcomes.
An existing component that already satisfies a requirement does not need to be rewritten.

## 2. Work breakdown

| ID | Component | Required work | Completion evidence |
|---|---|---|---|
| PI-01 | Scenario Author configuration | Apply Main_Agent_Prompt.txt and expose only its permitted tools. | Correct tool bindings and external response shape. |
| PI-02 | UnitTestGenerator | Configure its prompt, single-string A2A input, tools and GR response style. | GEN/SG input reaches Generator unchanged; source reads use supplied GUIDs. |
| PI-03 | UnitTestValidator | Configure its prompt, single-string A2A input, read-only tools and VR/VI response style. | VAL/UT input reaches Validator unchanged; all attributable siblings receive results. |
| PI-04 | WriteMemory | Implement the shared batch write interface and immutable version creation. | Independent row outcomes, new GUIDs, exact payloads, Pending initialization. |
| PI-05 | GetMemory | Read by exact case/type/GUID and return identity with the payload. | No latest/group fallback; exact metadata and payload round trip. |
| PI-06 | UpdateMemory | Implement permitted shallow root metadata patches on existing records. | Protected fields unchanged; independent row outcomes; confirmed lifecycle writes. |
| PI-07 | JsonValidationTool | Resolve the candidate by the exact supplied GUID before schema validation. | Different candidate versions cannot be substituted; valid/invalid/tool-error results differ. |
| PI-08 | KnowledgeTool | Publish exact semantic and structural composite keys, schemas and templates. | All required keys return usable content; executable target ruleset carriers are supplied. |
| PI-09 | GetCaseData | Preserve the existing interface and provide complete, consistent case/RUT identity. | Identity gate succeeds for correct data and fails before further work for bad data. |
| PI-10 | RuleCrawler boundary | Confirm the existing wrapper supplies the facts required by Main. Keep its implementation external. | Request/response mapping is documented; key resolution is not mistaken for RuleJSON. |
| PI-11 | Existing candidate consumer | Separate validated informational results from executable unit-test candidates. | NotTestable without RuleCode is visible as information and is not imported as a runnable test. |
| PI-12 | Version rollout and acceptance | Use a consistent v6 prompt/content set and perform the external acceptance cases. | Version inventory, actual request/response traces and independent stored-record evidence. |

## 3. Agent configuration

### 3.1 Files and tool bindings

Use the readable prompts as the editable authority. The supplied exports provide the
Generator/Validator embedded prompts and configuration references. They are not a claim that
a complete, target-ready Pega deployment package has been produced.

| Agent | Prompt | Permitted tools |
|---|---|---|
| Scenario Author | Main_Agent_Prompt.txt | GetCaseData, semantic KnowledgeTool, RuleCrawler, WriteMemory for ScenarioGroup, UnitTestGenerator |
| UnitTestGenerator | UnitTestGenerator_Prompt.txt | GetMemory for ScenarioGroup, structural KnowledgeTool, WriteMemory for UnitTestCandidate, UpdateMemory for candidate lifecycle, UnitTestValidator |
| UnitTestValidator | Validator_Prompt.txt | JsonValidationTool, GetMemory for UnitTestCandidate, structural KnowledgeTool |

Use `UnitTestGenerator.txt` and `JsonValidator_tool.txt` to check embedded prompt parity and
tool configuration. The v6 source set has no updated Main_Agent export; apply the Main prompt
to the existing Author configuration and verify its tool bindings separately.

Do not expose candidate-writing or validation tools to Author. Validator must not be able to
write/update Memory, invoke Generator, or read ScenarioGroups. Generator must not call
GetCaseData, RuleCrawler or JsonValidationTool directly.

Retain legacy tools for unrelated consumers if necessary, but do not bind their old interfaces
into this chain. In particular, do not route current calls through old scalar
`WriteMemory(CaseID,Type,Payload)` or combined candidate/report transports.

### 3.2 Agent-to-agent interfaces

Both callable agents receive exactly one scalar string argument named `question`.
Do not add CaseID, RUTType, GUID lists or payload arguments to their callable interface.

Author → Generator:

```text
GEN|pxCaseID=UT-CASE-001|RUTType=Rule-Obj-Model
SG|pyGroup=G001|pyGUID=sg-guid-001
SG|pyGroup=G002|pyGUID=sg-guid-002
```

Generator → Validator:

```text
VAL|pxCaseID=UT-CASE-001|RUTType=Rule-Obj-Model
UT|pyGroup=G001|pyGUID=candidate-guid-001
UT|pyGroup=G002|pyGUID=candidate-guid-002
```

These are illustrative addresses. Runtime GUIDs come only from successful Memory writes.
Forward the exact string and preserve record boundaries. The A2A field encoding is:

| Value character/state | Encoded field content |
|---|---|
| Backslash | `\\` |
| Literal pipe | `\|` |
| CR / LF / TAB | `\r` / `\n` / `\t` |
| Empty string | `\0` |
| Exact literal hyphen | `\-` |

Structural pipes and record LF remain literal. Split records/fields before decoding field values
once. Unescaped `-` means absent only where the protocol permits it. Do not apply this A2A
encoding to Memory payload content as an additional transformation.

Generator returns GR lines, not JSON:

```text
GR|pyGroup=G001|pyGUID=candidate-guid-001|status=OK|reason=-
GR|pyGroup=G002|pyGUID=-|status=FAILED|reason=LIFECYCLE_UPDATE_FAILED
```

Validator returns VR blocks followed by their optional VI records:

```text
VR|pyGroup=G001|pyGUID=candidate-guid-001|route=OK|blocking=0|warnings=0
```

Its blocking routes are `GENERATOR_REPAIR`, `SEMANTIC_REJECT` and `HUMAN`. Full VI grammar
and allowed code/action pairs remain in Validator V2 and its appendix; do not add a new
JSON report wrapper or persisted Validator result record.

### 3.3 External Author response

Preserve the existing response object with exactly these two fields:

```json
{"AIAgentResponseStatus":"Completed","AIAgentErrorResponseMessage":""}
```

or:

```json
{"AIAgentResponseStatus":"Failed","AIAgentErrorResponseMessage":"Unit test generation failed."}
```

Completed means at least one attributable group returned a valid GR OK. It does not mean
every group succeeded or an executable Pega unit test ran. Failure text remains one sentence,
at most 20 words and 180 characters. No internal payloads, GUIDs or reports are exposed here.

## 4. Persistent Memory model

Provide these observable canonical fields. Actual Pega class names, storage mapping and
rule categories are implementation choices in the existing application, not prescribed here.

| Field | Contract |
|---|---|
| pyGUID | Nonempty opaque address generated by Memory; immutable and never reused for another version. |
| pxCaseID | Exact GetCaseData.pyID; immutable. |
| Type | Exact ScenarioGroup or UnitTestCandidate; immutable. |
| pyGroup | Physical group lineage/correlation; immutable; never a lookup replacement for GUID. |
| pyPayload | Exact opaque nonempty text; immutable for the current chain. |
| pyStatusValue | UnitTestCandidate lifecycle: initialized Pending; valid transitions use Passed or Failed. |
| pyRouterKey | UnitTestCandidate lifecycle: initially empty; subsequently the valid Validator route. |

Do not apply candidate lifecycle defaults to ScenarioGroup unless a separate existing
application contract requires them. No new Memory types for Validator reports are required.

Each write creates a new record. Two versions may have the same case/type/group but must
have different GUIDs. Repair must not overwrite the previous candidate. Reads must work
across separate tool/agent requests, not depend solely on one requestor's clipboard.

The Memory layer stores payload text without interpreting the ScenarioGroup ledger or
reserializing candidate JSON. Preserve whitespace, terminal LF, escapes and Unicode after
the single transport JSON decode. Candidate schema validation belongs to JsonValidationTool.

## 5. WriteMemory — PI-04 / C-027

### 5.1 Exact arguments

```text
WriteMemory(pxCaseID: string, Type: string, RequestsJSON: string)
```

RequestsJSON is JSON text. Its decoded structure is exactly:

```json
{
  "pxResults": [
    {"pyGroup":"G001","pyPayload":"<exact complete payload for G001>"},
    {"pyGroup":"G002","pyPayload":"<exact complete payload for G002>"}
  ]
}
```

The caller sends a nonempty batch, with unique nonempty group IDs and exactly pyGroup/pyPayload
per row. Use Type=ScenarioGroup for Author and Type=UnitTestCandidate for Generator.
Caller-supplied GUIDs or lifecycle defaults are not part of this request.

### 5.2 Exact response

Return four outer fields: Boolean Success, and string ResultsJSON, ErrorCode, ErrorMessage.
On outer success, errors are empty and ResultsJSON is JSON text encoding exactly a pxResults
array. The following shows the **decoded ResultsJSON**, not the outer response:

```json
{
  "pxResults": [
    {"pyGroup":"G002","Success":false,"pyGUID":"","ErrorCode":"WRITE_FAILED","ErrorMessage":"Record could not be stored."},
    {"pyGroup":"G001","Success":true,"pyGUID":"candidate-guid-001","ErrorCode":"","ErrorMessage":""}
  ]
}
```

Return one row per requested group; response order is non-authoritative. Successful rows have
a new nonempty GUID and empty errors. Failed rows have an empty GUID, a nonempty diagnostic,
and ErrorCode in `INVALID_INPUT`, `UNSUPPORTED_TYPE`, `WRITE_FAILED`.

Outer Success=true describes a usable batch result, including partial success. A failed row
must not roll back a successful sibling. An outer failure must not be disguised as a successful
empty array. The caller does not retry a write or infer success from an uncertain response.

For each successfully stored UnitTestCandidate, initialize Pending and empty pyRouterKey
before reporting success. A success response must refer to the actual committed record.

## 6. GetMemory — PI-05

```text
GetMemory(pxCaseID: string, Type: string, pyGUID: string)
```

Return the canonical response:

```json
{
  "Success":true,
  "pxCaseID":"UT-CASE-001",
  "Type":"UnitTestCandidate",
  "pyGroup":"G001",
  "pyGUID":"candidate-guid-001",
  "pyPayload":"<exact stored payload>",
  "ErrorCode":"",
  "ErrorMessage":""
}
```

Success is a Boolean; the remaining fields are strings. On success, all identity fields and
payload match the addressed record, and errors are empty. Enforce case/type ownership before
returning content. Missing GUID, wrong case/type and read failure must not trigger latest-record
or group-based fallback. Diagnostics cannot be substituted for payload.

Generator reads only supplied ScenarioGroup addresses. Validator reads only supplied candidate
addresses, after that exact candidate passes its schema call. Both compare returned pyGroup
with the independently supplied group reference.

Lifecycle fields are deliberately outside this response. For implementation acceptance, supply
a separate read-only observer or server trace showing the canonical stored record. Do not
silently add lifecycle fields to GetMemory just to support the acceptance harness.

## 7. UpdateMemory — PI-06 / C-028 / C-029

```text
UpdateMemory(pxCaseID: string, Type: string, RequestsJSON: string)
```

Current Generator uses Type=UnitTestCandidate. Decoded RequestsJSON:

```json
{
  "pxResults": [
    {"pyGroup":"G001","pyGUID":"candidate-guid-001","pyUpdates":{"pyStatusValue":"Passed","pyRouterKey":"OK"}}
  ]
}
```

For each row:

1. Resolve the exact existing GUID.
2. Verify pxCaseID, Type, pyGroup and pyGUID against stored identity.
3. Validate the complete nonempty pyUpdates object before applying it.
4. Under current Generator permissions, allow only string pyStatusValue and pyRouterKey.
5. Shallow-replace explicitly named allowed root fields. Preserve omitted fields.
6. Persist the change on that same record and report the independent row outcome.

Protect pyGUID, pxCaseID, Type, pyGroup and pyPayload. Reject path expressions, deep-merge
instructions, implicit deletion and unauthorized fields. A rejected row must not leave a partial
allowed-field patch. A successful sibling must not be rolled back. Future generic metadata
permissions need a separate explicit caller contract.

The outer response uses the same four fields as WriteMemory. On outer success, decoded
ResultsJSON has one row per requested `(pyGroup,pyGUID)`:

```json
{"pxResults":[{"pyGroup":"G001","pyGUID":"candidate-guid-001","Success":true,"ErrorCode":"","ErrorMessage":""}]}
```

Both successful and failed rows echo the exact group and GUID. Failed rows have nonempty
stable diagnostics; `UPDATE_FAILED` is the established failure example. Unlike WriteMemory
row errors, the current prompts do not define a complete closed GetMemory/UpdateMemory error
catalog. Document the service's stable codes during implementation; do not make the agents
infer semantic repairs or retry decisions from diagnostic wording.

### 7.1 Required lifecycle transitions

| Valid Validator route | Stored status/router | Generator continuation after confirmed update |
|---|---|---|
| OK | Passed / OK | Return eligible candidate GUID in GR OK. |
| GENERATOR_REPAIR | Failed / GENERATOR_REPAIR | Write a new immutable candidate if repair budget remains. |
| SEMANTIC_REJECT | Failed / SEMANTIC_REJECT | Stop that group; no semantic rewrite. |
| HUMAN | Failed / HUMAN | Stop that group for human review. |

Each lifecycle UpdateMemory call has one attempt. Explicit failure, malformed response and
uncertain result all terminate the affected group as LIFECYCLE_UPDATE_FAILED, without retry
or further repair. If a response is lost after commit, the stored record may already have changed;
the caller still must not claim GR OK or retry without a confirmed result.

A malformed/unattributable Validator report has no route: **zero UpdateMemory calls**,
Pending candidate, and VALIDATOR_RESPONSE_INVALID. Do not manufacture Failed/HUMAN.

Repair budget is per group: one initial validation plus at most two repaired candidate versions,
at most three Validator attempts. Each new version starts Pending with a new GUID.

## 8. JsonValidationTool — PI-07

Retain these exact existing argument names:

```text
JsonValidationTool(CaseID: string, UUID: string, JsonSchema: string)
```

Map CaseID from VAL.pxCaseID and UUID from the current UT.pyGUID. Do not rename these two
parameters to the Memory API names, add a Memory Type parameter, accept candidate JSON
through A2A, or resolve the latest candidate for a case.

Internally resolve that exact UnitTestCandidate with its case constraint and validate its stored
pyPayload against the selected current schema. Schema family depends only on the original
VAL.RUTType:

| Original RUT type | JsonSchema key |
|---|---|
| Rule-Obj-When | Rule-Test-Unit-Case_MultInpComb-JsonSchema |
| Every other supported type | Rule-Test-Unit-Case_JsonSchema |

Required result fields are Boolean Success and IsValid, and string ValidationMessage,
ErrorCode, ErrorMessage. Distinguish:

- Success=true, IsValid=true: Validator may read the same candidate GUID.
- Success=true, IsValid=false: schema-invalid candidate; no subsequent GetMemory for that UT.
- Tool/read/input failure or malformed result: tool error; no subsequent GetMemory for that UT.

Validation must be read-only. Do not fix JSON, create RuleCode, change candidate status or
rewrite payload. The agent retains its existing diagnostic thresholds and repair routing.

## 9. KnowledgeTool and template content — PI-08

Keep `KnowledgeTool(KnowledgeAreas)` with a comma-separated string of composite keys.
Return pxResults rows with exact Area and nonempty Description strings:

```json
{"pxResults":[{"Area":"Rule-Obj-Model_KnowledgeArea","Description":"<current knowledge content>"}]}
```

Publish the semantic KnowledgeAreas from the v6 `sources` files for Model, When, Property,
Decision Table, Data Pages and RUF. Author requests semantic content only.

Publish these structural keys with exact spelling:

| Family | KnowledgeArea | Schema | Example/template |
|---|---|---|---|
| Standard | Rule-Test-Unit-Case_KnowledgeArea | Rule-Test-Unit-Case_JsonSchema | Rule-Test-Unit-Case_JsonExample |
| When | Rule-Test-Unit-Case_MultInpComb-KnowledgeArea | Rule-Test-Unit-Case_MultInpComb-JsonSchema | Rule-Test-Unit-Case_MultInpComb-JsonExample |

Use the two current schema files and their matching primary example files. The additional
MultInpComb example files are reference fixtures; they do not introduce new mandatory tool keys.
The two structural UTC KnowledgeArea contents are an existing external prerequisite, not
included as new implementation files in the v6 package.

For executable candidates, the selected example/template must carry the application's
**already selected** pyRuleSet and pyRuleSetVersion. Preserve the existing target selection
mechanism. Do not use illustrative local example values as an operational target, infer the
target from the RUT ruleset, or add TargetRuleSet parameters to the agents.

An informational-only Generator group requires its schema key only. It must not depend on
UTC KnowledgeArea, JsonExample or target-ruleset metadata. For mixed ready modes, Generator
requests the union once; a missing key fails only groups that need that key. Return keys by
identity rather than position. Do not silently substitute another family's schema.

## 10. Case identity and RuleCrawler compatibility — PI-09 / PI-10

### 10.1 GetCaseData

Preserve its existing invocation interface. Provide nonempty pyID, TestedRuleKey and RUT
RuleJSON containing pzInsKey, pxObjClass, pyClassName and pyRuleName. The first three
whitespace-separated components of TestedRuleKey and pzInsKey must agree with the uppercase
RUT type/class/name triplet. Keep the original strings; Author does not repair identity.
No KnowledgeTool, RuleCrawler or Memory call is permitted after an invalid initial identity.

### 10.2 RuleCrawler

This refactoring does not require rewriting the external crawler or moving its implementation
into the prompt repository. Verify the existing wrapper boundary against Main and the RUF
KnowledgeArea. Preserve holder identity, exact requested references, resolved identity and
retrievable rule content without fabricating missing facts.

The packaged Rule_Crawler_tool.txt is the exact `ResolveCrawlerBatch(String,String)` export.
Its Java code works on clipboard pages: input InterestedRules with pyItemRuleId and
pxRuleReferences; output InterestedRules with copied supported references and resolvedKey
when available. **It does not itself return the complete LLM-visible RuleJSON contract.**
Its pyDescription mentions SuggestedReferences, but its executable Java writes InterestedRules;
the wrapper mapping must be confirmed against actual behavior, not inferred from that label.

Check the existing wrapper for:

- One physical request per exact canonical key in a wave, with each occurrence's context preserved.
- Distinction between same-name rules in different classes; no class borrowed from another occurrence.
- Exact RUF source projection: pxObjClass, pxRuleFamilyName, pxRuleObjClass, pyRuleName;
  no synthetic RUF pxRuleClassName. RUF family uses Library!Function and canonical key RUF@@family.
- Resolved key without fetched RuleJSON treated as KEYONLY, not a closed executable dependency.
- Explicit handling of missing/filtered/unsupported results; a silently dropped reference is not success.
- Preservation of raw Model fields pyPropertiesName, pyParametersParamType and STRING;
  raw Data Page scope thread; and other evidence needed by the current KnowledgeAreas.
- Data Page simulation boundaries enforced by Author: loader-only references do not force
  recursive discovery, while caller/metadata/parameter obligations remain.

Main's planning limits remain 120 crawler calls and 260 total requested references per task.
These are caller planning limits, not a new server batching implementation requirement.
Exact LLM-visible RuleCrawler scalar parameter names/envelope are not established by the
lower-level export alone. Record the existing wrapper mapping before changing its configuration.

## 11. Informational outcomes and downstream consumers — PI-11

The two current schemas enforce a single UnitTestRules entry with one of two modes:

| Mode | Candidate content | Meaning of Passed / OK |
|---|---|---|
| Executable | RuleCode present; FullyTestable or PartiallyTestable scenarios. | Candidate validation succeeded; not proof that a Pega unit test was executed. |
| Informational NotTestable | RuleCode absent; zero ASSERT/SIM; explicit OMIT and gaps; Low confidence and Blocked closure. | The non-executable outcome is represented consistently. |

Keep informational records visible with their BlockingGaps. Do not create dummy RuleCode,
empty harness tests, invented simulations or test assertions for them. Validator completes
their visible consistency checks without UTC Knowledge and continues remaining batch siblings.

If an existing process creates Pega unit-test rules from Memory, it must require the selected
record's confirmed Passed/OK lifecycle **and** an executable candidate with RuleCode. It must
not create a runnable test merely because pyStatusValue=Passed. Preserve candidate Testability
inside Scenarios; do not duplicate it in GR or invent Memory metadata fields for it.

## 12. Version alignment and rollout — PI-12

Keep Main, Generator, Validator, both embedded prompts, KnowledgeArea content, schemas and
template contract versions aligned. Verify the actual source hashes against SOURCE_MANIFEST_v6.json.
Adapt target-environment rule metadata through the existing deployment process; do not blindly
copy source-system ownership, identifiers or environment settings from readable exports.

SG.version intentionally remains **1.4** under accepted D-003, even though v6 changes canonical
DP_SIG and informational grouping keys. A version value of 1.4 alone is not sufficient to prove
compatibility. Track the v6 source manifest/release revision during configuration.

Do not normalize old persisted ScenarioGroups or candidate payloads in place. Preserve them
as history; use newly generated groups/candidates under the consistent v6 configuration.
Do not attach a v6 Generator to an older incompatible source payload and infer an upgrade.

Recommended implementation order:

1. Establish exact Memory write/read/update interfaces and persistent canonical fields.
2. Bind JsonValidationTool to exact candidate GUIDs and publish current schema content.
3. Configure KnowledgeTool keys and existing target ruleset/version template carriers.
4. Configure Generator and Validator question-based A2A interfaces and restricted tool sets.
5. Configure Author with the current prompt and verify GetCaseData/crawler boundary compatibility.
6. Adjust an existing candidate-to-unit-test consumer for informational outcomes.
7. Execute the acceptance cases below in a dedicated test case and retain actual evidence.

## 13. Acceptance criteria

Use the 24 detailed Memory cases in ACCEPTANCE_CASES.json from the companion contract package.
They cover 20 external-service cases and four caller failure/no-retry cases. Additionally:

| ID | Scenario | Required result |
|---|---|---|
| AT-01 | Standard executable group | Exact SG read, one candidate/version, schema/read validation, confirmed Passed/OK and GR OK. |
| AT-02 | When rows with equal simulation key and execution class | One physical candidate, one Decision block, multiple aligned rows. |
| AT-03 | When scenarios with different simulation keys | Separate physical candidates and independent outcomes. |
| AT-04 | Informational NotTestable without a usable required simulation | No RuleCode/SIM/assertions, explicit gaps, Low/Blocked; no fabricated mock. |
| AT-05 | Informational UT followed by executable UT | Both UT results emitted; informational completion does not terminate the batch. |
| AT-06 | Informational candidate with High confidence or Closed closure | Current schema rejects it. |
| AT-07 | Missing executable example key with valid informational schema | Only the dependent executable group fails knowledge acquisition. |
| AT-08 | Malformed/unattributable Validator result | Candidate remains Pending; zero lifecycle updates; VALIDATOR_RESPONSE_INVALID. |
| AT-09 | Failed, malformed or uncertain UpdateMemory result | One caller attempt; no retry/repair; no GR OK for that group. |
| AT-10 | Two repairs followed by a valid third candidate | At most three Validator attempts; three distinct immutable candidate GUIDs; old versions retained. |
| AT-11 | One group succeeds and another fails | Successful group remains eligible; Author returns Completed. |
| AT-12 | No group succeeds | Author returns the bounded two-field Failed response. |
| AT-13 | Wrong case, type, group or candidate version | No unintended read/update/validation or fallback to another record. |
| AT-14 | Repeated dependency occurrences and same-name/different-class rules | Deduplication does not lose occurrence evidence or merge different keys. |
| AT-15 | Existing candidate consumer receives Passed/OK informational result | Information is retained; no runnable Pega unit-test rule is created from absent RuleCode. |

For runtime acceptance, retain the target version inventory, exact requests/responses,
complete caller call sequence, failure-injection method and independent canonical before/after
record snapshots. Use a fresh request/requestor when verifying durability. No credentials are
required in the evidence package.

The existing 598 local v6 checks and 90 Memory contract checks validate source contracts,
schemas, fixtures and assertion logic. They do not establish external implementation readiness.
C-027/C-028/C-029 remain external until actual implementation acceptance is complete.

## 14. Source package and handover

In the project workspace:

- `07_V6_WORK/RuleIQ_v6/sources/` — current prompt, schema, knowledge and export references.
- `07_V6_WORK/RuleIQ_v6/SOURCE_MANIFEST_v6.json` — pinned source identities.
- `09_MEMORY_RUNTIME/MEMORY_TOOL_CONTRACT_v1.md` — detailed Memory boundary contract.
- `09_MEMORY_RUNTIME/ACCEPTANCE_CASES.json` — external acceptance specification.
- `09_MEMORY_RUNTIME/memory_contract.py` — read-only assertions for captured evidence.
- `09_MEMORY_RUNTIME/SOURCE_AUTHORITY.json` — precise current prompt anchors.

Pega implementation handover should identify the rules/configuration used for PI-01–PI-12,
document the actual wrapper mappings and stable service error codes, and attach acceptance
evidence. Storage class names, ruleset versions, deployment tooling and environment settings
must come from the target application; none is invented by this specification.
