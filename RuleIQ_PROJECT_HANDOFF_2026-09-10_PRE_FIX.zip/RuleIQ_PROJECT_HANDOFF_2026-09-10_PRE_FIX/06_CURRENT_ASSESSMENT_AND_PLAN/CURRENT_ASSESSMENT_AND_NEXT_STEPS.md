# RuleIQ — initial state assessment and next-step plan

Assessment date: 2026-09-10. This is the historical assessment made before the v6
corrections. For current status, see ../CURRENT_V6_START_HERE.md. This English
translation preserves the assessment's original findings and implementation plan.

Scope: local snapshot, file integrity, rerun of existing checks, selected source
cross-references and actual JSON Schema mutation probes. Neither a running Pega
system nor the current GitHub contents was checked during this initial assessment.

The assessed state was PRE_FIX / REOPENED / CORRECTIONS_REQUIRED. Work was to resume
from the v5 baseline and fix the full-project audit. FINAL_VERIFIED_LOCAL in the
old ZIP name described an earlier, narrower verification result. The latest v52
audit left 29 findings open: two critical, 21 high and six medium.

The directory contains prompts, readable Pega exports, KnowledgeAreas, schemas,
examples and verification scripts. It is not a Git repository; local branch/history
and divergence from remote could not be established here. The handoff's statement
that GitHub was unchanged was historical package evidence, not a fresh remote check.

## Verified at this assessment checkpoint

| Check | Fresh result | Meaning |
|---|---|---|
| Snapshot SHA-256 and file sizes | 90/90 match | All original handoff-manifest files are preserved. |
| v5 sources | 19/19 match their source manifest | FP-001–FP-029 are not yet applied to this baseline. |
| ZIP | CRC passes; 72/72 entries match extraction | Archive and extracted v5 agree. |
| Architecture, verify_prompt_refactor_v6.py | 86/86 PASS | Covered textual contracts, tools and embedded prompts agree within the suite. |
| RISK-001, verify_risk001_v3.py | 49/49 PASS | Existing positive/negative fixtures and JSON/XML checks pass. |
| Examples, verify_example_alignment_v3.py | 84/84 PASS | Covered examples and cardinality rules agree. |
| MultInpComb, verify_multinpcomb_deep_v3.py | 212/212 PASS | Covered rows, classes, traces and counters agree. |
| FP-010 mutation replay | Defect reproduced in both schemas | Informational candidates incorrectly accept High and/or Closed with nonempty BlockingGaps. |
| Complete source inventory | Incomplete | Rule_Crawler_tool.txt is missing. |

Existing suites returned 431/431 PASS. These are regression checks, not execution
of Main → Generator → Validator in Pega. Many prompt checks look for present/absent
text and can miss conflicting clauses elsewhere.

ASSESSMENT_EVIDENCE_2026-09-10.json records commands, interpreter/dependency versions,
hashes, suite results and schema mutation evidence. Full reports are stored beside it.
The assessment used bundled Python 3.12 and jsonschema 4.25.1 with dependencies in
/tmp/ruleiq-assessment-deps-2026-09-10; jsonschema was initially absent from the
inspected Python environments.

## Principal findings at that checkpoint

1. FP-005, critical: Main requires RuleCode and successful Data Page simulation audit
   where informational NotTestable must have neither RuleCode nor SIM. A terminal
   unresolved required Data Page therefore has a contradictory completion path.
   Baseline Main storage gates: sources/Main_Agent_Prompt.txt, line 1004.
2. FP-025, critical: DWL uses canonical When/DTable/Model/Prop and other kinds, while
   ScenarioGroup DEP in Main and Generator still uses RUF/DP/HELPER/DT. A real
   dependency cannot be represented without changing its meaning. Baseline anchors:
   Main line 1883; Generator line 392.
3. FP-010, high: real schema validation accepts incorrect informational confidence
   and closure. New regression cases must reject these mutations.
4. Other findings concern early identity validation, cross-layer NotTestable rules,
   confirmed export fields, branch/producer coverage, provenance and serialization.
5. The crawler is missing. The recovery reference records Git blob
   5bf29ef62534f74275c3d04ae03c9c9c3945e238. Recovery requires exact byte/blob identity;
   external availability had not yet been established at this checkpoint.

Baseline source paths are under ../01_CURRENT_V5_BASELINE/EXTRACTED_V5/RuleIQ_risk001_v5_work/.
The crawler recovery reference is ../04_EXTERNAL_REFERENCES/RULE_CRAWLER_TOOL_FETCH_REFERENCE.json.

## Handoff discrepancies

The saved 28-case matrix contains three PASS, two PASS_PROMPT_ONLY, 17 FAIL-prefixed
results, five AMBIGUOUS and one OPEN_DECISION. These are prior contract-review results;
the full matrix was not rerun during this initial assessment. UNKNOWN:28 in the
original CURRENT_STATE.json and START_HERE.md conflicts with the actual matrix rows.

FP-002 appears in the audit but is omitted from START_HERE's suggested correction
sequence. It is explicitly included below.

FP-028 remains OPEN_DECISION in the old audit/matrix, although START_HERE already
selects conservative continuation: retain the scenario, omit unsupported claims
about skipped-output state and record the evidence gap. That was the direction for
implementation and revalidation, not an already closed finding.

The v5 register's 74 VERIFIED_LOCAL and three EXTERNAL_PENDING rows predate the
reopened audit. Their statuses cannot be carried into a new certification without
rechecking affected contracts.

## Original correction plan

Each phase must produce changed files, a reviewable difference from baseline and
verification evidence. Mark a finding VERIFIED_LOCAL only after resolving conflicts
in every affected layer. First priority: FP-005, FP-025 and FP-002.

| Phase | Findings | Work | Completion criteria |
|---|---|---|---|
| 0. Complete working baseline | FP-001 | Create a separate v6 copy from verified v5; recover the exact crawler blob; record dependencies and FP/file/check/evidence mapping. | Baseline preserved; crawler identified and included; all 29 findings listed. Missing crawler blocks complete certification but not other local corrections. |
| 1. Resolve critical conflicts | FP-002, FP-005, FP-025 | Validate full case/RUT identity immediately after GetCaseData. Separate executable/informational storage gates and terminal-DP grouping. Synchronize canonical DEP kinds in Main/Generator. | Bad identity stops early; terminal gaps allow truthful information; active work still blocks storage; kind/identity match without translation. |
| 2. Align the full NotTestable path | FP-003, FP-004, FP-006–FP-011 | Align Main, Generator, Validator, When KnowledgeArea, both schemas and embedded prompts. Scope Decision assertions and G5/G6 to execution; preserve informational scenarios; minimize their acquisition; continue siblings. | No RuleCode; zero ASSERT/SIM; required OMIT/gaps and Low/Blocked; both-family positive/negative fixtures behave correctly; later UTs are processed. |
| 3. Freeze serialization and deduplication | FP-026, FP-027 | Define stable unique-key OUT and SCAN occurrence mapping; update examples. Specify exact typed given/DP_SIG shapes, ordering, escapes and absent/null/empty distinctions. | Repeated keys retain occurrence evidence; different classes remain distinct; equivalent semantic values serialize consistently; round trips preserve values. |
| 4. Correct KnowledgeAreas/export fields | FP-012–FP-016, FP-018 | Model WHEN uses pyPropertiesName; formal metadata uses pyParametersParamType and STRING. Define append/map source/target contexts, thread scope comparison, simulation loader boundary and strict pyLabel fallback. | Confirmed forms retain raw evidence; unsupported forms are not guessed; child target is new item and child source is configured existing page; simulation replaces loader traversal only. |
| 5. Correct coverage/execution/evidence | FP-017, FP-019–FP-024, FP-028 | Include observable suppressed false edges and APPEND_AND_MAP_TO; allow needed item leaves; unify omission codes; direct SET uses own RHS; prior EXIT proves exclusion; provenance depends on binding kind; retain conservative skipped-output policy. | SIM-19–SIM-25 and SIM-28 have expected outcomes; unknown initial state does not become an assertion; no fabricated property definition for Param/Page/List; coverage retained. |
| 6. Verify and package | FP-029; cross-cutting FP-001–FP-029 | Rerun regressions; add all new contract cases; independently reread final files; compare embedded/standalone prompts; update register, ledger, state, README, manifests and ZIP. | All applicable local checks pass; every closure has evidence; counts derive from records; ZIP matches manifest; deferred runtime is explicit. |

Phases 1–3 are coupled: resolve informational grouping and canonical keys before
finalizing examples/checks. FP-005 cannot close before the complete phase 2–3 path
is checked. Phase 4 KnowledgeArea corrections precede final phase 5 coverage checks.

## Planned additional checks

- SIM-04–SIM-09: standard/When NotTestable, terminal unresolved DP, execution-class
  separation, batch continuation, rejection of High and Closed.
- SIM-12/SIM-26/SIM-27: supported DEP kinds, kind/identity mismatch, repeated
  occurrences, different classes, reversible typed JSON and escaping.
- SIM-13–SIM-25/SIM-28: incomplete/conflicting identity, confirmed export fields,
  append/map contexts, item leaves, direct SET, EXIT, provenance and unknown presence.
- SIM-01–SIM-03/SIM-10/SIM-11 and additional cases: preserve good siblings, malformed
  Validator reports, two repairs/three attempts per group, update failure without
  retry, Completed with at least one valid success and Failed with none.
- Structure: both schemas valid, two agent exports parse, embedded prompts equal
  standalone content, current examples validate and crawler provenance is verified.

Check expected outcomes and negative cases, not only newly inserted phrases.
A formalized prompt harness is an explicit local contract model; its success does
not prove LLM-agent or external Memory behavior.

## Boundaries and preserved decisions

One physical pyGroup corresponds to one candidate and one UnitTestRules entry.
A2A carries addresses/control data; exact Memory identity is pyGUID. UpdateMemory
is not retried. Repair budget is per group. PartiallyTestable remains executable.
NotTestable has no RuleCode; Passed/OK means the informational result is consistent.

C-027/C-028/C-029 remain EXTERNAL_PENDING/DEFERRED under the handoff decisions.
Memory implementation/runtime are outside local correction closure. A future
VERIFIED_LOCAL result must name its actual evidence scope. GitHub publication
requires a separate explicit instruction.

The next action at this historical checkpoint was to prepare v6, recover the crawler
and begin FP-005/FP-025/FP-002 with reproducing checks. Original snapshot sources and
documents were preserved; only this assessment directory was added at that time.
