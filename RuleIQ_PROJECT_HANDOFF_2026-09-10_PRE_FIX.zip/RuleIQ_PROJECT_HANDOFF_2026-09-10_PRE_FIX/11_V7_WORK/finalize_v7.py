"""Package verified prompt/contract artifacts; no external implementation actions."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=HERE/'RuleIQ_v7'
RELEASE=BASE/'08_RELEASE'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
summary=json.loads((ROOT/'verification/VERIFICATION_SUMMARY_v7.json').read_text())
assert summary['status']=='PASS_LOCAL_CONTRACTS' and summary['checks_failed']==0
hashes={p.name:sha(p) for p in sorted((ROOT/'sources').glob('*.txt'))}
assert hashes==summary['source_sha256']
state={'date':'2026-09-11','version':'v7','memory_contract':'v2','status':'VERIFIED_LOCAL_CONTRACTS','working_scope':'PROMPTS_AND_CONTRACTS_ONLY','language':'English','unique_key':['pxCaseID','Type','pyGroup'],'memory_tools':['WriteMemory','GetMemory'],'source_count':20,'checks_total':summary['checks_total'],'checks_passed':summary['checks_passed'],'checks_failed':0,'runtime_validation':'NOT_EXECUTED','external_implementation_changes':False,'github':'NO_WRITES','wire_revision':'1.4','supersedes':'v6 Memory creation/update contract; retains v6 semantic corrections','external_acceptance':'Pega team implements and verifies Memory v2, case serialization and current-run selection under specification/PEGA_IMPLEMENTATION_SPEC_v2.md','next_prompt_contract_step':'Review only the LLM-visible RuleCrawler wrapper contract; leave external implementations unchanged.'}
dump(ROOT/'CURRENT_STATE.json',state)
source_manifest={'package_version':'v7','memory_contract':'v2','sources':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((ROOT/'sources').glob('*.txt'))],'verification':'verification/VERIFICATION_SUMMARY_v7.json'}
dump(ROOT/'SOURCE_MANIFEST_v7.json',source_manifest)
changes=[
 ('UP-01','Use exact composite key; absent creates, existing updates stable GUID',['Composite key isolates (\'CASE-2\', \'UnitTestCandidate\', \'G001\')','Delimiter-concatenation collision stays distinct']),
 ('UP-02','Use complete Type-specific WriteMemory rows with no operation or partial patch',['Metadata-only write cannot fabricate missing payload','Reject obsolete/extra row field Operation','Retired UpdateMemory tool is rejected']),
 ('UP-03','Make candidate payload replacement and Pending reset atomic',['Repair replaces payload on same GUID','Repeated run resets an existing Passed candidate','Repair cannot inherit old Passed state']),
 ('UP-04','Keep one candidate record and GUID across at most two repairs',['Existing record cannot get a replacement GUID','UnitTestGenerator_Prompt.txt — maximum three Validator attempts']),
 ('UP-05','Fresh validation and current-invocation response under case serialization',['Validator_Prompt.txt — Exact GUID equality alone cannot prove unchanged content','UnitTestGenerator_Prompt.txt — never a cached or delayed response from an earlier attempt']),
 ('UP-06','Unify response rows and no-retry failure handling',['Failed sibling does not erase valid success','Recreated missing lifecycle record is not validated GUID','Outer failure cannot promote embedded successes']),
 ('UP-07','Preserve exact GetMemory identity and eight-field response',['Same GUID reads repaired current content','GetMemory does not gain lifecycle fields','GetMemory does not accept group as address']),
 ('UP-08','Select only current-run GR OK and preserve informational outcomes',['UnitTestGenerator_Prompt.txt — only confirmed GR OK rows from this invocation','Main_Agent_Prompt.txt — Records omitted or failed in the current run']),
 ('UP-09','Remove retired tool and synchronize standalone/embedded prompts',['Retired tool/patch absent from UnitTestGenerator.txt','Retired tool/patch absent from JsonValidator_tool.txt']),
 ('UP-10','Specify external migration, acceptance and handover against exact v7 source set',['Main_Agent_Prompt.txt — (pxCaseID, Type, pyGroup)','Validator_Prompt.txt — Cache no schema result, candidate payload or Validator report across invocations by GUID'])]
dump(ROOT/'CHANGE_REGISTER_v7.json',{'version':'v7','authority':'User chose a single WriteMemory upsert without an operation parameter and accepted unique-combination addressing. Selected combination: pxCaseID, Type, pyGroup.','status_semantics':'Verified local contract means source/assertion compatibility; no runtime implementation or acceptance is certified. Documentation traceability is checked by verify_package_v7.py.','baseline':'Preserved v6 sources and release; previous 598-check suite retained/adapted and rerun. Historical C-027/C-028/C-029 runtime obligations are replaced by the current Memory v2 specification, not marked implemented.','changes':[{'id':key,'resolution':title,'status':'VERIFIED_LOCAL_CONTRACT','evidence':evidence,'runtime_status':'NOT_EXECUTED'} for key,title,evidence in changes]})
receipt_path=ROOT/'verification/SOURCE_BUILD_RECEIPT.json'
receipt=json.loads(receipt_path.read_text()); receipt['status']='VERIFIED_LOCAL_CONTRACTS'; dump(receipt_path,receipt)
(ROOT/'README.md').write_text(f'''# RuleIQ v7 — one WriteMemory upsert

Current key: `(pxCaseID, Type, pyGroup)`. WriteMemory creates a missing record or updates
an existing record while keeping its GUID. GetMemory remains the exact read interface.
There is no operation parameter or separate lifecycle tool.

Start with the [Pega implementation specification v2](specification/PEGA_IMPLEMENTATION_SPEC_v2.md)
and [Memory contract v2](memory_contracts/MEMORY_TOOL_CONTRACT_v2.md).
The [source manifest](SOURCE_MANIFEST_v7.json) pins all 20 source files. The readable
configuration exports are references with synchronized embedded prompts, not a ready Pega RAP.

Candidate rows always contain complete payload and status/router. Initial writes and repairs
atomically write Pending/empty router. Lifecycle writes resend the exact validated payload.
Repairs retain the GUID and require fresh validation; at most three Validator attempts per group.
Pega must serialize a case pipeline through downstream selection. Only the current invocation's
confirmed GR OK records are eligible, including informational results that must not become tests.
Older immutable candidate-version history is no longer required by the current storage contract.

SG.version remains 1.4. Semantic authoring, schema families, examples and the RuleCrawler
reference are retained. The v7 change affects three prompts and two embedded configurations;
15 source files are byte-identical to v6. [Change register](CHANGE_REGISTER_v7.json).

Local verification: {summary['checks_passed']}/{summary['checks_total']} checks passed, comprising the
598 inherited/adapted regression checks plus 123 upsert contract checks. The reports bearing
v6 suffixes retain suite lineage; they were rerun against the v7 hashes recorded in the
[current summary](verification/VERIFICATION_SUMMARY_v7.json). No Pega or deployed LLM ran.
The 33 Memory/orchestration acceptance cases and 15 integration cases remain external work.

Run `python3 verification/verify_package_v7.py` to verify package bytes before regenerating
reports. For source/schema checks, install `verification/requirements.txt` in your chosen Python
and run `python3 verification/run_all_v7.py`. The upsert assertions alone use the standard library:
`python3 verification/verify_memory_upsert_v7.py`.

The original handoff and prior v6/Memory-v1/spec-v1 artifacts remain preserved outside this
package. [NEXT_STEPS.md](NEXT_STEPS.md) keeps further workspace work within prompts/contracts.
''')
(ROOT/'NEXT_STEPS.md').write_text('''# Next prompt and contract work

The requested Memory consolidation is complete in the v7 artifacts. Continue with the
LLM-visible RuleCrawler wrapper contract only: map the observed wrapper inputs/outputs to
Author requirements without changing the lower-level RuleCrawler implementation. Keep the
exact reference export as evidence; do not invent wrapper argument names from it.

The Pega team owns implementation, uniqueness/migration, pipeline serialization, tool binding
and runtime acceptance specified in specification/PEGA_IMPLEMENTATION_SPEC_v2.md. Those are
external handover requirements, not instructions to modify implementations in this workspace.
All deliverables stay in English. Do not apply the no-mistakes workflow.
''')
# Preserve exact original handoff and previous archives; these hashes are independent of v7.
original=json.loads((BASE/'HANDOFF_MANIFEST_SHA256.json').read_text())['files']
assert all((BASE/x['path']).stat().st_size==x['bytes'] and sha(BASE/x['path'])==x['sha256'] for x in original)
v6manifest=json.loads((BASE/'07_V6_WORK/RuleIQ_v6/PACKAGE_MANIFEST_SHA256.json').read_text())['files']
assert all(sha(BASE/'07_V6_WORK/RuleIQ_v6'/x['path'])==x['sha256'] for x in v6manifest)
old_archives=['RuleIQ_A2A_Memory_Refactor_v6_VERIFIED_LOCAL.zip','RuleIQ_Memory_Contracts_v1.zip','RuleIQ_Pega_Implementation_Spec_v1.zip']
old_expected=['b78edf930dc5a14ad0d7db87f308ec57eddf635df37824ceac1a3ed13db077c2','6b2be4b736ca7cf0b37b35d240d88e1b4c0df3b7a42f713d8478972cf0fb3626','8c119c59bf07cdae781b9e595130629a1e4a733df6052be8e20676f4297a72f5']
assert all(sha(RELEASE/name)==digest for name,digest in zip(old_archives,old_expected))
dump(ROOT/'verification/BASELINE_PRESERVATION.json',{'status':'PASS','original_handoff_files_unchanged':len(original),'v6_package_manifest_files_unchanged':len(v6manifest),'old_archives':[{'file':name,'sha256':sha(RELEASE/name)} for name in old_archives],'scope':'Read-only hash comparison; no historical artifact modified.'})
# Check governance before freezing a byte manifest.
proc=subprocess.run([sys.executable,str(ROOT/'verification/verify_package_v7.py'),'--governance'],capture_output=True,text=True)
if proc.returncode:
    print(proc.stdout); print(proc.stderr); raise SystemExit(proc.returncode)
dump(ROOT/'verification/GOVERNANCE_VERIFICATION_v7.json',json.loads(proc.stdout))
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ('.DS_Store','PACKAGE_MANIFEST_SHA256.json'))
dump(ROOT/'PACKAGE_MANIFEST_SHA256.json',{'package':'RuleIQ_v7','files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]})
proc=subprocess.run([sys.executable,str(ROOT/'verification/verify_package_v7.py')],capture_output=True,text=True)
if proc.returncode:
    print(proc.stdout); print(proc.stderr); raise SystemExit(proc.returncode)
package_result=json.loads(proc.stdout); dump(RELEASE/'PACKAGE_VERIFICATION_v7.json',package_result)
archive=RELEASE/'RuleIQ_v7_Prompts_Contracts_Pega_Spec.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.name!='.DS_Store': z.write(p,'RuleIQ_v7/'+str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(z.read('RuleIQ_v7/'+str(p.relative_to(ROOT)))==p.read_bytes() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='.DS_Store')
    entries=len(z.namelist())
    with tempfile.TemporaryDirectory(prefix='ruleiq-v7-integrity-') as folder:
        z.extractall(folder)
        portable=Path(folder)/'RuleIQ_v7'
        proc=subprocess.run([sys.executable,str(portable/'verification/verify_package_v7.py')],capture_output=True,text=True)
        assert proc.returncode==0,proc.stdout+proc.stderr
        portable_result=json.loads(proc.stdout)
        dump(RELEASE/'PORTABILITY_VERIFICATION_v7.json',{'status':'PASS_PACKAGE_INTEGRITY','checks_passed':portable_result['checks_passed'],'fresh_archive_extraction':True,'source_suites_rerun':False,'reason':'Archive bytes match the verified v7 source/check reports; package checks confirm all pins and relative paths after extraction.'})
archive.with_suffix(archive.suffix+'.sha256').write_text(sha(archive)+'  '+archive.name+'\n')
dump(RELEASE/'RELEASE_RECEIPT_v7.json',{'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'zip_entries':entries,'zip_crc':'PASS','status':'PACKAGED_VERIFIED_LOCAL_CONTRACTS','source_count':20,'sources_changed':5,'local_checks_passed':summary['checks_passed'],'package_checks_passed':package_result['checks_passed'],'runtime_executed':False,'external_implementation_changes':False,'github_writes':False,'memory_acceptance_cases':33,'integration_acceptance_cases':15,'original_handoff_files_unchanged':len(original),'prior_v6_package_unchanged':True})
index='''# Current continuation — RuleIQ v7

Current decision: WriteMemory upserts by `(pxCaseID, Type, pyGroup)` with no operation
parameter; GetMemory remains the only other Memory tool. Repairs replace current content
on the same GUID, reset Pending, and require fresh validation under case serialization.

- [Current package README](11_V7_WORK/RuleIQ_v7/README.md)
- [Pega implementation specification v2](11_V7_WORK/RuleIQ_v7/specification/PEGA_IMPLEMENTATION_SPEC_v2.md)
- [Memory contract v2](11_V7_WORK/RuleIQ_v7/memory_contracts/MEMORY_TOOL_CONTRACT_v2.md)
- [Complete v7 release](08_RELEASE/RuleIQ_v7_Prompts_Contracts_Pega_Spec.zip)
- [Current state](11_V7_WORK/RuleIQ_v7/CURRENT_STATE.json)

721 local checks passed. External implementations were not changed; runtime acceptance
remains with the Pega team. Scope is prompts/contracts only; all deliverables are English.
The original handoff (01–05), v6 package (07), Memory-v1 contracts (09), specification v1
(10), and previous release archives are preserved historical references. They do not define
the active v7 Memory contract. Root START_HERE.md/CURRENT_STATE.json remain the original snapshot.
'''
(BASE/'CURRENT_START_HERE.md').write_text(index)
(BASE/'CURRENT_V6_START_HERE.md').write_text('''# Superseded continuation index

The current package is v7: [CURRENT_START_HERE.md](CURRENT_START_HERE.md).
It uses one composite-key WriteMemory upsert and GetMemory. The previous
[v6 source package](07_V6_WORK/RuleIQ_v6/README.md), [Memory-v1 contracts](09_MEMORY_RUNTIME/README.md)
and [specification v1](10_PEGA_IMPLEMENTATION_SPEC/README.md) are preserved as historical
references. Use the current index for active prompts, contracts, specification and release.
''')
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'checks_passed':summary['checks_passed'],'package_checks':package_result['checks_passed'],'entries':entries}))
