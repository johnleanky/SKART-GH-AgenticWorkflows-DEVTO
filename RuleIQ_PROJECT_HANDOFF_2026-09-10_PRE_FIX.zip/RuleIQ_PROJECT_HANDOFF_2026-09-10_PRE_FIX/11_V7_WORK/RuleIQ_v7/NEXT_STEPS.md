# Next prompt and contract work

The requested Memory consolidation is complete in the v7 artifacts. Continue with the
LLM-visible RuleCrawler wrapper contract only: map the observed wrapper inputs/outputs to
Author requirements without changing the lower-level RuleCrawler implementation. Keep the
exact reference export as evidence; do not invent wrapper argument names from it.

The Pega team owns implementation, uniqueness/migration, pipeline serialization, tool binding
and runtime acceptance specified in specification/PEGA_IMPLEMENTATION_SPEC_v2.md. Those are
external handover requirements, not instructions to modify implementations in this workspace.
All deliverables stay in English. Do not apply the no-mistakes workflow.
