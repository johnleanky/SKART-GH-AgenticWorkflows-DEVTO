# RuleIQ — Pega Implementation Specification After Refactoring

**Version:** 2.0  
**Contract baseline:** RuleIQ v7; Memory contract v2; ScenarioGroup wire revision 1.4  
**Language:** English  
**Purpose:** Specify the Pega work needed to support the refactored prompts and contracts.  
**Ownership:** The Pega team implements and configures external components. This workspace maintains prompts, contracts, specifications and local verification only.

## 1. Required outcome

The existing entry point must run this chain:

```text
Case → Scenario Author → persisted ScenarioGroups
     → UnitTestGenerator → persisted UnitTestCandidates
     → UnitTestValidator → direct validation results
     → Generator updates candidate lifecycle → final per-group results
     → Author returns the existing two-field case response
```

Scenario Author owns test semantics. Generator projects those semantics into candidate JSON.
Validator checks the current persisted candidate under case serialization. Memory upserts one
record per exact `(pxCaseID, Type, pyGroup)` combination and preserves its GUID on updates. The agents do not pass large payloads to each other.

One physical `pyGroup` has one current candidate record containing exactly one `UnitTestRules`
entry. A When candidate may contain several executable combination rows. Different physical
groups remain independently addressable and can succeed or fail separately.

**Minimum Pega work:** implement composite-key WriteMemory upserts and retain exact GetMemory;
serialize pipelines per case; configure Generator and Validator as callable agents using one `question`
parameter; make JsonValidationTool validate the exact candidate GUID; publish the required
KnowledgeTool content; and make any existing candidate consumer respect informational outcomes.
An existing component that already satisfies a requirement does not need to be rewritten.

## 2. Work breakdown

| ID | Component | Required work | Completion evidence |
|---|---|---|---|
| PI-01 | Scenario Author configuration | Apply Main_Agent_Prompt.txt and expose only its permitted tools. | Correct tool bindings and external response shape. |
| PI-02 | UnitTestGenerator | Configure its prompt, single-string A2A input, tools and GR response style. | GEN/SG input reaches Generator unchanged; source reads use supplied GUIDs. |
| PI-03 | UnitTestValidator | Configure its prompt, single-string A2A input, read-only tools and VR/VI response style. | VAL/UT input reaches Validator unchanged; all attributable siblings receive results. |
| PI-04 | WriteMemory | Upsert complete records by the unique case/type/group combination. | Create when absent, retain GUID on update, atomic payload/lifecycle writes and independent rows. |
| PI-05 | GetMemory | Read by exact case/type/GUID and return identity with the payload. | No latest/group fallback; exact metadata and payload round trip. |
| PI-06 | Lifecycle and orchestration | Route all writes through WriteMemory; serialize the complete pipeline per case. | Fresh validation after each payload write, same-GUID repairs, current-run selection, no stale reports. |
| PI-07 | JsonValidationTool | Resolve the candidate by the exact supplied GUID before schema validation. | Current payload stays unchanged throughout schema/read validation; valid/invalid/tool-error results differ. |
| PI-08 | KnowledgeTool | Publish exact semantic and structural composite keys, schemas and templates. | All required keys return usable content; executable target ruleset carriers are supplied. |
| PI-09 | GetCaseData | Preserve the existing interface and provide complete, consistent case/RUT identity. | Identity gate succeeds for correct data and fails before further work for bad data. |
| PI-10 | RuleCrawler boundary | Confirm the existing wrapper supplies the facts required by Main. Keep its implementation external. | Request/response mapping is documented; key resolution is not mistaken for RuleJSON. |
| PI-11 | Existing candidate consumer | Separate validated informational results from executable unit-test candidates. | NotTestable without RuleCode is visible as information and is not imported as a runnable test. |
| PI-12 | Version rollout and acceptance | Use a consistent v7 prompt/content set and perform the external acceptance cases. | Version inventory, actual request/response traces and independent stored-record evidence. |

## 3. Agent configuration

### 3.1 Files and tool bindings

Use the readable prompts as the editable authority. The supplied exports provide the
Generator/Validator embedded prompts and configuration references. They are not a claim that
a complete, target-ready Pega deployment package has been produced.

| Agent | Prompt | Permitted tools |
|---|---|---|
| Scenario Author | Main_Agent_Prompt.txt | GetCaseData, semantic KnowledgeTool, RuleCrawler, WriteMemory for ScenarioGroup, UnitTestGenerator |
| UnitTestGenerator | UnitTestGenerator_Prompt.txt | GetMemory for ScenarioGroup, structural KnowledgeTool, WriteMemory for complete UnitTestCandidate and lifecycle upserts, UnitTestValidator |
| UnitTestValidator | Validator_Prompt.txt | JsonValidationTool, GetMemory for UnitTestCandidate, structural KnowledgeTool |

Use `UnitTestGenerator.txt` and `JsonValidator_tool.txt` to check embedded prompt parity and
tool configuration. The v7 source set has no updated Main_Agent export; apply the Main prompt
to the existing Author configuration and verify its tool bindings separately.

Do not expose candidate-writing or validation tools to Author. Validator must not be able to
write/update Memory, invoke Generator, or read ScenarioGroups. Generator must not call
GetCaseData, RuleCrawler or JsonValidationTool directly.

Retain legacy tools for unrelated consumers if necessary, but do not bind their old interfaces
into this chain. In particular, do not route current calls through old scalar
`WriteMemory(CaseID,Type,Payload)` or combined candidate/report transports.

### 3.2 Agent-to-agent interfaces

Both callable agents receive exactly one scalar string argument named `question`.
Do not add CaseID, RUTType, GUID lists or payload arguments to their callable interface.

Author → Generator:

```text
GEN|pxCaseID=UT-CASE-001|RUTType=Rule-Obj-Model
SG|pyGroup=G001|pyGUID=sg-guid-001
SG|pyGroup=G002|pyGUID=sg-guid-002
```

Generator → Validator:

```text
VAL|pxCaseID=UT-CASE-001|RUTType=Rule-Obj-Model
UT|pyGroup=G001|pyGUID=candidate-guid-001
UT|pyGroup=G002|pyGUID=candidate-guid-002
```

These are illustrative addresses. Runtime GUIDs come only from successful Memory writes.
Forward the exact string and preserve record boundaries. The A2A field encoding is:

| Value character/state | Encoded field content |
|---|---|
| Backslash | `\\` |
| Literal pipe | `\|` |
| CR / LF / TAB | `\r` / `\n` / `\t` |
| Empty string | `\0` |
| Exact literal hyphen | `\-` |

Structural pipes and record LF remain literal. Split records/fields before decoding field values
once. Unescaped `-` means absent only where the protocol permits it. Do not apply this A2A
encoding to Memory payload content as an additional transformation.

Generator returns GR lines, not JSON:

```text
GR|pyGroup=G001|pyGUID=candidate-guid-001|status=OK|reason=-
GR|pyGroup=G002|pyGUID=-|status=FAILED|reason=LIFECYCLE_UPDATE_FAILED
```

Validator returns VR blocks followed by their optional VI records:

```text
VR|pyGroup=G001|pyGUID=candidate-guid-001|route=OK|blocking=0|warnings=0
```

Its blocking routes are `GENERATOR_REPAIR`, `SEMANTIC_REJECT` and `HUMAN`. Full VI grammar
and allowed code/action pairs remain in Validator V2 and its appendix; do not add a new
JSON report wrapper or persisted Validator result record.

### 3.3 External Author response

Preserve the existing response object with exactly these two fields:

```json
{"AIAgentResponseStatus":"Completed","AIAgentErrorResponseMessage":""}
```

or:

```json
{"AIAgentResponseStatus":"Failed","AIAgentErrorResponseMessage":"Unit test generation failed."}
```

Completed means at least one attributable group returned a valid GR OK. It does not mean
every group succeeded or an executable Pega unit test ran. Failure text remains one sentence,
at most 20 words and 180 characters. No internal payloads, GUIDs or reports are exposed here.

## 4. Persistent Memory model — PI-04

There is one current record per exact tuple `(pxCaseID, Type, pyGroup)`.
Use separate exact key components or an equally lossless representation; concatenating
them with an unescaped delimiter is invalid. Case, whitespace, Unicode and punctuation
are significant. Types are exactly `ScenarioGroup` and `UnitTestCandidate`.

On an absent key, Memory creates a record and assigns a new nonempty opaque `pyGUID`.
On an existing key, Memory updates that record and preserves `pyGUID` and all key fields.
GUIDs are globally unique opaque read addresses, not payload revision identifiers.
The same group ID in a different case or Type selects a different record. `pyGroup`
alone is never an address. Callers do not supply a GUID to WriteMemory.

| Caller | WriteMemory | GetMemory |
|---|---|---|
| Author | Complete ScenarioGroups, one batch per invocation. | Unavailable. |
| Generator | Complete candidate payload and lifecycle, including repairs. | Supplied ScenarioGroup GUIDs only. |
| Validator | Unavailable. | Supplied candidate GUID, after fresh successful schema validation. |

The public Memory surface contains only WriteMemory and GetMemory. There is no
operation discriminator, separate UpdateMemory tool, pyUpdates carrier or partial patch.

## 5. WriteMemory — PI-04

### 5.1 Exact request and upsert behavior

All three arguments are strings, with no additional arguments:

```text
WriteMemory(pxCaseID, Type, RequestsJSON)
```

`RequestsJSON` decodes once to exactly `{"pxResults":[...]}`. The array is nonempty.
Current callers send at most one row for each nonempty `pyGroup` in a batch.

For `Type="ScenarioGroup"`, each row has exactly two fields:

```json
{"pyGroup":"G001","pyPayload":"<complete frozen ScenarioGroup payload>"}
```

For `Type="UnitTestCandidate"`, each row has exactly four fields:

```json
{"pyGroup":"G001","pyPayload":"<complete candidate payload>","pyStatusValue":"Pending","pyRouterKey":""}
```

Payload is nonempty opaque text. Candidate lifecycle fields are mandatory strings.
The allowed pairs are `Pending/""`, `Passed/OK`, `Failed/GENERATOR_REPAIR`,
`Failed/SEMANTIC_REJECT`, and `Failed/HUMAN`. Missing fields, unknown fields, null,
path expressions and inconsistent lifecycle pairs fail validation. A candidate row
containing only metadata is incomplete even when a matching record already exists.

Memory validates a complete row before applying it. It then atomically inserts or
replaces all supplied mutable fields using the composite key. Initial writes and
repairs explicitly send Pending/empty router; status is not a creation-only default.
There is no hidden update-only path: a complete lifecycle row also inserts if its key
is absent. Memory does not verify a Validator report or execute candidate JSON.
Generator decides when each lifecycle pair is authorized by its direct Validator result.

Canonical ScenarioGroup projections contain `pyGUID, pxCaseID, Type, pyGroup, pyPayload`.
Candidate projections add `pyStatusValue, pyRouterKey`. Other existing private storage
fields need not be removed. The contract does not prescribe Pega class names or require
history retention. The server must preserve exact payload bytes after one JSON decode;
it must not parse/reserialize, trim, normalize or merge payload content.

### 5.2 Response, atomicity and failures

Exact outer fields:

```json
{"Success":true,"ResultsJSON":"<JSON text>","ErrorCode":"","ErrorMessage":""}
```

Success is a Boolean; the other fields are strings. Outer success requires empty errors.
Decoded ResultsJSON is exactly `{"pxResults":[...]}` with one row per requested group:

```json
{"pyGroup":"G001","Success":true,"pyGUID":"<created or retained GUID>","ErrorCode":"","ErrorMessage":""}
```

The row always has exactly these five fields. Successful rows have a nonempty GUID and
empty errors. Failed rows have an empty GUID, nonempty diagnostic, and ErrorCode from
`INVALID_INPUT`, `UNSUPPORTED_TYPE`, `WRITE_FAILED`. A failed update therefore does not
echo the old GUID. Use group correlation for both creation and update, never array order.
Different successful groups must not return the same GUID. For a candidate already
successfully written during this invocation, a later success must return its known GUID.

Validate all requested/result identities and framing before trusting a result. An
explicit valid row failure leaves successful siblings usable. Missing, duplicate,
unknown or malformed results never establish success; an invalid outer envelope,
outer failure or invocation exception makes the entire wave unconfirmed. Outer failure
requires nonempty error code and message; embedded rows cannot override that failure.
The service must validate batch framing and duplicate key ambiguity before mutating it.
For a well-framed batch, validate and commit each row independently. A rejected row
must not partially replace payload or metadata or roll back a successful sibling.

Successful responses describe committed state visible to another requestor. Exact-key
uniqueness and insert/update must remain atomic under contention. No response may report
success before durable completion. Response loss can still make a committed write
unconfirmed. The caller makes one attempt per write and never retries automatically.

## 6. GetMemory — PI-05

The existing read interface and exact eight-field response remain unchanged:

```text
GetMemory(pxCaseID, Type, pyGUID)
```

```json
{"Success":true,"pxCaseID":"CASE-1","Type":"UnitTestCandidate","pyGroup":"G001","pyGUID":"<requested GUID>","pyPayload":"<current payload>","ErrorCode":"","ErrorMessage":""}
```

Success is Boolean; every other field is a string. Enforce exact case/type/GUID
ownership and return the current record. A successful response has a nonempty payload
and empty errors. Callers independently compare pyGroup with the A2A reference.
Missing GUID or mismatched ownership fails; no latest/group fallback or retry.
GetMemory does not accept the composite key in place of its GUID argument.
Failed or malformed reads do not release partial payloads to the caller.

Lifecycle fields are not added to this response. Acceptance evidence for stored status
uses a separate read-only canonical projection or equivalent server observation.

## 7. Lifecycle and orchestration — PI-06

### 7.1 Candidate lifecycle and repairs through WriteMemory

Every initial candidate write in a run, including an existing record, and every repair
upserts the complete payload with Pending/empty router atomically. Keep the exact written
payload locally. Perform a fresh Validator invocation for each successful candidate write.

| Direct Validator route | Complete lifecycle write | Continuation after confirmation |
|---|---|---|
| OK | Same payload, Passed/OK. | GR OK for the known GUID. |
| GENERATOR_REPAIR | Same payload, Failed/GENERATOR_REPAIR. | If budget remains, repair then upsert Pending at the same key/GUID and validate again. |
| SEMANTIC_REJECT | Same payload, Failed/SEMANTIC_REJECT. | Stop the group. |
| HUMAN | Same payload, Failed/HUMAN. | Stop the group. |

A lifecycle write must resend exactly the payload checked by its current Validator
invocation; no payload reserialization or repair is combined with that write. The next
repair is a separate Pending write. Budget remains initial plus at most two repairs,
at most three Validator attempts per group, with the same record GUID. Other groups'
budgets and source semantics remain independent. Old candidate payloads may be replaced;
frozen ScenarioGroup semantics must not change within the run.

Failed/unconfirmed candidate write: `CANDIDATE_WRITE_FAILED`. Failed/unconfirmed lifecycle
write: `LIFECYCLE_UPDATE_FAILED`, no further repair. A new GUID on a lifecycle or repair
response is not the validated known record: fail that stage even if the server recreated
an absent key successfully. A malformed/unattributable Validator result produces zero
lifecycle writes, leaves Pending, and yields `VALIDATOR_RESPONSE_INVALID`.

### 7.2 Case serialization and current-run selection

Pega must allow only one active pipeline per pxCaseID, from before ScenarioGroup upserts
through downstream selection. Queue or reject an overlapping run in orchestration before
any writes; use the existing application mechanism rather than a new LLM parameter.
All writers in this chain must honor that exclusion. Different cases can run independently.
The unique key constraint protects record identity; it does not replace this run-level guard.

For each group, finish candidate write, direct Validator invocation, lifecycle write,
and any repair in that order. No concurrent write may replace a candidate between its
JsonValidationTool schema check, GetMemory, Validator response and lifecycle confirmation.
Do not cache schema results, candidate payloads or reports across Validator invocations
by GUID. Accept only the currently awaited invocation's direct response. The unchanged
A2A wire has no attempt discriminator; GUID equality alone cannot detect a stale response.

Only current invocation GR OK rows with confirmed current Passed/OK state are eligible.
Records omitted or failed in this run, including older Passed records at the same case,
must not be selected by scanning Memory. Selection/materialization must finish under the
case guard, or take a protected complete snapshot before releasing it. Informational
NotTestable/no-RuleCode records remain valid information and never become runnable tests.

## 8. JsonValidationTool — PI-07

Retain these exact existing argument names:

```text
JsonValidationTool(CaseID: string, UUID: string, JsonSchema: string)
```

Map CaseID from VAL.pxCaseID and UUID from the current UT.pyGUID. Do not rename these two
parameters to the Memory API names, add a Memory Type parameter, accept candidate JSON
through A2A, or resolve the latest candidate for a case.

Internally resolve that exact UnitTestCandidate with its case constraint and validate its stored
pyPayload against the selected current schema. Schema family depends only on the original
VAL.RUTType:

| Original RUT type | JsonSchema key |
|---|---|
| Rule-Obj-When | Rule-Test-Unit-Case_MultInpComb-JsonSchema |
| Every other supported type | Rule-Test-Unit-Case_JsonSchema |

Required result fields are Boolean Success and IsValid, and string ValidationMessage,
ErrorCode, ErrorMessage. Distinguish:

- Success=true, IsValid=true: Validator may read the same candidate GUID.
- Success=true, IsValid=false: schema-invalid candidate; no subsequent GetMemory for that UT.
- Tool/read/input failure or malformed result: tool error; no subsequent GetMemory for that UT.

Validation must be read-only. Do not fix JSON, create RuleCode, change candidate status or
rewrite payload. The agent retains its existing diagnostic thresholds and repair routing.

## 9. KnowledgeTool and template content — PI-08

Keep `KnowledgeTool(KnowledgeAreas)` with a comma-separated string of composite keys.
Return pxResults rows with exact Area and nonempty Description strings:

```json
{"pxResults":[{"Area":"Rule-Obj-Model_KnowledgeArea","Description":"<current knowledge content>"}]}
```

Publish the semantic KnowledgeAreas from the v7 `sources` files for Model, When, Property,
Decision Table, Data Pages and RUF. Author requests semantic content only.

Publish these structural keys with exact spelling:

| Family | KnowledgeArea | Schema | Example/template |
|---|---|---|---|
| Standard | Rule-Test-Unit-Case_KnowledgeArea | Rule-Test-Unit-Case_JsonSchema | Rule-Test-Unit-Case_JsonExample |
| When | Rule-Test-Unit-Case_MultInpComb-KnowledgeArea | Rule-Test-Unit-Case_MultInpComb-JsonSchema | Rule-Test-Unit-Case_MultInpComb-JsonExample |

Use the two current schema files and their matching primary example files. The additional
MultInpComb example files are reference fixtures; they do not introduce new mandatory tool keys.
The two structural UTC KnowledgeArea contents are an existing external prerequisite, not
included as new implementation files in the v7 package.

For executable candidates, the selected example/template must carry the application's
**already selected** pyRuleSet and pyRuleSetVersion. Preserve the existing target selection
mechanism. Do not use illustrative local example values as an operational target, infer the
target from the RUT ruleset, or add TargetRuleSet parameters to the agents.

An informational-only Generator group requires its schema key only. It must not depend on
UTC KnowledgeArea, JsonExample or target-ruleset metadata. For mixed ready modes, Generator
requests the union once; a missing key fails only groups that need that key. Return keys by
identity rather than position. Do not silently substitute another family's schema.

## 10. Case identity and RuleCrawler compatibility — PI-09 / PI-10

### 10.1 GetCaseData

Preserve its existing invocation interface. Provide nonempty pyID, TestedRuleKey and RUT
RuleJSON containing pzInsKey, pxObjClass, pyClassName and pyRuleName. The first three
whitespace-separated components of TestedRuleKey and pzInsKey must agree with the uppercase
RUT type/class/name triplet. Keep the original strings; Author does not repair identity.
No KnowledgeTool, RuleCrawler or Memory call is permitted after an invalid initial identity.

### 10.2 RuleCrawler

This refactoring does not require rewriting the external crawler or moving its implementation
into the prompt repository. Verify the existing wrapper boundary against Main and the RUF
KnowledgeArea. Preserve holder identity, exact requested references, resolved identity and
retrievable rule content without fabricating missing facts.

The packaged Rule_Crawler_tool.txt is the exact `ResolveCrawlerBatch(String,String)` export.
Its Java code works on clipboard pages: input InterestedRules with pyItemRuleId and
pxRuleReferences; output InterestedRules with copied supported references and resolvedKey
when available. **It does not itself return the complete LLM-visible RuleJSON contract.**
Its pyDescription mentions SuggestedReferences, but its executable Java writes InterestedRules;
the wrapper mapping must be confirmed against actual behavior, not inferred from that label.

Check the existing wrapper for:

- One physical request per exact canonical key in a wave, with each occurrence's context preserved.
- Distinction between same-name rules in different classes; no class borrowed from another occurrence.
- Exact RUF source projection: pxObjClass, pxRuleFamilyName, pxRuleObjClass, pyRuleName;
  no synthetic RUF pxRuleClassName. RUF family uses Library!Function and canonical key RUF@@family.
- Resolved key without fetched RuleJSON treated as KEYONLY, not a closed executable dependency.
- Explicit handling of missing/filtered/unsupported results; a silently dropped reference is not success.
- Preservation of raw Model fields pyPropertiesName, pyParametersParamType and STRING;
  raw Data Page scope thread; and other evidence needed by the current KnowledgeAreas.
- Data Page simulation boundaries enforced by Author: loader-only references do not force
  recursive discovery, while caller/metadata/parameter obligations remain.

Main's planning limits remain 120 crawler calls and 260 total requested references per task.
These are caller planning limits, not a new server batching implementation requirement.
Exact LLM-visible RuleCrawler scalar parameter names/envelope are not established by the
lower-level export alone. Record the existing wrapper mapping before changing its configuration.

## 11. Informational outcomes and downstream consumers — PI-11

The two current schemas enforce a single UnitTestRules entry with one of two modes:

| Mode | Candidate content | Meaning of Passed / OK |
|---|---|---|
| Executable | RuleCode present; FullyTestable or PartiallyTestable scenarios. | Candidate validation succeeded; not proof that a Pega unit test was executed. |
| Informational NotTestable | RuleCode absent; zero ASSERT/SIM; explicit OMIT and gaps; Low confidence and Blocked closure. | The non-executable outcome is represented consistently. |

Keep informational records visible with their BlockingGaps. Do not create dummy RuleCode,
empty harness tests, invented simulations or test assertions for them. Validator completes
their visible consistency checks without UTC Knowledge and continues remaining batch siblings.

If an existing process creates Pega unit-test rules from Memory, it must require the selected
record's confirmed Passed/OK lifecycle **and** an executable candidate with RuleCode. Select only
GUIDs from this invocation's confirmed GR OK rows while holding the case guard; do not scan
all previously Passed records. Read/materialize current content before allowing another run. It must
not create a runnable test merely because pyStatusValue=Passed. Preserve candidate Testability
inside Scenarios; do not duplicate it in GR or invent Memory metadata fields for it.

## 12. Version alignment and rollout — PI-12

Keep Main, Generator, Validator, both embedded prompts, KnowledgeArea content, schemas and
template contract versions aligned. Verify the actual source hashes against SOURCE_MANIFEST_v7.json.
Adapt target-environment rule metadata through the existing deployment process; do not blindly
copy source-system ownership, identifiers or environment settings from readable exports.

SG.version remains **1.4**. The v6 semantic/DP_SIG corrections are retained; v7 changes the Memory
interface and candidate record lifecycle. A wire value of 1.4 alone does not prove compatibility.
Track both the v7 source manifest and Memory contract v2 during configuration.

The earlier contract permitted multiple GUIDs for the same case/type/group. Before activating
v2 uniqueness, inventory such duplicates and use an explicit Pega-owned migration mapping or
a clean isolated test scope. Preserve old data outside the active keyed set where required.
Do not silently select the latest record or delete duplicates. This package executes no migration.
New runs author fresh v7-compatible ScenarioGroups and upsert them; never reinterpret older
payloads or old Passed status as proof for the current run. Within a run, freeze source semantics.
Remove the retired lifecycle tool binding from Generator. Deploy the new complete candidate
row shape with the matching prompts; old two-field candidate writes are not compatible.

Recommended implementation order:

1. Establish the composite key, unique enforcement, complete WriteMemory rows, GetMemory and case serialization.
2. Bind JsonValidationTool to exact candidate GUIDs and publish current schema content.
3. Configure KnowledgeTool keys and existing target ruleset/version template carriers.
4. Configure Generator and Validator question-based A2A interfaces and restricted tool sets.
5. Configure Author with the current prompt and verify GetCaseData/crawler boundary compatibility.
6. Restrict selection to current invocation GR OK rows under the case guard, and preserve informational outcomes.
7. Execute the acceptance cases below in a dedicated test case and retain actual evidence.

## 13. Acceptance criteria

Use the detailed cases in [ACCEPTANCE_CASES.json](../memory_contracts/ACCEPTANCE_CASES.json).
They cover service upserts, identity, atomicity, fresh validation, serialization and caller failures.
They are requirements, not executed runtime evidence. Additionally:

| ID | Scenario | Required result |
|---|---|---|
| AT-01 | Standard executable group | Exact SG read, one current candidate, fresh schema/read validation, confirmed Passed/OK and GR OK. |
| AT-02 | When rows with equal simulation key and execution class | One physical candidate, one Decision block, multiple aligned rows. |
| AT-03 | When scenarios with different simulation keys | Separate physical candidates and independent outcomes. |
| AT-04 | Informational NotTestable without a usable required simulation | No RuleCode/SIM/assertions, explicit gaps, Low/Blocked; no fabricated mock. |
| AT-05 | Informational UT followed by executable UT | Both UT results emitted; informational completion does not terminate the batch. |
| AT-06 | Informational candidate with High confidence or Closed closure | Current schema rejects it. |
| AT-07 | Missing executable example key with valid informational schema | Only the dependent executable group fails knowledge acquisition. |
| AT-08 | Malformed/unattributable Validator result | Candidate remains Pending; zero lifecycle updates; VALIDATOR_RESPONSE_INVALID. |
| AT-09 | Failed, malformed or uncertain lifecycle WriteMemory result | One caller attempt; no retry/repair; no GR OK for that group. |
| AT-10 | Two repairs followed by a valid third attempt | At most three Validator attempts; one candidate GUID; each repair atomically replaces payload and resets Pending; every attempt revalidated. |
| AT-11 | One group succeeds and another fails | Successful group remains eligible; Author returns Completed. |
| AT-12 | No group succeeds | Author returns the bounded two-field Failed response. |
| AT-13 | Wrong case/type/group/GUID or stale same-GUID response | No unintended read or validation; writes use the exact composite key and only the active invocation can authorize lifecycle. |
| AT-14 | Repeated dependency occurrences and same-name/different-class rules | Deduplication does not lose occurrence evidence or merge different keys. |
| AT-15 | Existing candidate consumer receives Passed/OK informational result | Information is retained; no runnable Pega unit-test rule is created from absent RuleCode. |

For runtime acceptance, retain the target version inventory, exact requests/responses,
complete caller call sequence, failure-injection method and independent canonical before/after
record snapshots. Use a fresh request/requestor when verifying durability. No credentials are
required in the evidence package.

The current local suite checks source contracts, schemas, fixtures and synthetic upsert evidence.
See ../verification/VERIFICATION_SUMMARY_v7.json for actual counts and source hashes. These
checks do not establish external implementation readiness. Earlier C-027/C-028/C-029 runtime
obligations are superseded by this v2 specification and remain external acceptance work.

## 14. Source package and handover

This self-contained v7 package includes:

- [Source manifest](../SOURCE_MANIFEST_v7.json) and `../sources/` — current prompts, schemas, knowledge and readable configuration exports.
- [Memory contract v2](../memory_contracts/MEMORY_TOOL_CONTRACT_v2.md) — normative upsert and read boundary.
- [Memory acceptance cases](../memory_contracts/ACCEPTANCE_CASES.json) — external requirements, not runtime results.
- [Read-only assertions](../memory_contracts/memory_contract.py) and [source pins](../memory_contracts/SOURCE_AUTHORITY.json).
- [Change register](../CHANGE_REGISTER_v7.json) — the v6-to-v7 decision and verification scope.

Pega implementation handover should identify the rules/configuration used for PI-01–PI-12,
document actual wrapper mappings and stable service error codes, and attach acceptance evidence.
Storage class names, ruleset versions, deployment tooling and environment settings must come
from the target application; none is invented by this specification.
