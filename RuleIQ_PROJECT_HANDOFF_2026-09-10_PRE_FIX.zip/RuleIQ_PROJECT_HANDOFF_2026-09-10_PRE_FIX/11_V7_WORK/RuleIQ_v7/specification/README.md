# Pega implementation specification v2

[PEGA_IMPLEMENTATION_SPEC_v2.md](PEGA_IMPLEMENTATION_SPEC_v2.md) defines the external
team's required work. SPEC_SOURCE_MAP.json pins its source references. This package
includes Memory v2 and exact v7 prompt/config sources. No Pega implementation was changed.
