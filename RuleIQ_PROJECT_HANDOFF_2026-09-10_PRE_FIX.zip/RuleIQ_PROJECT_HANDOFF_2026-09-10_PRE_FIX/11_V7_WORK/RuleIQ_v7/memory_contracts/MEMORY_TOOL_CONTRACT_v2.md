# Memory contract v2 — composite-key upsert

Authority: the user's decision to use one WriteMemory tool, no operation parameter,
and a unique combination to choose create versus update. The selected combination is
`(pxCaseID, Type, pyGroup)`, as described before this revision. This contract supersedes
the separate creation/lifecycle-update interface and per-repair immutable records in v1.
It specifies external behavior; this package contains no Memory implementation.

## 1. Identity and ownership

There is one current record per exact tuple `(pxCaseID, Type, pyGroup)`.
Use separate exact key components or an equally lossless representation; concatenating
them with an unescaped delimiter is invalid. Case, whitespace, Unicode and punctuation
are significant. Types are exactly `ScenarioGroup` and `UnitTestCandidate`.

On an absent key, Memory creates a record and assigns a new nonempty opaque `pyGUID`.
On an existing key, Memory updates that record and preserves `pyGUID` and all key fields.
GUIDs are globally unique opaque read addresses, not payload revision identifiers.
The same group ID in a different case or Type selects a different record. `pyGroup`
alone is never an address. Callers do not supply a GUID to WriteMemory.

| Caller | WriteMemory | GetMemory |
|---|---|---|
| Author | Complete ScenarioGroups, one batch per invocation. | Unavailable. |
| Generator | Complete candidate payload and lifecycle, including repairs. | Supplied ScenarioGroup GUIDs only. |
| Validator | Unavailable. | Supplied candidate GUID, after fresh successful schema validation. |

The public Memory surface contains only WriteMemory and GetMemory. There is no
operation discriminator, separate UpdateMemory tool, pyUpdates carrier or partial patch.

## 2. WriteMemory request

All three arguments are strings, with no additional arguments:

```text
WriteMemory(pxCaseID, Type, RequestsJSON)
```

`RequestsJSON` decodes once to exactly `{"pxResults":[...]}`. The array is nonempty.
Current callers send at most one row for each nonempty `pyGroup` in a batch.

For `Type="ScenarioGroup"`, each row has exactly two fields:

```json
{"pyGroup":"G001","pyPayload":"<complete frozen ScenarioGroup payload>"}
```

For `Type="UnitTestCandidate"`, each row has exactly four fields:

```json
{"pyGroup":"G001","pyPayload":"<complete candidate payload>","pyStatusValue":"Pending","pyRouterKey":""}
```

Payload is nonempty opaque text. Candidate lifecycle fields are mandatory strings.
The allowed pairs are `Pending/""`, `Passed/OK`, `Failed/GENERATOR_REPAIR`,
`Failed/SEMANTIC_REJECT`, and `Failed/HUMAN`. Missing fields, unknown fields, null,
path expressions and inconsistent lifecycle pairs fail validation. A candidate row
containing only metadata is incomplete even when a matching record already exists.

Memory validates a complete row before applying it. It then atomically inserts or
replaces all supplied mutable fields using the composite key. Initial writes and
repairs explicitly send Pending/empty router; status is not a creation-only default.
There is no hidden update-only path: a complete lifecycle row also inserts if its key
is absent. Memory does not verify a Validator report or execute candidate JSON.
Generator decides when each lifecycle pair is authorized by its direct Validator result.

Canonical ScenarioGroup projections contain `pyGUID, pxCaseID, Type, pyGroup, pyPayload`.
Candidate projections add `pyStatusValue, pyRouterKey`. Other existing private storage
fields need not be removed. The contract does not prescribe Pega class names or require
history retention. The server must preserve exact payload bytes after one JSON decode;
it must not parse/reserialize, trim, normalize or merge payload content.

## 3. WriteMemory response and failure handling

Exact outer fields:

```json
{"Success":true,"ResultsJSON":"<JSON text>","ErrorCode":"","ErrorMessage":""}
```

Success is a Boolean; the other fields are strings. Outer success requires empty errors.
Decoded ResultsJSON is exactly `{"pxResults":[...]}` with one row per requested group:

```json
{"pyGroup":"G001","Success":true,"pyGUID":"<created or retained GUID>","ErrorCode":"","ErrorMessage":""}
```

The row always has exactly these five fields. Successful rows have a nonempty GUID and
empty errors. Failed rows have an empty GUID, nonempty diagnostic, and ErrorCode from
`INVALID_INPUT`, `UNSUPPORTED_TYPE`, `WRITE_FAILED`. A failed update therefore does not
echo the old GUID. Use group correlation for both creation and update, never array order.
Different successful groups must not return the same GUID. For a candidate already
successfully written during this invocation, a later success must return its known GUID.

Validate all requested/result identities and framing before trusting a result. An
explicit valid row failure leaves successful siblings usable. Missing, duplicate,
unknown or malformed results never establish success; an invalid outer envelope,
outer failure or invocation exception makes the entire wave unconfirmed. Outer failure
requires nonempty error code and message; embedded rows cannot override that failure.
The service must validate batch framing and duplicate key ambiguity before mutating it.
For a well-framed batch, validate and commit each row independently. A rejected row
must not partially replace payload or metadata or roll back a successful sibling.

Successful responses describe committed state visible to another requestor. Exact-key
uniqueness and insert/update must remain atomic under contention. No response may report
success before durable completion. Response loss can still make a committed write
unconfirmed. The caller makes one attempt per write and never retries automatically.

## 4. GetMemory

The existing read interface and exact eight-field response remain unchanged:

```text
GetMemory(pxCaseID, Type, pyGUID)
```

```json
{"Success":true,"pxCaseID":"CASE-1","Type":"UnitTestCandidate","pyGroup":"G001","pyGUID":"<requested GUID>","pyPayload":"<current payload>","ErrorCode":"","ErrorMessage":""}
```

Success is Boolean; every other field is a string. Enforce exact case/type/GUID
ownership and return the current record. A successful response has a nonempty payload
and empty errors. Callers independently compare pyGroup with the A2A reference.
Missing GUID or mismatched ownership fails; no latest/group fallback or retry.
GetMemory does not accept the composite key in place of its GUID argument.
Failed or malformed reads do not release partial payloads to the caller.

Lifecycle fields are not added to this response. Acceptance evidence for stored status
uses a separate read-only canonical projection or equivalent server observation.

## 5. Candidate lifecycle and repairs

Every initial candidate write in a run, including an existing record, and every repair
upserts the complete payload with Pending/empty router atomically. Keep the exact written
payload locally. Perform a fresh Validator invocation for each successful candidate write.

| Direct Validator route | Complete lifecycle write | Continuation after confirmation |
|---|---|---|
| OK | Same payload, Passed/OK. | GR OK for the known GUID. |
| GENERATOR_REPAIR | Same payload, Failed/GENERATOR_REPAIR. | If budget remains, repair then upsert Pending at the same key/GUID and validate again. |
| SEMANTIC_REJECT | Same payload, Failed/SEMANTIC_REJECT. | Stop the group. |
| HUMAN | Same payload, Failed/HUMAN. | Stop the group. |

A lifecycle write must resend exactly the payload checked by its current Validator
invocation; no payload reserialization or repair is combined with that write. The next
repair is a separate Pending write. Budget remains initial plus at most two repairs,
at most three Validator attempts per group, with the same record GUID. Other groups'
budgets and source semantics remain independent. Old candidate payloads may be replaced;
frozen ScenarioGroup semantics must not change within the run.

Failed/unconfirmed candidate write: `CANDIDATE_WRITE_FAILED`. Failed/unconfirmed lifecycle
write: `LIFECYCLE_UPDATE_FAILED`, no further repair. A new GUID on a lifecycle or repair
response is not the validated known record: fail that stage even if the server recreated
an absent key successfully. A malformed/unattributable Validator result produces zero
lifecycle writes, leaves Pending, and yields `VALIDATOR_RESPONSE_INVALID`.

## 6. Serialization, fresh validation and selection

Pega must allow only one active pipeline per pxCaseID, from before ScenarioGroup upserts
through downstream selection. Queue or reject an overlapping run in orchestration before
any writes; use the existing application mechanism rather than a new LLM parameter.
All writers in this chain must honor that exclusion. Different cases can run independently.
The unique key constraint protects record identity; it does not replace this run-level guard.

For each group, finish candidate write, direct Validator invocation, lifecycle write,
and any repair in that order. No concurrent write may replace a candidate between its
JsonValidationTool schema check, GetMemory, Validator response and lifecycle confirmation.
Do not cache schema results, candidate payloads or reports across Validator invocations
by GUID. Accept only the currently awaited invocation's direct response. The unchanged
A2A wire has no attempt discriminator; GUID equality alone cannot detect a stale response.

Only current invocation GR OK rows with confirmed current Passed/OK state are eligible.
Records omitted or failed in this run, including older Passed records at the same case,
must not be selected by scanning Memory. Selection/materialization must finish under the
case guard, or take a protected complete snapshot before releasing it. Informational
NotTestable/no-RuleCode records remain valid information and never become runnable tests.

## 7. Migration and evidence

Deploy this contract with the v7 prompts and both embedded configurations. Do not mix the
v1 immutable-version writer with v2 upsert callers. Existing duplicate case/type/group
records require a Pega-owned migration decision before enforcing uniqueness; preserve the
old records outside the active keyed set or use a clean test scope. Do not silently choose
the latest GUID, delete historical data, or reinterpret older payloads as current results.

Local assertions validate synthetic requests/responses and supplied snapshots; they do
not provide storage or prove Pega persistence, serialization, durability or deployed LLM
behavior. External acceptance cases are specified separately and remain unexecuted here.
