# Memory contracts v2

Read [MEMORY_TOOL_CONTRACT_v2.md](MEMORY_TOOL_CONTRACT_v2.md) for the current two-tool
interface. [ACCEPTANCE_CASES.json](ACCEPTANCE_CASES.json) lists external requirements;
none were run against Pega. `memory_contract.py` only asserts supplied request/response
and snapshot evidence and has no storage implementation.

Local results: `../verification/MEMORY_UPSERT_VERIFICATION_v7.json`. Run
`python3 ../verification/verify_memory_upsert_v7.py` from this directory for the
standard-library checks. Server serialization and caller sequencing require actual
external traces; synthetic checks do not establish runtime compliance.
