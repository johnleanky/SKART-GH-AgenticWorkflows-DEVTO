"""Read-only v2 boundary assertions. No persistence, networking or GUID generation."""
import json

class ContractError(ValueError):
    pass

def require(okay, message):
    if not okay:
        raise ContractError(message)

def exact(value, fields):
    require(isinstance(value, dict) and set(value) == set(fields), 'unexpected/missing fields')

def string(value, nonempty=False):
    require(isinstance(value, str) and (not nonempty or value != ''), 'expected string')

def parse(value):
    string(value)
    def pairs(items):
        out = {}
        for key, item in items:
            require(key not in out, 'duplicate JSON field')
            out[key] = item
        return out
    def invalid(value):
        raise ContractError('non-finite JSON')
    try:
        return json.loads(value, object_pairs_hook=pairs, parse_constant=invalid)
    except json.JSONDecodeError as error:
        raise ContractError('malformed JSON') from error

TYPES = ('ScenarioGroup', 'UnitTestCandidate')
KEY = ('pxCaseID', 'Type', 'pyGroup')
PAIRS = {('Pending', ''), ('Passed', 'OK'), ('Failed', 'GENERATOR_REPAIR'),
         ('Failed', 'SEMANTIC_REJECT'), ('Failed', 'HUMAN')}

def composite_key(case, type_, group):
    for value in (case, type_, group):
        string(value, True)
    require(type_ in TYPES, 'unsupported Type')
    return case, type_, group

def arguments(tool, args):
    require(tool in ('WriteMemory', 'GetMemory'), 'unknown Memory tool')
    tail = 'pyGUID' if tool == 'GetMemory' else 'RequestsJSON'
    exact(args, ['pxCaseID', 'Type', tail])
    string(args['pxCaseID'], True); string(args[tail], True)
    require(args['Type'] in TYPES, 'unsupported Type')

def batch(args):
    envelope = parse(args['RequestsJSON'])
    exact(envelope, ['pxResults'])
    values = envelope['pxResults']
    require(isinstance(values, list) and bool(values), 'nonempty batch required')
    return values

def row(type_, value):
    fields = ['pyGroup', 'pyPayload']
    if type_ == 'UnitTestCandidate':
        fields += ['pyStatusValue', 'pyRouterKey']
    exact(value, fields)
    string(value['pyGroup'], True); string(value['pyPayload'], True)
    if type_ == 'UnitTestCandidate':
        string(value['pyStatusValue']); string(value['pyRouterKey'])
        require((value['pyStatusValue'], value['pyRouterKey']) in PAIRS, 'invalid lifecycle pair')

def request(tool, args):
    arguments(tool, args)
    if tool == 'GetMemory':
        return None
    values = batch(args)
    keys = set()
    for value in values:
        row(args['Type'], value)
        key = composite_key(args['pxCaseID'], args['Type'], value['pyGroup'])
        require(key not in keys, 'duplicate composite key')
        keys.add(key)
    return values

def diagnostic(value):
    require(type(value['Success']) is bool, 'Success must be Boolean')
    string(value['ErrorCode']); string(value['ErrorMessage'])
    if value['Success']:
        require(value['ErrorCode'] == value['ErrorMessage'] == '', 'success contains errors')
    else:
        require(bool(value['ErrorCode']) and bool(value['ErrorMessage']), 'missing failure diagnostic')

def batch_response(args, response, known_guids=None):
    arguments('WriteMemory', args)
    # A row-invalid request may be supplied as partial-failure evidence. Identity
    # and framing must still be unambiguous; no invalid row is promoted to success.
    sent = batch(args)
    groups = []
    for value in sent:
        require(isinstance(value, dict) and 'pyGroup' in value, 'uncorrelatable request')
        string(value['pyGroup'], True)
        groups.append(value['pyGroup'])
    require(len(groups) == len(set(groups)), 'duplicate request group')
    exact(response, ['Success', 'ResultsJSON', 'ErrorCode', 'ErrorMessage'])
    diagnostic(response); string(response['ResultsJSON'])
    if not response['Success']:
        return {'trusted': False, 'results': {}}
    decoded = parse(response['ResultsJSON']); exact(decoded, ['pxResults'])
    require(isinstance(decoded['pxResults'], list), 'result array required')
    found, guids = {}, set()
    sent_map = {x['pyGroup']: x for x in sent}
    for value in decoded['pxResults']:
        exact(value, ['pyGroup', 'pyGUID', 'Success', 'ErrorCode', 'ErrorMessage'])
        string(value['pyGroup'], True); string(value['pyGUID']); diagnostic(value)
        group = value['pyGroup']
        require(group in groups and group not in found, 'unknown/duplicate response group')
        if value['Success']:
            row(args['Type'], sent_map[group])
            string(value['pyGUID'], True)
            require(value['pyGUID'] not in guids, 'GUID reused across distinct keys')
            guids.add(value['pyGUID'])
            if known_guids and group in known_guids:
                require(value['pyGUID'] == known_guids[group], 'known GUID changed')
        else:
            require(value['pyGUID'] == '', 'failed upsert must return empty GUID')
            require(value['ErrorCode'] in ('INVALID_INPUT', 'UNSUPPORTED_TYPE', 'WRITE_FAILED'), 'unknown row error')
        found[group] = value
    require(set(found) == set(groups), 'missing result row')
    return {'trusted': True, 'results': found}

def projection(value):
    require(isinstance(value, dict) and value.get('Type') in TYPES, 'invalid projection type')
    fields = {'pyGUID', 'pxCaseID', 'Type', 'pyGroup', 'pyPayload'}
    if value['Type'] == 'UnitTestCandidate':
        fields |= {'pyStatusValue', 'pyRouterKey'}
    exact(value, fields)
    for field in fields:
        string(value[field], field not in ('pyStatusValue', 'pyRouterKey'))
    if value['Type'] == 'UnitTestCandidate':
        require((value['pyStatusValue'], value['pyRouterKey']) in PAIRS, 'invalid stored lifecycle')

def upserted_record(args, sent_row, before, after, returned_guid):
    request('WriteMemory', args)
    require(sent_row in batch(args), 'row absent from request')
    projection(after); string(returned_guid, True)
    expected = {'pxCaseID': args['pxCaseID'], 'Type': args['Type'], **sent_row, 'pyGUID': returned_guid}
    require(after == expected, 'stored projection differs from complete upsert')
    if before is not None:
        projection(before)
        require(all(before[key] == after[key] for key in KEY), 'existing record key changed')
        require(before['pyGUID'] == after['pyGUID'], 'existing GUID changed')
    return True

def pending_write(args):
    require(args['Type'] == 'UnitTestCandidate', 'candidate required')
    values = request('WriteMemory', args)
    require(all((x['pyStatusValue'], x['pyRouterKey']) == ('Pending', '') for x in values), 'initial/repair must reset lifecycle')
    return True

def lifecycle_write(args, payloads, routes):
    require(args['Type'] == 'UnitTestCandidate', 'candidate required')
    for value in request('WriteMemory', args):
        group = value['pyGroup']
        require(group in payloads and group in routes, 'no current validated payload/route')
        route = routes[group]
        require(route in ('OK', 'GENERATOR_REPAIR', 'SEMANTIC_REJECT', 'HUMAN'), 'no valid Validator route')
        pair = ('Passed' if route == 'OK' else 'Failed', route)
        require((value['pyStatusValue'], value['pyRouterKey']) == pair, 'route/lifecycle mismatch')
        require(value['pyPayload'] == payloads[group], 'lifecycle write changed validated payload')
    return True

def get_response(args, expected_group, response):
    request('GetMemory', args)
    exact(response, ['Success', 'pxCaseID', 'Type', 'pyGroup', 'pyGUID', 'pyPayload', 'ErrorCode', 'ErrorMessage'])
    diagnostic(response)
    for field in ('pxCaseID', 'Type', 'pyGroup', 'pyGUID', 'pyPayload'):
        string(response[field])
    if not response['Success']:
        return None
    require(all(response[k] == args[k] for k in ('pxCaseID', 'Type', 'pyGUID')), 'read identity mismatch')
    require(response['pyGroup'] == expected_group, 'read group mismatch')
    string(response['pyPayload'], True)
    return response['pyPayload']
