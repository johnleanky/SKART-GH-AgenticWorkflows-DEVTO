# RuleIQ v7 — one WriteMemory upsert

Current key: `(pxCaseID, Type, pyGroup)`. WriteMemory creates a missing record or updates
an existing record while keeping its GUID. GetMemory remains the exact read interface.
There is no operation parameter or separate lifecycle tool.

Start with the [Pega implementation specification v2](specification/PEGA_IMPLEMENTATION_SPEC_v2.md)
and [Memory contract v2](memory_contracts/MEMORY_TOOL_CONTRACT_v2.md).
The [source manifest](SOURCE_MANIFEST_v7.json) pins all 20 source files. The readable
configuration exports are references with synchronized embedded prompts, not a ready Pega RAP.

Candidate rows always contain complete payload and status/router. Initial writes and repairs
atomically write Pending/empty router. Lifecycle writes resend the exact validated payload.
Repairs retain the GUID and require fresh validation; at most three Validator attempts per group.
Pega must serialize a case pipeline through downstream selection. Only the current invocation's
confirmed GR OK records are eligible, including informational results that must not become tests.
Older immutable candidate-version history is no longer required by the current storage contract.

SG.version remains 1.4. Semantic authoring, schema families, examples and the RuleCrawler
reference are retained. The v7 change affects three prompts and two embedded configurations;
15 source files are byte-identical to v6. [Change register](CHANGE_REGISTER_v7.json).

Local verification: 721/721 checks passed, comprising the
598 inherited/adapted regression checks plus 123 upsert contract checks. The reports bearing
v6 suffixes retain suite lineage; they were rerun against the v7 hashes recorded in the
[current summary](verification/VERIFICATION_SUMMARY_v7.json). No Pega or deployed LLM ran.
The 33 Memory/orchestration acceptance cases and 15 integration cases remain external work.

Run `python3 verification/verify_package_v7.py` to verify package bytes before regenerating
reports. For source/schema checks, install `verification/requirements.txt` in your chosen Python
and run `python3 verification/run_all_v7.py`. The upsert assertions alone use the standard library:
`python3 verification/verify_memory_upsert_v7.py`.

The original handoff and prior v6/Memory-v1/spec-v1 artifacts remain preserved outside this
package. [NEXT_STEPS.md](NEXT_STEPS.md) keeps further workspace work within prompts/contracts.
