"""Adversarial local contract checks; no Pega runtime, persistence or LLM execution."""
from pathlib import Path
import copy
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'memory_contracts'))
import memory_contract as c

SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'sources'
checks = []

def check(name, fn, invalid=False, kind='LOCAL_CONTRACT_ASSERTION'):
    try:
        fn()
        okay = not invalid
    except c.ContractError:
        okay = invalid
    checks.append({'check': name, 'status': 'PASS' if okay else 'FAIL', 'kind': kind})

def expect(value):
    c.require(value, 'expectation failed')

def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))

def args(values, type_='UnitTestCandidate', case='CASE-1'):
    return {'pxCaseID': case, 'Type': type_, 'RequestsJSON': encoded({'pxResults': values})}

def pending(group='G001', payload=' exact payload\n'):
    return {'pyGroup': group, 'pyPayload': payload, 'pyStatusValue': 'Pending', 'pyRouterKey': ''}

def result(group='G001', guid='guid-1'):
    return {'pyGroup': group, 'pyGUID': guid, 'Success': True, 'ErrorCode': '', 'ErrorMessage': ''}

def envelope(values):
    return {'Success': True, 'ResultsJSON': encoded({'pxResults': values}), 'ErrorCode': '', 'ErrorMessage': ''}

def record(value, guid='guid-1', case='CASE-1', type_='UnitTestCandidate'):
    return {'pxCaseID': case, 'Type': type_, **value, 'pyGUID': guid}

opaque = '  exact | \\n and actual\nnewline\r\t " &quot; \u0451😀  '
first = pending(payload=opaque)
call = args([first])
check('Complete candidate request preserves opaque bytes', lambda: expect(c.request('WriteMemory',call)[0]['pyPayload'] == opaque))
check('Creation returns exact new canonical record', lambda: c.upserted_record(call,first,None,record(first),'guid-1'))
sg = {'pyGroup':'G001','pyPayload':opaque}
sg_args = args([sg], 'ScenarioGroup')
check('ScenarioGroup creation uses two fields', lambda: c.upserted_record(sg_args,sg,None,record(sg,type_='ScenarioGroup'),'guid-1'))
sg_after = dict(sg,pyPayload='new frozen source')
check('Next run can upsert ScenarioGroup at same GUID', lambda: c.upserted_record(args([sg_after],'ScenarioGroup'),sg_after,record(sg,type_='ScenarioGroup'),record(sg_after,type_='ScenarioGroup'),'guid-1'))

for case,type_,group in [('CASE-2','UnitTestCandidate','G001'),('CASE-1','ScenarioGroup','G001'),('CASE-1','UnitTestCandidate','G002'),('CASE-1 ','UnitTestCandidate','G001'),('case-1','UnitTestCandidate','G001')]:
    check('Composite key isolates '+repr((case,type_,group)), lambda case=case,type_=type_,group=group: expect(c.composite_key(case,type_,group) != c.composite_key('CASE-1','UnitTestCandidate','G001')))
a=('A|UnitTestCandidate','UnitTestCandidate','G')
b=('A','UnitTestCandidate','UnitTestCandidate|G')
check('Delimiter-concatenation collision stays distinct', lambda: expect('|'.join(a)=='|'.join(b) and c.composite_key(*a)!=c.composite_key(*b)))
check('Key preserves opaque Unicode and escapes', lambda: expect(c.composite_key(opaque,'ScenarioGroup',opaque)==(opaque,'ScenarioGroup',opaque)))

for field in ('pyGroup','pyPayload','pyStatusValue','pyRouterKey'):
    omitted=dict(first); omitted.pop(field)
    check('Reject missing candidate field '+field,lambda omitted=omitted:c.request('WriteMemory',args([omitted])),True)
for field,value in [('Operation','UPSERT'),('operation','CREATE'),('pyGUID','guid-1'),('pyUpdates',{}),('extra','value')]:
    check('Reject obsolete/extra row field '+field,lambda field=field,value=value:c.request('WriteMemory',args([dict(first,**{field:value})])),True)
for field in ('Operation','pyGUID','CaseID'):
    check('Reject extra API argument '+field,lambda field=field:c.request('WriteMemory',dict(call,**{field:'value'})),True)
check('Retired UpdateMemory tool is rejected',lambda:c.request('UpdateMemory',call),True)
check('ScenarioGroup rejects candidate lifecycle fields',lambda:c.request('WriteMemory',args([first],'ScenarioGroup')),True)
check('Metadata-only write cannot fabricate missing payload',lambda:c.request('WriteMemory',args([{'pyGroup':'G001','pyStatusValue':'Passed','pyRouterKey':'OK'}])),True)
for field,value in [('pyPayload',''),('pyGroup',''),('pyPayload',None),('pyStatusValue',None),('pyStatusValue',True),('pyRouterKey',{}),('pyStatusValue','Unknown'),('pyRouterKey','OK')]:
    check('Reject invalid '+field+' '+repr(value),lambda field=field,value=value:c.request('WriteMemory',args([dict(first,**{field:value})])),True)
for raw in ['{"pxResults":[],"pxResults":[]}','{bad','{"pxResults":[NaN]}','{"pxResults":[]}']:
    check('Reject invalid carrier '+raw,lambda raw=raw:c.request('WriteMemory',dict(call,RequestsJSON=raw)),True)
check('Duplicate composite keys rejected before mutation',lambda:c.request('WriteMemory',args([first,first])),True)

for route in ('OK','GENERATOR_REPAIR','SEMANTIC_REJECT','HUMAN'):
    value=dict(first,pyStatusValue='Passed' if route=='OK' else 'Failed',pyRouterKey=route)
    write=args([value]); snapshot=record(value)
    check('Route lifecycle '+route,lambda write=write,route=route:c.lifecycle_write(write,{'G001':opaque},{'G001':route}))
    check('Existing upsert preserves GUID '+route,lambda write=write,value=value,snapshot=snapshot:c.upserted_record(write,value,record(first),snapshot,'guid-1'))
    check('Absent key still creates complete lifecycle row '+route,lambda write=write,value=value,snapshot=snapshot:c.upserted_record(write,value,None,snapshot,'guid-1'))
passed=dict(first,pyStatusValue='Passed',pyRouterKey='OK')
check('Lifecycle cannot reserialize validated payload',lambda:c.lifecycle_write(args([dict(passed,pyPayload=opaque.strip())]),{'G001':opaque},{'G001':'OK'}),True)
check('Lifecycle cannot guess route for malformed report',lambda:c.lifecycle_write(args([passed]),{'G001':opaque},{'G001':None}),True)
check('Lifecycle cannot use another route',lambda:c.lifecycle_write(args([passed]),{'G001':opaque},{'G001':'HUMAN'}),True)
check('Lifecycle requires current payload evidence',lambda:c.lifecycle_write(args([passed]),{}, {'G001':'OK'}),True)
repair=pending(payload=' repaired complete payload\n')
check('Repair Pending request accepted',lambda:c.pending_write(args([repair])))
check('Repair replaces payload on same GUID',lambda:c.upserted_record(args([repair]),repair,record(passed),record(repair),'guid-1'))
check('Repeated run resets an existing Passed candidate',lambda:c.upserted_record(call,first,record(passed),record(first),'guid-1'))
check('Repair cannot inherit old Passed state',lambda:c.pending_write(args([dict(repair,pyStatusValue='Passed',pyRouterKey='OK')])),True)
for field,value in [('pyPayload',opaque),('pyStatusValue','Passed'),('pyRouterKey','OK'),('pyGUID','new-guid'),('pxCaseID','CASE-2'),('Type','ScenarioGroup'),('pyGroup','G002')]:
    changed=record(repair); changed[field]=value
    check('Reject non-atomic/identity mutation '+field,lambda changed=changed:c.upserted_record(args([repair]),repair,record(passed),changed,'guid-1'),True)
check('Existing record cannot get a replacement GUID',lambda:c.upserted_record(args([repair]),repair,record(passed),record(repair,guid='new'),'new'),True)

second=pending('G002','second'); batch=args([first,second])
success=[result('G002','guid-2'),result()]
check('Shuffled result rows correlate by group',lambda:expect(set(c.batch_response(batch,envelope(success))['results'])=={'G001','G002'}))
check('Known GUIDs confirmed on subsequent writes',lambda:c.batch_response(batch,envelope(success),{'G001':'guid-1','G002':'guid-2'}))
mixed=copy.deepcopy(success); mixed[0].update(Success=False,pyGUID='',ErrorCode='WRITE_FAILED',ErrorMessage='Injected failure')
check('Failed sibling does not erase valid success',lambda:expect(c.batch_response(batch,envelope(mixed))['results']['G001']['Success']))
bad_input=args([first,dict(second,pyPayload='')])
mixed[0]['ErrorCode']='INVALID_INPUT'
check('Row-invalid sibling can be correlated as failure',lambda:c.batch_response(bad_input,envelope(mixed)))
check('Row-invalid request cannot be claimed successful',lambda:c.batch_response(bad_input,envelope(success)),True)
for name,values in [('missing',success[:1]),('duplicate',success+[success[0]]),('unknown',[result('G003'),success[0]]),('same GUID',[result(),result('G002')]),('string Boolean',[dict(success[0],Success='true'),success[1]]),('success error',[dict(success[0],ErrorCode='WRITE_FAILED'),success[1]]),('empty success GUID',[dict(success[0],pyGUID=''),success[1]]),('failed retained GUID',[dict(mixed[0],pyGUID='guid-2'),mixed[1]]),('unknown error',[dict(mixed[0],ErrorCode='UPDATE_FAILED'),mixed[1]])]:
    check('Reject response '+name,lambda values=values:c.batch_response(batch,envelope(values)),True)
check('Recreated missing lifecycle record is not validated GUID',lambda:c.batch_response(call,envelope([result(guid='recreated')]),{'G001':'guid-1'}),True)
outer=envelope(success); outer.update(Success=False,ErrorCode='WRITE_FAILED',ErrorMessage='lost outcome')
check('Outer failure cannot promote embedded successes',lambda:expect(c.batch_response(batch,outer)=={'trusted':False,'results':{}}))
check('Malformed outer envelope cannot confirm writes',lambda:c.batch_response(call,{'Success':True}),True)

read={'pxCaseID':'CASE-1','Type':'UnitTestCandidate','pyGUID':'guid-1'}
got={'Success':True,**read,'pyGroup':'G001','pyPayload':opaque,'ErrorCode':'','ErrorMessage':''}
check('Exact GetMemory reads current payload',lambda:expect(c.get_response(read,'G001',got)==opaque))
check('Same GUID reads repaired current content',lambda:expect(c.get_response(read,'G001',dict(got,pyPayload=repair['pyPayload']))==repair['pyPayload']))
for field in ('pxCaseID','Type','pyGroup','pyGUID','pyPayload'):
    value='' if field=='pyPayload' else 'other'
    check('Reject read mismatch '+field,lambda field=field,value=value:c.get_response(read,'G001',dict(got,**{field:value})),True)
check('GetMemory does not gain lifecycle fields',lambda:c.get_response(read,'G001',dict(got,pyStatusValue='Passed')),True)
check('GetMemory does not accept group as address',lambda:c.request('GetMemory',{'pxCaseID':'CASE-1','Type':'UnitTestCandidate','pyGroup':'G001'}),True)
failed=dict(got,Success=False,ErrorCode='READ_FAILED',ErrorMessage='unavailable')
check('Failed read cannot release partial content',lambda:expect(c.get_response(read,'G001',failed) is None))

texts={name:(SRC/name).read_text() for name in ('Main_Agent_Prompt.txt','UnitTestGenerator_Prompt.txt','Validator_Prompt.txt','UnitTestGenerator.txt','JsonValidator_tool.txt')}
for name,content in texts.items():
    check('Retired tool/patch absent from '+name,lambda content=content:expect('UpdateMemory' not in content and 'pyUpdates' not in content),kind='SOURCE')
anchors={
 'Main_Agent_Prompt.txt':['(pxCaseID, Type, pyGroup)','no operation parameter','Returned GUIDs must be distinct','serializes the complete pipeline per case','Records omitted or failed in the current run'],
 'UnitTestGenerator_Prompt.txt':['Every later successful write for that group must return that same GUID','payload replacement and lifecycle reset are one atomic row update','exact locally retained payload bytes','maximum three Validator attempts','no WriteMemory retry','only confirmed GR OK rows from this invocation','never a cached or delayed response from an earlier attempt','different GUID, the Generator cannot confirm'],
 'Validator_Prompt.txt':['Cache no schema result, candidate payload or Validator report across invocations by GUID','Exact GUID equality alone cannot prove unchanged content','same exact UT pyGUID']}
for name,phrases in anchors.items():
    for phrase in phrases:
        check(name+' — '+phrase,lambda name=name,phrase=phrase:expect(phrase in texts[name]),kind='SOURCE')
for name in ('Main_Agent_Prompt.txt','UnitTestGenerator_Prompt.txt'):
    for stale in ('immutable UnitTestCandidate','new complete immutable candidate','new `pyGUID` and validate it','repaired candidate versions'):
        check(name+' omits obsolete '+stale,lambda name=name,stale=stale:expect(stale not in texts[name]),kind='SOURCE')

failed=[x for x in checks if x['status']=='FAIL']
print(json.dumps({'status':'PASS_LOCAL_CONTRACT' if not failed else 'FAIL','checks':checks,'checks_total':len(checks),'checks_passed':len(checks)-len(failed),'checks_failed':len(failed),'scope':'Read-only assertions with synthetic snapshots and final source checks. No external runtime or storage implementation.'},indent=2))
raise SystemExit(bool(failed))
