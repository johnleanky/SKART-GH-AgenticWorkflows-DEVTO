"""Read-only v7 package, source, document and evidence integrity checks."""
from pathlib import Path
import argparse
import hashlib
import json
import re

parser=argparse.ArgumentParser()
parser.add_argument('--governance',action='store_true')
args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def read(path):
    return json.loads((ROOT/path).read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def check(name,okay,detail=''):
    checks.append({'check':name,'status':'PASS' if okay else 'FAIL','detail':detail})

state=read('CURRENT_STATE.json')
summary=read('verification/VERIFICATION_SUMMARY_v7.json')
manifest=read('SOURCE_MANIFEST_v7.json')
receipt=read('verification/SOURCE_BUILD_RECEIPT.json')
register=read('CHANGE_REGISTER_v7.json')
hashes={p.name:sha(p) for p in sorted((ROOT/'sources').glob('*.txt'))}
check('Exactly 20 sources match manifest and current suite evidence',len(hashes)==20 and hashes==summary['source_sha256']=={x['name']:x['sha256'] for x in manifest['sources']})
changed={x['file'] for x in receipt['sources'] if x['changed']}
check('Only three prompts and two embedded configurations changed',changed=={'Main_Agent_Prompt.txt','UnitTestGenerator_Prompt.txt','Validator_Prompt.txt','UnitTestGenerator.txt','JsonValidator_tool.txt'} and hashes=={x['file']:x['sha256'] for x in receipt['sources']})
check('Fifteen other sources retained exactly',all(x['sha256']==x['baseline_sha256'] for x in receipt['sources'] if not x['changed']) and len(receipt['sources'])-len(changed)==15)
check('RuleCrawler reference bytes retained',hashes['Rule_Crawler_tool.txt']=='b64d64d924e5ee91faaeb85465f01657c9107303876f93df2a5b04d48ef901ac')
for suite in summary['suites']:
    report=read(suite['report'])
    rows=report['checks']
    check('Passing current evidence: '+suite['suite'],suite['status']=='PASS' and suite['checks_total']==suite['checks_passed']==len(rows) and bool(rows) and all(x['status']=='PASS' for x in rows))
check('Counts agree across state and summary',summary['status']=='PASS_LOCAL_CONTRACTS' and summary['checks_total']==summary['checks_passed']==state['checks_total']==state['checks_passed']==sum(x['checks_total'] for x in summary['suites']) and state['checks_failed']==summary['checks_failed']==0)
check('Scope excludes external implementation and runtime',state['working_scope']=='PROMPTS_AND_CONTRACTS_ONLY' and state['runtime_validation']=='NOT_EXECUTED' and state['github']=='NO_WRITES' and not state['external_implementation_changes'])
check('Ten v7 changes have local evidence',len(register['changes'])==10 and all(x['status']=='VERIFIED_LOCAL_CONTRACT' and x['evidence'] for x in register['changes']))
all_checks={x['check'] for s in summary['suites'] for x in read(s['report'])['checks'] if x['status']=='PASS'}
check('Change register points to actual passing checks',all(e in all_checks for x in register['changes'] for e in x['evidence']))
pinsets=[read('memory_contracts/SOURCE_AUTHORITY.json')['anchors']]
specmap=read('specification/SPEC_SOURCE_MAP.json')
pinsets += [x['anchors'] for x in specmap['source_map']]
check('All source map hashes, lines and text match',all(a['sha256']==hashes[a['file']] and a['text'] in (ROOT/'sources'/a['file']).read_text().splitlines()[a['line']-1] for anchors in pinsets for a in anchors))
spec=(ROOT/'specification/PEGA_IMPLEMENTATION_SPEC_v2.md').read_text()
examples=re.findall(r'```json\n(.*?)\n```',spec,re.S)
json_valid=True
try:
    for example in examples: json.loads(example)
except ValueError:
    json_valid=False
check('Specification JSON examples parse',json_valid and len(examples)==specmap['json_examples_parsed'])
cases=read('memory_contracts/ACCEPTANCE_CASES.json')
check('External cases explicitly unexecuted',cases['case_count']==specmap['memory_acceptance_cases']==len(cases['cases']) and cases['executed']==0 and all(x['status']=='NOT_RUN_EXTERNAL_BY_SCOPE' for x in cases['cases']))
check('Specification work and integration case inventory complete',specmap['work_items']==12==len(specmap['source_map']) and specmap['integration_acceptance_cases']==15==len(re.findall(r'^\| AT-\d+',spec,re.M)))
check('Active spec uses current contract and source paths',not any(x in spec for x in ('09_MEMORY_RUNTIME','07_V6_WORK','MEMORY_TOOL_CONTRACT_v1','SOURCE_MANIFEST_v6','Each write creates a new record','new immutable candidate','90 Memory contract checks')))
links=[]
for path in ROOT.rglob('*.md'):
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',path.read_text()):
        if not target.startswith(('http:','https:','#')):
            dest=target.split('#',1)[0]
            if dest and not (path.parent/dest).exists(): links.append({'file':str(path.relative_to(ROOT)),'target':target})
check('Local Markdown links resolve',not links,links)
check('Documents state Memory v2, key and source wire revision',state['memory_contract']=='v2' and state['unique_key']==['pxCaseID','Type','pyGroup'] and 'SG.version remains 1.4' in (ROOT/'README.md').read_text())
if not args.governance:
    package=read('PACKAGE_MANIFEST_SHA256.json')
    tracked={x['path']:x for x in package['files']}
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ('.DS_Store','PACKAGE_MANIFEST_SHA256.json')}
    check('Package inventory complete',set(tracked)==actual and len(tracked)==len(package['files']))
    mismatch=[name for name,row in tracked.items() if not (ROOT/name).is_file() or sha(ROOT/name)!=row['sha256'] or (ROOT/name).stat().st_size!=row['bytes']]
    check('Package SHA-256 and byte counts match',not mismatch,mismatch)
failed=[x for x in checks if x['status']=='FAIL']
print(json.dumps({'status':'PASS' if not failed else 'FAIL','checks_total':len(checks),'checks_passed':len(checks)-len(failed),'checks_failed':len(failed),'checks':checks,'failed':failed,'scope':'Local package integrity and evidence consistency; not external runtime validation.'},indent=2))
raise SystemExit(bool(failed))
