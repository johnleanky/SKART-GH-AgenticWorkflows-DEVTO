"""Build the v7 prompt/config contract delta from the preserved v6 sources.

No external implementation is edited or invoked. Re-running replaces v7 sources.
"""
from pathlib import Path
import difflib
import hashlib
import html
import json
import re

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / '07_V6_WORK/RuleIQ_v6/sources'
OUT = HERE / 'RuleIQ_v7/sources'
OUT.mkdir(parents=True, exist_ok=True)
texts = {p.name: p.read_text() for p in BASE.glob('*.txt')}
baseline = dict(texts)

def replace(file, old, new, count=1):
    assert texts[file].count(old) == count, (file, old, texts[file].count(old))
    texts[file] = texts[file].replace(old, new)

def block(file, start, end, value):
    content = texts[file]
    assert content.count(start) == content.count(end) == 1
    a, b = content.index(start), content.index(end)
    texts[file] = content[:a] + value.rstrip() + '\n\n' + content[b:]

M = 'Main_Agent_Prompt.txt'
G = 'UnitTestGenerator_Prompt.txt'
V = 'Validator_Prompt.txt'

replace(M, 'Never retry, delete, overwrite, or fabricate a GUID.',
        'Never retry, delete a record, or fabricate/change a GUID. WriteMemory replaces the payload at an existing composite key as specified below.')
replace(M, 'If zero ScenarioGroups were successfully persisted,', '''Memory contract v2: the unique record key is the exact tuple `(pxCaseID, Type, pyGroup)`. WriteMemory is an upsert with no operation parameter: absent key creates a record and server-generated opaque `pyGUID`; existing key replaces the supplied complete payload and preserves its `pyGUID`. Key components are separate exact strings, never a delimiter-concatenated lookup. The caller never supplies a GUID to WriteMemory. Returned GUIDs must be distinct across successful groups. The Author sends each frozen group once in this invocation and does not rewrite it after handoff. Pega serializes the complete pipeline per case, through downstream selection; a later run may replace the same group's stored payload. Records omitted or failed in the current run are not eligible merely because older Memory records remain.

If zero ScenarioGroups were successfully persisted,''')
replace(M, 'never calls GetMemory/UpdateMemory/Validator', 'never calls GetMemory/Validator')
replace(M, '`GetMemory`, `UpdateMemory`, `JsonValidationTool`', '`GetMemory`, `JsonValidationTool`')
replace(M, 'No row is retried, deleted, overwritten or fabricated.', 'No row is retried, deleted or fabricated; an existing composite key is updated by that one upsert.')
replace(M, '- UnitTestCandidate versions are addressed by their own new `pyGUID`; `pyGroup` remains lineage/correlation and never becomes an address.',
        '- UnitTestCandidate records use the unique `(pxCaseID, Type, pyGroup)` key for WriteMemory. Their `pyGUID` remains stable across repairs and is the exact GetMemory/A2A address; `pyGroup` alone is never a read address.')
replace(M, '- Generator owns candidate lifecycle UpdateMemory. Validator remains read-only.', '- Generator owns complete candidate and lifecycle WriteMemory upserts. Validator remains read-only.')
replace(M, 'It projects and persists one immutable UnitTestCandidate per physical `pyGroup`', 'It projects and upserts one current UnitTestCandidate per physical `pyGroup`')
replace(M, 'projects one immutable UnitTestCandidate per physical `pyGroup`, persists candidate versions', 'projects one current UnitTestCandidate per physical `pyGroup`, upserts initial and repaired payloads at the same key')
replace(M, 'one initial validation plus at most two repaired candidate versions', 'one initial validation plus at most two repaired candidates')

replace(G, '`pyGUID` is the canonical Memory address; `pyGroup` is lineage/correlation only.', '`pyGUID` is the canonical GetMemory/A2A address; `pyGroup` is also the group component of the composite WriteMemory key.')
replace(G, '| `WriteMemory(pxCaseID,Type,RequestsJSON)` | Persist complete immutable UnitTestCandidate versions; current calls use `Type="UnitTestCandidate"`. |\n| `UpdateMemory(pxCaseID,Type,RequestsJSON)` | Patch only lifecycle metadata of the exact current UnitTestCandidate; one attempt per transition, no retry. |',
        '| `WriteMemory(pxCaseID,Type,RequestsJSON)` | Upsert the complete current UnitTestCandidate and its lifecycle by `(pxCaseID, Type, pyGroup)`; no operation parameter, one attempt per write, no retry. |')
replace(G, 'For current Generator use, `UpdateMemory` may change only root metadata `pyStatusValue` and `pyRouterKey`; it must never change `pyGUID`, `pxCaseID`, `Type`, `pyGroup` or `pyPayload`.', '''Memory contract v2 keeps one current record for each exact `(pxCaseID, Type, pyGroup)` tuple. WriteMemory creates an absent record or updates an existing record, preserving the latter's `pyGUID`. A candidate row always supplies complete `pyPayload`, `pyStatusValue` and `pyRouterKey`; no operation, caller GUID or partial patch carrier is sent. Identity stays stable; a mechanical repair may replace candidate payload. Source ScenarioGroup bytes and semantic decisions remain frozen throughout this invocation. Pega must serialize the entire pipeline per case through downstream selection; the agent cannot establish that exclusion itself.''')
block(G, '### G8.1 Candidate WriteMemory', '### G8.2 Validator question and report', '''### G8.1 Candidate WriteMemory

For every group with one complete initial or repaired candidate, call batch-shaped:

`WriteMemory(pxCaseID=<GEN pxCaseID>, Type="UnitTestCandidate", RequestsJSON=<JSON string>)`

`RequestsJSON` decodes to `{"pxResults":[{"pyGroup":"G001","pyPayload":"<complete candidate JSON>","pyStatusValue":"Pending","pyRouterKey":""}]}`. Each row has exactly those four fields; a wave may contain N distinct groups. A candidate `pyPayload` contains exactly one `UnitTestRules` entry for that physical group. Every initial write, including a new run over an existing record, and every repair explicitly supplies `pyStatusValue="Pending"` and empty `pyRouterKey`; payload replacement and lifecycle reset are one atomic row update.

WriteMemory is one attempt per candidate write and is never retried. Validate outer `Success/ResultsJSON/ErrorCode/ErrorMessage`, then exact independent response rows `pyGroup/Success/pyGUID/ErrorCode/ErrorMessage` as in the Main batch contract. Response order is non-authoritative. The exact `(pxCaseID, Type, pyGroup)` tuple selects a record: absent means create with a server-generated GUID; present means replace the supplied payload and lifecycle while preserving the GUID. The first successful write in this invocation establishes the nonempty candidate GUID. Every later successful write for that group must return that same GUID; different groups require distinct GUIDs. An explicit failed row ends only that group as `CANDIDATE_WRITE_FAILED`. A missing, duplicate, malformed or unexpected known GUID result cannot establish success. A malformed/failing outer wave makes its outcomes unconfirmed. Do not fall back to an earlier payload or an older run's status. Keep the exact successfully written payload locally for the lifecycle write.

The GUID addresses the current record, not an immutable payload version. No record history is required by this contract. Do not reuse any previous validation result after a candidate write, even when the payload or GUID is unchanged.''')
replace(G, 'do not call UpdateMemory for that candidate', 'do not issue a lifecycle WriteMemory for that candidate')
replace(G, 'Call `UnitTestValidator(question=<exact text>)`. Never put candidate JSON/`pyPayload` in the question and never read UnitTestCandidate Memory yourself.', '''Call `UnitTestValidator(question=<exact text>)`. Never put candidate JSON/`pyPayload` in the question and never read UnitTestCandidate Memory yourself. Allow only one active validation invocation for a group's current payload; await its completion before writing lifecycle or a repair. Accept VR/VI only from that invocation's direct response, never a cached or delayed response from an earlier attempt with the same GUID. Every successfully written initial or repaired payload requires a fresh schema check and Validator invocation. Case serialization prevents other writers from replacing it during validation.''')
block(G, '### G8.3 Mandatory lifecycle UpdateMemory', '### G8.4 Per-group routes and repair budget', '''### G8.3 Mandatory lifecycle WriteMemory

Every valid `VR` requires exactly one complete lifecycle upsert before any next action:

`WriteMemory(pxCaseID=<GEN pxCaseID>, Type="UnitTestCandidate", RequestsJSON=<JSON string>)`

Each row contains exactly the same four fields as G8.1. Resend the exact locally retained payload bytes validated by the current invocation; change only the lifecycle pair:

```json
{"pyGroup":"G001","pyPayload":"<exact current candidate payload>","pyStatusValue":"Passed","pyRouterKey":"OK"}
```

For blocking routes use `pyStatusValue="Failed"` and `pyRouterKey` exactly `GENERATOR_REPAIR`, `SEMANTIC_REJECT` or `HUMAN`. Never rebuild, reformat or reserialize the payload during this lifecycle write. A subsequent mechanical repair is a separate complete Pending write under G8.1.

Its outer result must contain exact `Success` boolean plus string `ResultsJSON`, `ErrorCode`, `ErrorMessage`. Use the same row envelope, errors and group correlation as every WriteMemory call. On outer success, require empty outer errors and exactly one result per requested group. Successful rows require the group's already known candidate GUID and empty errors. Failed rows carry an empty GUID and a nonempty diagnostic with `INVALID_INPUT`, `UNSUPPORTED_TYPE` or `WRITE_FAILED`; siblings remain independent. Missing/duplicate/malformed results, a changed GUID, and outer failure or uncertain completion cannot confirm the affected lifecycle writes. There is **no WriteMemory retry** after explicit failure, malformed result or uncertain outcome. A group whose lifecycle write is not confirmed ends `FAILED/LIFECYCLE_UPDATE_FAILED` and performs no further repair. Upsert semantics do not authorize a retry or an assumption that the server rolled back.

The server uses only the composite key to decide insert versus update, including for lifecycle writes. It does not create a special update-only operation. If the record disappeared and this write recreated it with a different GUID, the Generator cannot confirm the validated record and fails that group.''')
replace(G, 'If fewer than two repaired candidate versions have already been written for that group, write a new complete immutable candidate with a new `pyGUID` and validate it.', 'If fewer than two repaired candidates have already been written for that group, upsert the complete repaired candidate at the same composite key and same `pyGUID`, atomically set Pending/empty router, and validate it again.')
replace(G, 'one initial Validator attempt plus at most two repaired candidate versions, maximum three Validator attempts.', 'one initial Validator attempt plus at most two repaired candidates, maximum three Validator attempts.')
replace(G, 'Every new version is rebuilt/audited', 'Every repaired payload is rebuilt/audited')
texts[G] = texts[G].replace('UpdateMemory', 'WriteMemory')
replace(G, 'invokes the five allowed interfaces.', 'invokes the four allowed interfaces. Downstream selection uses only confirmed GR OK rows from this invocation and checks the current Passed/OK state under case serialization; older successful records are not a fallback.')

replace(V, '`pyGUID` is the canonical candidate Memory address; `pyGroup` is correlation only.', '`pyGUID` is the stable candidate Memory address; `pyGroup` correlates this invocation and is a component of the WriteMemory key.')
replace(V, 'For each UT independently call exactly once:', '''A GUID may contain a repaired payload on a later invocation. Cache no schema result, candidate payload or Validator report across invocations by GUID. Pega must serialize writes for this case through validation and downstream selection; the same payload must remain stored from JsonValidationTool through GetMemory and this invocation's final response. Exact GUID equality alone cannot prove unchanged content without that serialization.

For each UT independently call exactly once:''')
replace(V, 'never calls UpdateMemory.', 'never calls WriteMemory.')

for config, prompt in [('UnitTestGenerator.txt', G), ('JsonValidator_tool.txt', V)]:
    encoded = '\n'.join('<p>' + html.escape(line, quote=False) + '</p>' for line in texts[prompt].splitlines())
    texts[config], n = re.subn(r'(<pySystemPrompt>).*?(</pySystemPrompt>)', lambda m: m[1] + encoded + m[2], texts[config], flags=re.S)
    assert n == 1
config = 'UnitTestGenerator.txt'
# This source export uses literal escaped newlines around its fourth tool row.
texts[config], n = re.subn(r'<rowdata REPEATINGINDEX="4">(?:\\n|\s)*<pxObjClass>Rule-AI-Tool</pxObjClass>(?:\\n|\s)*<pyPurpose>UpdateMemory</pyPurpose>(?:\\n|\s)*</rowdata>', '', texts[config])
assert n == 1

receipt = []
diff = []
for name, content in texts.items():
    if content == baseline[name]:
        # Preserve unchanged export bytes, including line endings.
        data = (BASE / name).read_bytes()
    else:
        data = content.encode()
        diff.extend(difflib.unified_diff(baseline[name].splitlines(True), content.splitlines(True), fromfile='v6/'+name, tofile='v7/'+name))
    (OUT / name).write_bytes(data)
    receipt.append({'file': name, 'changed': data != (BASE/name).read_bytes(), 'baseline_sha256': hashlib.sha256((BASE/name).read_bytes()).hexdigest(), 'sha256': hashlib.sha256(data).hexdigest()})
assert not any('UpdateMemory' in texts[n] or 'pyUpdates' in texts[n] for n in (M,G,V,config,'JsonValidator_tool.txt'))
verification = OUT.parent / 'verification'
(verification / 'SOURCE_BUILD_RECEIPT.json').write_text(json.dumps({'status':'BUILT_PENDING_VERIFICATION','sources':receipt}, indent=2)+'\n')
(verification / 'V6_TO_V7_SOURCE_DIFF.patch').write_text(''.join(diff))
print(json.dumps({'sources':len(receipt),'changed':[x['file'] for x in receipt if x['changed']]}))
