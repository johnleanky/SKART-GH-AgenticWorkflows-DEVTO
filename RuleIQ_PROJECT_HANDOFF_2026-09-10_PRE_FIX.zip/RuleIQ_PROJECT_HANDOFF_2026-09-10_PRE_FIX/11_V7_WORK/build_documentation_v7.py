"""Build English v7 specification/traceability from preserved v6 references."""
from pathlib import Path
import hashlib
import json
import re
HERE=Path(__file__).resolve().parent
ROOT=HERE/'RuleIQ_v7'; SRC=ROOT/'sources'; MEM=ROOT/'memory_contracts'; SPEC=ROOT/'specification'
base=(HERE.parent/'10_PEGA_IMPLEMENTATION_SPEC/PEGA_IMPLEMENTATION_SPEC.md').read_text()
contract=(MEM/'MEMORY_TOOL_CONTRACT_v2.md').read_text()
def section(text,start,end):
    assert text.count(start)==text.count(end)==1
    return text.split(start,1)[1].split(end,1)[0].strip()
prefix=base.split('## 4. Persistent Memory model',1)[0]
suffix='## 8. JsonValidationTool'+base.split('## 8. JsonValidationTool',1)[1]
sections=[
 ('## 4. Persistent Memory model — PI-04','## 1. Identity and ownership','## 2. WriteMemory request'),
 ('## 5. WriteMemory — PI-04\n\n### 5.1 Exact request and upsert behavior','## 2. WriteMemory request','## 3. WriteMemory response and failure handling'),
 ('### 5.2 Response, atomicity and failures','## 3. WriteMemory response and failure handling','## 4. GetMemory'),
 ('## 6. GetMemory — PI-05','## 4. GetMemory','## 5. Candidate lifecycle and repairs'),
 ('## 7. Lifecycle and orchestration — PI-06\n\n### 7.1 Candidate lifecycle and repairs through WriteMemory','## 5. Candidate lifecycle and repairs','## 6. Serialization, fresh validation and selection'),
 ('### 7.2 Case serialization and current-run selection','## 6. Serialization, fresh validation and selection','## 7. Migration and evidence')]
spec=prefix+''.join(title+'\n\n'+section(contract,start,end)+'\n\n' for title,start,end in sections)+suffix
def replace(old,new,count=1):
    global spec
    assert spec.count(old)==count,(old,spec.count(old))
    spec=spec.replace(old,new)
replace('**Version:** 1.0','**Version:** 2.0')
replace('**Contract baseline:** RuleIQ v6; ScenarioGroup wire revision 1.4','**Contract baseline:** RuleIQ v7; Memory contract v2; ScenarioGroup wire revision 1.4')
replace('Validator checks the exact persisted candidate. Memory stores immutable payloads and separately\nupdates permitted lifecycle metadata.', 'Validator checks the current persisted candidate under case serialization. Memory upserts one\nrecord per exact `(pxCaseID, Type, pyGroup)` combination and preserves its GUID on updates.')
replace('One physical `pyGroup` produces one candidate version containing exactly one `UnitTestRules`', 'One physical `pyGroup` has one current candidate record containing exactly one `UnitTestRules`')
replace('**Minimum Pega work:** adapt WriteMemory and GetMemory to the current contract; provide\nUpdateMemory;', '**Minimum Pega work:** implement composite-key WriteMemory upserts and retain exact GetMemory;\nserialize pipelines per case;')
replace('| PI-04 | WriteMemory | Implement the shared batch write interface and immutable version creation. | Independent row outcomes, new GUIDs, exact payloads, Pending initialization. |', '| PI-04 | WriteMemory | Upsert complete records by the unique case/type/group combination. | Create when absent, retain GUID on update, atomic payload/lifecycle writes and independent rows. |')
replace('| PI-06 | UpdateMemory | Implement permitted shallow root metadata patches on existing records. | Protected fields unchanged; independent row outcomes; confirmed lifecycle writes. |', '| PI-06 | Lifecycle and orchestration | Route all writes through WriteMemory; serialize the complete pipeline per case. | Fresh validation after each payload write, same-GUID repairs, current-run selection, no stale reports. |')
replace('Different candidate versions cannot be substituted; valid/invalid/tool-error results differ.', 'Current payload stays unchanged throughout schema/read validation; valid/invalid/tool-error results differ.')
replace('WriteMemory for UnitTestCandidate, UpdateMemory for candidate lifecycle', 'WriteMemory for complete UnitTestCandidate and lifecycle upserts')
replace('SOURCE_MANIFEST_v6.json','SOURCE_MANIFEST_v7.json',2)
replace('SG.version intentionally remains **1.4** under accepted D-003, even though v6 changes canonical\nDP_SIG and informational grouping keys. A version value of 1.4 alone is not sufficient to prove\ncompatibility. Track the v6 source manifest/release revision during configuration.', 'SG.version remains **1.4**. The v6 semantic/DP_SIG corrections are retained; v7 changes the Memory\ninterface and candidate record lifecycle. A wire value of 1.4 alone does not prove compatibility.\nTrack both the v7 source manifest and Memory contract v2 during configuration.')
replace('Do not normalize old persisted ScenarioGroups or candidate payloads in place. Preserve them\nas history; use newly generated groups/candidates under the consistent v6 configuration.\nDo not attach a v6 Generator to an older incompatible source payload and infer an upgrade.', '''The earlier contract permitted multiple GUIDs for the same case/type/group. Before activating
v2 uniqueness, inventory such duplicates and use an explicit Pega-owned migration mapping or
a clean isolated test scope. Preserve old data outside the active keyed set where required.
Do not silently select the latest record or delete duplicates. This package executes no migration.
New runs author fresh v7-compatible ScenarioGroups and upsert them; never reinterpret older
payloads or old Passed status as proof for the current run. Within a run, freeze source semantics.
Remove the retired lifecycle tool binding from Generator. Deploy the new complete candidate
row shape with the matching prompts; old two-field candidate writes are not compatible.''')
replace('1. Establish exact Memory write/read/update interfaces and persistent canonical fields.', '1. Establish the composite key, unique enforcement, complete WriteMemory rows, GetMemory and case serialization.')
replace('6. Adjust an existing candidate-to-unit-test consumer for informational outcomes.', '6. Restrict selection to current invocation GR OK rows under the case guard, and preserve informational outcomes.')
replace('one candidate/version, schema/read validation','one current candidate, fresh schema/read validation')
replace('Failed, malformed or uncertain UpdateMemory result','Failed, malformed or uncertain lifecycle WriteMemory result')
spec=re.sub(r'\| AT-10 \|[^\n]+','| AT-10 | Two repairs followed by a valid third attempt | At most three Validator attempts; one candidate GUID; each repair atomically replaces payload and resets Pending; every attempt revalidated. |',spec)
spec=spec.replace('v6 prompt/content set','v7 prompt/content set').replace('The v6 source set','The v7 source set')
replace('Use the 24 detailed Memory cases in ACCEPTANCE_CASES.json from the companion contract package.\nThey cover 20 external-service cases and four caller failure/no-retry cases. Additionally:', 'Use the detailed cases in [ACCEPTANCE_CASES.json](../memory_contracts/ACCEPTANCE_CASES.json).\nThey cover service upserts, identity, atomicity, fresh validation, serialization and caller failures.\nThey are requirements, not executed runtime evidence. Additionally:')
replace("record's confirmed Passed/OK lifecycle **and** an executable candidate with RuleCode. It must", "record's confirmed Passed/OK lifecycle **and** an executable candidate with RuleCode. Select only\nGUIDs from this invocation's confirmed GR OK rows while holding the case guard; do not scan\nall previously Passed records. Read/materialize current content before allowing another run. It must")
replace('Publish the semantic KnowledgeAreas from the v6 `sources` files', 'Publish the semantic KnowledgeAreas from the v7 `sources` files')
replace('included as new implementation files in the v6 package.', 'included as new implementation files in the v7 package.')
replace('| AT-13 | Wrong case, type, group or candidate version | No unintended read/update/validation or fallback to another record. |', '| AT-13 | Wrong case/type/group/GUID or stale same-GUID response | No unintended read or validation; writes use the exact composite key and only the active invocation can authorize lifecycle. |')
replace('The existing 598 local v6 checks and 90 Memory contract checks validate source contracts,\nschemas, fixtures and assertion logic. They do not establish external implementation readiness.\nC-027/C-028/C-029 remain external until actual implementation acceptance is complete.', 'The current local suite checks source contracts, schemas, fixtures and synthetic upsert evidence.\nSee ../verification/VERIFICATION_SUMMARY_v7.json for actual counts and source hashes. These\nchecks do not establish external implementation readiness. Earlier C-027/C-028/C-029 runtime\nobligations are superseded by this v2 specification and remain external acceptance work.')
handover='''## 14. Source package and handover

This self-contained v7 package includes:

- [Source manifest](../SOURCE_MANIFEST_v7.json) and `../sources/` — current prompts, schemas, knowledge and readable configuration exports.
- [Memory contract v2](../memory_contracts/MEMORY_TOOL_CONTRACT_v2.md) — normative upsert and read boundary.
- [Memory acceptance cases](../memory_contracts/ACCEPTANCE_CASES.json) — external requirements, not runtime results.
- [Read-only assertions](../memory_contracts/memory_contract.py) and [source pins](../memory_contracts/SOURCE_AUTHORITY.json).
- [Change register](../CHANGE_REGISTER_v7.json) — the v6-to-v7 decision and verification scope.

Pega implementation handover should identify the rules/configuration used for PI-01–PI-12,
document actual wrapper mappings and stable service error codes, and attach acceptance evidence.
Storage class names, ruleset versions, deployment tooling and environment settings must come
from the target application; none is invented by this specification.
'''
spec=spec.split('## 14. Source package and handover',1)[0]+handover
SPEC.mkdir(exist_ok=True)
(SPEC/'PEGA_IMPLEMENTATION_SPEC_v2.md').write_text(spec)
cases=[
 ('SERVICE','Create ScenarioGroup','An absent exact key creates one record and a new opaque GUID; payload round-trips unchanged.'),
 ('SERVICE','Upsert existing ScenarioGroup','The same tuple updates payload on the same GUID without another active record.'),
 ('SERVICE','Create candidate Pending','A complete candidate row persists Pending and empty router exactly.'),
 ('SERVICE','Reset existing candidate for a new run','Existing Passed/Failed record is atomically replaced with complete payload and Pending/empty router; GUID stays stable.'),
 ('SERVICE','Repair at same key','Repaired payload replaces current candidate on same GUID with Pending/empty router in one commit.'),
 ('SERVICE','Complete lifecycle row on absent key','Absent key creates supplied complete record and lifecycle; no update-only switch or hidden missing-record exception.'),
 ('SERVICE','Case isolation','Same Type/group in two cases has independent records and GUIDs.'),
 ('SERVICE','Type isolation','ScenarioGroup and UnitTestCandidate in the same case/group remain distinct.'),
 ('SERVICE','Group isolation','Two groups in one case/type receive distinct stable GUIDs.'),
 ('SERVICE','Opaque strings and delimiter collision','Whitespace, case, Unicode and delimiters remain exact; concatenation collisions cannot alias different tuples.'),
 ('SERVICE','Complete row validation','Missing payload/lifecycle, extra operation/GUID/patch/path fields, nulls and inconsistent pairs fail without mutation.'),
 ('SERVICE','Duplicate batch key','Reject an ambiguous duplicate-key batch before mutation; order never decides a winner.'),
 ('SERVICE','Atomic rejected row','An invalid row cannot partly overwrite existing payload/status/router.'),
 ('SERVICE','Independent partial failure','A valid row remains committed when a correlatable sibling is rejected.'),
 ('SERVICE','Shuffled response','One exact result per group; retained/created GUIDs correlate by group; failures use empty GUID.'),
 ('SERVICE','Exact read ownership','GetMemory rejects missing GUID and wrong case/type; no group/latest fallback.'),
 ('SERVICE','Read repaired current content','Stable GUID reads latest committed payload, without lifecycle fields in the public eight-field response.'),
 ('SERVICE','Cross-request durability','Separate request/requestor observes exact committed row after successful upsert.'),
 ('SERVICE','Concurrent insertion','Uniqueness and atomic upsert yield one active record and stable address; no duplicate key records.'),
 ('ORCHESTRATION','Overlapping case runs','Second run queued/rejected before writes; other cases proceed. All writers and selection honor the case guard.'),
 ('ORCHESTRATION','Schema/read snapshot interval','A competing write between schema validation and GetMemory is blocked until active chain completes selection.'),
 ('CALLER','Fresh validation','Initial and repaired writes get fresh schema checks and Validator invocations even with same GUID or equal payload.'),
 ('CALLER','All lifecycle routes','Direct valid route sends exact retained payload and matching pair; lifecycle write is separate from repaired Pending write.'),
 ('CALLER','Stale same-GUID report','Only currently awaited invocation response is accepted; cached/delayed previous-attempt output cannot approve current content.'),
 ('CALLER','Malformed Validator result','Zero lifecycle writes, Pending retained, VALIDATOR_RESPONSE_INVALID; no invented Failed/HUMAN.'),
 ('CALLER','Explicit failed lifecycle write','One write attempt, LIFECYCLE_UPDATE_FAILED, no retry/repair, no GR OK.'),
 ('CALLER','Malformed lifecycle result','Malformed/unknown/duplicate result cannot confirm success; no retry/repair for unconfirmed group.'),
 ('CALLER','Response lost after commit','Snapshot may show commit, but caller has no confirmed result and does not retry, repair or report GR OK.'),
 ('CALLER','Changed known GUID','Recreated key on lifecycle/repair returns a new GUID and fails the stage; it is not the validated known record.'),
 ('CALLER','Per-group repair limit','Initial plus two repairs at most; maximum three Validator attempts, stable GUID per group and independent budgets.'),
 ('CONSUMER','Exclude absent/failed groups','Older Passed records, orphan groups and current failures excluded; current GR OK allowlist and protected selection mandatory.'),
 ('CONSUMER','Informational result','Passed/OK without RuleCode remains information; no empty runnable test.'),
 ('MIGRATION','Existing duplicate keys','Mapping or clean isolated scope established before uniqueness; no automatic latest selection, deletion or old-payload upgrade.')]
rows=[]
for i,(kind,title,expected) in enumerate(cases,1):
    evidence=['Exact request/response trace with invocation attribution','Independent before/after canonical record projection']
    if kind in ('ORCHESTRATION','CALLER','CONSUMER'):
        evidence+=['Ordered current-run tool/selection trace and case-guard evidence']
    rows.append({'id':f'MU-{i:02}','kind':kind,'title':title,'expected':expected,'required_evidence':evidence,'status':'NOT_RUN_EXTERNAL_BY_SCOPE'})
(MEM/'ACCEPTANCE_CASES.json').write_text(json.dumps({'contract':'Memory v2','case_count':len(rows),'executed':0,'scope':'External acceptance specification only.','cases':rows},indent=2)+'\n')
def anchor(file,phrase):
    path=SRC/file
    hits=[i for i,line in enumerate(path.read_text().splitlines(),1) if phrase in line]
    assert hits,(file,phrase)
    return {'file':file,'text':phrase,'line':hits[0],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
pins={
 'Main_Agent_Prompt.txt':['Memory contract v2:','Returned GUIDs must be distinct','never calls GetMemory/Validator'],
 'UnitTestGenerator_Prompt.txt':['Memory contract v2 keeps one current record','payload replacement and lifecycle reset','Every later successful write','exact locally retained payload bytes','There is **no WriteMemory retry**','maximum three Validator attempts','only confirmed GR OK rows from this invocation'],
 'Validator_Prompt.txt':['Cache no schema result','same exact UT pyGUID','Validator never repairs or writes/updates Memory']}
(MEM/'SOURCE_AUTHORITY.json').write_text(json.dumps({'contract':'Memory v2','source_root':'../sources','authority':'User-selected single WriteMemory upsert without operation discriminator, keyed by unique combination; active v7 prompts.','anchors':[anchor(file,p) for file,phrases in pins.items() for p in phrases]},indent=2)+'\n')
work={
 'PI-01':[('Main_Agent_Prompt.txt','## 1A.')],
 'PI-02':[('UnitTestGenerator_Prompt.txt','## G1.'),('UnitTestGenerator.txt','<pzKnowledgeTools')],
 'PI-03':[('Validator_Prompt.txt','## V1.'),('JsonValidator_tool.txt','<pzKnowledgeTools')],
 'PI-04':[('Main_Agent_Prompt.txt','Memory contract v2:'),('UnitTestGenerator_Prompt.txt','### G8.1')],
 'PI-05':[('UnitTestGenerator_Prompt.txt','## G2.'),('Validator_Prompt.txt','## V3.')],
 'PI-06':[('UnitTestGenerator_Prompt.txt','### G8.3'),('Validator_Prompt.txt','Cache no schema result')],
 'PI-07':[('Validator_Prompt.txt','JsonValidationTool(CaseID=<VAL')],
 'PI-08':[('UnitTestGenerator_Prompt.txt','## G3.')],
 'PI-09':[('Main_Agent_Prompt.txt','GetCaseData.TestedRuleKey, and RuleJSON')],
 'PI-10':[('Rule_Crawler_tool.txt','InterestedRules'),('Main_Agent_Prompt.txt','120')],
 'PI-11':[('UnitTestGenerator_Prompt.txt','## G9.'),('UnitTestGenerator_Prompt.txt','only confirmed GR OK')],
 'PI-12':[('Main_Agent_Prompt.txt','SG.version remains 1.4'),('UnitTestGenerator_Prompt.txt','Memory contract v2 keeps')]}
examples=re.findall(r'```json\n(.*?)\n```',spec,re.S)
for example in examples: json.loads(example)
(SPEC/'SPEC_SOURCE_MAP.json').write_text(json.dumps({'status':'SPECIFICATION_READY','language':'English','baseline':'RuleIQ v7 / Memory v2 / ScenarioGroup 1.4','work_items':len(work),'integration_acceptance_cases':len(re.findall(r'^\| AT-\d+',spec,re.M)),'memory_acceptance_cases':len(rows),'json_examples_parsed':len(examples),'source_root':'../sources','source_map':[{'requirement':key,'anchors':[anchor(*a) for a in values]} for key,values in work.items()]},indent=2)+'\n')
(MEM/'README.md').write_text('''# Memory contracts v2

Read [MEMORY_TOOL_CONTRACT_v2.md](MEMORY_TOOL_CONTRACT_v2.md) for the current two-tool
interface. [ACCEPTANCE_CASES.json](ACCEPTANCE_CASES.json) lists external requirements;
none were run against Pega. `memory_contract.py` only asserts supplied request/response
and snapshot evidence and has no storage implementation.

Local results: `../verification/MEMORY_UPSERT_VERIFICATION_v7.json`. Run
`python3 ../verification/verify_memory_upsert_v7.py` from this directory for the
standard-library checks. Server serialization and caller sequencing require actual
external traces; synthetic checks do not establish runtime compliance.
''')
(SPEC/'README.md').write_text('''# Pega implementation specification v2

[PEGA_IMPLEMENTATION_SPEC_v2.md](PEGA_IMPLEMENTATION_SPEC_v2.md) defines the external
team's required work. SPEC_SOURCE_MAP.json pins its source references. This package
includes Memory v2 and exact v7 prompt/config sources. No Pega implementation was changed.
''')
print(json.dumps({'memory_cases':len(rows),'integration_cases':len(re.findall(r'^\| AT-\d+',spec,re.M)),'json_examples':len(examples),'work_items':len(work)}))
