# Full-project cross-reference audit v2

29/29 findings closed at the local contract level. 598/598 source/schema/fixture/model checks pass.
Runtime was not executed; C-027/C-028/C-029 remain EXTERNAL_PENDING.
Detailed evidence: CHANGE_REGISTER_v6.json and verification/VERIFICATION_SUMMARY_v6.json.

| Finding | Correction | Evidence |
|---|---|---|
| FP-001 | Restored the exact intended crawler blob, with SHA-256, Git blob identity and scope provenance. | HASH |
| FP-002 | Require case id, TestedRuleKey and full RuleJSON identity before acquisition; reject identity mismatch. | MODEL, SOURCE |
| FP-003 | Active Author gates operate on immutable semantic decisions; physical projection references are explicitly downstream. | SOURCE, XML |
| FP-004 | WHEN DecisionInput/DecisionResult formation is EXECUTABLE-only; informational outcomes carry OMIT/GAP. | SOURCE |
| FP-005 | Closed informational compiler/storage path uses zero ASSERT/SIM and Low/Blocked with terminal proof, without a mock or DPA success. Preserve actual evidenced coverage; isolate each informational WHEN by its frozen S id. | MODEL, SCHEMA, SOURCE |
| FP-006 | Infeasible WHEN rows are excluded from executable columns but preserved as separate informational outcomes. | MODEL, SOURCE |
| FP-007 | Informational Generator path skips G5/G6 physical RuleCode projection and proceeds to G7. | SOURCE, XML |
| FP-008 | Generator classifies mode before knowledge acquisition: schema only for information, full structural knowledge for executable groups, with per-dependent-group failures. | MODEL, SOURCE, XML |
| FP-009 | Validator finalizes an informational UT locally, continues siblings, then emits all results once. | MODEL, SOURCE, XML |
| FP-010 | Both real schemas and Validator require informational Low confidence and Blocked closure, including required fields. | MODEL, SCHEMA, SOURCE, XML |
| FP-011 | Schema descriptions follow conditional RuleCode and one-candidate cardinality; Main downstream indexing uses the sole UnitTestRules[0]. | SCHEMA, SOURCE |
| FP-012 | Confirmed Model WHEN condition field pyPropertiesName is used in all relevant mappings. | SOURCE |
| FP-013 | Confirmed formal field pyParametersParamType and raw STRING are supported without losing original spelling. | SOURCE |
| FP-014 | Raw thread scope is retained and compared as Thread; unsupported scope values are not generalized. | SOURCE |
| FP-015 | Concrete pyLabel is a last-resort behavior source only when stronger sources are empty and the label is unambiguous. | SOURCE |
| FP-016 | Simulated Data Page loader traversal stops at the accepted boundary; caller, metadata, parameters and independent references still require evidence. | SOURCE |
| FP-017 | Required Model owner outcomes include terminal false edges that suppress observable modifying producers. | SOURCE |
| FP-018 | APPEND_AND_MAP_TO appends a new target, reads relative RHS from the configured existing source, writes children into the new target and copies only mapped fields. | MODEL, SOURCE |
| FP-019 | Simulation carrier/depth and items remain witness-locked, while closed executable dependencies may require leaves inside those items. | SOURCE |
| FP-020 | One omission reason catalog includes incorrect_candidate_assertion across producer and consumer contracts. | SOURCE |
| FP-021 | Owner coverage outputs include APPEND_AND_MAP_TO and modifying operations defined by the active knowledge area. | SOURCE |
| FP-022 | Direct SET payload derives from its own RHS; composite payload may include only grounded descendant mappings in its target structure. | SOURCE |
| FP-023 | Non-execution accepts terminal control-flow exclusion, including an actually executed prior EXIT; UNKNOWN guards do not become guessed false guards. | SOURCE, XML |
| FP-024 | PROFILE provenance is per binding kind: property, formal parameter, named-page context, or owning collection property plus execution evidence. | SOURCE, XML |
| FP-025 | DEP.kind exactly matches authoritative canonical identity, including When/DTable/Model/Prop/RUF/DP; aliases are forbidden and RUF has empty class. SG.version stays 1.4 per D-003. | MODEL, SOURCE, XML |
| FP-026 | SCAN retains all READY occurrences; OUT and actual requests deduplicate exact keys in stable order, then fan out evidence while retaining each occurrence context. | MODEL, SOURCE |
| FP-027 | Canonical typed JSON specifies exact decimal, Unicode, ordering, root shapes and absence semantics. Only concrete accesses have DP_SIG; unresolved crawl access identity remains its D occurrence. Examples migrate SIM.sig without changing RuleCode. | FIXTURE, MODEL, SCHEMA, SOURCE, XML |
| FP-028 | Retain the already selected conservative omission/gap policy for unknown initial presence. A skipped write alone proves neither presence nor absence. | MODEL, SOURCE |
| FP-029 | Current audit, register, matrix, state, ledger and manifest are regenerated from v6 evidence; old certifications are explicitly historical and runtime work stays external. | GOVERNANCE |
