# RuleIQ v6 — locally verified prompt and contract corrections

This is the current set of 20 source files after corrections FP-001 through FP-029.
Current authority: CURRENT_STATE.json and CHANGE_REGISTER_v6.json. Historical
VERIFIED_LOCAL/PASS labels in verification/historical_v5/ describe earlier checkpoints.
All current documentation and future authored content must be in English.

Scope is prompts and contracts only. External Memory, RuleCrawler and other tool
implementations are maintained separately. This workspace does not change or deploy
those implementations, and live Pega access is not required for its contract work.

All 598 local checks passed: 86 architecture checks, 49 RISK-001 checks, 84 example
checks, 212 MultInpComb checks and 167 new source/schema/XML/local-model checks.
The matrix contains 28 reviewed cases with explicitly classified evidence. These
are not 28 Pega executions; deployed LLM agents and Memory were not run.

Corrections cover informational NotTestable without RuleCode or SIM; Main,
Generator and Validator ownership; KnowledgeTool modes; Low/Blocked schema rules;
confirmed Model/Data Page fields; append/map contexts; false-edge coverage;
provenance; DEP.kind; request deduplication; and exact canonical JSON for DP_SIG
and scenario snapshots. Existing example RuleCode objects are unchanged; only
SIM.sig signatures migrated. See the register and
verification/V5_TO_V6_SOURCE_DIFF.patch for the complete source changes.

SG.version remains 1.4 under accepted D-003. The canonical DP_SIG and informational
key formats changed, so Main, Generator, Validator, embedded prompts, schemas and
related examples form one coordinated contract set. The manifest identifies this
revision more precisely than the 1.4 wire number. The external integration must
preserve old persisted payloads and produce new immutable groups/candidates;
consumers must not silently normalize old payloads in place.

sources/Rule_Crawler_tool.txt preserves the exact reference Git blob. It is the
lower-level ResolveCrawlerBatch export, not the complete LLM-visible RuleCrawler
wrapper. It is reference evidence for contract review, not an implementation target
for this workspace.

To verify an extracted package (checked with Python 3.12):

```sh
python3 verification/verify_package_v6.py
python3 -m venv /tmp/ruleiq-v6-venv
/tmp/ruleiq-v6-venv/bin/python -m pip install -r verification/requirements.txt
/tmp/ruleiq-v6-venv/bin/python verification/run_all_v6.py
```

The first command checks the manifest using the standard library. The other
commands regenerate local verification reports. Some report paths may change,
so check package integrity before rerunning them. Verification evidence is pinned
to source hashes in verification/VERIFICATION_SUMMARY_v6.json.

See NEXT_STEPS.md for current prompt/contract work. C-027/C-028/C-029 retain their
EXTERNAL_PENDING implementation status; the companion Memory specification closes
only their contract stage. No GitHub writes or Pega deployment were performed.
