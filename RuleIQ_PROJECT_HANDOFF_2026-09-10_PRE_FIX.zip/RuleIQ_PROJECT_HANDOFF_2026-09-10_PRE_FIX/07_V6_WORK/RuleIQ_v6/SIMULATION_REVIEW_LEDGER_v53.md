# Simulation review ledger — checkpoint 53

Date: 2026-09-10. Baseline: immutable v5 pre-fix handoff.
Previous accepted decisions and full history: verification/historical_v5/SIMULATION_REVIEW_LEDGER_v52.md.
This checkpoint supersedes v5 completion claims; it does not rewrite historical bytes.

FP-001–FP-029 are VERIFIED_LOCAL_CONTRACT after source verification and package
governance checks passed. Final SHA-256/ZIP checks are in the release receipt.
Current status is CURRENT_STATE.json / CHANGE_REGISTER_v6.json.

Decisions preserved: Model WHEN pyPropertiesName; formal pyParametersParamType
including raw STRING; thread scope alias; strict pyLabel fallback; simulated loader
boundary; canonical DEP.kind with unchanged SG.version 1.4 (D-003); conservative
skipped-output omission/gap policy already selected by the pre-fix handoff plan.

New contract details: informational WHEN group identity follows its frozen S id;
terminal informational outcomes remain materializable with gaps and zero ASSERT/SIM;
known execution coverage is preserved, blocked execution never becomes achieved
coverage. Canonical given/simulation sorting happens before S ids, so grouping does
not feed back into scenario ordering. DP_SIG describes only resolved concrete maps.
No silent in-place conversion of persisted sources is permitted.

Independent regression results: 598/598 local checks.
The 28-case matrix distinguishes source review, real schema/fixture validation and
synthetic local model runs. No Pega/LLM execution is claimed. Existing example
RuleCode objects are unchanged; the legacy SIM signature assertion was replaced
by actual canonical key/params validation in verify_example_alignment_v4.py.

C-027/C-028/C-029 remain EXTERNAL_PENDING. Exact crawler provenance is recorded,
but wrapper integration remains unexecuted. GitHub writes: none. no-mistakes was
not used for this implementation, following the user's instruction.
