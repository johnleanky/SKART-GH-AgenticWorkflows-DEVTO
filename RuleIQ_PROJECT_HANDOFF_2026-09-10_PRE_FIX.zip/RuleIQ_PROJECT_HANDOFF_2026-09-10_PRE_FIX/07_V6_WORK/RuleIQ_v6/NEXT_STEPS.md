# Next steps — prompts and contracts only

The user confirmed that external implementations remain separate. Current work
covers prompts, schemas, knowledge content, interface contracts and their local
verification. All deliverables and communication are in English.

1. Review the LLM-visible RuleCrawler contract in Main and the relevant KnowledgeAreas.
   Use the unchanged ResolveCrawlerBatch export only as reference evidence. Identify
   any missing wrapper mapping or conflicting prompt expectation; do not rewrite
   or deploy the crawler implementation.
2. Reconcile cross-agent request, response, identity, grouping and failure contracts.
   Preserve the single-question A2A interfaces, exact GUID reads, independent group
   outcomes and the existing no-retry rules.
3. Correct any confirmed prompt/contract contradiction in its authoritative source.
   Synchronize affected embedded prompts and update schemas/examples only when their
   contracts change. Keep external tool implementations outside the change set.
4. Run the checks relevant to changed contracts. Distinguish source review, schema
   fixtures and local assertion/model checks from actual external runtime evidence.
5. Update the current register, ledger and package manifests with traceable evidence.
   Keep C-027/C-028/C-029 implementation status EXTERNAL_PENDING; their Memory
   contract specification and local checks are maintained in the companion package.

The external Pega team's implementation requirements are described in the separate
Pega Implementation Specification. That document is a handover specification, not
an instruction to modify external systems from this workspace.

Completion for this workspace means consistent prompts/contracts, passing applicable
local checks, synchronized artifacts and accurate evidence labels. It does not
require Pega access, external deployment or proof of live storage behavior.
