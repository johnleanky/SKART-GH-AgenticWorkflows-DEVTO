#!/usr/bin/env python3
"""Read-only release governance and SHA-256 integrity checks (standard library)."""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json

parser = argparse.ArgumentParser()
parser.add_argument('--preflight', action='store_true', help='Allow only FP-029 to await package verification.')
parser.add_argument('--governance', action='store_true', help='Check governance before generating the file manifest.')
args = parser.parse_args()
ROOT = Path(__file__).resolve().parents[1]
checks = []

def ck(name, okay, detail=''):
    checks.append({'check': name, 'status': 'PASS' if okay else 'FAIL', 'detail': detail})

def read(relative):
    return json.loads((ROOT / relative).read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

state = read('CURRENT_STATE.json')
register = read('CHANGE_REGISTER_v6.json')
audit = read('FULL_PROJECT_CROSS_REFERENCE_AUDIT_v2.json')
matrix = read('FULL_PROJECT_SIMULATION_MATRIX_v2.json')
summary = read('verification/VERIFICATION_SUMMARY_v6.json')
source_manifest = read('SOURCE_MANIFEST_v6.json')
expected_ids = [f'FP-{n:03}' for n in range(1, 30)]
ck('All 29 current findings retained exactly once', [x['id'] for x in register['findings']] == expected_ids)
ck('Audit and register agree', audit['findings'] == register['findings'])
ck('Only final statuses or FP-029 preflight are allowed', all(
    x['status'] == 'VERIFIED_LOCAL_CONTRACT' or
    (args.preflight and x['id'] == 'FP-029' and x['status'] == 'APPLIED_PENDING_PACKAGE_VERIFICATION')
    for x in register['findings']))
ck('State finding counts are derived from the current register',
   state['finding_status_counts'] == dict(Counter(x['status'] for x in register['findings'])))
ck('Current state and register have matching completion status', state['status'] == register['status'] == audit['status'])
legacy = register['legacy_changes']
ck('Historical C records preserved, not blanket-recertified', len(legacy) == 77 and
   len({x['change_id'] for x in legacy}) == 77 and
   all(x['status'] == 'HISTORICAL_SUPERSEDED' for x in legacy if x['change_id'] not in state['deferred']))
ck('Exactly three deferred Memory contracts remain', state['deferred'] == ['C-027', 'C-028', 'C-029'] and
   [x['change_id'] for x in legacy if x['status'] == 'EXTERNAL_PENDING'] == state['deferred'])
ck('Runtime and remote scope are explicit', state['runtime_validation'] == 'NOT_EXECUTED' and
   state['github'] == 'NO_WRITES' and not register['github_writes'] and
   all(not x['runtime_executed'] for x in matrix['simulations']))
ck('All 28 reviewed cases retained exactly once',
   [x['id'] for x in matrix['simulations']] == [f'SIM-{n:02}' for n in range(1, 29)])
ck('Matrix counts are factual and never UNKNOWN placeholders',
   matrix['simulation_status_counts'] == state['simulation_status_counts'] ==
   dict(Counter(x['result'] for x in matrix['simulations'])) and
   sum(matrix['simulation_status_counts'].values()) == state['simulations_total'] == 28 and
   all(x['result'].startswith('PASS_') and x['trace'] for x in matrix['simulations']))

reports = {}
for row in summary['suites']:
    data = read(row['report']); reports[row['report']] = data
    records = data['checks']
    ck('Current suite evidence: ' + row['suite'],
       bool(records) and all(x['status'] == 'PASS' for x in records) and
       len(records) == row['checks_total'] == row['checks_passed'] and row['checks_failed'] == 0)
ck('Verification totals agree across current state and reports',
   summary['status'] == 'PASS_LOCAL_CONTRACTS' and
   summary['checks_total'] == summary['checks_passed'] == state['checks_total'] == state['checks_passed'] ==
   sum(x['checks_total'] for x in summary['suites']) and summary['checks_failed'] == state['checks_failed'] == 0)
full_checks = {x['check']: x for x in reports['verification/FULL_PROJECT_VERIFICATION_v6.json']['checks']}
ck('FP evidence references real passing checks for that finding', all(
    x['evidence'] and all(e['check'] in full_checks and x['id'] in full_checks[e['check']]['findings']
                         and e['kind'] == full_checks[e['check']]['evidence_kind'] for e in x['evidence'])
    for x in register['findings'] if x['id'] != 'FP-029'))
ck('Source anchor paths and lines exist', all(
   (ROOT / a['file']).is_file() and 1 <= a['line'] <= len((ROOT / a['file']).read_text().splitlines())
   for x in register['findings'] for a in x['source_anchors']))
source_hashes = {p.name: sha(p) for p in sorted((ROOT / 'sources').iterdir()) if p.is_file()}
ck('Exactly 20 current source files match both evidence and manifest',
   len(source_hashes) == state['source_count'] == 20 and source_hashes == summary['source_sha256'] ==
   {x['name']: x['sha256'] for x in source_manifest['sources']} and
   all((ROOT / 'sources' / x['name']).stat().st_size == x['bytes'] for x in source_manifest['sources']))
ck('Historical authority is explicitly withdrawn',
   'superseded' in (ROOT / 'verification/historical_v5/README.md').read_text().lower() and
   not list((ROOT / 'verification').glob('*REGISTER*v5*')) and
   not list((ROOT / 'verification').glob('FINAL_*_v5*')))
ck('Current docs preserve migration and runtime limitations',
   all((ROOT / f).is_file() for f in ('README.md', 'NEXT_STEPS.md', 'SIMULATION_REVIEW_LEDGER_v53.md')) and
   'SG.version remains 1.4' in (ROOT / 'README.md').read_text() and
   'EXTERNAL_PENDING' in (ROOT / 'README.md').read_text())

if not args.preflight and not args.governance:
    manifest = read('PACKAGE_MANIFEST_SHA256.json')
    tracked = {x['path']: x for x in manifest['files']}
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and
              '__pycache__' not in p.parts and p.name != '.DS_Store' and
              str(p.relative_to(ROOT)) != 'PACKAGE_MANIFEST_SHA256.json'}
    ck('Package manifest inventory is complete', len(tracked) == len(manifest['files']) and set(tracked) == actual)
    mismatches = [name for name, row in tracked.items() if not (ROOT / name).is_file() or
                  sha(ROOT / name) != row['sha256'] or (ROOT / name).stat().st_size != row['bytes']]
    ck('All package bytes match SHA-256 manifest', not mismatches, mismatches)

failed = [x for x in checks if x['status'] != 'PASS']
print(json.dumps({'status': 'PASS' if not failed else 'FAIL',
                  'scope': 'Package governance/integrity; no runtime execution.',
                  'checks_total': len(checks), 'checks_passed': len(checks) - len(failed),
                  'checks_failed': len(failed), 'checks': checks, 'failed': failed}, indent=2))
raise SystemExit(bool(failed))
