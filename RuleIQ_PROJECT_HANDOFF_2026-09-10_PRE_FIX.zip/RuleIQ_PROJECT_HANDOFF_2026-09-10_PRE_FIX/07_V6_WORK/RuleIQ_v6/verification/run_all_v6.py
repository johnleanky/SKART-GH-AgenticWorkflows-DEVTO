#!/usr/bin/env python3
"""Run the release's independent local checks; no external tools or runtime calls.

Install requirements.txt into the selected interpreter before running this script.
Reports are regenerated, so verify the release file manifest before rerunning.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SRC = ROOT / 'sources'
SUITES = [
    ('architecture', 'verify_prompt_refactor_v6.py', [SRC], 'ARCHITECTURE_VERIFICATION_v6.json'),
    ('risk001', 'verify_risk001_v3.py', [SRC, HERE], 'RISK001_VERIFICATION_v6.json'),
    ('examples', 'verify_example_alignment_v4.py', [SRC], 'EXAMPLES_VERIFICATION_v6.json'),
    ('multinpcomb', 'verify_multinpcomb_deep_v3.py', [SRC], 'MULTINPCOMB_DEEP_VERIFICATION_v6.json'),
    ('full_project', 'verify_full_project_v6.py', [SRC], 'FULL_PROJECT_VERIFICATION_v6.json'),
]

results = []
for name, script, args, report in SUITES:
    proc = subprocess.run([sys.executable, str(HERE / script), *map(str, args)],
                          capture_output=True, text=True, cwd=ROOT,
                          env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    try:
        data = json.loads(proc.stdout)
        checks = data['checks']
        passed = sum(x['status'] == 'PASS' for x in checks)
        okay = proc.returncode == 0 and passed == len(checks) and bool(checks)
    except (ValueError, KeyError, TypeError):
        checks = []; passed = 0; okay = False
        data = {'status': 'ERROR', 'stdout': proc.stdout, 'stderr': proc.stderr}
    (HERE / report).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    row = {'suite': name, 'status': 'PASS' if okay else 'FAIL',
           'checks_total': len(checks), 'checks_passed': passed,
           'checks_failed': len(checks) - passed, 'exit_code': proc.returncode,
           'report': 'verification/' + report}
    if proc.stderr:
        row['stderr'] = proc.stderr
    results.append(row)
    print(json.dumps(row, ensure_ascii=False))

summary = {
    'status': 'PASS_LOCAL_CONTRACTS' if all(r['status'] == 'PASS' for r in results) else 'FAIL',
    'scope': 'Source, schema, fixture and explicit local model checks; no Pega/LLM or Memory runtime execution.',
    'checks_total': sum(r['checks_total'] for r in results),
    'checks_passed': sum(r['checks_passed'] for r in results),
    'checks_failed': sum(r['checks_failed'] for r in results),
    'suites': results,
    'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SRC.glob('*.txt'))},
    'external_pending': ['C-027', 'C-028', 'C-029'],
}
(HERE / 'VERIFICATION_SUMMARY_v6.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k: summary[k] for k in ('status', 'checks_total', 'checks_passed', 'checks_failed')}))
raise SystemExit(summary['status'] == 'FAIL')
