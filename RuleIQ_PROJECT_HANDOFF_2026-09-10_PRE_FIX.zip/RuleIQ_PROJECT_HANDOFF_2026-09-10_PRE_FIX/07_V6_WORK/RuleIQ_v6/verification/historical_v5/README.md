# Historical v5 evidence — superseded

All files in this directory retain their original bytes. Their PASS, VERIFIED_LOCAL,
OPEN and OPEN_DECISION labels describe previous checkpoints and are not the current
v6 status. In particular, the pre-fix audit reopened 29 findings after the old
verification suites passed. Do not use a historical register, source manifest,
apply script or test result as current release authority.

Current authority is ../../CHANGE_REGISTER_v6.json, ../../CURRENT_STATE.json and
../VERIFICATION_SUMMARY_v6.json. The v52 ledger preserves accepted decisions and
history; ../../SIMULATION_REVIEW_LEDGER_v53.md records the new checkpoint.

Historical source examples retained in the parent directory are explicit regression
fixtures, not deployment sources. Only ../../sources/ is the current source set.
