#!/usr/bin/env python3
"""Independent final-source checks and local contract simulations.

Does not import or execute the apply script. Checks labelled MODEL exercise the
documented contract model, not a deployed Pega agent or external Memory service.
"""
from pathlib import Path
import copy, hashlib, html, json, re, sys
from decimal import Decimal
from xml.etree import ElementTree as ET
import jsonschema
import contract_model_v6 as model

SRC = Path(sys.argv[1]).resolve()
VER = Path(__file__).resolve().parent
texts = {p.name: p.read_text() for p in SRC.glob('*.txt')}
checks = []


def check(name, condition, findings, kind='SOURCE', detail=''):
    checks.append({'check': name, 'status': 'PASS' if condition else 'FAIL',
                   'findings': findings.split(','), 'evidence_kind': kind, 'detail': detail})


def raises(fn):
    try:
        fn()
        return False
    except (ValueError, TypeError, KeyError):
        return True


def source(name, file, required, forbidden, findings):
    text = texts[file]
    missing = [item for item in required if item not in text]
    stale = [item for item in forbidden if item in text]
    check(name, not missing and not stale, findings, detail={'file': file, 'missing': missing, 'stale': stale})


M='Main_Agent_Prompt.txt'; G='UnitTestGenerator_Prompt.txt'; V='Validator_Prompt.txt'
MOD='rule-obj-model_knowledgearea.txt'; DP='rule-declare-pages_knowledgearea.txt'
RUF='rule-utility-function_knowledgearea.txt'; WHEN='rule-obj-when_knowledgearea.txt'

# Independent contradiction scans cover both the intended rule and old conflicting clauses.
source('Initial complete identity before acquisition', M,
       ['GetCaseData.TestedRuleKey, and RuleJSON.pzInsKey/pxObjClass/pyClassName/pyRuleName',
        'before any KnowledgeTool, RuleCrawler, Scenario formation or storage'],
       ['2. Require non-empty `RuleJSON.pzInsKey` and `RuleJSON.pxObjClass`;'], 'FP-002')
source('Author semantic ownership throughout active sections', M,
       ['MODE=AUTHOR`: form Scenarios and immutable semantic',
        'Downstream formatting reference for the remainder of Section 10',
        'Downstream projection reference — not executable by Scenario Author'],
       ['generate scenarios, assertions, RuleCode, and EvidenceSummary',
        'Before every legacy candidate-write transport call:',
        'storage gate over final RuleCode/EvidenceSummary'], 'FP-003')
source('When assertion formation mode-scoped', M,
       ['For every Scenario in an EXECUTABLE physical group at local row N',
        'NOT_TESTABLE groups instead contain OMIT/GAP evidence only'],
       ['For every Scenario at local row N, create exactly one semantic DecisionInput'], 'FP-004')
source('Terminal informational path from compiler to storage', M,
       ['DWL_STORAGE_GATE` is mode-specific', 'No RuleCode, concrete mock payload, or `DPA.pass=true` is required',
        'neither low confidence nor NotTestable bypasses active work',
        'informationalScenario', 'covers is absent (-)', 'retains that actual owner/covers',
        'zero executable rows then does not imply zero materializable outcomes'],
       ['DWL_STORAGE_GATE` passes when `DWL_CLOSURE_GATE`, producer/list gates, and final RuleCode',
        '`covers` is non-empty and names original-RUT coverage targets'], 'FP-005')
source('When infeasible row preserved as informational outcome', WHEN,
       ['Preserve the intended Scenario in its own NOT_TESTABLE physical group/candidate',
        'NOT_TESTABLE groups do not participate in executable column backfilling'],
       ['Do NOT describe it in Scenarios[]', 'Only after all untestable scenarios are excluded'], 'FP-006')
source('Generator skips physical stages for information', G,
       ['G5 and G6 are EXECUTABLE-only', 'proceeds directly from G4 to G7'], [], 'FP-007')
source('Per-mode knowledge acquisition and failure isolation', G,
       ['requires only its JsonSchema key', 'fails only groups requiring that Area',
        'Each EXECUTABLE group requires all three keys'],
       ['An unusable shared structural Knowledge result fails every still-ready group'], 'FP-008')
source('Validator informational branch continues siblings', V,
       ['continue every sibling UT', 'single final batch return',
        'Never return from the invocation inside this per-UT branch'],
       ['return that UT immediately', 'candidates return before UTC Knowledge'], 'FP-009')
source('Visible confidence and closure gate', V,
       ['ReasoningConfidence=Low', 'EvidenceSummary.DependencyClosureStatus=Blocked'], [], 'FP-010')
source('All Model WHEN mappings synchronized', MOD,
       ['WHEN" AND pyPropertiesName contains', 'KT.25/pyPropertiesName',
        'Rule-Obj-Model WHEN -> pyPropertiesName'],
       ['AND pyCondition contains', 'KT.25/pyCondition', 'WHEN -> pyCondition'], 'FP-012')
source('Confirmed formal export fields and STRING', MOD,
       ['Model definition -> pyParametersParamType', 'Raw STRING is the confirmed String-compatible'],
       ['pyParametersType'], 'FP-013')
source('Raw lowercase scope retained with explicit comparison', DP,
       ['normalize exact confirmed raw "thread" to "Thread"', 'evidence still records raw "thread"'],
       ['any value other than "Thread"\n'], 'FP-014')
source('RUF concrete label fallback bounded', RUF,
       ['KRUF.5a|P|ConcreteLabelFallback', 'stronger concrete sources are empty/unavailable',
        'must not override stronger or conflicting evidence', 'does not establish behavior for null'], [], 'FP-015')
source('Simulation loader boundary preserves caller obligations', DP,
       ['KDP.5|P|SimulatedDataPageDependencyBoundary', 'behind the simulation boundary',
        'Dependencies invoked directly elsewhere by the RUT remain real obligations'], [], 'FP-016')
source('Main uses Data Page boundary', M, ['apply Rule-Declare-Pages KDP.5', 'Loader-only'], [], 'FP-016')
source('Terminal false outcomes with modifying effects are required', M,
       ['executes OR suppresses an observable modifying producer', 'including terminal false edges'],
       ['A false edge covered by another S needs no T unless'], 'FP-017')
source('Append/map source and new target contexts', MOD,
       ['relative child source values read that existing source', 'Source and target classes may differ',
        'not an implicit full-page copy', 'Restore both contexts'], [], 'FP-018')
source('Closed dependency leaf seed exception', M,
       ['permit leaf fields required by closed executable dependencies',
        'not an extra collection/navigation level or dependency-only Scenario'],
       ['Do not seed nested properties when the RUT accesses top-level'], 'FP-019')
omission = texts[M].split('### 5.5 Omissions ledger',1)[1].split('### 5.6',1)[0]
check('Omission catalog includes rejected candidate assertion', 'incorrect_candidate_assertion' in omission,
      'FP-020', detail='Main 5.5 plus common producer/consumer/Validator catalogs')
source('Coverage producer operation catalog includes append/map', M,
       ['including SET/APPEND/APPEND_AND_MAP_TO/PREPEND/INSERT/REMOVE'], [], 'FP-021')
source('Direct producer own RHS with composite descendant boundary', M,
       ['own evidenced RHS/expression for direct writes', 'For a direct SET or other direct write',
        'inside that same target structure'], ['payload=<field:value from descendant rows only>'], 'FP-022')
source('LPE and DP execution permit proven prior termination', M,
       ['LPE.executes=false only when RX.actionState=skipped with terminal control-flow exclusion',
        'CONTROL_FLOW_EXCLUSION/<RXid>', 'A prior EXIT must itself be executed'],
       ['a true or absent guard cannot justify skipping a producer',
        'RX.actionState=skipped` with terminal guard proof'], 'FP-023')
for file in (M,G):
    source(file+' provenance alternatives', file,
           ['PARAMETER_DEFINITION/<assertionID>', 'PAGE_CONTEXT/<assertionID>',
            'A list/group structural target uses its owning property definition'],
           ['For each binding, DEPENDENCY source `PROPERTY_DEFINITION'], 'FP-024')
    source(file+' canonical DEP grammar', file,
           ['kind=<canonicalDWLKind>', 'DEP.kind equals its first component exactly',
            'DT and HELPER are forbidden aliases'], ['kind=<RUF|DP|HELPER|DT|NOT_APPLICABLE>'], 'FP-025')
    source(file+' exact serialization grammar', file,
           ['Concrete DP_SIG is the canonical serialization of exactly',
            'SCENARIO_SNAPSHOT.given is canonical JSON with exactly actions, inputs, parameters, setup, unresolved',
            'parse then reserialize equality'],
           ['DP KEY + normalized parameter', 'DP_SIG = KEY + normalized parameter set',
            '`DP_SIG` may use normalized parameter bindings', 'row keyed by `DP_SIG`',
            'canonical given+simulation'], 'FP-027')
source('Physical candidate index never group array index', M,
       ['in its own candidate use the sole zero-indexed UnitTestRules[0]'],
       ['UnitTestRules[G]'], 'FP-011')
source('Physical request dedup and occurrence mapping', M,
       ['OUT is the stable ordered unique canonical-KEY projection of SCAN',
        'fanned out to all matching SCAN occurrences', 'Account physical request budgets by len(OUT)'],
       ['When:IsAlpha@', 'When:IsBeta@', 'When:IsGamma@', 'Prop:RelationshipList@',
        'When:InnerCheck@'], 'FP-026')
source('Conservative skipped-output policy synchronized', M,
       ['Current skipped-output policy (FP-028)', 'emit neither Exists nor Not exists'], [], 'FP-028')
source('Model no absence inferred from skipped write', MOD,
       ['Unknown presence cannot justify Exists, Not exists or ResultCount=0'],
       ['If no -> assert Not exists', 'A list never written does not exist'], 'FP-028')
source('Property no absence inferred from missing setup', 'rule-obj-property_knowledgearea.txt',
       ['Never infer initial absence from missing setup or skipped writes'],
       ['never modified in trace -> Property comparator'], 'FP-028')

# Shared normative blocks must be exactly identical across source producer/consumer.
def shared(text, start, end):
    return text.split(start,1)[1].split(end,1)[0]
check('Canonical serialization block identical in Main/Generator',
      shared(texts[M],'Canonical typed JSON and DP_SIG','The payload is UTF-8') ==
      shared(texts[G],'Canonical typed JSON and DP_SIG','The payload is UTF-8'), 'FP-027')
for start,end,fp in [('Canonical DEP kinds (D-003;', '\n\n`BRANCH|','FP-025'),
                     ('- Binding acquisition provenance', '\n- EXECUTION source `EXECUTION_ACTIONS`','FP-024')]:
    check('Producer/consumer equality '+fp, shared(texts[M],start,end)==shared(texts[G],start,end), fp)
for config,prompt in [('UnitTestGenerator.txt',G),('JsonValidator_tool.txt',V)]:
    tree=ET.fromstring(texts[config])
    markup=re.search(r'<pySystemPrompt>(.*?)</pySystemPrompt>',texts[config],re.S).group(1)
    decoded='\n'.join(html.unescape(x) for x in re.findall(r'<p>(.*?)</p>',markup,re.S))
    check(config+' exact standalone prompt content',decoded==texts[prompt].rstrip('\n'),
          'FP-003,FP-007,FP-008,FP-009,FP-010,FP-023,FP-024,FP-025,FP-027','XML')

crawler=SRC/'Rule_Crawler_tool.txt'
b=crawler.read_bytes()
sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
check('Restored exact crawler blob',sha=='5bf29ef62534f74275c3d04ae03c9c9c3945e238','FP-001','HASH')
check('Complete source inventory',len(texts)==20,'FP-001','HASH')

# Concrete schema counterexamples: both families, missing fields, positive partials.
schemas={}; fixtures={}
for family,stem,fixture in [('STANDARD','rule-test-unit-case','FIXTURE_STANDARD_INFORMATIONAL_NOT_TESTABLE.json'),
                            ('WHEN','rule-test-unit-case_multInpComb','FIXTURE_MULTINPCOMB_INFORMATIONAL_NOT_TESTABLE.json')]:
    schema=json.loads(texts[stem+'-JsonSchema.txt'] if family=='WHEN' else texts[stem+'_JsonSchema.txt'])
    jsonschema.Draft202012Validator.check_schema(schema)
    validator=jsonschema.Draft202012Validator(schema); schemas[family]=validator
    info=json.loads((VER/fixture).read_text()); fixtures[family]=info
    check(family+' positive informational fixture',validator.is_valid(info),'FP-005,FP-010','SCHEMA')
    for name,field,value in [('High','ReasoningConfidence','High'),('Medium','ReasoningConfidence','Medium'),
                             ('Closed','DependencyClosureStatus','Closed'),('missing confidence','ReasoningConfidence',None),
                             ('missing closure','DependencyClosureStatus',None)]:
        obj=copy.deepcopy(info); scenario=obj['UnitTestRules'][0]['Scenarios'][0]
        target=scenario if field=='ReasoningConfidence' else scenario['EvidenceSummary']
        if value is None: del target[field]
        else: target[field]=value
        check(family+' rejects '+name,not validator.is_valid(obj),'FP-010','SCHEMA')
    for field,value in [('AssertionCount',1),('SimulatedDependencyCount',1),('OmittedClaimCount',0),('BlockingGaps',[])]:
        obj=copy.deepcopy(info);obj['UnitTestRules'][0]['Scenarios'][0]['EvidenceSummary'][field]=value
        check(family+' rejects '+field,not validator.is_valid(obj),'FP-005,FP-010','SCHEMA')
    check(family+' descriptions no stale minimal RuleCode mode',
          'harness-only' not in json.dumps(schema) and 'Cardinality modes: SHARED_SIMULATION' not in schema.get('$comment',''),
          'FP-011','SCHEMA')
    partial=json.loads(texts[stem+'-JsonExample.txt'] if family=='WHEN' else texts[stem+'_JsonExample.txt'])
    for scenario in partial['UnitTestRules'][0]['Scenarios']:
        scenario['Testability']='PartiallyTestable'; scenario['ReasoningConfidence']='Low'
    check(family+' executable partial remains accepted',validator.is_valid(partial),'FP-010','SCHEMA')

# Exact serializer properties and adversarial values (the decimal path is lossless).
for raw,expected in [('1.00','1'),('1e3','1000'),('-0.00','0'),
                     ('123456789012345678901234567890.1234500','123456789012345678901234567890.12345')]:
    check('Exact decimal '+raw, model.canonical(model.loads(raw))==expected,'FP-027','MODEL')
for value in ['a|b','a\\b','a\nb','a\rb','a\tb','"quote"','&quot;','-','', 'é😀']:
    encoded=model.canonical(value)
    check('Unicode/string round trip '+repr(value),model.loads(encoded)==value,'FP-027','MODEL')
for bad in ['{"a":1,"a":2}','NaN','Infinity','{"x":-Infinity}']:
    check('Reject noncanonical input '+bad,raises(lambda: model.loads(bad)),'FP-027','MODEL')
check('Boolean/number/string are distinct',len({model.canonical(x) for x in [True,1,'true','1']})==4,'FP-027','MODEL')
check('Absent/null/empty/string-empty are distinct',len({model.canonical(model.typed(k,v))
      for k,v in [('absent',None),('null',None),('empty',''),('string','')]})==4,'FP-027','MODEL')
check('Arrays preserve order',model.canonical([1,2])!=model.canonical([2,1]),'FP-027','MODEL')
check('Equivalent object order canonicalizes equally',model.canonical({'b':2,'a':1})==model.canonical({'a':1,'b':2}),'FP-027','MODEL')
for kind,value in [('boolean','true'),('number',True),('empty',None),('json','{}')]:
    check('Reject typed coercion '+kind,raises(lambda: model.typed(kind,value)),'FP-027','MODEL')

# Validate actual final example traces, including negative visible-signature mutations.
for file in sorted(texts):
    if 'JsonExample' not in file: continue
    obj=json.loads(texts[file]);family='WHEN' if 'multInpComb' in file else 'STANDARD'
    check(file+' valid final schema',schemas[family].is_valid(obj),'FP-011,FP-027','SCHEMA')
    for si,scenario in enumerate(obj['UnitTestRules'][0]['Scenarios']):
        for line in scenario['EvidenceSummary']['AssertionDecisionTrace'].splitlines():
            if not line.startswith('SIM|'): continue
            fields=dict(part.split('=',1) for part in line.split('|')[1:]); sig=html.unescape(fields['sig'])
            params=model.loads(html.unescape(fields['params']))
            check(file+f' s{si} signature consistency',model.validate_signature(sig,fields['rule'],params),'FP-027','FIXTURE')
            check(file+f' s{si} wrong rule rejected',raises(lambda: model.validate_signature(sig,'D_Wrong',params)),'FP-027','FIXTURE')
            check(file+f' s{si} wrong params rejected',raises(lambda: model.validate_signature(sig,fields['rule'],{})),'FP-027','FIXTURE')

# Case identity and canonical kinds, including same name/different class.
case={'pyID':'UT-1','TestedRuleKey':'RULE-OBJ-MODEL DATA-A BUILD #RS',
      'RuleJSON':{'pxObjClass':'Rule-Obj-Model','pyClassName':'Data-A','pyRuleName':'Build',
                  'pzInsKey':'RULE-OBJ-MODEL DATA-A BUILD #2026'}}
check('Valid identity gate',model.identity_gate(case),'FP-002','MODEL')
for field in ('pyID','TestedRuleKey','pzInsKey','pxObjClass','pyClassName','pyRuleName'):
    bad=copy.deepcopy(case);target=bad if field in bad else bad['RuleJSON'];target[field]=''
    check('Identity rejects empty '+field,not model.identity_gate(bad),'FP-002','MODEL')
bad=copy.deepcopy(case);bad['TestedRuleKey']='RULE-OBJ-MODEL DATA-B BUILD #RS'
check('Identity conflict rejected',not model.identity_gate(bad),'FP-002','MODEL')
for kind in ['When','DTable','Model','Prop','RUF','DP']:
    key=kind+('@' if kind=='RUF' else '@Data-A')+'@Thing'
    check('Canonical dependency '+kind,model.dependency(kind,key,{key}),'FP-025','MODEL')
    check('Wrong dependency prefix '+kind,not model.dependency('DP' if kind!='DP' else 'When',key,{key}),'FP-025','MODEL')
for alias in ['DT','HELPER']:
    check('Legacy alias rejected '+alias,not model.dependency(alias,alias+'@Data-A@Thing',{alias+'@Data-A@Thing'}),'FP-025','MODEL')
check('RUF class must be empty',not model.dependency('RUF','RUF@Data-A@Library!Thing',
      {'RUF@Data-A@Library!Thing'}),'FP-025','MODEL')
rows=[{'id':'D1','key':'When@Data-A@Check','state':'READY'},
      {'id':'D2','key':'When@Data-A@Check','state':'READY'},
      {'id':'D3','key':'When@Data-B@Check','state':'READY'},
      {'id':'D4','key':'When@?@Check','state':'CTX'}]
plan=model.request_plan(rows)
check('Dedup physical requests preserves occurrences',plan=={'SCAN':['D1','D2','D3'],
      'OUT':['When@Data-A@Check','When@Data-B@Check'],
      'occurrences':{'When@Data-A@Check':['D1','D2'],'When@Data-B@Check':['D3']},'physical_count':2},'FP-026','MODEL')

# Informational storage never needs a fabricated simulation or coverage result.
info={'id':'S1','mode':'INFORMATIONAL_NOT_TESTABLE','assertions':[],'simulations':[],
      'required_simulation':True,'dpa_pass':False,'omits':['O1'],'gaps':['DP_PARAMETER_UNRESOLVED'],
      'confidence':'Low','closure':'Blocked','terminal_proof':True,'work':{}}
check('Unresolved terminal DP informational storage',model.storage_gate(info),'FP-005','MODEL')
check('Informational key independent of missing payload',model.group_key(info)=='{"informationalScenario":"S1"}','FP-005','MODEL')
for field in ['open','ready','ctx','unscanned']:
    bad=copy.deepcopy(info);bad['work'][field]=1
    check('Informational cannot bypass active '+field,not model.storage_gate(bad),'FP-005','MODEL')
for field,value in [('assertions',['A1']),('simulations',[{}]),('gaps',[]),('terminal_proof',False),('confidence','High'),('closure','Closed')]:
    bad=copy.deepcopy(info);bad[field]=value
    check('Informational rejects '+field,not model.storage_gate(bad),'FP-005,FP-010','MODEL')
other=copy.deepcopy(info);other['id']='S2'
check('Distinct informational scenarios isolated',model.group_key(info)!=model.group_key(other),'FP-005,FP-006','MODEL')
ex=copy.deepcopy(info);ex.update(mode='EXECUTABLE',assertions=['A1'],required_simulation=False)
check('Executable no-simulation key',model.group_key(ex)=='NO_SIMULATION','FP-005','MODEL')
ex['required_simulation']=True
check('Executable cannot label missing simulation NO_SIMULATION',raises(lambda:model.group_key(ex)),'FP-005','MODEL')

check('Informational requests schema only',model.knowledge_keys(True,['INFORMATIONAL_NOT_TESTABLE'])==
      ['Rule-Test-Unit-Case_MultInpComb-JsonSchema'],'FP-008','MODEL')
groups=[{'id':'I','when':True,'mode':'INFORMATIONAL_NOT_TESTABLE'}, {'id':'E','when':True,'mode':'EXECUTABLE'}]
check('Missing example affects executable sibling only',model.affected_by_missing_knowledge(groups,
      ['Rule-Test-Unit-Case_MultInpComb-JsonExample'])==['E'],'FP-008','MODEL')
exec_payload=json.loads(texts['rule-test-unit-case_multInpComb-JsonExample.txt'])
batch=[{'id':'I','payload':fixtures['WHEN']},{'id':'E','payload':exec_payload}]
result,events=model.validator_batch(batch,schemas['WHEN'].is_valid)
check('Informational then executable yields both VR results',result==[('I','OK'),('E','OK')] and
      events[-1]==('batch','final-return') and events.count(('batch','final-return'))==1,'FP-009','MODEL')
result,events=model.validator_batch(batch,schemas['WHEN'].is_valid,False)
check('Informational success survives executable Knowledge failure',result==[('I','OK'),('E','HUMAN')],
      'FP-009','MODEL')
check('Informational makes no Knowledge request',('I','knowledge-required') not in events,'FP-008,FP-009','MODEL')

# Previously accepted lifecycle and safety behavior remain regression gates.
check('Malformed Validator leaves Pending without update',model.lifecycle([None])==
      {'result':'VALIDATOR_RESPONSE_INVALID','status':'Pending','attempts':1,'updates':[]},'REGRESSION','MODEL')
failed=model.lifecycle(['OK'],False)
check('Update failure has one attempt no retry',failed['result']=='LIFECYCLE_UPDATE_FAILED' and len(failed['updates'])==1,'REGRESSION','MODEL')
check('Two repairs then OK succeeds at third attempt',model.lifecycle(['GENERATOR_REPAIR','GENERATOR_REPAIR','OK'])['result']=='OK','REGRESSION','MODEL')
check('Fourth Validator attempt forbidden',model.lifecycle(['GENERATOR_REPAIR']*3+['OK'])['result']=='REPAIR_EXHAUSTED','REGRESSION','MODEL')
check('Semantic rejection terminal',model.lifecycle(['SEMANTIC_REJECT','OK'])['attempts']==1,'REGRESSION','MODEL')
check('Sibling success produces Completed',any(x['result']=='OK' for x in [failed,model.lifecycle(['OK'])]),'REGRESSION','MODEL')
for initial,effects,expected in [('UNKNOWN',['skip'],'UNKNOWN'),('ABSENT',['skip'],'ABSENT'),
                                ('PRESENT',['skip'],'PRESENT'),('PRESENT',['remove'],'ABSENT'),
                                ('ABSENT',['materialize','remove','materialize'],'PRESENT')]:
    check('Presence '+initial+str(effects),model.presence(initial,effects)==expected,'FP-028','MODEL')
mapped=model.append_and_map([{'pxObjClass':'Target','X':'old'}],{'pxObjClass':'Source','X':'new','Y':'unmapped'},[('X','X')],'Target')
check('Append mapping writes new target reads existing source',mapped==[{'pxObjClass':'Target','X':'old'},
      {'pxObjClass':'Target','X':'new'}],'FP-018','MODEL')

failed=[item for item in checks if item['status']!='PASS']
result={'status':'PASS_LOCAL_CONTRACT' if not failed else 'FAIL',
        'scope':'Final-source contract checks, real JSON Schema fixtures and an explicitly labelled local model. No Pega/LLM runtime execution.',
        'checks_total':len(checks),'checks_passed':len(checks)-len(failed),'checks_failed':len(failed),
        'checks':checks,'failed':failed,'external_pending':['C-027','C-028','C-029']}
print(json.dumps(result,indent=2,ensure_ascii=False))
raise SystemExit(bool(failed))
