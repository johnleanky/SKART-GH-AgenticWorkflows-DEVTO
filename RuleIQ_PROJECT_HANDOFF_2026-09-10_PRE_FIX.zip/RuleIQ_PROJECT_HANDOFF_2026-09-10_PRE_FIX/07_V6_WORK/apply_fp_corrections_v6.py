#!/usr/bin/env python3
"""Deterministically build corrected local sources from the immutable v5 baseline.

All replacement guards and JSON parsing run before source writes. This script is
not a verifier; independent verification is in the package verification folder.
"""
from pathlib import Path
import hashlib, html, json, re

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / '01_CURRENT_V5_BASELINE/EXTRACTED_V5/RuleIQ_risk001_v5_work'
WORK = ROOT / '07_V6_WORK/RuleIQ_v6'
S = {p.name: p.read_text() for p in (BASE / 'sources').glob('*.txt')}
CHANGES = []
M = 'Main_Agent_Prompt.txt'
G = 'UnitTestGenerator_Prompt.txt'
V = 'Validator_Prompt.txt'
MODEL = 'rule-obj-model_knowledgearea.txt'
DP = 'rule-declare-pages_knowledgearea.txt'
RUF = 'rule-utility-function_knowledgearea.txt'
WHEN = 'rule-obj-when_knowledgearea.txt'

def replace(file, old, new, fp, count=1):
    actual = S[file].count(old)
    assert actual == count, (fp, file, actual, count, old[:180])
    S[file] = S[file].replace(old, new)
    CHANGES.append({'finding': fp, 'file': file, 'occurrences': actual,
                    'old': old, 'new': new})

def before(file, anchor, block, fp):
    replace(file, anchor, block + '\n\n' + anchor, fp)

def section(file, start, end, block, fp):
    begin = S[file].index(start)
    finish = S[file].index(end, begin + len(start))
    replace(file, S[file][begin:finish], block.rstrip() + '\n\n', fp)

# FP-002: no semantic acquisition before the complete case/RUT identity gate.
replace(M,
 '2. Require non-empty `RuleJSON.pzInsKey` and `RuleJSON.pxObjClass`; otherwise stop before Scenario formation/storage and return bounded Failed status.',
 '2. Require nonempty string GetCaseData.pyID, GetCaseData.TestedRuleKey, and RuleJSON.pzInsKey/pxObjClass/pyClassName/pyRuleName. Parse TestedRuleKey into at least three whitespace-separated components; the first three must equal the uppercase original pxObjClass, pyClassName and pyRuleName respectively. Parse pzInsKey by the same rule and require the same identity triplet. Preserve exact raw strings as evidence; never repair, trim a stored identity, invent a case key, or substitute another rule. Missing, unparseable or conflicting identity returns bounded Failed before any KnowledgeTool, RuleCrawler, Scenario formation or storage.', 'FP-002')

# FP-025: retain revision 1.4, explicitly accepted in ledger decision D-003.
DEP_OLD = 'kind=<RUF|DP|HELPER|DT|NOT_APPLICABLE>'
DEP_RULES = '''Canonical DEP kinds (D-003; SG.version remains 1.4): except for the sole sentinel NOT_APPLICABLE, identity is the exact final DWL KEY `<kind>@<applyToClass>@<name>` and DEP.kind equals its first component exactly. Current kinds are When, DTable, Model, Prop, RUF and DP; another exact kind is allowed only with its authoritative canonical D-row evidence. RUF uses the empty class component `RUF@@<exactFamily>`. NOT_APPLICABLE requires state=NOT_APPLICABLE, identity=NOT_APPLICABLE and absent parameters; it cannot stand for an unresolved real dependency. No case folding or translation; DT and HELPER are forbidden aliases. Generator validates exact prefix equality and never remaps kinds.'''
for file in (M, G):
    replace(file, DEP_OLD, 'kind=<canonicalDWLKind>', 'FP-025')
    anchor = '`BRANCH|scenario=<ID>|id=<ID>|order=<N>|source=<sourceID>|logic=<exactLogic>|inputs=<inputIDsOrAbsent>|result=<TRUE|FALSE|UNKNOWN|NOT_APPLICABLE>|writes=<pathsOrAbsent>|evidence=<evidenceIDs>`'
    before(file, anchor, DEP_RULES, 'FP-025')

# FP-005: terminal informational outcomes have their own gates and identity.
section(M, '### 7.7 Closure and semantic handoff gates', '## 8. RUF transitive discovery discipline', '''### 7.7 Closure and semantic handoff gates

`DWL_CLOSURE_GATE` requires latest `_DWLState.CHECK.open=0`, `ready=0`, `ctx=0`, and `unscanned=0`; every dependency is CLOSED or has proven terminal GAP evidence. Every emitted exact claim uses closed executable evidence. A terminal gap affecting a claim is explicitly represented by OMIT/GAP, never guessed away.

READY, CTX, REQUESTED, FETCHED, unclosed SCANNED, and unscanned rows are work, not final evidence. They require the next crawl/scan/state transition in both modes; neither low confidence nor NotTestable bypasses active work.

`DWL_STORAGE_GATE` is mode-specific and audits semantic ScenarioGroup records, never physical candidate fields:
- EXECUTABLE: DWL_CLOSURE_GATE plus producer/list, ASSERT/SETUP and semantic Data Page audit gates pass. Every reachable/unknown DP obligation needed for this execution has concrete grounded SIM data with `DPA.pass=true`. A terminal unmet simulation needed for execution makes the Scenario informational; a new executable witness must return to WITNESSES.
- INFORMATIONAL_NOT_TESTABLE: DWL_CLOSURE_GATE plus complete terminal evidence, zero ASSERT/SIM, one or more OMIT/GAP, confidence=Low, SUMMARY.dependencyClosureStatus=Blocked, and all mode-applicable source self-parse/coverage gates pass. No RuleCode, concrete mock payload, or `DPA.pass=true` is required. Terminal DP gaps are retained in dependency/access evidence and SUMMARY.simulationState=RequiredButLimited. Never invent a successful DPA result or mark the required simulation NotRequired.

`STATECHECK.preFinal` checks that selected semantic gate and B/A before ScenarioGroup WriteMemory. Incomplete dependency work is internal only and cannot be stored. Generator owns all later candidate/RuleCode validation.''', 'FP-005')

INFO_KEY = '''Informational grouping identity: for an all-NotTestable WHEN group use exactly canonical JSON `{"informationalScenario":"<frozen S.id>"}` as SIMULATION_GROUP_KEY. Such a group contains exactly that one Scenario, zero SIM and zero ASSERT, and explicit terminal OMIT/GAP evidence; this isolates each informational outcome without needing any resolved simulation payload. The key is assigned only after F assigns stable S IDs, is not a simulation, and must not be used to sort or reassign those IDs. EXECUTABLE groups use NO_SIMULATION only when no simulation is required; otherwise they use the complete canonical simulations object. Continue to partition by `(SIMULATION_GROUP_KEY, EXECUTION_CLASS)`; no execution-class mixing or downstream regrouping.'''
for file in (M, G):
    before(file, '`ROOT|page=<primaryPage>|class=<primaryClass>|primarySetup=<true|false>|pagesAndClasses=<canonicalTypedJSON>|namedPageEvidence=<canonicalTypedJSON>`', INFO_KEY, 'FP-005')
    replace(file, '- `kind=WHEN` requires `rutType=Rule-Obj-When`, one or more scenarios, and exactly one key. A no-simulation group uses the literal `NO_SIMULATION`. Otherwise the key is canonical minified typed JSON with exact root shape `{"simulations":[<entry>...]}`. Object keys are recursively sorted and array order is preserved.',
     '- `kind=WHEN` requires `rutType=Rule-Obj-When` and exactly one key selected by execution class. EXECUTABLE permits one or more scenarios: use literal NO_SIMULATION when no simulation is required, otherwise canonical JSON with exact root shape `{"simulations":[<entry>...]}`. NOT_TESTABLE uses the informational grouping identity below and exactly one scenario. Object keys are recursively sorted and array order is preserved.', 'FP-005')
    replace(file, '3. zero `COLUMN` records for STANDARD, or one or more ordered `COLUMN` records for WHEN;',
     '3. zero COLUMN records for STANDARD; for EXECUTABLE WHEN, one or more ordered COLUMN records; for NOT_TESTABLE WHEN, zero or more evidenced COLUMN records with no executable assertions;', 'FP-005')
    replace(file, 'Every final physical Scenario appears once. Scenario order is contiguous and stable. `covers` is non-empty and names original-RUT coverage targets, never dependency-owned targets.',
     'Every final physical Scenario appears once. Scenario order is contiguous and stable. EXECUTABLE covers is nonempty and names actually executed REQUIRED original-RUT targets. NOT_TESTABLE retains any actually evidenced executed REQUIRED targets; if execution itself was blocked, covers is absent (-) and its intended targets are BLOCKED with terminal proof rather than achieved coverage. No failed assertion/unknown output alone proves that an executed owner was not covered. Preserve the informational outcome in the frozen Scenario census. Dependencies never own targets.', 'FP-005')
    replace(file, 'For WHEN, each Scenario\'s ordered SIM records serialize to the complete `simulationGroupKey` entry set; every declared key field is compared, not only signature and parameters. A `NO_SIMULATION` group contains zero SIM records in every Scenario.',
     'For EXECUTABLE WHEN, each Scenario\'s ordered SIM records serialize to the complete simulationGroupKey entry set; compare every field, including payloadPage/itemPath. NO_SIMULATION requires zero SIM and no required simulation. For NOT_TESTABLE WHEN, require the informationalScenario key to equal the sole frozen Scenario ID and zero SIM; preserve unmet simulation obligations as terminal GAP evidence instead of fabricating key entries.', 'FP-005')
    before(file, 'Each resolved Data Page input has one PARAM per access, under revision 1.4 below.', '''Informational source applicability: for NotTestable retain all acquired identity, intended inputs and factual execution/dependency evidence, plus explicit terminal gaps. Bindings is empty because ASSERT count is zero. Do not materialize unknown input values, action parameters, execution results or simulation payloads. PROFILE.actions contains only grounded planned actions; unavailable action execution has GAP evidence, never a fabricated successful action. An empty actions census means no concrete runnable action was materialized. Missing executable projection data is represented by GAP and Low/Blocked, not a failure of the informational mode. Validate grammar, identity, all present facts, referenced evidence, counts and terminality normally. Requirements for complete runnable setup/formal parameter projection, successful branch evaluation, resolved DP bindings and SIM are EXECUTABLE-only. An informational RX may report UNKNOWN with terminal proof; it must not masquerade as executed or NOT_APPLICABLE when execution was actually blocked.''', 'FP-005')
    replace(file, 'Generator must report that Scenario as unprojectable under its scoped failure contract;',
     'For an EXECUTABLE Scenario, Generator must report that Scenario as unprojectable under its scoped failure contract; an informational NotTestable Scenario retains that gap and remains representable without runnable parameter projection;', 'FP-005')

before(M, '### Scenario Compiler — sole authority for Scenario cardinality', INFO_KEY, 'FP-005')
replace(M, 'For an original `Rule-Obj-When`, compute exactly one canonical typed `SIMULATION_GROUP_KEY` per Scenario using every runtime-relevant simulation field required by the ScenarioGroup contract, including typed parameters, payload, setup pages, class, shape, method, signature, and target; use exact `NO_SIMULATION` when none is required.',
 'For an original Rule-Obj-When, select SIMULATION_GROUP_KEY by mode: EXECUTABLE uses the complete canonical simulation fields, or exact NO_SIMULATION when none is required; NotTestable uses the informationalScenario identity defined in Sections 11 and 13 without requiring a resolved mock.', 'FP-005')
before(M, '1. INVENTORY (`I`).', '''Terminal informational compiler path (applies in I/W/F/B/A): finish all active acquisition first. If a required behavior has no executable witness because its dependency/representation obligations are terminally blocked, retain the intended Scenario as NotTestable and its original-RUT targets as B with a census proving that the current environment cannot provide a runnable witness; one failed witness alone is insufficient. Such an S has no achieved covers and no ASSERT/SIM. Its known given values and unresolved obligations remain frozen evidence. It is not an executable witness and must not be re-executed with guessed values. B/A independently audit its terminal proof and preservation, while executable rows alone contribute to union covers=R. Reduction cannot remove an informational outcome merely because it contributes no executable coverage. F may contain only informational rows when all intended targets are proven B; zero executable rows then does not imply zero materializable outcomes. Any transition from executable to informational returns to W before freezing, preserving the intended Scenario and coverage census and rebuilding mode-dependent decisions; never remove SIM in place after F.''', 'FP-005')
replace(M, 'If no complete base exists, find another witness, prove B/U, or fail.',
 'If no complete executable base exists, find another witness or prove B/U; preserve proven terminal-blocked outcomes through the informational compiler path. Fail only if neither an executable nor a truthful informational base can be materialized.', 'FP-005')
replace(M, 'each S given/simulation/name/group location exactly matches one materialized Scenario and covers its execution;',
     'each S given/simulation/name/group location exactly matches one materialized Scenario and covers its evidenced execution in either mode, or has empty covers with audited terminal B evidence when execution was blocked;', 'FP-005')

# FP-007/008/009/010: projection/validation dispatch must preserve siblings.
replace(G, 'After source reads, if no group is source-ready, return one `GR ... status=FAILED` row per attributable SG and make no Knowledge/write/Validator call. If at least one group is ready, request the one G3 structural Knowledge batch and cache it. An unusable shared structural Knowledge result fails every still-ready group as `KNOWLEDGE_FAILED`; already failed groups keep their own reason.',
 'After source reads, if no group is source-ready, return one GR status=FAILED row per attributable SG and make no Knowledge/write/Validator call. Otherwise classify every ready group by execution class before selecting G3 keys. Request the union once and cache each valid Area independently. A missing/duplicate/malformed requested Area fails only groups requiring that Area as KNOWLEDGE_FAILED; an invocation exception or malformed outer envelope fails every still-ready group. Already failed groups keep their reason.', 'FP-008')
replace(G, 'Choose keys only from immutable original RUTType:',
 'Choose the schema family only from immutable original RUTType. Each INFORMATIONAL_NOT_TESTABLE group requires only its JsonSchema key from the table; no UTC KnowledgeArea, JsonExample, pyRuleSet or pyRuleSetVersion carrier is needed. Each EXECUTABLE group requires all three keys:', 'FP-008')
replace(G, 'Request the comma-joined keys once after complete source acquisition and before projection. Read pxResults rows with exact Area and nonempty Description. Require each requested key exactly once; missing/duplicate/malformed rows terminate, not invite another call or inference. Never use bare, blank or double-underscore keys. Cache all three strings; no Knowledge or source reacquisition after the first Validator call.',
 'After complete source acquisition, form the ordered union of keys required by ready modes using table order, and request that comma-joined list once before projection. Read pxResults rows by exact Area and nonempty Description. Require each needed key exactly once per dependent group; missing/duplicate/malformed content affects that group only. Unattributable or unrequested rows invalidate the shared envelope. Never retry or infer content. Cache valid strings independently; no Knowledge or source reacquisition after the first Validator call.', 'FP-008')
replace(G, 'The selected schema governs structure and allowed fields; UTC documentation governs Pega serialization;',
 'The selected schema governs structure and allowed fields in both modes; for EXECUTABLE only, UTC documentation governs Pega serialization;', 'FP-008')
replace(G, 'The Generator merely copies the two schema-required metadata carriers, pyRuleSet and pyRuleSetVersion,',
 'For EXECUTABLE mode only, the Generator copies the two RuleCode-required metadata carriers, pyRuleSet and pyRuleSetVersion,', 'FP-008')
before(G, 'Physical Param namespace INPUT records identify formal RUT arguments,',
 'G5 and G6 are EXECUTABLE-only. INFORMATIONAL_NOT_TESTABLE skips both sections and proceeds directly from G4 to G7 evidence projection and candidate write; no RuleCode metadata, setup, parameters, simulations or assertions are constructed.', 'FP-007')
before(G, 'For every non-cell ASSERT use its exact PROFILE binding.', 'This section applies only to EXECUTABLE candidates; informational candidates continue at G7.', 'FP-007')
replace(V, 'every Scenario is `NotTestable` with `SupportLevel=NotTestable`;',
 'every Scenario is NotTestable with SupportLevel=NotTestable, ReasoningConfidence=Low and EvidenceSummary.DependencyClosureStatus=Blocked;', 'FP-010')
replace(V, 'If consistent, return that UT immediately as `VR ... route=OK|blocking=0|warnings=0` with no VI rows and do not include it in the KnowledgeTool phase.',
 'If consistent, finalize and retain this UT result immediately as `VR ... route=OK|blocking=0|warnings=0` with no VI rows; continue every sibling UT and do not include it in the KnowledgeTool phase. Emit all retained VR/VI blocks exactly once at the final V10 return after every attributable UT has a result. Never return from the invocation inside this per-UT branch.', 'FP-009')
replace(V, 'INFORMATIONAL_NOT_TESTABLE candidates return before UTC Knowledge because no RuleCode behavior exists to document.',
 'INFORMATIONAL_NOT_TESTABLE candidates complete their own checks before UTC Knowledge because no RuleCode behavior exists to document; their stored results wait for the single final batch return.', 'FP-009')
replace(M, 'For every Scenario at local row N, create exactly one semantic DecisionInput ASSERT per ordered COLUMN and exactly one DecisionResult ASSERT:',
 'For every Scenario in an EXECUTABLE physical group at local row N, create exactly one semantic DecisionInput ASSERT per ordered COLUMN and exactly one DecisionResult ASSERT. NOT_TESTABLE groups instead contain OMIT/GAP evidence only and zero ASSERT/SIM; retained COLUMN/INPUT facts are informational. For executable rows:', 'FP-004')
for file in (M, G):
    replace(file, '`NotTestable` is used only when no meaningful executable assertion remains and requires assertionCount=0, simulationCount=0,',
     '`NotTestable` is used only when no meaningful executable assertion remains and requires confidence=Low, dependencyClosureStatus=Blocked, assertionCount=0, simulationCount=0,', 'FP-010')

# FP-006: infeasible executable rows remain explicit informational outcomes.
replace(WHEN, 'I: DecisionColumnSignature is fixed from the UNION of all candidate scenario input paths and identical across all rows.',
 'I: DecisionColumnSignature is fixed from the UNION of candidate EXECUTABLE scenario input paths within one simulation group and identical across that group\'s rows. NOT_TESTABLE groups do not participate in executable column backfilling.', 'FP-006')
replace(WHEN, 'Do NOT add it as a row. Do NOT describe it in Scenarios[].',
 'Exclude it only from EXECUTABLE MultInpComb rows. Preserve the intended Scenario in its own NOT_TESTABLE physical group/candidate, with no RuleCode and no ASSERT/SIM, explicit OMIT/GAP, Low confidence and Blocked closure. Do not delete its informational Scenarios[] entry or pretend its input columns are runnable.', 'FP-006')
replace(WHEN, 'I: Only after all untestable scenarios are excluded, lock the column signature from the remaining rows.',
 'I: After separating informational NotTestable outcomes, lock each executable group\'s column signature from its remaining executable rows; preserve all informational outcomes separately.', 'FP-006')

# FP-012/013/014/015/016/018: confirmed environment mappings and semantics.
for old, new in [
 ('WHEN" AND pyCondition contains', 'WHEN" AND pyPropertiesName contains'),
 ('WHEN with pyCondition:', 'WHEN with pyPropertiesName:'),
 ('evaluateWhen(...) inside pyCondition', 'evaluateWhen(...) inside WHEN pyPropertiesName'),
 ('X: pyCondition:"evaluateWhen', 'X: pyPropertiesName:"evaluateWhen'),
 ('Rule-Obj-Model WHEN -> pyCondition.', 'Rule-Obj-Model WHEN -> pyPropertiesName in the confirmed RuleIQ export. Preserve its exact value; do not substitute Rule-Obj-When pyCondition[] semantics.'),
 ('; pyCondition:"Param.InputTempPage5', '; pyPropertiesName:"Param.InputTempPage5')]:
    replace(MODEL, old, new, 'FP-012', S[MODEL].count(old))
replace(MODEL, 'pyParametersType', 'pyParametersParamType', 'FP-013', S[MODEL].count('pyParametersType'))
replace(MODEL, 'Condition field for WHEN -> KT.25/pyCondition.', 'Condition field for WHEN -> KT.25/pyPropertiesName.', 'FP-012')
replace(MODEL, 'use single expression field such as pyCondition or pyExpression.', 'use the exact single-expression field confirmed by the active rule-type mapping; never apply another type\'s condition field.', 'FP-012')
replace(MODEL, 'values: "PAGE","String","Integer","Decimal","Boolean".',
 'values: "PAGE","String","STRING","Integer","Decimal","Boolean" (and TrueFalse when evidenced). Raw STRING is the confirmed String-compatible export value. Preserve raw spelling in formal evidence; normalize only for semantic compatibility/projection. Do not generalize this to arbitrary case folding.', 'FP-013')
replace(G, 'String -> quoted Pega string literal', 'String or confirmed STRING -> quoted Pega string literal', 'FP-013')
for file in (M, G):
    replace(file, '- String arguments require a string or initialized-empty value;',
     '- String and confirmed raw STRING arguments require a string or initialized-empty value; retain raw formalType/evidence spelling and apply the same String projection;', 'FP-013')
replace(M, '| String \u00a0| String |', '| String or confirmed STRING | preserve raw type in evidence; String serialization |', 'FP-013', 2)
replace(DP, 'A: 1. Read pyScope from the Data Page RuleJSON.',
 'A: 1. Read and preserve raw pyScope from the Data Page RuleJSON. For eligibility comparison only normalize exact confirmed raw "thread" to "Thread"; retain the raw field in source evidence. No other case folding, trimming or defaulting is authorized.', 'FP-014')
replace(DP, '   pyScope="Thread"\n', '   pyScope="Thread" or confirmed raw pyScope="thread"\n', 'FP-014')
replace(DP, 'set to any value other than "Thread"', 'set to any value other than "Thread" or confirmed "thread"', 'FP-014')
before(DP, 'X B Requestor-scope Data Page (ineligible):',
 'X A2 Confirmed lowercase export: raw pyScope="thread" -> comparison Thread -> ELIGIBLE, resolvedScope="Thread"; evidence still records raw "thread".', 'FP-014')
before(DP, 'KDP.4|A|CallerInputBinding', '''KDP.5|P|SimulatedDataPageDependencyBoundary
P: Bound dependency discovery at a Data Page replaced by a valid simulation.
I: For an eligible Data Page selected for simulation, its connector/activity/data-transform loader and loader-internal dependencies are behind the simulation boundary. Do not crawl or execute them merely because they appear in the Data Page RuleJSON references.
A: Still resolve Data Page identity, raw scope, shape/class, declared inputs, caller bindings, payload/item context, and every dependency needed to evaluate the caller's access or produce its parameters. Dependencies invoked directly elsewhere by the RUT remain real obligations even if the same rule is a loader.
I: The boundary substitutes only loader execution. It never proves unresolved declarations, parameters, shape, scope or required caller behavior; terminal missing facts produce explicit GAP/NotTestable under the Main mode gate. Preserve acquired evidence; do not invent loader output.
R: KDP.1,KDP.2,KDP.4; Main dependency scanning and semantic DPA gates.''', 'FP-016')
replace(DP, 'Coverage: core KDP.1; scope and eligibility KDP.2; examples KDP.3; bindings KDP.4.',
 'Coverage: core KDP.1; scope and eligibility KDP.2; examples KDP.3; bindings KDP.4; simulated-loader boundary KDP.5.', 'FP-016')
before(M, '### 3.4 Guided semantic extraction',
 'Simulated Data Page scan boundary: apply Rule-Declare-Pages KDP.5 when scanning a Data Page chosen for simulation. Loader-only connector/activity/Model references do not enter DWL; retain all declaration/context/caller-parameter obligations and any independent direct RUT use of the same loader rule.', 'FP-016')
before(RUF, 'KRUF.6|A|RuleArgumentExtraction', '''KRUF.5a|P|ConcreteLabelFallback
P: Last-resort behavior evidence for the fetched function only.
A: Prefer the concrete prompt helper, implementation, parameter usage, pyDescription and pyUsage. Only when stronger concrete sources are empty/unavailable and establish no behavior, a nonempty fetched pyLabel may establish exactly the behavior it unambiguously describes. Preserve the raw label and its fetched-rule provenance.
I: A label must not override stronger or conflicting evidence. A name-like, vague or ambiguous label remains insufficient; function name/signature/type never substitutes for the label. Do not infer unstated null/error/side-effect/argument semantics. If those details affect the requested result, retain RUF_RETURN_UNKNOWN for that claim.
X: fetched pyLabel="Removes non-alphabetic characters in a string", with stronger sources empty, supports that described transformation for a grounded string input; it does not establish behavior for null.
R: KRUF.5,KRUF.12.''', 'FP-015')
replace(RUF, 'If prompt helper, `pyParametersDefinition[].pyParameterUsage`, `pyDescription`, `pyUsage`, and implementation do not establish return behavior:',
 'If prompt helper, `pyParametersDefinition[].pyParameterUsage`, `pyDescription`, `pyUsage`, implementation, and the strictly eligible concrete pyLabel fallback in KRUF.5a do not establish the required return behavior:', 'FP-015')
replace(RUF, 'Missing documentation must remain unknown.',
 'Missing documentation must remain unknown unless the exact KRUF.5a fallback conditions establish the specific required behavior.', 'FP-015')
replace(RUF, 'fetched fields/parameters KRUF.5;', 'fetched fields/parameters KRUF.5; concrete label fallback KRUF.5a;', 'FP-015')

replace(MODEL, 'M: APPEND_AND_MAP_TO -> LIST_APPEND: adds element; in WHEN/OTHERWISE/OTHERWISE-WHEN branches, both may execute across iterations, so size equals executed branches, not matched conditions.',
 '''M: APPEND_AND_MAP_TO -> LIST_APPEND: append one new page to the target PageList; its new index is prior size+1. The new page becomes target/current for child mappings. With relationship EXISTING_PAGE, resolve the configured existing source-page expression (pyPropertiesValue in the confirmed export); relative child source values read that existing source, while child write targets address the newly appended page. Preserve any explicit Primary/Top/named-page qualification under KT.23. The append materializes only the new page and required class metadata; child mappings materialize fields, not an implicit full-page copy. Source and target classes may differ. Restore both contexts on leaving the scope. An unresolved source, target, relationship export or class has a gap; do not invent a page or copy unrelated source fields.
X: APPEND_AND_MAP_TO .Addresses EXISTING_PAGE D_CustomerTestRef.Addresses(Param.AddressIndex); child SET .City=.City reads City from the selected source item and writes City on the new target .Addresses(n+1), leaving unmapped source fields uncopied.
I: In WHEN/OTHERWISE branches across loop iterations, count actual executed appends, not matched conditions.''', 'FP-018')
replace(MODEL, 'M: Rule-Obj-Model -> ["UPDATE_PAGE","FOR_EACH_PAGE_IN"]. Target page/list field -> pyPropertiesName.',
 'M: Rule-Obj-Model -> ["UPDATE_PAGE","FOR_EACH_PAGE_IN","APPEND_AND_MAP_TO"]. Target page/list field -> pyPropertiesName. APPEND_AND_MAP_TO uses the separate child source/target scopes in KT.22.', 'FP-018')
replace(MODEL, 'I: Resolve UPDATE_PAGE source through KT.28 and inherited loop source through KT.34 before evaluating child expressions.',
 'I: Resolve UPDATE_PAGE source through KT.28, inherited loop source through KT.34, and APPEND_AND_MAP_TO source/new target through KT.22 before evaluating child expressions.', 'FP-018')

# FP-017/019..024/028: behavior coverage and evidence must track execution.
replace(M, 'A false edge covered by another S needs no T unless it reaches OTHERWISE, EXIT/error, or different later owner execution.',
 'A reachable owner outcome is R whenever it executes OR suppresses an observable modifying producer, including terminal false edges with no OTHERWISE or later owner. An S covers that edge only with its actual branch execution and suppression proof. A false edge may be E only after exact non-effect/equivalence proof; equal asserted values alone are insufficient.', 'FP-017')
replace(M, 'OWNER_COVERAGE_OUTPUTS = {every property path written by SET/APPEND/PREPEND/INSERT/REMOVE',
 'OWNER_COVERAGE_OUTPUTS = {every property path written by an observable modifying operation defined in the active primary KnowledgeArea, including SET/APPEND/APPEND_AND_MAP_TO/PREPEND/INSERT/REMOVE', 'FP-021')
replace(M, 'payload=<field:value from descendant rows only>',
 'payload=<own evidenced RHS/expression for direct writes; own operation plus descendant mappings within the composite target>', 'FP-022')
replace(M, '- `PC.payload` may include only descendant `Set`, `MapTo`, or mapping rows under the same producer path.',
 '- For a direct SET or other direct write, PC.payload comes from that producer\'s own evidenced RHS/expression and payloadSourcePaths contains that source path. For a composite append/map producer it may additionally contain descendant Set/MapTo mappings inside that same target structure. Evaluate against the recorded source context. Never require a nonexistent child row for a direct producer.', 'FP-022')
replace(M, '- `LPE.executes=false` only when the producer action `RX.actionState=skipped` with terminal guard proof.',
 '- LPE.executes=false only when RX.actionState=skipped with terminal control-flow exclusion proof: a false effective guard, an earlier executed EXIT/termination in the same invocation, a proven unreachable alternative, or KnowledgeArea-defined non-execution. A prior EXIT proof does not require evaluating the skipped producer\'s own guard.', 'FP-023')
replace(M, '- If the controlling `RX` row is missing or unknown, set `LPE.executes=unknown`.',
 '- If there is neither a conclusive execution row nor terminal control-flow exclusion proof, set LPE.executes=unknown. An unknown skipped guard does not override an independently proven prior termination.', 'FP-023')
replace(M, '- Unsupported DecisionTable, unsupported RUF, unavailable RuleJSON, omitted guard dependency, unresolved Data Page, unknown function, or unknown branch makes `guardState=unknown` and `executes=unknown`.',
 '- Unsupported DecisionTable/RUF, unavailable RuleJSON, unresolved guard dependencies, Data Page or branch makes guardState=unknown; executes remains unknown unless an independent terminal control-flow exclusion proves non-execution before that guard.', 'FP-023')
for file in (M, G):
    replace(file, 'Execution-state proof is bidirectional: NOT_EXECUTED requires a terminal false effective RX guard (including the parent/short-circuit guard where applicable); a true or absent guard cannot justify skipping a producer. Without sufficient execution proof retain UNKNOWN. A false guard requires NOT_EXECUTED and an unknown guard requires UNKNOWN.',
     'Execution-state proof is bidirectional: NOT_EXECUTED requires terminal control-flow exclusion: false effective/parent/short-circuit guard, prior executed EXIT/termination in the same invocation, proven unreachable alternative, or KnowledgeArea-defined non-execution. For non-guard exclusion link EXECUTION EVIDENCE source CONTROL_FLOW_EXCLUSION/<RXid> with exact fact {execution,kind,source,proof}; execution equals the excluded RX, kind is EXIT/UNREACHABLE/KNOWLEDGE, source identifies the actual prior RX or grounded source, and proof establishes ordering, invocation scope and exclusion. A prior EXIT must itself be executed; it does not require evaluating the later guard. A true/absent guard alone is not an exclusion. A false guard requires NOT_EXECUTED; an unknown guard requires UNKNOWN unless independent terminal exclusion is proven. Without sufficient execution proof retain UNKNOWN.', 'FP-023')
    replace(file, 'A false RX guard requires NOT_EXECUTED, an unknown guard requires UNKNOWN; an executed producer requires a true or absent guard.',
     'A false RX guard requires NOT_EXECUTED; an unknown guard requires UNKNOWN unless independent terminal control-flow exclusion below proves NOT_EXECUTED. An executed producer requires a true or absent guard.', 'FP-023')

replace(M, '- allowed reason code: `unresolved_external_source`, `unavailable_rulejson_after_limit_exhaustion`, `unresolvable_runtime_input`, `inactive_evaluate_all_scalar`, `inactive_return_values_scalar`, `schema_incompatible_assertion_target`, or `redundant_iteration_coverage`;',
 '- allowed reason code: exactly the Section 13.4.6 catalog: `unresolved_external_source`, `unavailable_rulejson_after_limit_exhaustion`, `unresolvable_runtime_input`, `inactive_evaluate_all_scalar`, `inactive_return_values_scalar`, `schema_incompatible_assertion_target`, `redundant_iteration_coverage`, or `incorrect_candidate_assertion`;', 'FP-020')
replace(M, 'RUT access depth is authoritative. Do not use Data Page class structure to decide seed depth. Do not seed nested properties when the RUT accesses top-level. If assertion path depth differs from RUT access depth, adjust assertion path or omit; never adjust seed depth away from RUT access.',
 'RUT-evidenced collection carrier, navigation depth and witness-locked item count are authoritative. Do not insert wrappers, rename paths or add items from a class template. Inside those locked items, permit leaf fields required by closed executable dependencies even when the RUT directly reads only the containing page/list. Record the exact dependency read, item context and type as seed evidence. This permits needed leaf content, not an extra collection/navigation level or dependency-only Scenario. Assertions do not dictate new seed structure; unsupported assertions are omitted.', 'FP-019')
replace(M, '- verification string must prove expression depth equals seed depth.',
 '- verification string must prove the RUT collection/navigation skeleton equals the seed skeleton; dependency-required leaves inside locked items carry separate exact dependency read/context proof and do not introduce a new collection level.', 'FP-019')
replace(M, 'Seed only properties that are asserted, accessed by the RUT at that depth, or required structural metadata.',
 'Seed only RUT-accessed values, required structural metadata, or leaf fields required by closed executable dependencies inside the RUT/witness-locked items under Section 9.1; assertion selection alone cannot introduce seeds.', 'FP-019')

BINDING_PROVENANCE = '''- Binding acquisition provenance is selected by target kind, never a universal PROPERTY_DEFINITION requirement. A property leaf uses DEPENDENCY source PROPERTY_DEFINITION/<assertionID> with exact {path,pyPropertyMode,pyStringType} matching fullPath, structure, scalarType. A Param target uses DEPENDENCY source PARAMETER_DEFINITION/<assertionID> with exact {path,pyParametersParamName,pyParametersParamType} from its actual declaration; path equals fullPath and the name matches Param.<name>. The raw formal type is preserved; the existing Param assertion projection is structure=Value, scalarType=Text, parentMode=null, not an invented Rule-Obj-Property. A named/root Page target uses EXECUTION source PAGE_CONTEXT/<assertionID> with exact {path,class,source}; path equals fullPath, class comes from the grounded page/harness/creation context and ROOT map, structure=Page and scalarType=NotApplicable. A list/group structural target uses its owning property definition plus recorded list/group execution context; preserve actual collection mode and class, never fabricate an item index.
- Every binding also links EXECUTION source ASSERTION_CONTEXT/<assertionID> with exactly stepPage, stepClass, fullPath, parentMode, context, producerIndex (Known, Unknown, NotApplicable), and payloadProven (boolean) from audited execution/APB. All five common fields equal the binding. Both the kind-specific acquisition ID and execution-context ID occur in binding.evidence and refer to prior source facts, not the PROFILE census. Missing appropriate provenance is a GAP, not permission to change the binding kind. A List with unknown producer index requires proven payload and InAnyInstance; never turn it into all-items or positional proof.'''
for file in (M, G):
    start = '- For each binding, DEPENDENCY source `PROPERTY_DEFINITION/<assertionID>`'
    line = next(x for x in S[file].splitlines() if x.startswith(start))
    replace(file, line, BINDING_PROVENANCE, 'FP-024')
    replace(file, 'Capture property definitions and final APB/runtime context before freezing.',
     'Capture the kind-specific acquisition provenance and final APB/runtime context before freezing.', 'FP-024')
    replace(file, 'Non-Param fullPath begins with stepPage plus a dot; never guess a second root from serialized JSON.',
     'Non-Param fullPath begins with stepPage plus a dot, or equals stepPage itself for a Page assertion on that evidenced page root; never guess a second root from serialized JSON.', 'FP-024')
replace(M, '3. **Assertion, setup, and seed gate.** Every ASSERT has matching PROPERTY, producer/execution when applicable, setup, and evidence.',
 '3. **Assertion, setup, and seed gate.** Every ASSERT has matching final semantic property/parameter/page facts, kind-specific acquisition provenance, producer/execution when applicable, setup, and evidence. Use Section 13 PROFILE provenance alternatives; Param and named Page targets do not require fabricated property definitions.', 'FP-024')

replace(MODEL, 'A: Before every ResultCount assertion ask: did any write operation targeting this list execute on this scenario path? Write ops: APPEND,APPEND_AND_MAP_TO,INSERT,PREPEND,SET. If yes -> ResultCount allowed. If no -> assert Not exists; stop.',
 'A: Before every ResultCount, establish final presence from initial-state evidence and ordered executed effects. APPEND/APPEND_AND_MAP_TO/INSERT/PREPEND/SET may materialize a list; evaluate actual semantics and later removals. No executed write preserves the initial state. Emit Not exists only with proven final absence, and a count only for a proven present list with known count. Unknown initial/final presence yields OMIT unresolvable_runtime_input and explicit GAP; retain the Scenario.', 'FP-028')
replace(MODEL, 'I: A list never written does not exist; it is not an empty list. ResultCount=0 is forbidden when no write reached the list on this path.',
 'I: A never-written list is absent only with proven initial absence. A preexisting list may remain present. Unknown presence cannot justify Exists, Not exists or ResultCount=0.', 'FP-028')
replace('rule-obj-property_knowledgearea.txt', 'A: If list/group/page never modified in trace -> Property comparator "Not exists". Else if modified but empty -> ResultCount "Is Equals To" "0".',
 'A: Track initial presence and ordered executed effects. A never-modified list/group/page preserves initial state: proven absence may support Not exists, proven presence continues value/structure analysis, and unknown presence requires OMIT unresolvable_runtime_input plus GAP. A proven present empty collection may support ResultCount=0; a Page is not a collection count. Never infer initial absence from missing setup or skipped writes.', 'FP-028')
replace('rule-obj-property_knowledgearea.txt', 'I: ResultCount=0 forbidden for never-modified list/group/page.',
 'I: ResultCount=0 is forbidden for absent or unknown-presence collections; a proven preexisting present empty collection is distinct from an absent one.', 'FP-028')
before(M, 'INITIAL AND FINAL STATE:',
 'Current skipped-output policy (FP-028): preserve omission/gap semantics. Do not add an unrequested harness initialization assumption to force absence. Preserve each intended Scenario; unsupported output claims are omitted, with PartiallyTestable when another meaningful executable ASSERT remains and NotTestable otherwise.', 'FP-028')

# FP-026: occurrence evidence and physical requests have distinct cardinalities.
DWL_DEDUP = '''DWL physical request projection: READY contains occurrence IDs in stable D-ledger discovery order. SCAN is that complete ordered occurrence-ID list, including occurrences sharing a KEY. OUT is the stable ordered unique canonical-KEY projection of SCAN: retain the first occurrence of each exact KEY. Build exactly one physical pxRuleReferences request for each OUT key under its first request-ready holder using that occurrence's exact permitted reference fields; preserve the other holders/contexts as D-row evidence. ACT is the ordered canonical-KEY list of physical requested references and must equal OUT exactly, with no duplicates. Compare BLK/ACT by KEY. Every READY occurrence maps to exactly one OUT key; no occurrence is silently dropped. A fetched result is associated to that key and fanned out to all matching SCAN occurrences, then each occurrence is scanned/reconciled in its own context. A context provider resolves only the occurrences whose ctx it actually proves. Metadata lookup may be shared, but class/context/parameter/execution proof cannot be copied from another occurrence. Account physical request budgets by len(OUT), not len(SCAN); count repeat requests in different waves again. All examples use KEY=<kind>@<class>@<name>; legacy Kind:Name@Class notation is invalid.'''
before(M, 'Core invariants:', DWL_DEDUP, 'FP-026')
replace(M, '- `_DWLPlan.OUT` is mechanically derived from `_DWLState.READY`.',
 '- _DWLPlan.OUT is the stable ordered unique canonical-KEY projection of all READY occurrences under the physical request projection above.', 'FP-026')
replace(M, '`CHK=PASS` means `OUT == ACT`, `BLK` is disjoint from `ACT`, and no READY item is omitted.',
 '`CHK=PASS` means OUT == ACT, both are unique KEY lists, BLK is disjoint from ACT by KEY, and every READY occurrence appears in SCAN and maps to an OUT key.', 'FP-026')
for old, new in [('When:IsAlpha@Demo-Data-A','When@Demo-Data-A@IsAlpha'),
                 ('When:IsBeta@Demo-Data-A','When@Demo-Data-A@IsBeta'),
                 ('When:IsGamma@Demo-Data-A','When@Demo-Data-A@IsGamma'),
                 ('Prop:RelationshipList@RBG-Data-LegalRep','Prop@RBG-Data-LegalRep@RelationshipList'),
                 ('When:IsRelationshipTypeValid','When@?@IsRelationshipTypeValid'),
                 ('When:InnerCheck@Demo-Data-Item','When@Demo-Data-Item@InnerCheck')]:
    replace(M, old, new, 'FP-026', S[M].count(old))

# FP-027: exact local canonical serializer, not an appeal to unspecified JSON order.
CANONICAL = '''Canonical typed JSON and DP_SIG (shared producer/consumer contract):
- Parse duplicate-free JSON preserving exact finite decimals; reject NaN/Infinity and invalid Unicode surrogates. Object keys sort by Unicode code point, without case folding or Unicode normalization. Serialize no optional whitespace; preserve array order. Emit non-ASCII characters literally, escape quote/backslash and control characters with JSON escapes (\\b, \\f, \\n, \\r, \\t, otherwise lowercase \\u00xx), and do not escape slash. Numbers use exact plain decimal notation without exponent, trailing fractional zeros or a trailing decimal point; all numerical zeros serialize as 0. Never convert through binary floating point or coerce Boolean/string/number values.
- Canonical typed value is exactly {"valueType":<string|boolean|number|null|empty|json|absent>,"value":<native JSON value>}. string requires a string, boolean a Boolean, number a finite exact JSON number, null JSON null, empty the empty string, json an actual object/array, absent JSON null. The tag distinguishes empty from string-empty and null from absence. PARAM/ASSERT ledger value carriers remain strings (absent alone uses null): decode the already declared valueType once to this native form; a typed string 'true' or 'null' stays a string. Never reinterpret an untyped textual value.
- Canonical params is an object keyed by exact declared names, each value a canonical typed value. An optional omitted parameter is excluded from this effective map only with declaration evidence; present null/empty are included. Unknown is never absence or an empty map: unresolved inputs have GAP evidence and cannot produce a concrete signature.
- Concrete DP_SIG is the canonical serialization of exactly {"key":<exact DP canonical KEY>,"params":<canonical params>}. Its key is DP@<evidenced apply-to class>@<exact rule name>; params must equal the independently frozen SIM.params map after typed-carrier conversion. A parameterless signature contains params={}. This replaces all legacy KEY|name=type:value signatures. JSON encoding alone frames the key and parameters, including delimiter characters in values; outer ScenarioGroup escaping and final trace entity encoding are applied only afterwards.
- Crawl-time symbolic bindings are not DP_SIG. Address an unresolved access by its exact D occurrence plus invocation path, preserving symbolic expression/declaration evidence. Author creates concrete DP_SIG only after resolving the executed access map. Metadata deduplicates by KEY; concrete simulations deduplicate by the entire signature. Unknown/terminally blocked accesses retain their identities and gaps without a guessed signature.
- SCENARIO_SNAPSHOT.given is canonical JSON with exactly actions, inputs, parameters, setup, unresolved. parameters is an exact-name object of grounded formal RUT canonical typed values. inputs/setup are arrays with exactly role,path,page,class,mode,valueType,value per known INPUT/SETUP, converting carriers as above and using JSON null for explicitly absent page/class. Sort those arrays by (role,page-or-empty,path,class-or-empty,mode); conflicting duplicate coordinates are invalid. Preserve all nested value-array order. actions is the ordered planned-action projection with exactly phase,type,name,page,parameters; each argument has name,formalType,valueType,value, retains declared order and canonical native value. unresolved is a sorted unique array of {code,scope} terminal gap coordinates for required facts not available in these carriers; sort by (code,scope). Unknown facts occur there, never as invented seeds or resolved params. Do not include evidence IDs, Scenario IDs, labels or runtime Memory addresses in given.
- SCENARIO_SNAPSHOT.simulation for executable rows is NO_SIMULATION only if no simulation is required, otherwise the complete canonical {"simulations":[...]} object from the group contract. For an informational row with unmet simulation obligations it is exactly {"unresolved":[<sorted unique {code,scope} terminal simulation-gap coordinates>]}, with no invented payload; for an informational row without simulation obligations it is NO_SIMULATION. This snapshot field is frozen before S ID assignment; the informationalScenario grouping key is derived afterwards. Sort S by the tuple (canonical given, canonical snapshot simulation), not ambiguous string concatenation. Full simulation entries preserve all runtime fields and payloadPage/itemPath binding. Array order is preserved even when an example claims it is insignificant.
Every producer/consumer validates canonical serialization by parse then reserialize equality. Semantic changes return to W; consumers never normalize an old persisted payload in place.'''
for file in (M, G):
    before(file, 'The payload is UTF-8 text without a BOM.', CANONICAL, 'FP-027')
replace(M, '- `DP_SIG` = Data Page simulation identity: `DP KEY + normalized parameter bindings/values`.',
 '- DP_SIG = concrete Data Page simulation identity: canonicalJSON({key:KEY,params:canonicalTypedEffectiveMap}) under Section 13.2. Unresolved crawl bindings retain D occurrence/invocation identity until concrete values are grounded.', 'FP-027')
replace(M, '1. `DP_SIG = DP KEY + normalized parameter set` is the identity for simulation. In `MODE=CRAWL`, the normalized set may contain parameter bindings such as `ObjectID=.Objects(1).ID`; in `MODE=AUTHOR`, each Scenario must instantiate those bindings with concrete seeded values. Same Data Page with different concrete parameter values creates separate `SIM` obligations.',
 '1. Concrete DP_SIG is canonicalJSON({key:KEY,params:canonicalTypedEffectiveMap}) under Section 13.2. In MODE=CRAWL, unresolved symbolic bindings belong to the exact D occurrence/invocation and are not concrete DP_SIG. In MODE=AUTHOR, ground the effective values before constructing a signature. Same Data Page with different concrete parameter values creates separate semantic SIM obligations; terminal unresolved accesses retain GAP evidence under the informational gate.', 'FP-027')
replace(M, '- Simulation identity is `DP_SIG = KEY + normalized parameter set`. RuleCrawler metadata may deduplicate by `KEY`; `pySimulation` obligations deduplicate by `DP_SIG`.',
 '- Concrete simulation identity is DP_SIG=canonicalJSON({key:KEY,params:canonicalTypedEffectiveMap}) under Section 13.2. RuleCrawler metadata deduplicates by KEY; grounded semantic SIM obligations deduplicate by DP_SIG.', 'FP-027')
replace(M, '- In `MODE=CRAWL`, `DP_SIG` may use normalized parameter bindings, e.g. `ObjectID=.Objects(1).ID`. In `MODE=AUTHOR`, each Scenario instantiates the binding with concrete seeded values in `SIM`/`RuleCode.pySimulation`; `DPA` matches crawl-time bindings to scenario-time concrete params.',
 '- In MODE=CRAWL, retain unresolved symbolic bindings against D occurrence/invocation, for example ObjectID=.Objects(1).ID, without calling them a concrete DP_SIG. In MODE=AUTHOR, resolve the actual map and construct canonical DP_SIG; semantic DPA links the exact occurrence to that concrete SIM.', 'FP-027')
replace(M, '`given` is canonical minified typed JSON for all RUT parameters, setup inputs, and Rule-Obj-When cells; `simulation` is the complete canonical resolved payload.',
 '`given` and `simulation` use the exact canonical shapes and tuple ordering defined in Section 13.2, including explicit unresolved informational obligations; resolved runtime simulation payloads are never guessed.', 'FP-027')
replace(M, 'sort by canonical `given+simulation`', 'sort by the canonical (given, simulation) tuple', 'FP-027')
replace(M, 'canonical given+simulation)', 'canonical given, canonical simulation)', 'FP-027')
replace(M, 'sig=<DP_SIG>|state=<CTX|CLOSED|READY>', 'sig=<concrete DP_SIG or ->|state=<CTX|CLOSED|READY>', 'FP-027')
replace(M, '7. For every Data Page access found during scan, create/update a `DP` row keyed by `DP_SIG`. Resolved reachable/unknown `DP` rows become `CLOSED` with `proof=simRequired` and remain an AUTHOR audit obligation; unresolved parameters stay `CTX`; exact Data Page rule metadata requests use `READY` only when required.',
 '7. For each Data Page access retain one D occurrence with canonical DP KEY and its invocation/access evidence. Do not key an unresolved access by a guessed DP_SIG. When symbolic bindings and declaration/scope metadata are grounded, close acquisition with proof=simRequired even if scenario execution must still produce concrete values. Missing declaration or symbolic binding evidence remains CTX; request exact metadata through READY only when required. Author later links that occurrence to a concrete DP_SIG/SIM or a terminal informational gap.', 'FP-027')
replace(M, '|missing=<DP_SIG...>|fix=<return WITNESSES or reserialize frozen payload>',
 '|missing=<DP D occurrence ids, plus concrete DP_SIG when known>|fix=<return WITNESSES or reserialize frozen payload>', 'FP-027')
replace(M, '- preserve array order when array order affects runtime behavior;', '- preserve every array order exactly;', 'FP-027')
replace(M, '- list element order when order affects execution;', '- exact list element order;', 'FP-027')
replace(M, 'For every simulation group G and local row n:',
 'For each EXECUTABLE group G, in its own candidate use the sole zero-indexed UnitTestRules[0] and corresponding Scenario/Decision array index n:', 'FP-011')
replace(M, 'UnitTestRules[G]', 'UnitTestRules[0]', 'FP-011', 4)
before(V, 'First enforce the explicit scalar Text/TrueFalse decision and candidate constraints in V6;',
 'For each SIM trace, decode sig and params after splitting fields. Both are canonical duplicate-free typed JSON under the producer contract: sig has exactly key and params, key is the exact DP canonical identity for SIM.rule, and sig.params equals the separately recorded SIM.params with JSON types preserved. Reject a legacy name=type:value signature or a map mismatch as TRACE_INVALID/REJECT_SEMANTICS; no hidden source fact may be inferred. Canonical JSON sorts object keys by Unicode code point, preserves arrays/types, uses no optional whitespace and exact plain finite decimal notation (no exponent, trailing fractional zeros or negative zero); strings use literal Unicode and standard control/quote/backslash escaping. This verifies candidate-visible signature consistency, not proof of missing runtime inputs.', 'FP-027')

# FP-003: remove active lower-section physical candidate authoring obligations.
OWNERSHIP = [
 ('- `DPA` = Data Page Audit proving final setup seeds and `pySimulation` match reachable/unknown `DP_SIG` obligations.', '- DPA = semantic Data Page audit matching frozen SIM/SETUP to relevant concrete signatures and terminal unresolved access obligations.'),
 ('- `SIM` = final simulation decision line for `AssertionDecisionTrace`; it must correspond to serialized `RuleCode.pySimulation`.', '- SIM = final immutable semantic simulation decision; Generator alone later projects it into a physical mock and trace.'),
 ('- `ASSERT` = final emitted assertion decision that must appear in RuleCode.', '- ASSERT = final semantic assertion decision; its downstream projection belongs to Generator.'),
 ('- `OMIT` = final omitted candidate/claim that must not appear in RuleCode.', '- OMIT = final excluded claim with grounded omission evidence and no executable assertion.'),
 ('A reachable/unknown `DP` row with `proof=simRequired` remains an AUTHOR/DPA obligation until matching `SIM`/`RuleCode.pySimulation` exists and `DPA.pass=true`.', 'A reachable/unknown DP row with proof=simRequired remains an Author obligation until grounded semantic SIM/DPA passes for executable use, or its terminal failure is retained as informational OMIT/GAP under Section 7.7.'),
 ('- `STATECHECK.preFinal` is a storage gate over final RuleCode/EvidenceSummary; it is not the gate for entering `MODE=AUTHOR`.', '- STATECHECK.preFinal is a storage gate over final semantic ScenarioGroup/ASSERT/SIM/OMIT/SUMMARY records, not the gate for entering MODE=AUTHOR.'),
 ('No assertion, omission, or RuleCode may be authored until this gate passes.', 'No final ASSERT, OMIT or semantic ScenarioGroup may be authored until this gate passes.'),
 ('use only for setup/existence, PropertyTrace, assertions, and RuleCode}', 'use only for semantic setup/existence, PropertyTrace and assertion decisions}'),
 ('- ReasoningTrace, APB, PropertyTrace, EvidenceSummary, and RuleCode must use only payload values from `PC.payload`.', '- ReasoningTrace, APB, PropertyTrace, SUMMARY and ASSERT decisions use only grounded PC.payload values.'),
 ('- `APB.target` is the canonical runtime property path used to construct RuleCode.', '- APB.target is the canonical runtime property path frozen in semantic ASSERT/binding records.'),
 ('repair assertions by switching to the correct producer payload or omit them before RuleCode.', 'return to the affected semantic phase and rebuild grounded ASSERT/OMIT before freezing; never repair a candidate here.'),
 ('Every exact-value assertion in `RuleCode.pyExpectedResults` must be backed by an internal property trace with `Verified` or `PredictedFromRules`. Every structural assertion must be backed by a structural trace. Every omitted exact-value claim must be absent from `RuleCode.pyExpectedResults` and represented in `EvidenceSummary.OmittedClaimCount` and `ReasoningTrace`.', 'Every exact-value ASSERT requires a grounded property trace with Verified or PredictedFromRules. Structural ASSERT requires structural evidence. Every omitted exact claim has no ASSERT and is represented by OMIT, SUMMARY.omissionCount and frozen reasoning evidence.'),
 ('`MODE=AUTHOR`: generate scenarios, assertions, RuleCode, and EvidenceSummary. Enter this mode only after `STATECHECK.preAuthor=PASS` proves `open=0`, `ready=0`, `ctx=0`, and `unscanned=0`. `STATECHECK.preFinal` runs later before storage to reconcile final RuleCode, ReasoningTrace, BlockingGaps, AssertionDecisionTrace, and EvidenceSummary.', '`MODE=AUTHOR`: form Scenarios and immutable semantic ASSERT/SIM/OMIT/SUMMARY/GAP/EVIDENCE. Enter only after STATECHECK.preAuthor=PASS proves open=ready=ctx=unscanned=0. STATECHECK.preFinal later reconciles those semantic records under the mode-specific storage gate.'),
 ('PropertyTrace, setup, assertions, and RuleCode.', 'PropertyTrace, semantic setup and assertion decisions.'),
 ('or RuleCode expected result.', 'or final ASSERT.'),
 ('the final RuleCode.pySetupPages JSON must contain the exact recorded DTA.before key/value', 'the frozen SETUP records must contain the exact recorded DTA.before key/value'),
 ('concrete `SIM`/`pySimulation` parameter value.', 'concrete semantic SIM parameter value.'),
 ('Before creating any pySimulation artifact', 'Before freezing any semantic SIM'),
 ('Before every legacy candidate-write transport call:', 'Before the ScenarioGroup WriteMemory handoff:'),
 ('- Verify every pySimulation entry maps', '- Verify every semantic SIM maps'),
 ('Use `RuleCode.pySimulation` for mocked `Rule-Declare-Pages` dependencies. Do not represent Data Page mocking as `pySetup + LoadDataPage`.', 'Use semantic SIM for mocked Rule-Declare-Pages dependencies; never turn a mocked Data Page into a LoadDataPage action.'),
 ('`pySimulation[*].pySetupPages[*].pyPageDetails` is seeded payload, not dependency metadata.', 'SIM.payload and its grounded setup-page binding are seeded data, not dependency metadata.'),
 ('a matching seed in `pySimulation` or `pySetupPages`.', 'a matching seed in semantic SIM or SETUP.'),
 ('→ final pySimulation must seed', '→ final SIM payload must seed'),
 ('- Technical detail belongs exclusively in EvidenceSummary.ReasoningTrace and RuleCode.', '- Technical detail belongs in frozen semantic EVIDENCE/PROFILE reasoning, ASSERT/SIM/OMIT and SUMMARY records.'),
 ('Narratives must summarize the same decisions as `RuleCode` and `EvidenceSummary`; they must not add unsupported claims.', 'Narratives summarize the same frozen semantic ASSERT/SIM/OMIT/SUMMARY decisions; they never add unsupported claims.')]
for old, new in OWNERSHIP:
    replace(M, old, new, 'FP-003')
replace(M, '5. `pySimulation` is required for every reachable/unknown `DP_SIG` with resolved Scenario params. Empty/no-match output is valid only when explicitly represented in `pySimulation` for the same `DP_SIG`. Missing `pySimulation` is blocking, not equivalent to empty results.',
 '5. EXECUTABLE mode requires a grounded SIM for each reachable/unknown simulation obligation needed for execution, with resolved params. Empty/no-match is valid only with an explicit payload. Missing required SIM prevents execution and follows the terminal informational path in Section 7.7; it never means empty results.', 'FP-005')
replace(M, '`DPA.pass=true` requires every reachable/unknown `DP_SIG` to have: matching `RuleCode.pySimulation`, same normalized parameters, required/property-expression params seeded, correct page/list shape, and explicit output for empty/no-match cases.',
 'For EXECUTABLE mode, DPA.pass=true requires matching semantic SIM, identical canonical params, required caller seeds, correct shape and explicit empty/no-match output for every relevant DP obligation. Informational mode retains terminal gaps without requiring or claiming DPA.pass=true.', 'FP-005')
before(M, 'Structure mapping:', 'Downstream formatting reference for the remainder of Section 10: Scenario Author captures the corresponding semantic type/context facts only. Physical py* candidate field construction is performed only by Generator.', 'FP-003')
replace(M, 'For every final Scenario:\n- serialize the DP_SIG',
 'For each EXECUTABLE final Scenario (NOT_TESTABLE uses the informationalScenario key from Section 13):\n- serialize the DP_SIG', 'FP-005')
replace(M, 'Scenarios with no required pySimulation use:', 'EXECUTABLE Scenarios with no required simulation use:', 'FP-005')
replace(M, '- RuleCode.pySimulation MUST match the canonical simulation represented by that group\'s SIMULATION_GROUP_KEY;',
 '- For EXECUTABLE groups, RuleCode.pySimulation matches the canonical simulations key. NOT_TESTABLE groups have no RuleCode and use their informationalScenario key.', 'FP-005')
replace(M, 'Every FROZEN `S` row is a mandatory final combination row.',
 'Every EXECUTABLE FROZEN S row is a mandatory final combination row; informational S rows are mandatory NotTestable outcomes with no physical Decision row.', 'FP-005')
replace(M, '- verify every Scenario\'s serialized SIMULATION_GROUP_KEY equals its FROZEN `S` value; a semantic difference returns to WITNESSES;',
 '- verify each executable key equals its canonical frozen S.simulation; for informational keys verify the sole frozen S ID and retained unresolved snapshot facts. Any semantic difference returns to WITNESSES;', 'FP-005')

# Schema changes are mode-specific; executable RuleCode payload structures stay intact.
before(M, 'Terminal informational compiler path (applies in I/W/F/B/A):',
 'An informational Scenario whose owner execution is already grounded retains that actual owner/covers even if every output assertion is unavailable. Its no-ASSERT/zero-SIM projection never retroactively changes executed branch facts. Only informational rows with blocked execution use empty covers and B targets under the terminal path below. No informational mode fabricates an expected Result.', 'FP-005')
replace(M, 'while executable rows alone contribute to union covers=R.',
 'while only actually evidenced execution in either mode contributes to union covers=R.', 'FP-005')
TRACE_DESCRIPTION = ('Final candidate-visible decision projection. EXECUTABLE contains canonical ASSERT/SIM/OMIT records aligned to RuleCode; INFORMATIONAL_NOT_TESTABLE contains one or more OMIT only, zero ASSERT/SIM and no RuleCode. Author finalizes semantic decisions; Generator projects them; Validator never invents or changes them. SIM.sig is canonical typed JSON with exactly key and params and must agree with SIM.params. '
 'Trace field values only encode source ampersand as &amp;, double quote as &quot;, literal pipe as &#124;, CR as &#13; and LF as &#10;. Structural fields remain separated by literal | and trace records by actual LF in the in-memory trace before normal JSON serialization; never entity-encode structural separators. Validator splits records and literal structural pipes before decoding field-value entities exactly once.')
for file in ('rule-test-unit-case_JsonSchema.txt', 'rule-test-unit-case_multInpComb-JsonSchema.txt'):
    schema = json.loads(S[file])
    item = schema['properties']['UnitTestRules']['items']
    info = item['allOf'][0]['else']['properties']['Scenarios']['items']
    info.setdefault('required', []).extend(['ReasoningConfidence', 'EvidenceSummary'])
    info['properties']['ReasoningConfidence'] = {'const': 'Low'}
    es = info['properties']['EvidenceSummary']
    es['required'].append('DependencyClosureStatus')
    es['properties']['DependencyClosureStatus'] = {'const': 'Blocked'}
    family = 'Rule-Obj-When MultInpComb' if 'multInpComb' in file else 'standard'
    schema['title'] = f'Pega {family} candidate for one physical group: executable or informational'
    schema['$comment'] = ('One physical pyGroup = one candidate = exactly one UnitTestRules entry. EXECUTABLE requires RuleCode and FullyTestable/PartiallyTestable Scenarios. INFORMATIONAL_NOT_TESTABLE omits RuleCode, requires Low confidence, Blocked closure, zero ASSERT/SIM, nonempty OMIT/gaps. Different physical groups are different candidates. '
      + ('For executable When only: one Decision block, ordered combination rows, input cells first and one Result cell last; Scenario[n] describes row[n]. Full typed simulation key and execution class govern grouping. Informational When has one Scenario and no Decision rows. Empty input cells initialize their carrier; they do not prove absence. ' if 'multInpComb' in file else '')
      + 'All RuleCode/setup/assertion/simulation definitions apply only when RuleCode is present. Source provenance and Pega runtime behavior require their separate checks.')
    ed = schema['$defs']['EvidenceSummary']
    ed['title'] = 'Mode-aware final EvidenceSummary'
    ed['description'] = 'Frozen scenario evidence projection for executable or informational mode; internal source ledgers are not emitted.'
    descriptions = {
      'SupportLevel': 'NotTestable exactly for informational no-RuleCode outcomes. Otherwise omission takes precedence, then supported executable assertions: Verified, PredictedFromRules or StructuralOnly.',
      'DependencyClosureStatus': 'Closed requires no active dependency work and no gaps. Blocked preserves terminal gaps with no queued/unscanned work. Informational NotTestable requires Blocked.',
      'QueuedDependencyCount': 'Active queued work is not a final outcome; this count is zero in both candidate modes.',
      'UnscannedFetchedRuleJsonCount': 'Active unscanned fetched work is not a final outcome; this count is zero in both candidate modes.',
      'SimulationState': 'Semantic simulation requirement. Executable simulations align to frozen SIM records; informational outcomes have zero SIM but retain RequiredButLimited when required simulation could not be resolved.',
      'AssertionCount': 'EXECUTABLE: count all emitted ASSERT items/cells including ResultCount. INFORMATIONAL_NOT_TESTABLE: zero.',
      'ExactValueAssertionCount': 'Count emitted exact-value assertions in executable mode; zero in informational mode.',
      'StructuralAssertionCount': 'Count emitted structural/count/error assertions in executable mode; zero in informational mode.',
      'OmittedClaimCount': 'Count final canonical OMIT decisions in either mode; at least one in informational mode.',
      'SimulatedDependencyCount': 'Count projected SIM records in executable mode; zero in informational mode even when missing simulation caused the terminal gap.',
      'AssertionDecisionTrace': TRACE_DESCRIPTION,
    }
    for name, desc in descriptions.items():
        ed['properties'][name]['description'] = desc
    # Descriptions inside reusable physical definitions are scoped by root $comment.
    # Remove misleading source-authoring guidance from simulation data descriptions.
    for name, node in schema['$defs'].items():
        if name.startswith('Simulation') or name == 'ClipboardPageSeed':
            if 'description' in node:
                node['description'] = 'EXECUTABLE only: project the frozen semantic payload and evidenced page/item binding, including dependency-required leaves inside witness-locked items. Generator never invents seeds, wrappers or source semantics.'
            if name in ('SimulationSetupPage', 'SimulationRule'):
                for field in ('pyPageDetails', 'pySetupPages'):
                    if field in node.get('properties', {}):
                        node['properties'][field]['description'] = 'Project the exact frozen source payload/setup-page census and binding. Preserve types, classes and navigation; do not choose data from desired assertions.'
    old = S[file]
    S[file] = json.dumps(schema, indent=2, ensure_ascii=False) + '\n'
    CHANGES.append({'finding': 'FP-010/FP-011/FP-019/FP-027', 'file': file,
                    'old_sha256': hashlib.sha256(old.encode()).hexdigest(),
                    'new_sha256': hashlib.sha256(S[file].encode()).hexdigest()})

# Re-encode example signatures using their explicit historical key and typed map;
# preserve executable RuleCode byte-equivalent JSON objects and all other values.
def canon_native(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

def trace_encode(value):
    return value.replace('&', '&amp;').replace('"', '&quot;').replace('|', '&#124;').replace('\r', '&#13;').replace('\n', '&#10;')

for file in list(S):
    if 'JsonExample' not in file:
        continue
    data = json.loads(S[file]); changed = False
    for unit in data['UnitTestRules']:
        for scenario in unit['Scenarios']:
            es = scenario['EvidenceSummary']; lines = []
            for line in es['AssertionDecisionTrace'].splitlines():
                if line.startswith('SIM|'):
                    pairs = [p.split('=', 1) for p in line.split('|')[1:]]
                    fields = dict(pairs)
                    legacy_sig = html.unescape(fields['sig'])
                    key = legacy_sig.split('|', 1)[0]
                    assert key.startswith('DP@')
                    params = json.loads(html.unescape(fields['params']))
                    fields['sig'] = trace_encode(canon_native({'key': key, 'params': params}))
                    line = 'SIM|' + '|'.join(k+'='+fields[k] for k, _ in pairs)
                    changed = True
                lines.append(line)
            es['AssertionDecisionTrace'] = '\n'.join(lines)
    if changed:
        S[file] = json.dumps(data, indent=2, ensure_ascii=False) + '\n'
        CHANGES.append({'finding':'FP-027', 'file':file, 'change':'Canonical typed DP_SIG; RuleCode unchanged'})

# Build runtime embedded prompts from exact standalone text, preserving XML export.
for config, prompt in [('UnitTestGenerator.txt', G), ('JsonValidator_tool.txt', V)]:
    pattern = re.compile(r'(<pySystemPrompt>)(.*?)(</pySystemPrompt>)', re.S)
    assert len(pattern.findall(S[config])) == 1
    encoded = '\n'.join('<p>'+html.escape(line, quote=False)+'</p>' for line in S[prompt].rstrip('\n').split('\n'))
    S[config] = pattern.sub(lambda m: m.group(1)+encoded+m.group(3), S[config])
    CHANGES.append({'finding':'CROSS_RUNTIME_SYNC', 'file':config, 'source':prompt})

# Guard immutable baseline before any source writes.
manifest = json.loads((ROOT/'03_CONTINUITY_AND_DECISIONS/FINAL_SOURCE_MANIFEST_v5.json').read_text())
for entry in manifest['sources']:
    b = (BASE/'sources'/entry['name']).read_bytes()
    assert hashlib.sha256(b).hexdigest() == entry['sha256'], entry['name']
for file, text in S.items():
    if file.endswith('JsonSchema.txt') or 'JsonExample' in file:
        json.loads(text)
for file, text in S.items():
    (WORK/'sources'/file).write_text(text)
(WORK/'verification/FP_SOURCE_APPLY_RECEIPT_v6.json').write_text(json.dumps({
    'status':'APPLIED_LOCAL_NOT_YET_VERIFIED', 'baseline':'v5', 'target':'v6',
    'wire_revision':'1.4 per accepted D-003', 'changes':CHANGES,
    'deferred':['C-027','C-028','C-029'], 'github_writes':False}, indent=2, ensure_ascii=False)+'\n')
print(json.dumps({'status':'APPLIED_LOCAL_NOT_YET_VERIFIED','transformations':len(CHANGES),
                  'source_count':len(list((WORK/'sources').glob('*.txt')))}))
