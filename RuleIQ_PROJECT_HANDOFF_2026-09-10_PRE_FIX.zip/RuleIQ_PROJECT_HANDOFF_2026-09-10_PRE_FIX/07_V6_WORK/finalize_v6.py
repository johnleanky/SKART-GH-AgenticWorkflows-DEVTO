#!/usr/bin/env python3
"""Build current documentation from passing evidence; preserve the v5 snapshot."""
from pathlib import Path
from collections import Counter
import difflib
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / '07_V6_WORK/RuleIQ_v6'
VER = WORK / 'verification'
SRC = WORK / 'sources'
BASE = ROOT / '01_CURRENT_V5_BASELINE/EXTRACTED_V5/RuleIQ_risk001_v5_work'

def read(path):
    return json.loads(path.read_text())

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

summary = read(VER / 'VERIFICATION_SUMMARY_v6.json')
assert summary['status'] == 'PASS_LOCAL_CONTRACTS'
assert summary['source_sha256'] == {p.name: digest(p) for p in sorted(SRC.glob('*.txt'))}
full = read(VER / 'FULL_PROJECT_VERIFICATION_v6.json')
assert full['checks_failed'] == 0
original = read(ROOT / 'HANDOFF_MANIFEST_SHA256.json')
assert all(digest(ROOT / x['path']) == x['sha256'] for x in original['files'])

# Only artifacts copied from the baseline are archived; current v6 files stay put.
keep = {
    'verify_prompt_refactor_v6.py', 'verify_risk001_v3.py',
    'verify_example_alignment_v4.py', 'verify_multinpcomb_deep_v3.py',
    'FIXTURE_STANDARD_INFORMATIONAL_NOT_TESTABLE.json',
    'FIXTURE_MULTINPCOMB_INFORMATIONAL_NOT_TESTABLE.json',
    'SOURCE_rule-test-unit-case_JsonExample_PRE_CORRECTION.txt',
    'SOURCE_rule-test-unit-case_multInpComb-JsonExample_PRE_CORRECTION.txt',
    'ARCHITECTURE_VERIFICATION_v6.json',
}
hist = VER / 'historical_v5'
hist.mkdir(exist_ok=True)
for p in (BASE / 'verification').iterdir():
    local = VER / p.name
    if p.is_file() and p.name not in keep and local.exists():
        assert local.read_bytes() == p.read_bytes(), 'Refuse to archive modified file: ' + p.name
        local.rename(hist / p.name)
for path in [ROOT / '03_CONTINUITY_AND_DECISIONS/SIMULATION_REVIEW_LEDGER_v52.md',
             ROOT / '02_REOPENED_FULL_PROJECT_AUDIT/FULL_PROJECT_CROSS_REFERENCE_AUDIT_v1.json',
             ROOT / '02_REOPENED_FULL_PROJECT_AUDIT/FULL_PROJECT_CROSS_REFERENCE_AUDIT_v1.md',
             ROOT / '02_REOPENED_FULL_PROJECT_AUDIT/FULL_PROJECT_SIMULATION_MATRIX_v1.json',
             ROOT / '04_EXTERNAL_REFERENCES/RULE_CRAWLER_TOOL_FETCH_REFERENCE.json']:
    shutil.copyfile(path, hist / path.name)
(hist / 'README.md').write_text('''# Historical v5 evidence — superseded

All files in this directory retain their original bytes. Their PASS, VERIFIED_LOCAL,
OPEN and OPEN_DECISION labels describe previous checkpoints and are not the current
v6 status. In particular, the pre-fix audit reopened 29 findings after the old
verification suites passed. Do not use a historical register, source manifest,
apply script or test result as current release authority.

Current authority is ../../CHANGE_REGISTER_v6.json, ../../CURRENT_STATE.json and
../VERIFICATION_SUMMARY_v6.json. The v52 ledger preserves accepted decisions and
history; ../../SIMULATION_REVIEW_LEDGER_v53.md records the new checkpoint.

Historical source examples retained in the parent directory are explicit regression
fixtures, not deployment sources. Only ../../sources/ is the current source set.
''')

receipt = read(VER / 'FP_SOURCE_APPLY_RECEIPT_v6.json')
receipt['status'] = 'APPLIED_LOCAL'
receipt['status_semantics'] = 'Application receipt only; final verification is in VERIFICATION_SUMMARY_v6.json.'
receipt['verification_report'] = 'verification/VERIFICATION_SUMMARY_v6.json'
write(VER / 'FP_SOURCE_APPLY_RECEIPT_v6.json', receipt)

resolutions = [
    'Restored the exact intended crawler blob, with SHA-256, Git blob identity and scope provenance.',
    'Require case id, TestedRuleKey and full RuleJSON identity before acquisition; reject identity mismatch.',
    'Active Author gates operate on immutable semantic decisions; physical projection references are explicitly downstream.',
    'WHEN DecisionInput/DecisionResult formation is EXECUTABLE-only; informational outcomes carry OMIT/GAP.',
    'Closed informational compiler/storage path uses zero ASSERT/SIM and Low/Blocked with terminal proof, without a mock or DPA success. Preserve actual evidenced coverage; isolate each informational WHEN by its frozen S id.',
    'Infeasible WHEN rows are excluded from executable columns but preserved as separate informational outcomes.',
    'Informational Generator path skips G5/G6 physical RuleCode projection and proceeds to G7.',
    'Generator classifies mode before knowledge acquisition: schema only for information, full structural knowledge for executable groups, with per-dependent-group failures.',
    'Validator finalizes an informational UT locally, continues siblings, then emits all results once.',
    'Both real schemas and Validator require informational Low confidence and Blocked closure, including required fields.',
    'Schema descriptions follow conditional RuleCode and one-candidate cardinality; Main downstream indexing uses the sole UnitTestRules[0].',
    'Confirmed Model WHEN condition field pyPropertiesName is used in all relevant mappings.',
    'Confirmed formal field pyParametersParamType and raw STRING are supported without losing original spelling.',
    'Raw thread scope is retained and compared as Thread; unsupported scope values are not generalized.',
    'Concrete pyLabel is a last-resort behavior source only when stronger sources are empty and the label is unambiguous.',
    'Simulated Data Page loader traversal stops at the accepted boundary; caller, metadata, parameters and independent references still require evidence.',
    'Required Model owner outcomes include terminal false edges that suppress observable modifying producers.',
    'APPEND_AND_MAP_TO appends a new target, reads relative RHS from the configured existing source, writes children into the new target and copies only mapped fields.',
    'Simulation carrier/depth and items remain witness-locked, while closed executable dependencies may require leaves inside those items.',
    'One omission reason catalog includes incorrect_candidate_assertion across producer and consumer contracts.',
    'Owner coverage outputs include APPEND_AND_MAP_TO and modifying operations defined by the active knowledge area.',
    'Direct SET payload derives from its own RHS; composite payload may include only grounded descendant mappings in its target structure.',
    'Non-execution accepts terminal control-flow exclusion, including an actually executed prior EXIT; UNKNOWN guards do not become guessed false guards.',
    'PROFILE provenance is per binding kind: property, formal parameter, named-page context, or owning collection property plus execution evidence.',
    'DEP.kind exactly matches authoritative canonical identity, including When/DTable/Model/Prop/RUF/DP; aliases are forbidden and RUF has empty class. SG.version stays 1.4 per D-003.',
    'SCAN retains all READY occurrences; OUT and actual requests deduplicate exact keys in stable order, then fan out evidence while retaining each occurrence context.',
    'Canonical typed JSON specifies exact decimal, Unicode, ordering, root shapes and absence semantics. Only concrete accesses have DP_SIG; unresolved crawl access identity remains its D occurrence. Examples migrate SIM.sig without changing RuleCode.',
    'Retain the already selected conservative omission/gap policy for unknown initial presence. A skipped write alone proves neither presence nor absence.',
    'Current audit, register, matrix, state, ledger and manifest are regenerated from v6 evidence; old certifications are explicitly historical and runtime work stays external.',
]
old_audit = read(ROOT / '02_REOPENED_FULL_PROJECT_AUDIT/FULL_PROJECT_CROSS_REFERENCE_AUDIT_v1.json')
findings = []
for old, resolution in zip(old_audit['findings'], resolutions, strict=True):
    fid = old['id']
    checks = [x for x in full['checks'] if fid in x['findings']]
    anchors = []
    for change in receipt['changes']:
        if change['finding'] != fid or not change.get('new'):
            continue
        path = SRC / change['file']
        text = path.read_text()
        needle = change['new']
        if needle not in text:
            needle = needle.splitlines()[0]
        if needle and needle in text:
            row = {'file': 'sources/' + path.name,
                   'line': text[:text.index(needle)].count('\n') + 1}
            if row not in anchors:
                anchors.append(row)
    if fid == 'FP-001':
        anchors = [{'file': 'sources/Rule_Crawler_tool.txt', 'line': 1}]
    if fid == 'FP-029':
        anchors = [{'file': 'CHANGE_REGISTER_v6.json', 'line': 1},
                   {'file': 'verification/historical_v5/README.md', 'line': 1}]
    assert checks or fid == 'FP-029', fid
    findings.append({
        'id': fid, 'severity': old['severity'], 'title': old['title'],
        'previous_status': old['status'],
        'status': 'VERIFIED_LOCAL_CONTRACT' if checks else 'APPLIED_PENDING_PACKAGE_VERIFICATION',
        'resolution': resolution, 'source_anchors': anchors,
        'evidence': [{'report': 'verification/FULL_PROJECT_VERIFICATION_v6.json',
                      'check': x['check'], 'kind': x['evidence_kind']} for x in checks],
        'runtime_status': 'NOT_EXECUTED',
    })

old_register = read(ROOT / '03_CONTINUITY_AND_DECISIONS/REFACTOR_CHANGE_REGISTER_v5_LOCAL.json')
legacy = []
for old in old_register['changes']:
    row = dict(old)
    row['historical_status'] = row.pop('status')
    row['status'] = 'EXTERNAL_PENDING' if row['change_id'] in ('C-027', 'C-028', 'C-029') else 'HISTORICAL_SUPERSEDED'
    row['status_semantics'] = ('Runtime implementation and integration validation remain deferred.'
                             if row['status'] == 'EXTERNAL_PENDING' else
                             'Historical requirement text, not a new individual certification. Current interpretation and evidence are the FP register and current regression reports.')
    legacy.append(row)
register = {
    'version': 'v6', 'date': '2026-09-10', 'status': 'APPLIED_PENDING_PACKAGE_VERIFICATION',
    'authority': 'Only findings[] are the current FP closure register. legacy_changes[] preserves prior requirements and explicitly withdraws blanket v5 verification authority.',
    'status_semantics': {
        'VERIFIED_LOCAL_CONTRACT': 'Correction is present in final sources and checked locally; not proof of deployed LLM behavior or Pega runtime.',
        'HISTORICAL_SUPERSEDED': 'Previous implementation/verification record retained for traceability; see current FP contract and regression evidence.',
        'EXTERNAL_PENDING': 'Explicitly deferred Memory runtime contract.'},
    'findings': findings, 'legacy_changes': legacy,
    'current_regression': 'verification/VERIFICATION_SUMMARY_v6.json',
    'github_writes': False,
}
write(WORK / 'CHANGE_REGISTER_v6.json', register)
write(WORK / 'FULL_PROJECT_CROSS_REFERENCE_AUDIT_v2.json', {
    'status': 'APPLIED_PENDING_PACKAGE_VERIFICATION',
    'scope': 'Final-source cross-reference review plus local schema/fixture/model evidence. Runtime remains unverified.',
    'findings': findings,
    'previous_audit': 'verification/historical_v5/FULL_PROJECT_CROSS_REFERENCE_AUDIT_v1.json',
    'checks': 'verification/VERIFICATION_SUMMARY_v6.json',
    'crawler_scope': read(VER / 'CRAWLER_PROVENANCE_v6.json')['scope'],
})

# Each matrix row has its own reviewed trace and explicit evidence category.
matrix_specs = [
    ('PASS_CONTRACT_REVIEW', [], 'Author stores semantic groups; Generator reads exact addresses, writes one executable candidate per group, invokes Validator and updates the same candidate once after a valid route. Main completes when at least one group is OK. This is source/fixture/model evidence, not end-to-end runtime.'),
    ('PASS_FIXTURE', ['FP-004', 'FP-027'], 'Equal executable simulation keys keep rows in one physical candidate with one Decision block. Actual example schemas, row alignment and canonical SIM signatures pass.'),
    ('PASS_CONTRACT_REVIEW', ['FP-005', 'FP-027'], 'Different complete canonical simulation objects produce separate physical candidates; each contains UnitTestRules[0], with frozen order retained.'),
    ('PASS_SCHEMA_AND_MODEL', ['FP-005', 'FP-007', 'FP-008', 'FP-010'], 'Terminal zero-ASSERT/SIM informational source passes its semantic storage gate. Generator loads only the schema and skips RuleCode projection. Actual standard informational fixture validates with Low/Blocked and OMIT/GAP.'),
    ('PASS_CONTRACT_REVIEW', ['FP-004', 'FP-005', 'FP-006'], 'Executable scenario uses its concrete simulations key; informational scenario uses its frozen informationalScenario key in a separate group. No Decision row or Result is invented for information; the scenario remains in the census.'),
    ('PASS_LOCAL_MODEL', ['FP-005', 'FP-027'], 'After acquisition is terminal, retain unresolved DP access evidence and Low/Blocked gaps. Informational storage needs no DPA success, SIM or RuleCode. Unresolved simulation snapshot precedes S ids; the later informationalScenario key does not invent a payload. Active work still rejects storage.'),
    ('PASS_SCHEMA_AND_MODEL', ['FP-009', 'FP-008'], 'Actual informational and executable fixtures enter the local batch model in that order. Informational result is stored locally, executable sibling is processed, and one final-return event contains both results. Missing executable knowledge leaves the informational success intact.'),
    ('PASS_SCHEMA', ['FP-010'], 'Both actual schemas reject informational High (and Medium) confidence and missing confidence. Positive Low informational fixtures still pass.'),
    ('PASS_SCHEMA', ['FP-010'], 'Both actual schemas reject Closed closure and missing closure for informational candidates with gaps; Blocked positive fixtures pass.'),
    ('PASS_LOCAL_MODEL', [], 'Malformed Validator response produces VALIDATOR_RESPONSE_INVALID, leaves Pending and schedules no lifecycle update. Existing architecture gates also preserve sibling attribution.'),
    ('PASS_LOCAL_MODEL', [], 'One failed lifecycle update produces LIFECYCLE_UPDATE_FAILED without retry. Another successful group can satisfy the aggregate completion rule. The real Memory service is still deferred.'),
    ('PASS_LOCAL_MODEL', ['FP-026'], 'D1 and D2 with the same key both stay in SCAN and map to one OUT request. A same-name rule in another class remains a second request; CTX rows are not sent.'),
    ('PASS_LOCAL_MODEL', ['FP-002'], 'Identity gate rejects each empty required field and a conflicting TestedRuleKey before acquisition. Complete matching identity passes.'),
    ('PASS_CONTRACT_REVIEW', ['FP-012'], 'Model condition mappings including KT.17 use pyPropertiesName; stale pyCondition guidance for Model WHEN is removed.'),
    ('PASS_CONTRACT_REVIEW', ['FP-013'], 'Model formal capture reads pyParametersParamType; STRING maps to String semantics while raw type evidence is retained through Main and Generator.'),
    ('PASS_CONTRACT_REVIEW', ['FP-014'], 'Raw thread is accepted only through the explicit comparison alias to Thread. Raw evidence is preserved and other unsupported scopes remain ineligible.'),
    ('PASS_CONTRACT_REVIEW', ['FP-015'], 'Concrete unambiguous pyLabel can supply the described behavior only when stronger sources are empty. It cannot override conflicts or invent unstated null/error behavior.'),
    ('PASS_CONTRACT_REVIEW', ['FP-016'], 'Simulation replaces loader execution, so loader-only references are not recursively crawled. Metadata, caller parameters, shape and independently executed dependencies remain obligations.'),
    ('PASS_CONTRACT_REVIEW', ['FP-017', 'FP-021'], 'A terminal false owner edge that suppresses APPEND_AND_MAP_TO is required coverage. Actual suppression proof covers it; output equality alone cannot erase it.'),
    ('PASS_LOCAL_MODEL', ['FP-018'], 'Model appends a Target-class item and maps its X from the existing Source-class page. Existing target items stay intact; unmapped Y is absent in the new item. The source contract also restores contexts after child processing.'),
    ('PASS_CONTRACT_REVIEW', ['FP-019'], 'Keep RUT-proven list carrier, depth and item census; add only item leaves required by closed executable dependencies. No extra wrapper or collection level is permitted.'),
    ('PASS_CONTRACT_REVIEW', ['FP-020'], 'incorrect_candidate_assertion is legal in the single shared omission catalog and can record the rejected input-only claim without emitting ASSERT.'),
    ('PASS_CONTRACT_REVIEW', ['FP-022'], 'Direct SET owns its RHS payload and does not need a descendant row. Composite producer payload stays inside its own target structure and cannot borrow a sibling value.'),
    ('PASS_CONTRACT_REVIEW', ['FP-023'], 'An actually executed prior EXIT in the same invocation is terminal control-flow exclusion for the later producer. Explicit CONTROL_FLOW_EXCLUSION evidence supports skipped execution; an unknown guard alone still cannot do so.'),
    ('PASS_CONTRACT_REVIEW', ['FP-024'], 'Param assertion uses exact formal PARAMETER_DEFINITION; named Page uses PAGE_CONTEXT. Property leaves still need PROPERTY_DEFINITION; collections need owning property and execution context. ASSERTION_CONTEXT is always required.'),
    ('PASS_LOCAL_MODEL', ['FP-025'], 'When/Prop/Model and the other canonical prefixes serialize without aliases. Producer and consumer grammar blocks agree exactly; wrong prefixes and DT/HELPER aliases fail the model.'),
    ('PASS_LOCAL_MODEL', ['FP-027'], 'Exact decimal and typed JSON model agrees for reordered object keys, preserves arrays and native types, distinguishes absence/null/empty and round-trips delimiters/Unicode. Actual example signatures match their independent parameter maps. This does not prove two LLM runs will follow the contract identically.'),
    ('PASS_LOCAL_MODEL', ['FP-028'], 'Unknown initial presence plus a skipped write remains UNKNOWN and causes omission/gap. Known absent or present state is preserved; executed remove/materialize operations update it in order. No harness initialization is assumed.'),
]
old_matrix = read(ROOT / '02_REOPENED_FULL_PROJECT_AUDIT/FULL_PROJECT_SIMULATION_MATRIX_v1.json')
matrix = []
for old, (status, ids, trace) in zip(old_matrix['simulations'], matrix_specs, strict=True):
    evidence = [x for x in full['checks'] if set(ids) & set(x['findings'])]
    matrix.append({'id': old['id'], 'case': old['case'], 'previous_result': old['result'],
                   'result': status, 'findings': ids, 'trace': trace,
                   'evidence': [{'report': 'verification/FULL_PROJECT_VERIFICATION_v6.json', 'check': x['check'], 'kind': x['evidence_kind']} for x in evidence],
                   'regression_evidence': 'verification/VERIFICATION_SUMMARY_v6.json',
                   'runtime_executed': False})
counts = dict(Counter(x['result'] for x in matrix))
write(WORK / 'FULL_PROJECT_SIMULATION_MATRIX_v2.json', {
    'status': 'PASS_LOCAL_REVIEW', 'scope': '28 reviewed cases with explicitly classified local evidence, not 28 Pega executions.',
    'simulations_total': len(matrix), 'simulation_status_counts': counts, 'simulations': matrix,
})

source_manifest = {
    'package_version': 'v6', 'status': 'PASS_LOCAL_CONTRACTS',
    'sources': [{'name': p.name, 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(SRC.glob('*.txt'))],
    'verification': 'verification/VERIFICATION_SUMMARY_v6.json',
}
write(WORK / 'SOURCE_MANIFEST_v6.json', source_manifest)
patch = []
for file in sorted(SRC.glob('*.txt')):
    old = BASE / 'sources' / file.name
    patch.extend(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],
                                    file.read_text().splitlines(True),
                                    fromfile='v5/sources/' + file.name if old.exists() else '/dev/null',
                                    tofile='v6/sources/' + file.name))
(VER / 'V5_TO_V6_SOURCE_DIFF.patch').write_text(''.join(patch))

state = {
    'date': '2026-09-10', 'version': 'v6', 'status': 'APPLIED_PENDING_PACKAGE_VERIFICATION',
    'source_count': 20, 'findings_total': 29,
    'finding_status_counts': dict(Counter(x['status'] for x in findings)),
    'checks_total': summary['checks_total'], 'checks_passed': summary['checks_passed'],
    'checks_failed': summary['checks_failed'],
    'simulations_total': 28, 'simulation_status_counts': counts,
    'runtime_validation': 'NOT_EXECUTED', 'deferred': ['C-027', 'C-028', 'C-029'],
    'github': 'NO_WRITES', 'wire_revision': '1.4 (accepted D-003; synchronized contract migration)',
    'authority': ['CHANGE_REGISTER_v6.json', 'FULL_PROJECT_CROSS_REFERENCE_AUDIT_v2.json',
                  'FULL_PROJECT_SIMULATION_MATRIX_v2.json', 'verification/VERIFICATION_SUMMARY_v6.json'],
    'next_action': 'Continue prompt and contract review under NEXT_STEPS.md; external implementations remain outside this workspace.',
}
write(WORK / 'CURRENT_STATE.json', state)

(WORK / 'README.md').write_text(f'''# RuleIQ v6 — locally verified prompt and contract corrections

This is the current set of 20 source files after corrections FP-001 through FP-029.
Current authority: CURRENT_STATE.json and CHANGE_REGISTER_v6.json. Historical
VERIFIED_LOCAL/PASS labels in verification/historical_v5/ describe earlier checkpoints.
All current documentation and future authored content must be in English.

Scope is prompts and contracts only. External Memory, RuleCrawler and other tool
implementations are maintained separately. This workspace does not change or deploy
those implementations, and live Pega access is not required for its contract work.

All {summary['checks_passed']} local checks passed: 86 architecture checks, 49 RISK-001 checks, 84 example
checks, 212 MultInpComb checks and {full['checks_total']} new source/schema/XML/local-model checks.
The matrix contains 28 reviewed cases with explicitly classified evidence. These
are not 28 Pega executions; deployed LLM agents and Memory were not run.

Corrections cover informational NotTestable without RuleCode or SIM; Main,
Generator and Validator ownership; KnowledgeTool modes; Low/Blocked schema rules;
confirmed Model/Data Page fields; append/map contexts; false-edge coverage;
provenance; DEP.kind; request deduplication; and exact canonical JSON for DP_SIG
and scenario snapshots. Existing example RuleCode objects are unchanged; only
SIM.sig signatures migrated. See the register and
verification/V5_TO_V6_SOURCE_DIFF.patch for the complete source changes.

SG.version remains 1.4 under accepted D-003. The canonical DP_SIG and informational
key formats changed, so Main, Generator, Validator, embedded prompts, schemas and
related examples form one coordinated contract set. The manifest identifies this
revision more precisely than the 1.4 wire number. The external integration must
preserve old persisted payloads and produce new immutable groups/candidates;
consumers must not silently normalize old payloads in place.

sources/Rule_Crawler_tool.txt preserves the exact reference Git blob. It is the
lower-level ResolveCrawlerBatch export, not the complete LLM-visible RuleCrawler
wrapper. It is reference evidence for contract review, not an implementation target
for this workspace.

To verify an extracted package (checked with Python 3.12):

```sh
python3 verification/verify_package_v6.py
python3 -m venv /tmp/ruleiq-v6-venv
/tmp/ruleiq-v6-venv/bin/python -m pip install -r verification/requirements.txt
/tmp/ruleiq-v6-venv/bin/python verification/run_all_v6.py
```

The first command checks the manifest using the standard library. The other
commands regenerate local verification reports. Some report paths may change,
so check package integrity before rerunning them. Verification evidence is pinned
to source hashes in verification/VERIFICATION_SUMMARY_v6.json.

See NEXT_STEPS.md for current prompt/contract work. C-027/C-028/C-029 retain their
EXTERNAL_PENDING implementation status; the companion Memory specification closes
only their contract stage. No GitHub writes or Pega deployment were performed.
''')
(WORK / 'NEXT_STEPS.md').write_text("# Next steps — prompts and contracts only\n\nThe user confirmed that external implementations remain separate. Current work\ncovers prompts, schemas, knowledge content, interface contracts and their local\nverification. All deliverables and communication are in English.\n\n1. Review the LLM-visible RuleCrawler contract in Main and the relevant KnowledgeAreas.\n   Use the unchanged ResolveCrawlerBatch export only as reference evidence. Identify\n   any missing wrapper mapping or conflicting prompt expectation; do not rewrite\n   or deploy the crawler implementation.\n2. Reconcile cross-agent request, response, identity, grouping and failure contracts.\n   Preserve the single-question A2A interfaces, exact GUID reads, independent group\n   outcomes and the existing no-retry rules.\n3. Correct any confirmed prompt/contract contradiction in its authoritative source.\n   Synchronize affected embedded prompts and update schemas/examples only when their\n   contracts change. Keep external tool implementations outside the change set.\n4. Run the checks relevant to changed contracts. Distinguish source review, schema\n   fixtures and local assertion/model checks from actual external runtime evidence.\n5. Update the current register, ledger and package manifests with traceable evidence.\n   Keep C-027/C-028/C-029 implementation status EXTERNAL_PENDING; their Memory\n   contract specification and local checks are maintained in the companion package.\n\nThe external Pega team's implementation requirements are described in the separate\nPega Implementation Specification. That document is a handover specification, not\nan instruction to modify external systems from this workspace.\n\nCompletion for this workspace means consistent prompts/contracts, passing applicable\nlocal checks, synchronized artifacts and accurate evidence labels. It does not\nrequire Pega access, external deployment or proof of live storage behavior.\n")
(WORK / 'SIMULATION_REVIEW_LEDGER_v53.md').write_text(f'''# Simulation review ledger — checkpoint 53

Date: 2026-09-10. Baseline: immutable v5 pre-fix handoff.
Previous accepted decisions and full history: verification/historical_v5/SIMULATION_REVIEW_LEDGER_v52.md.
This checkpoint supersedes v5 completion claims; it does not rewrite historical bytes.

FP-001–FP-028 have final-source corrections and passing independent local evidence.
FP-029 is finalized only after package governance/integrity checks pass. Current
status is always CURRENT_STATE.json / CHANGE_REGISTER_v6.json.

Decisions preserved: Model WHEN pyPropertiesName; formal pyParametersParamType
including raw STRING; thread scope alias; strict pyLabel fallback; simulated loader
boundary; canonical DEP.kind with unchanged SG.version 1.4 (D-003); conservative
skipped-output omission/gap policy already selected by the pre-fix handoff plan.

New contract details: informational WHEN group identity follows its frozen S id;
terminal informational outcomes remain materializable with gaps and zero ASSERT/SIM;
known execution coverage is preserved, blocked execution never becomes achieved
coverage. Canonical given/simulation sorting happens before S ids, so grouping does
not feed back into scenario ordering. DP_SIG describes only resolved concrete maps.
No silent in-place conversion of persisted sources is permitted.

Independent regression results: {summary['checks_passed']}/{summary['checks_total']} local checks.
The 28-case matrix distinguishes source review, real schema/fixture validation and
synthetic local model runs. No Pega/LLM execution is claimed. Existing example
RuleCode objects are unchanged; the legacy SIM signature assertion was replaced
by actual canonical key/params validation in verify_example_alignment_v4.py.

C-027/C-028/C-029 remain EXTERNAL_PENDING. Exact crawler provenance is recorded,
but wrapper integration remains unexecuted. GitHub writes: none. no-mistakes was
not used for this implementation, following the user's instruction.
''')
(ROOT / 'CURRENT_V6_START_HERE.md').write_text("# Current continuation — RuleIQ v6\n\nWorking scope: prompts and contracts only. External Memory, RuleCrawler and other\ntool implementations remain separate. All deliverables and communication are in English.\n\nThe [Memory contract stage](09_MEMORY_RUNTIME/README.md) is complete: 90/90 local\nchecks passed; 24 external acceptance cases are specified but were not executed.\nThe [Pega Implementation Specification](10_PEGA_IMPLEMENTATION_SPEC/PEGA_IMPLEMENTATION_SPEC.md)\ndescribes the external team's required work without changing any implementation.\n\nCurrent source package: [RuleIQ_v6/README.md](07_V6_WORK/RuleIQ_v6/README.md).\nCurrent status: [CURRENT_STATE.json](07_V6_WORK/RuleIQ_v6/CURRENT_STATE.json).\nNext prompt/contract steps: [NEXT_STEPS.md](07_V6_WORK/RuleIQ_v6/NEXT_STEPS.md).\n\nRoot START_HERE.md, CURRENT_STATE.json and directories 01–05 preserve the original\nPRE_FIX snapshot. Their historical statuses do not describe the current v6 sources.\nDirectory 06 contains the initial pre-correction assessment; 07 contains the current\nsources; 08_RELEASE contains verified archives, hashes and package receipts.\n")
print(json.dumps({'status': 'DOCUMENTATION_READY_FOR_PACKAGE_VERIFICATION',
                  'findings': len(findings), 'cases': len(matrix), 'historical_files': len(list(hist.iterdir()))}))
