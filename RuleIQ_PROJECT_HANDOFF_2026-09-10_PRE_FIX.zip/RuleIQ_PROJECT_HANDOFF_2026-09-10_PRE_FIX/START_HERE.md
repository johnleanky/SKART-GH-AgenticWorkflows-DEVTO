# RuleIQ Refactoring — START HERE

## Snapshot identity

- **Snapshot date:** 2026-09-10
- **Project:** RuleIQ Refactoring 10092026
- **Snapshot state:** `PRE_FIX / REOPENED / CORRECTIONS_REQUIRED`
- **Current implementation baseline:** `RuleIQ_A2A_Memory_Refactor_FINAL_VERIFIED_LOCAL_v5.zip`
- **Authoritative latest audit:** `FULL_PROJECT_CROSS_REFERENCE_AUDIT_v1.*`
- **Authoritative latest simulation:** `FULL_PROJECT_SIMULATION_MATRIX_v1.json`
- **Authoritative continuity ledger:** `SIMULATION_REVIEW_LEDGER_v52.md`
- **GitHub source:** unchanged by the refactor session.
- **Critical handoff fact:** the user said **"fix all found issues right now"**, but then requested this snapshot before any FP-001…FP-029 source correction was applied.

## What the next chat must NOT assume

Do **not** treat the v5 label `FINAL_VERIFIED_LOCAL` as the current overall project verdict.
That label described the narrower verifier suites before the full-project cross-reference audit.

The full-project audit supersedes that claim:

- Overall verdict: **REOPENED_CORRECTIONS_REQUIRED**
- Were all planned corrections factually applied? **NO**
- Is the project free from ambiguity/conflict/drift? **NO**
- Existing verifier suite: **PASS_BUT_INCOMPLETE**
- Findings: **29 total — 2 critical, 21 high, 6 medium**
- Simulation cases: **28**

The old green verifier results remain useful regression gates, but they are not sufficient full-project certification.

## User decisions already made and still authoritative

1. One physical `pyGroup` = one UnitTestCandidate = exactly one `UnitTestRules` entry.
2. A2A messages transport addresses/control data only, not persisted payloads.
3. Memory identity is exact `pyGUID`; `pyGroup` is lineage/correlation only.
4. UpdateMemory never retries.
5. External Main result is `Failed` only when zero groups succeed; at least one valid group success means `Completed`.
6. Repair budget is per physical group: initial candidate + maximum two repairs / three Validator attempts.
7. `PartiallyTestable` remains executable.
8. **NotTestable has no RuleCode.** It is an informational candidate with zero ASSERT/SIM, explicit OMIT/gap evidence.
9. A valid informational NotTestable candidate may return Validator `OK` and lifecycle `Passed/OK`; this means the informational result is valid, not that a Pega unit test executed.
10. Rule-Obj-When grouping separates executable and NotTestable scenarios using execution class.
11. Missing simulation/crawl facts in reference examples may be explicitly synthetic only when clearly labelled as fixture facts, never reconstructed as historical runtime evidence.
12. C-027/C-028/C-029 Memory-runtime implementation review is **deliberately deferred for now**.
13. GitHub writes were not performed; earlier write attempts were blocked by integration permissions.

## Exact current step

The project was at:

`FULL PROJECT AUDIT COMPLETE -> USER REQUESTED APPLY ALL FINDINGS -> PRE-APPLY SNAPSHOT`

No source edit for findings FP-001 through FP-029 has been made after the audit.
Therefore, **start from the exact v5 baseline contained in `01_CURRENT_V5_BASELINE/`**, not from an imagined partially-fixed state.

## Exact next action

Apply the full set of audit corrections FP-001…FP-029 to a new local working copy, preserving the user decisions above and without silently reintroducing previously removed architecture.

Recommended execution order:

1. **Critical control-contract repairs:** FP-005 and FP-025.
2. **Complete RISK-001 cross-layer synchronization:** FP-003, FP-004, FP-006, FP-007, FP-008, FP-009, FP-010, FP-011.
3. **KnowledgeArea/runtime-export corrections:** FP-012 through FP-016 and FP-018.
4. **Coverage/execution/projection repairs:** FP-017 and FP-019 through FP-024.
5. **Canonicalization/DWL repairs:** FP-026 and FP-027.
6. **Resolve FP-028 conservatively** unless the user explicitly changes policy: never assert an unknown skipped-output initial state; preserve the scenario and downgrade/omit the unsupported output claim rather than inventing presence/absence.
7. **Project-state truthfulness:** FP-001 and FP-029 — restore `Rule_Crawler_tool.txt` to the complete package and regenerate the authoritative register/ledger/manifests so old “complete” wording cannot override the reopened audit.
8. Re-run **all old regression gates plus a fresh full-project cross-reference simulation**. Do not declare VERIFIED_LOCAL until both the narrow suites and the new full-project suite are green.

## Open/deferred boundary

- **C-027 / C-028 / C-029:** still `EXTERNAL_PENDING / DEFERRED`; do not falsely mark them verified.
- Actual Memory runtime behavior remains outside final certification until those implementations are supplied/reviewed.
- `Rule_Crawler_tool.txt` exists in GitHub at blob SHA `5bf29ef62534f74275c3d04ae03c9c9c3945e238` but is missing from v5; retrieval instructions are in `04_EXTERNAL_REFERENCES/`.

## All reopened findings

- **FP-001 [HIGH] — Canonical project package omits Rule_Crawler_tool.txt**  
  Status: `OPEN`.  
  Correction: Add the exact intended Rule_Crawler_tool.txt version to the audited package/manifest and rerun cross-reference checks.
- **FP-002 [HIGH] — Initial identity gate does not fail fast on pyID/TestedRuleKey/full RUT identity**  
  Status: `OPEN`.  
  Correction: Immediately after GetCaseData require nonempty pyID, parseable nonempty TestedRuleKey, nonempty pzInsKey/pxObjClass/pyClassName/pyRuleName, and early identity agreement.
- **FP-003 [MEDIUM] — Scenario Author ownership lock is contradicted by lower legacy RuleCode/pySimulation authoring language**  
  Status: `OPEN`.  
  Correction: Replace lower RuleCode/pySimulation references with frozen semantic SIM/ASSERT/SUMMARY source facts, and reserve physical RuleCode terminology for explicitly non-executable downstream reference sections.
- **FP-004 [HIGH] — Rule-Obj-When decision authoring remains unconditional despite NOT_TESTABLE zero-ASSERT rule**  
  Status: `OPEN`.  
  Correction: Scope §12.2 DecisionInput/DecisionResult construction to EXECUTABLE groups; define NOT_TESTABLE branch as OMIT/GAP-only.
- **FP-005 [CRITICAL] — Informational NotTestable path is not reconciled with Main storage/Data Page gates**  
  Status: `OPEN`.  
  Correction: Define an informational storage gate that does not require RuleCode. For terminal unresolved DP simulation, define a canonical NOT_TESTABLE grouping identity or isolate each informational Scenario without requiring a resolved simulation payload; allow terminal simulation gaps to pass informational storage without DPA.pass=true.
- **FP-006 [HIGH] — Rule-Obj-When KnowledgeArea deletes scenarios that new architecture must preserve as informational NotTestable**  
  Status: `OPEN`.  
  Correction: Clarify: exclude it from EXECUTABLE MultInpComb rows, but preserve it as a NOT_TESTABLE physical group/candidate with no RuleCode.
- **FP-007 [HIGH] — G5/G6 RuleCode projection is not explicitly gated to EXECUTABLE mode**  
  Status: `OPEN`.  
  Correction: At G5 entry state EXECUTABLE-only; informational mode skips G5/G6 and goes directly to G7 evidence projection/write.
- **FP-008 [MEDIUM] — Informational candidates remain coupled to full UTC Knowledge/example batch**  
  Status: `OPEN`.  
  Correction: Split structural acquisition by mode: informational candidates need only the schema/fields truly required for their informational projection; executable candidates require UTC docs/example target carriers.
- **FP-009 [HIGH] — INFORMATIONAL_NOT_TESTABLE uses batch-ambiguous “return immediately” wording**  
  Status: `OPEN`.  
  Correction: Say “finalize/store this UT result immediately, continue siblings, and emit all VR/VI records once at final return.”
- **FP-010 [HIGH] — Informational schema/Validator do not enforce Low confidence and Blocked closure**  
  Status: `OPEN`.  
  Correction: In both info schema branches require ReasoningConfidence=Low and DependencyClosureStatus=Blocked; Validator V4 must check both.
- **FP-011 [MEDIUM] — Both schemas retain RuleCode-era documentation after RuleCode became optional**  
  Status: `OPEN`.  
  Correction: Make descriptions conditional by candidate mode and update title/$comment to the one-candidate physical-group architecture.
- **FP-012 [HIGH] — Accepted Model WHEN export mapping was not applied**  
  Status: `OPEN`.  
  Correction: Update KT.3/KT.4/KT.25 and related examples to pyPropertiesName for Model WHEN in the confirmed environment.
- **FP-013 [HIGH] — Accepted Model formal-parameter export mapping/type was not fully applied**  
  Status: `OPEN`.  
  Correction: Use the confirmed export field pyParametersParamType and explicitly recognize raw STRING for String semantic compatibility while preserving raw spelling in evidence.
- **FP-014 [HIGH] — Accepted lowercase Data Page scope value is still rejected**  
  Status: `OPEN`.  
  Correction: Preserve raw value as evidence; normalize accepted environment value thread to Thread only for eligibility comparison.
- **FP-015 [MEDIUM] — Accepted RUF pyLabel fallback evidence is absent**  
  Status: `OPEN`.  
  Correction: Add pyLabel as last-resort fetched semantic evidence with the accepted strict fallback conditions.
- **FP-016 [HIGH] — Accepted simulated-Data-Page hard dependency boundary is absent**  
  Status: `OPEN`.  
  Correction: Add the hard boundary explicitly to Rule-Declare-Pages KnowledgeArea and cross-reference it from Main dependency scanning.
- **FP-017 [HIGH] — Model coverage adapter still loses terminal false edges that suppress observable producers**  
  Status: `OPEN`.  
  Correction: A reachable owner outcome is required whenever it executes OR suppresses an observable modifying producer, not only OTHERWISE/EXIT/later-owner differences.
- **FP-018 [HIGH] — APPEND_AND_MAP_TO source/target child-context semantics remain underspecified**  
  Status: `OPEN`.  
  Correction: Encode the resolved semantics: append new target item; child write targets resolve to it; relative child sources resolve from configured existing source page; materialize only mapped fields; source/target classes may differ.
- **FP-019 [HIGH] — Simulation seed-depth rule still blocks dependency-required item leaves**  
  Status: `OPEN`.  
  Correction: Lock the RUT-evidenced collection carrier/depth but permit leaf fields required by closed executable dependencies inside witness-locked items.
- **FP-020 [HIGH] — Omission reason-code authority still conflicts inside Main**  
  Status: `OPEN`.  
  Correction: Use one canonical reason-code set everywhere, including incorrect_candidate_assertion.
- **FP-021 [HIGH] — OWNER_COVERAGE_OUTPUTS still omits APPEND_AND_MAP_TO**  
  Status: `OPEN`.  
  Correction: Derive modifying operations from the active primary KnowledgeArea or at minimum include APPEND_AND_MAP_TO.
- **FP-022 [HIGH] — Producer catalog payload cannot represent direct SET producers**  
  Status: `OPEN`.  
  Correction: Direct producer payload comes from its own evidenced RHS/expression; composite producer may additionally include only descendant mappings inside its target structure.
- **FP-023 [HIGH] — LPE non-execution can only be proved by terminal guard, not prior EXIT/termination**  
  Status: `OPEN`.  
  Correction: Allow executes=false from any terminal control-flow exclusion proof: false guard, prior EXIT/termination, unreachable alternative, or KnowledgeArea-defined non-execution.
- **FP-024 [HIGH] — PROFILE binding provenance still requires PROPERTY_DEFINITION for every binding**  
  Status: `OPEN`.  
  Correction: Define evidence alternatives by binding kind: property definition for property leaves; formal parameter definition for Param; page creation/class context for named Page; owning property + execution context for list structure.
- **FP-025 [CRITICAL] — Accepted canonical DEP.kind solution D-003 was not applied**  
  Status: `OPEN`.  
  Correction: Use kind=<canonicalDWLKind>, require kind to equal the first component of identity, use DTable not DT, and remove HELPER alias unless it is itself a canonical DWL kind. Apply identically in Main and Generator ScenarioGroup grammar.
- **FP-026 [HIGH] — DWL physical request deduplication and examples remain ambiguous/stale**  
  Status: `OPEN`.  
  Correction: Define OUT as stable ordered unique canonical-KEY projection of READY occurrence rows, define SCAN mapping for duplicate occurrences, and rewrite every example in canonical key syntax.
- **FP-027 [HIGH] — SCENARIO_SNAPSHOT.given and DP_SIG still lack exact canonical serialization**  
  Status: `OPEN`.  
  Correction: Define exact canonical typed JSON shapes for given and DP_SIG (or exact textual grammar), including ordering, absence/null/empty handling, and escaping.
- **FP-028 [MEDIUM] — Skipped-output unknown-initial-presence policy remains an open design ambiguity**  
  Status: `OPEN_DECISION`.  
  Correction: Make a product decision: either require controlled initial absence for candidate outputs, or retain omission/gap semantics explicitly. Do not silently choose during implementation.
- **FP-029 [MEDIUM] — Change register/log overstate completion and contain stale semantics**  
  Status: `OPEN`.  
  Correction: Regenerate one current authoritative register after corrections; mark old logs historical/superseded and downgrade affected change IDs until reverified.

## Simulation status distribution

{
  "UNKNOWN": 28
}

## Verification discipline for the next chat

- Treat repository/source files as truth, not model memory.
- Keep live GitHub facts, user-supplied runtime evidence, synthetic fixtures, and inference explicitly separated.
- Never invent RuleCrawler/Memory GUIDs, RuleJSON, dependency results, or simulation payloads.
- Preserve source bytes/semantics unless the audited finding explicitly requires change.
- After applying corrections, perform an independent reread rather than validating only the strings just inserted.
- Verify standalone Generator/Validator prompts exactly equal the embedded runtime prompts.
- Parse both schemas as JSON and both runtime exports as XML.
- Validate both standard and MultInpComb executable examples.
- Validate informational NotTestable positive and negative fixtures.
- Simulate sibling success/failure, malformed Validator output, repair lifecycle, UpdateMemory failure, executable/NotTestable separation, unresolved Data Page NotTestable path, canonical dependency kinds, duplicate DWL occurrences, and skipped-output uncertainty.
- Final statuses must distinguish `VERIFIED_LOCAL`, `EXTERNAL_PENDING`, and `GitHub unchanged`.

## Artifact map

- `01_CURRENT_V5_BASELINE/RuleIQ_A2A_Memory_Refactor_FINAL_VERIFIED_LOCAL_v5.zip` — immutable exact prior baseline.
- `01_CURRENT_V5_BASELINE/EXTRACTED_V5/` — directly usable extracted baseline.
- `02_REOPENED_FULL_PROJECT_AUDIT/FULL_PROJECT_CROSS_REFERENCE_AUDIT_v1.md` — detailed human-readable audit.
- `02_REOPENED_FULL_PROJECT_AUDIT/FULL_PROJECT_CROSS_REFERENCE_AUDIT_v1.json` — machine-readable findings/evidence/corrections.
- `02_REOPENED_FULL_PROJECT_AUDIT/FULL_PROJECT_SIMULATION_MATRIX_v1.json` — 28-case cross-contract simulation.
- `03_CONTINUITY_AND_DECISIONS/SIMULATION_REVIEW_LEDGER_v52.md` — full durable continuity history.
- `03_CONTINUITY_AND_DECISIONS/REFACTOR_CHANGE_REGISTER_v5_LOCAL.json` — prior registered C-item state; note it predates the reopened audit.
- `03_CONTINUITY_AND_DECISIONS/FINAL_SOURCE_MANIFEST_v5.json` — v5 source hashes.
- `04_EXTERNAL_REFERENCES/RULE_CRAWLER_TOOL_FETCH_REFERENCE.json` — exact missing core-file GitHub location/blob SHA.
- `05_PRIOR_VERIFICATION_EVIDENCE/` — earlier narrow regression evidence. Keep it as regression baseline, not as final certification.

## New-chat instruction

After uploading this ZIP to a new chat, say:

> Read `START_HERE.md` first, then the full-project audit JSON/MD and ledger v52. Continue from the exact pre-fix boundary. Apply all FP-001…FP-029 corrections locally in one coherent batch, keep C-027…C-029 deferred, then run old regressions plus a fresh full-project simulation and provide a new complete ZIP. Do not trust the old v5 “final verified” wording as the current overall verdict.

