"""Build v8 Memory contracts, retained regressions and Pega handover documentation."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE/'RuleIQ_v8'
BASE = HERE.parent/'11_V7_WORK/RuleIQ_v7'
VER = ROOT/'verification'
MEM = ROOT/'memory_contracts'

for name in ['verify_risk001_v3.py','verify_multinpcomb_deep_v3.py','verify_example_alignment_v4.py',
             'SOURCE_rule-test-unit-case_multInpComb-JsonExample_PRE_CORRECTION.txt',
             'SOURCE_rule-test-unit-case_JsonExample_PRE_CORRECTION.txt',
             'FIXTURE_STANDARD_INFORMATIONAL_NOT_TESTABLE.json','FIXTURE_MULTINPCOMB_INFORMATIONAL_NOT_TESTABLE.json',
             'requirements.txt']:
    (VER/name).write_bytes((BASE/'verification'/name).read_bytes())

model = (BASE/'verification/contract_model_v6.py').read_text()
model = model.replace('verify_full_project_v6.py', 'verify_full_project_v8.py')
a, b = model.index('def validator_batch('), model.index('\ndef lifecycle(')
model = model[:a] + '''def validator_one(candidate, schema_valid, knowledge_available=True):
    """Synthetic single-candidate Validator phase model, never a deployed agent."""
    events = ['schema']
    if not schema_valid(candidate):
        return 'GENERATOR_REPAIR', events
    events.append('memory')
    unit = candidate['UnitTestRules'][0]
    if 'RuleCode' not in unit:
        valid = all(s['EvidenceSummary']['OmittedClaimCount'] ==
                    len(s['EvidenceSummary']['AssertionDecisionTrace'].splitlines())
                    for s in unit['Scenarios'])
        return ('OK' if valid else 'SEMANTIC_REJECT'), events
    events.append('knowledge-required')
    return ('OK' if knowledge_available else 'HUMAN'), events

''' + model[b:]
(VER/'semantic_model_v8.py').write_text(model)
full = (BASE/'verification/verify_full_project_v6.py').read_text().replace('import contract_model_v6 as model','import semantic_model_v8 as model')
full = full.replace("'fails only groups requiring that Area',", "'fails this invocation as KNOWLEDGE_FAILED',")
full = full.replace("['continue every sibling UT', 'single final batch return',\n        'Never return from the invocation inside this per-UT branch']", "['finishes this isolated invocation', 'do not include it in the KnowledgeTool phase',\n        'Never create RuleCode']")
full = full.replace("'Validator informational branch continues siblings'", "'Validator informational branch terminates only its isolated invocation'")
a, b = full.index("batch=[{'id':'I'"), full.index('# Previously accepted lifecycle', full.index("batch=[{'id':'I'"))
full = full[:a] + '''info_result, info_events = model.validator_one(fixtures['WHEN'], schemas['WHEN'].is_valid)
exec_result, exec_events = model.validator_one(exec_payload, schemas['WHEN'].is_valid)
check('Separate informational and executable invocations both validate',
      (info_result,exec_result)==('OK','OK'),'FP-009','MODEL')
failed_result, failed_events = model.validator_one(exec_payload, schemas['WHEN'].is_valid, False)
check('Information result retained when later isolated Knowledge fails',
      info_result=='OK' and failed_result=='HUMAN','FP-009','MODEL')
check('Informational makes no Knowledge request','knowledge-required' not in info_events,
      'FP-008,FP-009','MODEL')

''' + full[b:]
full = full.replace("check('Sibling success produces Completed',any(x['result']=='OK' for x in [failed,model.lifecycle(['OK'])]),'REGRESSION','MODEL')", "check('Earlier success cannot mask later group failure',not all(x['result']=='OK' for x in [model.lifecycle(['OK']),failed]),'REGRESSION_VARIANT_B','MODEL')")
(VER/'verify_full_project_v8.py').write_text(full)

code = (HERE.parent/'09_MEMORY_RUNTIME/memory_contract.py').read_text()
code = code.replace("require(response['pyGroup'] == expected_group, 'read group mismatch')", "string(response['pyGroup'], True)\n    if expected_group is not None:\n        require(response['pyGroup'] == expected_group, 'read group mismatch')")
code += '''

def lifecycle_request(args, current_guid, current_group, route):
    """The v8 Generator profile always sends both lifecycle fields for one version."""
    batch = request('UpdateMemory', args)
    require(len(batch) == 1, 'isolated Generator sends exactly one update row')
    row = batch[0]
    require(row['pyGUID']==current_guid and row['pyGroup']==current_group, 'not current version')
    require(row['pyUpdates']==lifecycle_updates(route), 'lifecycle pair differs from direct route')
    return row


def all_sources_confirmed(args, response):
    """Author source-set gate; successful siblings remain stored but cannot be handed off alone."""
    request('WriteMemory', args)
    require(args['Type']=='ScenarioGroup', 'expected source batch')
    result = batch_response('WriteMemory', args, response)
    require(result['trusted'] and all(row['Success'] for row in result['results'].values()),
            'incomplete source set; zero Generator invocations')
    return {key:row['pyGUID'] for key,row in result['results'].items()}
'''
code = code.replace('the v6 Memory boundary', 'the v3 immutable-version Memory boundary (RuleIQ v8)')
(MEM/'memory_contract.py').write_text(code)
test = (HERE.parent/'09_MEMORY_RUNTIME/test_memory_contract.py').read_text()
test = test.replace("HERE.parent/'07_V6_WORK/RuleIQ_v6/sources'", "HERE.parent/'sources'")
(MEM/'test_memory_contract.py').write_text(test)

MEMORY = '''# Memory v3 — immutable versions and metadata lifecycle

RuleIQ v8 / Variant B. This supersedes Memory v2 for the v8 chain. It does not change
the preserved v7 deployment or data. This package specifies and checks external behavior;
it contains no Pega persistence implementation.

## Identity and ownership

Types are exactly ScenarioGroup and UnitTestCandidate. pyGUID is globally unique and
identifies one immutable payload version. (pxCaseID,Type,pyGroup) is lineage; several
versions/runs may share it. Never update/resolve a record by that tuple or select latest.
Treat all addresses and payload text as exact opaque strings, preserving whitespace,
case, Unicode and escapes after one JSON decode. No payload parse/reserialize/trim/merge.

Author writes all complete ScenarioGroups in one batch. Each isolated Generator reads
one supplied ScenarioGroup, writes one initial candidate and at most two repair versions,
and updates lifecycle on the exact current candidate. Validator reads only its exact
candidate after schema success. Author and Validator never call UpdateMemory.

## WriteMemory

WriteMemory(pxCaseID, Type, RequestsJSON): exactly three string arguments.
RequestsJSON decodes once to exactly {"pxResults":[...]} with a nonempty array.
Each row is exactly {"pyGroup":"G001","pyPayload":"<complete opaque content>"}.
Require nonempty strings and unique groups within a batch. Author sends all source rows;
an isolated Generator always sends one candidate row. No GUID, operation or lifecycle input.

Every successful row creates a new GUID, including repeated writes of identical content.
Candidate canonical records contain pyGUID,pxCaseID,Type,pyGroup,pyPayload,pyStatusValue,
pyRouterKey; initialize the last two to Pending and empty string. ScenarioGroup canonical
records have the first five fields. Private storage fields may coexist.
Never overwrite an earlier payload. A successful response must describe committed state
visible to another requestor; no success before durable completion. Enforce GUID uniqueness
atomically under contention. Validate framing and duplicate-key ambiguity before mutation;
then validate/commit rows independently. A rejected row cannot partly write or roll back siblings.

Exact outer response: Success (boolean), ResultsJSON/ErrorCode/ErrorMessage (strings).
Success=true requires empty errors and ResultsJSON decoding to exactly pxResults with one
row per request. Every row has exactly pyGroup,Success,pyGUID,ErrorCode,ErrorMessage.
Success rows have nonempty distinct newly assigned GUIDs and empty errors. Failure rows have
empty GUID, nonempty diagnostic and code INVALID_INPUT, UNSUPPORTED_TYPE or WRITE_FAILED.
Correlate by group, never position. Outer failure requires nonempty code/message and makes
the entire result unconfirmed, regardless of embedded rows. Missing/unknown/duplicate or
malformed response identities cannot establish success. Response loss never implies rollback.

Author requires EVERY source row confirmed before any Generator invocation. This does not
make storage batch-transactional: successfully committed source rows remain after failure.
All callers make one attempt per operation and never automatically retry uncertain failures.

## GetMemory

GetMemory(pxCaseID, Type, pyGUID): exactly three nonempty strings. Enforce exact case/type/GUID
ownership. No group/latest lookup, retry or fallback. Return exactly these eight fields:

```json
{"Success":true,"pxCaseID":"CASE-1","Type":"UnitTestCandidate","pyGroup":"G001","pyGUID":"candidate-demo-1","pyPayload":"<complete candidate JSON>","ErrorCode":"","ErrorMessage":""}
```

All fields except Success are strings. A success requires nonempty group/payload and empty
errors. Failed/malformed reads do not release partial payloads. Generator compares returned
pyGroup with the parsed ScenarioGroup groupId. Validator reports the returned groupId and
Generator compares it with its source group. Do not add lifecycle fields to this response;
acceptance/consumer code uses a separate read-only canonical storage projection.

## UpdateMemory

UpdateMemory(pxCaseID, Type, RequestsJSON): exactly three string arguments. Current Generator
uses Type=UnitTestCandidate and exactly one row:

```json
{"pxResults":[{"pyGroup":"G001","pyGUID":"candidate-demo-1","pyUpdates":{"pyStatusValue":"Passed","pyRouterKey":"OK"}}]}
```

Address the existing exact GUID and verify case/type/group. Never insert on missing GUID.
Protect all identity fields and pyPayload. Only string pyStatusValue/pyRouterKey may be
shallow-patched; no nested/path/unknown fields or deletion. The generic service preserves
omitted metadata fields, but the v8 Generator ALWAYS supplies both fields matching one
direct validated ValidatorReport. Allowed current pairs are Passed/OK,
Failed/GENERATOR_REPAIR, Failed/SEMANTIC_REJECT, Failed/HUMAN. Pending/empty is creation only.

Use the WriteMemory outer envelope. Decoded row fields are exactly
pyGroup,pyGUID,Success,ErrorCode,ErrorMessage. Both success and failure echo requested group
and GUID. Success has empty errors; failure has nonempty code/diagnostic. Never substitute
an empty GUID on failed update or return a newly created GUID. Row updates are atomic;
failure cannot alter protected/omitted fields or undo another committed record.

## Lifecycle and selection

Persist candidate Pending -> fresh Validator -> validate direct JSON report -> exactly one
UpdateMemory. Confirm Passed/OK before reporting success. Confirm Failed/GENERATOR_REPAIR
before writing a new complete repair version with a new GUID. HUMAN/SEMANTIC_REJECT stop.
At most two repaired writes and three Validator attempts per isolated Generator. Prior
payloads and their confirmed statuses remain intact; never revalidate an older version as fallback.
Malformed Validator output leaves Pending and yields VALIDATOR_RESPONSE_INVALID with zero
updates. Failed/unconfirmed UpdateMemory yields LIFECYCLE_UPDATE_FAILED and no further repair.

Pega serializes the entire Author run per case through selection; other cases are independent.
Fresh Generator invocations never inherit transcripts/Knowledge from Author or earlier groups.
Only after all groups succeed may the consumer select final UUIDs from this run's verified
GeneratorRunReports, independently confirm Passed/OK, and read/materialize under the case guard.
Old Passed records and partially failed runs are not an automatic fallback. Informational
NotTestable without RuleCode is visible information, never a runnable unit test.

## Rollout and evidence

Bind all v8 prompts, schemas and Memory v3 together. Use an isolated v3 test scope by default.
Production migration requires a Pega-owned mapping/storage decision before removing v2 tuple
uniqueness or activating append-only writes; preserve all existing v7 records. Never silently
delete, overwrite or reinterpret a v7 candidate as a confirmed current v8 result.
Local assertions validate supplied requests/responses/snapshots only. Runtime acceptance
requires actual calls, failure injection, before/after projections, new-requestor durability
and context-isolation evidence. These external checks are not executed by this package.
'''
(MEM/'MEMORY_TOOL_CONTRACT_v3.md').write_text(MEMORY)
(MEM/'README.md').write_text('''# Memory v3

- [Contract](MEMORY_TOOL_CONTRACT_v3.md)
- [External acceptance requirements](ACCEPTANCE_CASES.json)

memory_contract.py validates supplied evidence and does not implement storage.
test_memory_contract.py exercises synthetic evidence and active source pins.
''')

SPEC = '''# Pega implementation specification v3 — RuleIQ v8 Variant B

## Outcome and deployment boundary

Deploy a consistent v8 prompt/contract set. One physical ScenarioGroup has one fresh Generator
invocation and one final candidate reference. When groups may contain multiple combination
rows. All groups are successfully persisted first; invocation and report checking then proceed
strictly by original groupOrder. First failure stops remaining groups and automatic selection.

This workspace delivers prompts, readable configuration references, four interface JSON Schemas,
Memory v3 and local verification. It does not modify Pega, configure actual agent cards, migrate
data, or establish deployed LLM behavior. No updated Main export or actual parameter-binding
rule exports exist in the supplied baseline. Apply Main to the existing rule and configure
the following exact interfaces through the application's existing mechanisms; do not invent
Pega XML fields or treat the readable exports as a target-ready RAP.

## Required Pega work

| ID | Component | Required behavior |
|---|---|---|
| PI-01 | Author | Apply Main prompt. Audit complete groups, batch-write once, demand all rows confirmed; then call Generator sequentially and validate each JSON report. |
| PI-02 | Fresh invocation boundary | Each Generator context contains only its static prompt, three current inputs and its own tool responses. Do not pass Author history, prior Generator output, shared chat/session history or cached Knowledge. |
| PI-03 | Generator binding | Exactly CaseID,RUTType,ScenarioGroupUUID, all strings; return GeneratorRunReport JSON. No question, array, previous artifacts or payload parameters. |
| PI-04 | Validator binding | Exactly CaseID,RUTType,UnitTestCandidateUUID, all strings; return ValidatorReport JSON. One current candidate. |
| PI-05 | WriteMemory | Implement immutable insert-per-success, new globally unique GUID, complete payload; candidate initialization Pending/empty. No tuple upsert. |
| PI-06 | GetMemory | Exact case/type/GUID ownership and unchanged eight-field response. |
| PI-07 | UpdateMemory | Existing exact candidate GUID only, metadata-only atomic patch, no payload/identity modification or insert fallback. |
| PI-08 | JsonValidationTool | Preserve CaseID,UUID,JsonSchema arguments; validate the stored exact candidate GUID; then Validator may read it. |
| PI-09 | KnowledgeTool | Publish current semantic content and both structural families. Each Generator obtains its own required keys; information needs only schema. |
| PI-10 | GetCaseData/RuleCrawler | Preserve complete RUT identity and existing semantic/crawler behavior; do not redesign crawler as part of isolation. |
| PI-11 | Case orchestration/consumer | Hold one pipeline per case; select only this complete run's final confirmed Passed/OK UUIDs. No old-version/partial-run fallback or runnable NotTestable. |
| PI-12 | Deployment/acceptance | Bind matching v8 artifacts, use isolated v3 scope or approved migration mapping, and capture actual external evidence. |

## Agent and tool inventory

- Author: GetCaseData, semantic KnowledgeTool, RuleCrawler, WriteMemory(ScenarioGroup), UnitTestGenerator.
- Generator: GetMemory(ScenarioGroup), structural KnowledgeTool, WriteMemory(UnitTestCandidate), UpdateMemory(UnitTestCandidate), UnitTestValidator.
- Validator: JsonValidationTool, GetMemory(UnitTestCandidate), structural KnowledgeTool. No writes or repairs.

Use [agent contracts](../agent_contracts/README.md) and [Memory v3](../memory_contracts/MEMORY_TOOL_CONTRACT_v3.md)
as the exact interface authority. Prompt source and embedded system/response-style prompts
must match. Existing environment ownership, model settings and target ruleset selection are
not changed by this package. Configure the three scalar parameters in the actual callable
agent tools and ensure invocation inputs are mapped by name; never rely on prompt text to
change a tool signature or guarantee a fresh context.

## Fresh context and failure ordering

Use the application's existing invocation/session mechanism to create a new Generator
context per group. A fresh call identifier alone is insufficient evidence: capture the
actual model input message inventory and demonstrate no previous group's source, candidate,
report, hidden history or cache content. The parent Author may retain its own map and reports
but must forward only the current three scalar inputs. Do not introduce a separate orchestrator.

Queue/reject overlapping runs of the same case before any source writes, using the existing
case mechanism. Different cases can proceed independently. Preserve the guard through all
Generator invocations and complete result materialization. A failed source row stops before
Generator #1; a failed/malformed Generator #N stops before #N+1. No automatic tool/agent retries
or rollback of committed sources/candidates. Network loss after commit remains unconfirmed.

## Knowledge, schemas and metadata

KnowledgeTool(KnowledgeAreas) keeps its comma-separated string and pxResults with exact
Area/Description strings. Publish the six v7 semantic KnowledgeAreas unchanged. Executable
Generator and Validator use the appropriate three structural keys:

| RUTType | Keys |
|---|---|
| Rule-Obj-When | Rule-Test-Unit-Case_MultInpComb-KnowledgeArea, Rule-Test-Unit-Case_MultInpComb-JsonSchema, Rule-Test-Unit-Case_MultInpComb-JsonExample |
| Other supported types | Rule-Test-Unit-Case_KnowledgeArea, Rule-Test-Unit-Case_JsonSchema, Rule-Test-Unit-Case_JsonExample |

The two structural UTC KnowledgeArea texts remain existing external prerequisites, not newly
invented files. Templates must carry the application's already-selected pyRuleSet and
pyRuleSetVersion; illustrative source example values are not deployment targets. Informational
Generator groups acquire only the matching schema and require no target metadata; Validator
does not request UTC Knowledge for a valid informational candidate. Each new Generator repeats
its own required lookup; no cross-invocation reuse and no reacquisition during repairs.

JsonValidationTool(CaseID,UUID,JsonSchema) retains its exact arguments and required response
Success,IsValid,ValidationMessage,ErrorCode,ErrorMessage. For When use the MultInpComb schema
key; otherwise Standard. Schema invalid and tool failure are distinct; both prevent that
Validator's GetMemory. Tool validation is read-only and never rewrites JSON or status.

GetCaseData retains its invocation and must provide pyID,TestedRuleKey plus RUT
pzInsKey/pxObjClass/pyClassName/pyRuleName with consistent first-three-component identity.
RuleCrawler export remains unchanged. Its low-level ResolveCrawlerBatch export resolves keys,
not complete LLM-visible RuleJSON; preserve the existing wrapper mapping and do not invent
its scalar parameter names. A resolved key alone cannot establish a fetched dependency.

## Results, versions and migration

Every candidate version has immutable payload and a new GUID. Confirm the exact direct
Validator route using UpdateMemory before returning or repairing. Report success only after
Passed/OK is confirmed. No more than two repaired writes/three Validator attempts per group.
The schemas and contextual contracts define report fields, census/counters, source matching
and local unit=0 coordinates. JSON report schemas do not themselves prove provenance or storage.

Author external response remains exactly AIAgentResponseStatus/AIAgentErrorResponseMessage:
Completed with empty error only when all groups processed. Failed with "Scenario group storage
failed." for source persistence; "Unit test generation failed." for Generator failure/exception;
"Unit test generator returned an invalid response." for malformed/mismatched reports.
Keep errors one sentence, at most 20 words/180 characters. Do not expose internal reports/GUIDs.

The consumer must first validate all current report correlations and successful statuses,
then confirm each final record's exact identity and Passed/OK through a canonical projection.
Only candidates with executable Scenarios and RuleCode become runnable tests. Keep NotTestable
with its BlockingGaps as information. Earlier successful groups in an overall failed run
remain stored for investigation, but automatic test creation does not start from that partial set.

Default rollout uses a clean v3 test scope. Production activation requires a Pega-owned
storage/migration mapping that supports multiple versions per case/type/group and preserves
all v7 data. Never run v7 upsert writers against the same active records as v8 version writers.
Switch all bindings/prompts/metadata handling together. The package performs no migration.

## Verification and handover

Run the packaged local suite and inspect exact source/package hashes. External acceptance
requires actual request/response traces, chronological calls, context input inventories,
failure-injection steps and independent before/after record snapshots from a fresh requestor.
See [acceptance cases](ACCEPTANCE_CASES.json) and [walkthroughs](../examples/TOOL_CALL_WALKTHROUGHS.md).
All external cases are initially NOT_RUN_EXTERNAL. Passing local models cannot certify Pega,
LLM context isolation, durability, tool bindings or production readiness.
'''
(ROOT/'specification/PEGA_IMPLEMENTATION_SPEC_v3.md').write_text(SPEC)
(ROOT/'specification/README.md').write_text('# Pega handover v3\n\n[Implementation specification](PEGA_IMPLEMENTATION_SPEC_v3.md) defines the external work.\n[Acceptance cases](ACCEPTANCE_CASES.json) require real runtime evidence.\n')

pins = {
 'Main_Agent_Prompt.txt': ['ANY unsuccessful/unconfirmed source row prevents ALL Generator invocations', 'strictly in original groupOrder', 'an earlier success cannot'],
 'UnitTestGenerator_Prompt.txt': ['one fresh invocation owns exactly one physical ScenarioGroup', 'NEW version GUID', '### G8.3 Confirm lifecycle'],
 'Validator_Prompt.txt': ['Receive exactly CaseID, RUTType, UnitTestCandidateUUID', 'Validator never repairs or writes/updates Memory', 'Return exactly one raw JSON ValidatorReport'],
}
pins['Main_Agent_Prompt.txt'][-1] = 'An earlier success cannot'
sources=[]
for file, anchors in pins.items():
    content=(ROOT/'sources'/file).read_text()
    rows=[]
    for anchor in anchors:
        assert anchor in content, (file,anchor)
        line=next(i for i,l in enumerate(content.splitlines(),1) if anchor in l)
        rows.append({'requirement':anchor,'text':anchor,'line':line})
    sources.append({'file':file,'sha256':hashlib.sha256((ROOT/'sources'/file).read_bytes()).hexdigest(),'anchors':rows})
(MEM/'SOURCE_AUTHORITY.json').write_text(json.dumps({'contract':'Memory v3 / Variant B','sources':sources},indent=2)+'\n')
print(json.dumps({'copied_semantic_assets':9,'adapted_full_project_suite':True,'memory_contract':'v3','specification':'v3'}))
