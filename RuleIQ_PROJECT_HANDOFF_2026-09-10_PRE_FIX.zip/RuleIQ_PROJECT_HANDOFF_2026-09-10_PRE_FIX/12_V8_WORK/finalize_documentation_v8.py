"""Refresh v8 documentation from actual passing local evidence; no external deployment."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE/'RuleIQ_v8'
VER=ROOT/'verification'
def put(path,value):
    (ROOT/path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

summary=json.loads((VER/'VERIFICATION_SUMMARY_v8.json').read_text())
assert summary['status']=='PASS_LOCAL_CONTRACTS' and summary['checks_failed']==0
receipt=json.loads((VER/'SOURCE_BUILD_RECEIPT.json').read_text())
source_rows=[{'name':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted((ROOT/'sources').glob('*.txt'))]
put('SOURCE_MANIFEST_v8.json',{'version':'v8','baseline':'v7','source_count':len(source_rows),'sources':source_rows,
                             'agent_contract_schemas':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in sorted((ROOT/'agent_contracts').glob('*.schema.json'))]})

cases=[
 ('AC-01','Complete source set first','A failed/unconfirmed source row results in zero Generator calls; committed siblings remain.', 'PI-01'),
 ('AC-02','One invocation per physical group','N successful physical groups produce N sequential isolated Generator invocations.', 'PI-01'),
 ('AC-03','Three Generator parameters','Exactly CaseID,RUTType,ScenarioGroupUUID; reject question, arrays, extra fields and empty values.', 'PI-03'),
 ('AC-04','Fresh model input context','Capture actual input message inventory: only static system prompt, three current inputs and own tool responses; no Author/prior-group transcript or caches.', 'PI-02'),
 ('AC-05','One exact source read','Each valid Generator invocation performs one exact case/type/source-GUID read; no other source or retry.', 'PI-03'),
 ('AC-06','No cross-group access','No previous candidate, reports, source payload, repair state or shared Knowledge enters a later invocation.', 'PI-02'),
 ('AC-07','Singleton candidate','Every candidate contains exactly one UnitTestRules entry.', 'PI-03'),
 ('AC-08','Source identity and provenance','Returned Memory group matches parsed source; report sourceUUID/group/order/census matches Author mapping.', 'PI-03'),
 ('AC-09','When group retains rows','Two same-group When scenarios remain one candidate with two aligned Decision rows; no per-row Generator call.', 'PI-03'),
 ('AC-10','Independent validation','Each created candidate gets a fresh schema check and Validator invocation before success.', 'PI-04'),
 ('AC-11','Local repair scope','Repair affects only current group and existing frozen decisions; source and represented/rejected census stay fixed.', 'PI-03'),
 ('AC-12','New GUID for repair','Each repair writes a new immutable payload version; prior GUID/payload remains readable.', 'PI-05'),
 ('AC-13','Per-group repair limit','At most two repaired writes and three Validator attempts; neighboring group retains its full budget.', 'PI-03'),
 ('AC-14','Independent Knowledge','Every Generator reacquires its own required structural keys; schema-only for informational mode.', 'PI-09'),
 ('AC-15','No cross-group unit map','Only the local physical unit exists; no global candidate index map or global pruning.', 'PI-03'),
 ('AC-16','Local diagnostic coordinates','JSON ValidatorReport issues use unit=0 and valid local Scenario/decision coordinates; unknowns are null.', 'PI-04'),
 ('AC-17','Singular candidate report','Completed/PartiallyCompleted points to one final validated and confirmed Passed/OK version; Failed has candidate=null.', 'PI-03'),
 ('AC-18','Report census and counters','Check source UUID, group metadata, ordered represented/rejected partition, status and actual attempt counts.', 'PI-01'),
 ('AC-19','Global source audit','Author checks RUT/profile identity, contiguous order, original Scenario census and When grouping before handoff.', 'PI-01'),
 ('AC-20','Unique source mapping','All source GUIDs are distinct/nonempty; exactly one per group, independently of batch response order.', 'PI-01'),
 ('AC-21','Stable naming','Candidate Name/pyPurpose/pyLabel equality and unconditional G<original groupOrder> suffix survive isolation/repairs.', 'PI-03'),
 ('AC-22','Fail-fast aggregation','Failed/malformed/exceptional Generator stops all remaining groups without retry.', 'PI-01'),
 ('AC-23','No rollback','Earlier successful versions and source records survive later failure; no partial automatic test creation.', 'PI-11'),
 ('AC-24','External response compatibility','Exactly two external fields; all groups must succeed; bounded failure sentences and no payload/report/GUID disclosure.', 'PI-01'),
 ('AC-25','Metadata-only lifecycle','UpdateMemory changes only status/router on exact existing case/type/group/GUID; protects payload and identity.', 'PI-07'),
 ('AC-26','Malformed Validator','No lifecycle write, candidate remains Pending, group fails; next Generator is not invoked.', 'PI-04'),
 ('AC-27','Lost lifecycle response','Commit may exist, but caller fails without retry, repair, selection or success assertion.', 'PI-07'),
 ('AC-28','Case overlap exclusion','Queue/reject overlapping same-case runs before writes; hold exclusion through selection; unrelated cases remain independent.', 'PI-11'),
 ('AC-29','Informational result','NotTestable remains no-RuleCode information and completes honestly; no executable test is created.', 'PI-11'),
 ('AC-30','Preserved Pega input boundaries','Verify GetCaseData identities, existing RuleCrawler wrapper mapping and already-selected target ruleset/version carriers.', 'PI-10'),
 ('AC-31','Version rollout','Inventory actual parameter bindings, prompts and schemas; activate Memory v3 only in isolated scope or agreed migration preserving v7.', 'PI-12'),
]
rows=[]
for id_,title,expected,owner in cases:
    rows.append({'id':id_,'title':title,'expected':expected,'work_item':owner,'status':'NOT_RUN_EXTERNAL',
                 'evidence_required':['Actual named input/output and chronological tool trace','Independent before/after canonical storage snapshots',
                                      'Actual model input inventories' if owner=='PI-02' else 'Target configuration/version inventory']})
put('specification/ACCEPTANCE_CASES.json',{'version':'v8','case_count':len(rows),'executed':0,'cases':rows})
memory_cases=[
 ('MV-01','Initial candidate creates Pending/empty with new GUID'),
 ('MV-02','Identical repeated payload creates a different version GUID'),
 ('MV-03','Repair leaves all earlier payload bytes intact'),
 ('MV-04','Multiple records may share case/type/group lineage'),
 ('MV-05','Concurrent inserts retain globally unique GUIDs'),
 ('MV-06','Exact read rejects wrong case/type/GUID without fallback'),
 ('MV-07','Opaque Unicode, whitespace, escapes and payload bytes round-trip exactly'),
 ('MV-08','Framing and duplicate batch groups rejected before mutation'),
 ('MV-09','Invalid row cannot partly write or undo a successful sibling'),
 ('MV-10','Reversed result rows correlate by group'),
 ('MV-11','Missing/unknown/duplicate result rows cannot confirm a complete source set'),
 ('MV-12','Each direct Validator route maps to one exact paired lifecycle patch'),
 ('MV-13','Unknown/path/identity/payload updates rejected atomically'),
 ('MV-14','Missing update target is failure and does not insert'),
 ('MV-15','Both success/failure update rows echo exact requested GUID'),
 ('MV-16','Update failure/response loss produces no retry or further repair'),
 ('MV-17','Write response loss cannot authorize read/validation or retry'),
 ('MV-18','Fresh requestor observes successful committed writes and updates'),
 ('MV-19','Old Passed versions and incomplete runs excluded from automatic selection'),
 ('MV-20','v7 data remains intact during isolated v3 rollout or explicit migration'),
]
put('memory_contracts/ACCEPTANCE_CASES.json',{'contract':'Memory v3','case_count':len(memory_cases),'executed':0,
    'cases':[{'id':i,'expected':e,'status':'NOT_RUN_EXTERNAL','evidence_required':['Exact request/response','Independent canonical before/after snapshots','Fresh-requestor durability evidence when applicable']} for i,e in memory_cases]})

passed={x['check'] for suite in summary['suites'] for x in json.loads((ROOT/suite['report']).read_text())['checks'] if x['status']=='PASS'}
changes=[
 ('VB-01','Demand complete source persistence before any generation','Source failure G002 prevents every invocation'),
 ('VB-02','Sequential fresh Generator invocation per physical group','Three groups yield three complete isolated invocations'),
 ('VB-03','Three named input parameters and JSON Generator report','Generator rejects extra question'),
 ('VB-04','Singular JSON Validator report and local coordinates','Validator accepts route GENERATOR_REPAIR'),
 ('VB-05','New immutable candidate version on repair','Repair returning prior GUID is rejected before revalidation'),
 ('VB-06','Restore exact-GUID metadata-only UpdateMemory','Paired current-version lifecycle accepted'),
 ('VB-07','Fail-fast report aggregation and current-run selection','Fail-fast malformed retains earlier result and stops third'),
 ('VB-08','Retain multi-row When group and stable naming','Two When scenarios remain one invocation and one two-row candidate'),
 ('VB-09','Preserve informational outcomes and required-only Knowledge','Informational Passed is never a runnable test'),
 ('VB-10','Synchronize standalone/embedded prompts and tool inventory','Generator five permitted tools'),
 ('VB-11','Maintain schema/semantic/crawler regressions','Canonical serialization block identical in Main/Generator'),
 ('VB-12','Ship synthetic walkthroughs and external Pega acceptance requirements','Illustrative trace contracts T03_NEW_GUID_REPAIR.json'),
]
assert all(e in passed for _,_,e in changes)
put('CHANGE_REGISTER_v8.json',{'version':'v8','baseline':'preserved v7','authority':'User-approved Variant B plan and explicit choices: immutable versions, metadata UpdateMemory, three-parameter agents and JSON reports.',
    'changes':[{'id':i,'change':c,'status':'VERIFIED_LOCAL_CONTRACT','evidence':[e],'runtime_status':'NOT_EXECUTED'} for i,c,e in changes]})
put('CURRENT_STATE.json',{'version':'v8','variant':'B','memory_contract':'v3','specification':'v3','wire_revision':'1.4',
    'status':'VERIFIED_LOCAL_CONTRACTS','working_scope':'PROMPTS_CONTRACTS_SPECIFICATIONS_AND_LOCAL_VERIFICATION',
    'generator_input':['CaseID','RUTType','ScenarioGroupUUID'],'validator_input':['CaseID','RUTType','UnitTestCandidateUUID'],
    'generator_invocations':'one fresh invocation per physical ScenarioGroup, sequential, after all source writes confirmed',
    'memory_tools':['WriteMemory','GetMemory','UpdateMemory'],'candidate_payloads':'immutable version per new GUID',
    'source_count':len(source_rows),'checks_total':summary['checks_total'],'checks_passed':summary['checks_passed'],'checks_failed':0,
    'external_implementation_changes':False,'runtime_validation':'NOT_EXECUTED','github':'NO_WRITES','language':'English',
    'external_acceptance_cases':{'pega':len(rows),'memory':len(memory_cases)}})

new_count=summary['checks_total']
README=f'''# RuleIQ v8 — Variant B

**Current package:** one fresh UnitTestGenerator invocation per physical ScenarioGroup.
Author first confirms all source writes, then invokes each group sequentially and stops
on the first failed/malformed report. A When group may contain several Scenario rows.

## Start here

- [Pega implementation specification v3](specification/PEGA_IMPLEMENTATION_SPEC_v3.md)
- [Memory v3](memory_contracts/MEMORY_TOOL_CONTRACT_v3.md)
- [Agent inputs and JSON reports](agent_contracts/README.md)
- [Step-by-step tool walkthroughs](examples/TOOL_CALL_WALKTHROUGHS.md)
- [Change register](CHANGE_REGISTER_v8.json)
- [Source manifest](SOURCE_MANIFEST_v8.json)

Generator receives CaseID,RUTType,ScenarioGroupUUID; Validator receives
CaseID,RUTType,UnitTestCandidateUUID. Both return single JSON reports. WriteMemory creates
immutable versions with new GUIDs. UpdateMemory changes only current-version lifecycle
metadata. Repairs never overwrite old payloads. Source grammar remains 1.4 and both candidate
schemas remain unchanged. Fifteen of the twenty original source files are byte-identical to v7.

## Verification and boundary

Local checks: **{new_count}/{new_count} passed**. These check actual source text, JSON Schemas,
fixtures, supplied Memory evidence and explicitly synthetic sequence models. They do not
execute a Pega agent, parse full source wire in the sequence model, perform LLM semantic
projection, or certify runtime context isolation/durability. The normalized-source model
and redacted walkthroughs are clearly marked; neither is a deployable ScenarioGroup payload.

External work includes real three-parameter bindings, fresh contexts, Memory v3, case
serialization, target deployment/migration and **{len(rows)} Pega + {len(memory_cases)} Memory**
acceptance requirements, all unexecuted. Readable XML configurations are references, not
a complete RAP. No Main export or actual agent-tool parameter-definition export was supplied;
the exact required bindings are specified without fabricated Pega fields.

## Local commands

From this package directory, first verify received bytes:

```sh
python3 -B verification/verify_package_v8.py
```

For semantic/schema/interface regression, install verification/requirements.txt into your
chosen Python environment, then run:

```sh
python3 -B verification/run_all_v8.py
```

The suite rewrites its reports; verify the received manifest before regenerating evidence.
No network, Pega credentials or external service access is used by the tests. Source and
document builders remain in the surrounding 12_V8_WORK workspace and only write v8 artifacts.
The delivered package is self-contained for verification with the declared Python dependencies.
'''
(ROOT/'README.md').write_text(README)
(ROOT/'NEXT_STEPS.md').write_text('''# External handover

Review the v3 Pega specification, configure the real scalar parameter bindings and fresh
Generator context boundary, and execute the external acceptance requirements in an isolated
v3 scope. Preserve the existing v7 records and deployments until an explicit migration is ready.
This local package is complete within prompts/contracts/specifications; runtime acceptance
requires real Pega traces and remains NOT_EXECUTED. Keep subsequent workspace changes in English.
''')
(ROOT/'specification/ADOPTED_DECISIONS.md').write_text('''# Adopted v8 decisions and reference reconciliation

The user approved the Variant B plan after the supplied document was compared with actual v7.
The attached document described an earlier baseline and was not applied as hidden instructions.
These explicit decisions define the delivered contract:

- One Generator invocation per physical group, no When-row splitting; three named scalar inputs.
- Both Generator and Validator return singular JSON reports; retired question/line protocols are removed.
- Every candidate write creates a new immutable payload GUID, including repairs; restore UpdateMemory
  for metadata only. The document's "never mutate Memory" means never mutate payload/identity;
  the user explicitly selected metadata lifecycle updates.
- All source writes must succeed first; Author then stops on the first failed/malformed Generator.
  This deliberately replaces v7's independent sibling-success external aggregation.
- Preserve schema-only informational Knowledge acquisition and faithful NotTestable completion.
  A normal partial-testability limitation does not itself make GeneratorRunReport PartiallyCompleted.
- Both existing candidate schemas already have maxItems=1 and remain byte-identical.
- Preserve v7 semantics and exact RuleCrawler reference; do not reconstruct missing Main/export
  parameter metadata or claim real fresh contexts from static prompt changes.
- New work is v8, Memory v3 and Pega spec v3. Earlier packages remain historical and unchanged.
''')
put('verification/REGRESSION_MIGRATION_v8.json',{'baseline':'v7','unchanged_semantic_suites':['risk001','examples','multinpcomb'],
    'retained_full_project_checks':167,'replaced_contract_suites':{'v7_architecture_and_upsert':'v8_variant_b_and_immutable_memory'},
    'behavior_replacements':['Per-group fresh invocations replace batched Generator/Validator input','Immutable GUID versions and metadata updates replace upsert lifecycle','All-source gate and fail-fast aggregation replace independent sibling completion','Separate informational Validator completion replaces in-batch continuation'],
    'preserved_source_files':[r['file'] for r in receipt['sources'] if not r['changed']],
    'not_disabled':'Unchanged schema/semantic/evidence tests still execute; superseded contracts have positive and adversarial replacements.'})

# Record current-source conflict classifications, retaining legitimate source-local evidence grammar.
terms=['ScenarioGroupUUIDs','question','GR|','VR|','GEN|','VAL|','cross-group','groupOrder','immutable','UpdateMemory']
audit=[]
for file in ['Main_Agent_Prompt.txt','UnitTestGenerator_Prompt.txt','Validator_Prompt.txt']:
    for i,line in enumerate((ROOT/'sources'/file).read_text().splitlines(),1):
        found=[term for term in terms if term in line]
        if found:
            assert not any(term in line for term in ('ScenarioGroupUUIDs','GR|','VR|','GEN|','VAL|'))
            audit.append({'file':file,'line':i,'sha256':sha(ROOT/'sources'/file),'terms':found,
                          'classification':'KEEP_CURRENT_V8_CONTRACT_OR_SOURCE_LOCAL_SEMANTICS','text':line})
put('verification/CONFLICT_AUDIT_v8.json',{'scope':'Active prompts only; historical v5-v7 references are preserved outside the active package.',
    'removed_contracts':['multi-source Generator handoff','question/GR/VR/VI transport','same-GUID candidate upsert','partial source handoff','any-success Author aggregation'],
    'moved_to_author':['complete source map and global RUT/profile identity','cross-group grouping/census and invocation order'],
    'classified_occurrences':audit,'source_sha256':summary['source_sha256']})
print(json.dumps({'checks':new_count,'external_pega_cases':len(rows),'external_memory_cases':len(memory_cases),'sources':len(source_rows)}))
