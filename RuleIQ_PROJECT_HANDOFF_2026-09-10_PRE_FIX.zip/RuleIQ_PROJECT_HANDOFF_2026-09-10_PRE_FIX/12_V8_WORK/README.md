# RuleIQ v8 workspace

The current deliverable is [RuleIQ_v8/README.md](RuleIQ_v8/README.md). All builders read the
preserved v7 baseline where needed and write only v8 artifacts. The release finalizer also
updates the root current pointer after verification; it never rebuilds a historical version.

Run the following from this directory using Python 3.9 or later, with the package's
verification/requirements.txt installed in that Python environment:

```sh
python3 -B build_contracts_v8.py
python3 -B build_sources_v8.py
python3 -B build_support_v8.py
python3 -B build_examples_v8.py
python3 -B RuleIQ_v8/verification/run_all_v8.py
python3 -B finalize_documentation_v8.py
python3 -B finalize_v8.py
```

The finalizer checks governance, constructs the package manifest, verifies the archive's
exact bytes and inventory, extracts into a temporary directory, and reruns the complete
suite without the historical workspace. It also proves altered/missing/extra files are
rejected. Only then does it publish the single v8 ZIP and SHA-256 sidecar into 08_RELEASE.
The archive contains self-contained verification code; the workspace builders remain here.
No command changes Pega or constitutes external runtime acceptance.
