# External handover

Review the v3 Pega specification, configure the real scalar parameter bindings and fresh
Generator context boundary, and execute the external acceptance requirements in an isolated
v3 scope. Preserve the existing v7 records and deployments until an explicit migration is ready.
This local package is complete within prompts/contracts/specifications; runtime acceptance
requires real Pega traces and remains NOT_EXECUTED. Keep subsequent workspace changes in English.
