"""Local adversarial checks for the assertion library, never a Pega runtime run."""
from pathlib import Path
import copy
import hashlib
import json
import sys
import memory_contract as c

HERE = Path(__file__).resolve().parent
checks = []

def check(name, fn, invalid=False):
    try:
        fn()
        passed = not invalid
    except c.ContractError:
        passed = invalid
    checks.append({'check': name, 'status': 'PASS' if passed else 'FAIL', 'kind': 'LOCAL_CONTRACT_ASSERTION'})

def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))

def args(batch, operation='WriteMemory'):
    return {'pxCaseID': 'TEST-CASE', 'Type': 'UnitTestCandidate', 'RequestsJSON': encoded({'pxResults': batch})}

payload = '  opaque | \\n versus actual\nnewline\r\t &quot; " \u0451😀  '
sent = [{'pyGroup': 'G1', 'pyPayload': payload}, {'pyGroup': 'G2', 'pyPayload': 'second'}]
write = args(sent)
good = [{'pyGroup': x['pyGroup'], 'pyGUID': 'guid-'+x['pyGroup'], 'Success': True,
         'ErrorCode': '', 'ErrorMessage': ''} for x in reversed(sent)]
def response(batch):
    return {'Success': True, 'ResultsJSON': encoded({'pxResults': batch}), 'ErrorCode': '', 'ErrorMessage': ''}

check('Valid write preserves opaque payload', lambda: c.require(c.request('WriteMemory', write)[0]['pyPayload'] == payload, 'payload'))
check('Shuffled write rows correlate by group', lambda: c.require(set(c.batch_response('WriteMemory', write, response(good))['results']) == {'G1','G2'}, 'groups'))
mixed = copy.deepcopy(good); mixed[0].update(Success=False, pyGUID='', ErrorCode='WRITE_FAILED', ErrorMessage='Injected failure')
check('One write failure preserves successful sibling', lambda: c.require(c.batch_response('WriteMemory', write, response(mixed))['results']['G1']['Success'], 'sibling'))
outer_failed = response(good); outer_failed.update(Success=False, ErrorCode='WRITE_FAILED', ErrorMessage='Unconfirmed wave')
check('Outer failure never trusts embedded success rows', lambda: c.require(c.batch_response('WriteMemory', write, outer_failed) == {'trusted':False, 'results':{}}, 'outer'))

for name, rows in [('missing row', good[:1]), ('duplicate group', good+[good[0]]),
                   ('unknown group', [dict(good[0], pyGroup='G9'), good[1]]),
                   ('reused created GUID', [dict(x, pyGUID='same') for x in good]),
                   ('success with error', [dict(good[0], ErrorCode='WRITE_FAILED'), good[1]]),
                   ('string Success', [dict(good[0], Success='true'), good[1]]),
                   ('failed write with GUID', [dict(good[0], Success=False, ErrorCode='WRITE_FAILED', ErrorMessage='bad'), good[1]]),
                   ('unknown write row error', [dict(mixed[0], ErrorCode='GUESS'), mixed[1]])]:
    check('Reject '+name, lambda rows=rows: c.batch_response('WriteMemory', write, response(rows)), True)
for text in ['{"pxResults":[],"pxResults":[]}', '{bad', '{"pxResults":[NaN]}']:
    check('Reject malformed/duplicate/nonfinite request '+text, lambda text=text: c.request('WriteMemory', dict(write, RequestsJSON=text)), True)
for name, changed in [('extra root', dict(write, CaseID='legacy')), ('legacy case key', {'CaseID':'TEST-CASE','Type':'UnitTestCandidate','RequestsJSON':write['RequestsJSON']}),
                      ('empty batch', args([])), ('duplicate request group', args([sent[0],sent[0]])),
                      ('empty payload', args([{'pyGroup':'G1','pyPayload':''}])),
                      ('caller supplied GUID', args([dict(sent[0],pyGUID='own')])),
                      ('unrecognized type',dict(write,Type='Unknown'))]:
    check('Reject '+name,lambda changed=changed:c.request('WriteMemory',changed),True)

read = {'pxCaseID':'TEST-CASE','Type':'UnitTestCandidate','pyGUID':' opaque|guid\\id '}
read_result = {'Success':True,**read,'pyGroup':'G1','pyPayload':payload,'ErrorCode':'','ErrorMessage':''}
check('Get exact opaque GUID and payload round trip', lambda:c.require(c.get_response(read,'G1',read_result)==payload,'payload'))
for key in ('pxCaseID','Type','pyGUID','pyGroup','pyPayload'):
    mutated = dict(read_result); mutated[key] = '' if key=='pyPayload' else 'different'
    check('Reject read mismatch/empty '+key,lambda mutated=mutated:c.get_response(read,'G1',mutated),True)
check('Reject lifecycle fields silently added to GetMemory',lambda:c.get_response(read,'G1',dict(read_result,pyStatusValue='Passed')),True)
failed_read = dict(read_result,Success=False,ErrorCode='READ_FAILED',ErrorMessage='unavailable')
check('Failed read never releases partial payload',lambda:c.require(c.get_response(read,'G1',failed_read) is None,'partial'))

record={'pyGUID':'guid-G1','pxCaseID':'TEST-CASE','Type':'UnitTestCandidate','pyGroup':'G1','pyPayload':payload,'pyStatusValue':'Pending','pyRouterKey':''}
check('New candidate initializes Pending and empty router',lambda:c.created_candidate(write,sent[0],record,'guid-G1'))
check('New version cannot reuse previous GUID',lambda:c.created_candidate(write,sent[0],record,'guid-G1',['guid-G1']),True)
check('Creation snapshot must match returned GUID',lambda:c.created_candidate(write,sent[0],record,'another-guid'),True)
check('Creation snapshot must match a sent row',lambda:c.created_candidate(write,dict(sent[0],pyGroup='UNSENT'),record,'guid-G1'),True)
for field, value in [('pyStatusValue','Passed'),('pyRouterKey','OK'),('pyPayload',payload.strip()),('pyGroup','G2')]:
    check('Reject created record mismatch '+field,lambda field=field,value=value:c.created_candidate(write,sent[0],dict(record,**{field:value}),'guid-G1'),True)
for route in ('OK','GENERATOR_REPAIR','SEMANTIC_REJECT','HUMAN'):
    patch=c.lifecycle_updates(route); row={'pyGroup':'G1','pyGUID':'guid-G1','pyUpdates':patch}; call=args([row])
    after=dict(record,**patch)
    check('Lifecycle patch '+route,lambda row=row,call=call,after=after:c.patched_candidate(call,row,record,after))
check('Reject fabricated route',lambda:c.lifecycle_updates('RETRY'),True)
for field in ('pyGUID','pxCaseID','Type','pyGroup','pyPayload','extra','pyPayload.x','/pyStatusValue'):
    row={'pyGroup':'G1','pyGUID':'guid-G1','pyUpdates':{field:'tampered'}}
    check('Reject protected/unknown/path patch '+field,lambda row=row:c.request('UpdateMemory',args([row])),True)
for value in ({}, {'pyStatusValue':None}, {'pyRouterKey':True}, {'pyStatusValue':{'nested':'Passed'}}):
    row={'pyGroup':'G1','pyGUID':'guid-G1','pyUpdates':value}
    check('Reject empty or non-string metadata '+encoded(value),lambda row=row:c.request('UpdateMemory',args([row])),True)

before=dict(record,pyStatusValue='Failed',pyRouterKey='HUMAN')
row={'pyGroup':'G1','pyGUID':'guid-G1','pyUpdates':{'pyRouterKey':'GENERATOR_REPAIR'}}
call=args([row]); after=dict(before,pyRouterKey='GENERATOR_REPAIR')
check('Shallow partial patch preserves omitted status and payload',lambda:c.patched_candidate(call,row,before,after))
for field, value in [('pyStatusValue','Pending'),('pyPayload','changed'),('pyGUID','another'),('pyGroup','another'),('pxCaseID','another'),('Type','ScenarioGroup')]:
    check('Reject collateral record change '+field,lambda field=field,value=value:c.patched_candidate(call,row,before,dict(after,**{field:value})),True)
for field, value in [('pxCaseID','OTHER'),('Type','ScenarioGroup')]:
    check('Reject patch ownership '+field,lambda field=field,value=value:c.patched_candidate(dict(call,**{field:value}),row,before,after),True)
bad_row=dict(row,pyGroup='G2')
check('Reject patch group mismatch',lambda:c.patched_candidate(args([bad_row]),bad_row,before,after),True)

second={'pyGroup':'G2','pyGUID':'guid-G2','pyUpdates':c.lifecycle_updates('OK')}
update=args([row,second]); update_result=[dict(good[0],Success=False,ErrorCode='UPDATE_FAILED',ErrorMessage='Injected failure'),good[1]]
check('Update partial failure correlates by group and GUID',lambda:c.require(c.batch_response('UpdateMemory',update,response(update_result))['results'][('G1','guid-G1')]['Success'],'sibling'))
check('Update response rejects another candidate version',lambda:c.batch_response('UpdateMemory',update,response([dict(update_result[0],pyGUID='old'),update_result[1]])),True)
check('Update failed row must echo current GUID',lambda:c.batch_response('UpdateMemory',update,response([dict(update_result[0],pyGUID=''),update_result[1]])),True)
check('Update missing result cannot imply success',lambda:c.batch_response('UpdateMemory',update,response(update_result[:1])),True)

# Verify the actual frozen sources used for this specification, without modifying
# the release. This is compatibility evidence, not generated model behavior.
source_root=Path(sys.argv[1]) if len(sys.argv)>1 else HERE.parent/'sources'
pins=json.loads((HERE/'SOURCE_AUTHORITY.json').read_text())
for item in pins['sources']:
    path=source_root/item['file']; content=path.read_bytes()
    check('Pinned source unchanged '+item['file'],lambda content=content,item=item:c.require(hashlib.sha256(content).hexdigest()==item['sha256'],'source changed'))
    for anchor in item['anchors']:
        check(item['file']+' supports '+anchor['requirement'],lambda content=content,anchor=anchor:c.require(anchor['text'] in content.decode(),'missing anchor'))

failed=[x for x in checks if x['status']=='FAIL']
result={'status':'PASS_LOCAL_CONTRACT' if not failed else 'FAIL','checks_total':len(checks),
        'checks_passed':len(checks)-len(failed),'checks_failed':len(failed),'checks':checks,
        'scope':'Read-only assertions exercised with synthetic inputs and snapshots, plus pinned source compatibility.',
        'pega_executed':False,'external_pending':['C-027','C-028','C-029']}
print(json.dumps(result,indent=2,ensure_ascii=False))
raise SystemExit(bool(failed))
