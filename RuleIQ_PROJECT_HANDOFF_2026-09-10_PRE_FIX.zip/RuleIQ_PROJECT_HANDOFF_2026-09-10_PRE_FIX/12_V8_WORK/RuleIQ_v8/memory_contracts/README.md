# Memory v3

- [Contract](MEMORY_TOOL_CONTRACT_v3.md)
- [External acceptance requirements](ACCEPTANCE_CASES.json)

memory_contract.py validates supplied evidence and does not implement storage.
test_memory_contract.py exercises synthetic evidence and active source pins.
