# Memory v3 — immutable versions and metadata lifecycle

RuleIQ v8 / Variant B. This supersedes Memory v2 for the v8 chain. It does not change
the preserved v7 deployment or data. This package specifies and checks external behavior;
it contains no Pega persistence implementation.

## Identity and ownership

Types are exactly ScenarioGroup and UnitTestCandidate. pyGUID is globally unique and
identifies one immutable payload version. (pxCaseID,Type,pyGroup) is lineage; several
versions/runs may share it. Never update/resolve a record by that tuple or select latest.
Treat all addresses and payload text as exact opaque strings, preserving whitespace,
case, Unicode and escapes after one JSON decode. No payload parse/reserialize/trim/merge.

Author writes all complete ScenarioGroups in one batch. Each isolated Generator reads
one supplied ScenarioGroup, writes one initial candidate and at most two repair versions,
and updates lifecycle on the exact current candidate. Validator reads only its exact
candidate after schema success. Author and Validator never call UpdateMemory.

## WriteMemory

WriteMemory(pxCaseID, Type, RequestsJSON): exactly three string arguments.
RequestsJSON decodes once to exactly {"pxResults":[...]} with a nonempty array.
Each row is exactly {"pyGroup":"G001","pyPayload":"<complete opaque content>"}.
Require nonempty strings and unique groups within a batch. Author sends all source rows;
an isolated Generator always sends one candidate row. No GUID, operation or lifecycle input.

Every successful row creates a new GUID, including repeated writes of identical content.
Candidate canonical records contain pyGUID,pxCaseID,Type,pyGroup,pyPayload,pyStatusValue,
pyRouterKey; initialize the last two to Pending and empty string. ScenarioGroup canonical
records have the first five fields. Private storage fields may coexist.
Never overwrite an earlier payload. A successful response must describe committed state
visible to another requestor; no success before durable completion. Enforce GUID uniqueness
atomically under contention. Validate framing and duplicate-key ambiguity before mutation;
then validate/commit rows independently. A rejected row cannot partly write or roll back siblings.

Exact outer response: Success (boolean), ResultsJSON/ErrorCode/ErrorMessage (strings).
Success=true requires empty errors and ResultsJSON decoding to exactly pxResults with one
row per request. Every row has exactly pyGroup,Success,pyGUID,ErrorCode,ErrorMessage.
Success rows have nonempty distinct newly assigned GUIDs and empty errors. Failure rows have
empty GUID, nonempty diagnostic and code INVALID_INPUT, UNSUPPORTED_TYPE or WRITE_FAILED.
Correlate by group, never position. Outer failure requires nonempty code/message and makes
the entire result unconfirmed, regardless of embedded rows. Missing/unknown/duplicate or
malformed response identities cannot establish success. Response loss never implies rollback.

Author requires EVERY source row confirmed before any Generator invocation. This does not
make storage batch-transactional: successfully committed source rows remain after failure.
All callers make one attempt per operation and never automatically retry uncertain failures.

## GetMemory

GetMemory(pxCaseID, Type, pyGUID): exactly three nonempty strings. Enforce exact case/type/GUID
ownership. No group/latest lookup, retry or fallback. Return exactly these eight fields:

```json
{"Success":true,"pxCaseID":"CASE-1","Type":"UnitTestCandidate","pyGroup":"G001","pyGUID":"candidate-demo-1","pyPayload":"<complete candidate JSON>","ErrorCode":"","ErrorMessage":""}
```

All fields except Success are strings. A success requires nonempty group/payload and empty
errors. Failed/malformed reads do not release partial payloads. Generator compares returned
pyGroup with the parsed ScenarioGroup groupId. Validator reports the returned groupId and
Generator compares it with its source group. Do not add lifecycle fields to this response;
acceptance/consumer code uses a separate read-only canonical storage projection.

## UpdateMemory

UpdateMemory(pxCaseID, Type, RequestsJSON): exactly three string arguments. Current Generator
uses Type=UnitTestCandidate and exactly one row:

```json
{"pxResults":[{"pyGroup":"G001","pyGUID":"candidate-demo-1","pyUpdates":{"pyStatusValue":"Passed","pyRouterKey":"OK"}}]}
```

Address the existing exact GUID and verify case/type/group. Never insert on missing GUID.
Protect all identity fields and pyPayload. Only string pyStatusValue/pyRouterKey may be
shallow-patched; no nested/path/unknown fields or deletion. The generic service preserves
omitted metadata fields, but the v8 Generator ALWAYS supplies both fields matching one
direct validated ValidatorReport. Allowed current pairs are Passed/OK,
Failed/GENERATOR_REPAIR, Failed/SEMANTIC_REJECT, Failed/HUMAN. Pending/empty is creation only.

Use the WriteMemory outer envelope. Decoded row fields are exactly
pyGroup,pyGUID,Success,ErrorCode,ErrorMessage. Both success and failure echo requested group
and GUID. Success has empty errors; failure has nonempty code/diagnostic. Never substitute
an empty GUID on failed update or return a newly created GUID. Row updates are atomic;
failure cannot alter protected/omitted fields or undo another committed record.

## Lifecycle and selection

Persist candidate Pending -> fresh Validator -> validate direct JSON report -> exactly one
UpdateMemory. Confirm Passed/OK before reporting success. Confirm Failed/GENERATOR_REPAIR
before writing a new complete repair version with a new GUID. HUMAN/SEMANTIC_REJECT stop.
At most two repaired writes and three Validator attempts per isolated Generator. Prior
payloads and their confirmed statuses remain intact; never revalidate an older version as fallback.
Malformed Validator output leaves Pending and yields VALIDATOR_RESPONSE_INVALID with zero
updates. Failed/unconfirmed UpdateMemory yields LIFECYCLE_UPDATE_FAILED and no further repair.

Pega serializes the entire Author run per case through selection; other cases are independent.
Fresh Generator invocations never inherit transcripts/Knowledge from Author or earlier groups.
Only after all groups succeed may the consumer select final UUIDs from this run's verified
GeneratorRunReports, independently confirm Passed/OK, and read/materialize under the case guard.
Old Passed records and partially failed runs are not an automatic fallback. Informational
NotTestable without RuleCode is visible information, never a runnable unit test.

## Rollout and evidence

Bind all v8 prompts, schemas and Memory v3 together. Use an isolated v3 test scope by default.
Production migration requires a Pega-owned mapping/storage decision before removing v2 tuple
uniqueness or activating append-only writes; preserve all existing v7 records. Never silently
delete, overwrite or reinterpret a v7 candidate as a confirmed current v8 result.
Local assertions validate supplied requests/responses/snapshots only. Runtime acceptance
requires actual calls, failure injection, before/after projections, new-requestor durability
and context-isolation evidence. These external checks are not executed by this package.
