"""Read-only assertions for the v3 immutable-version Memory boundary (RuleIQ v8), NOT a Memory implementation.

There is no storage, network, GUID generation, retry, or Pega execution here.
Functions return parsed evidence or raise ContractError. Server failure and
malformed evidence are distinct; neither establishes a usable candidate.
"""
import json


class ContractError(ValueError):
    pass


def require(okay, message):
    if not okay:
        raise ContractError(message)


def parse(text):
    require(isinstance(text, str), 'JSON carrier must be a string')
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON field')
            result[key] = value
        return result
    try:
        return json.loads(text, object_pairs_hook=pairs,
                          parse_constant=lambda value: (_ for _ in ()).throw(ContractError('non-finite JSON')))
    except json.JSONDecodeError as error:
        raise ContractError('invalid JSON carrier') from error


def exact(obj, fields):
    require(isinstance(obj, dict) and set(obj) == set(fields), 'unexpected/missing fields')


def string(value, nonempty=False):
    require(isinstance(value, str) and (not nonempty or value != ''), 'expected string')
    # Opaque addresses/payload are never stripped, decoded again or normalized.


def address(args, operation):
    tail = 'pyGUID' if operation == 'GetMemory' else 'RequestsJSON'
    exact(args, ['pxCaseID', 'Type', tail])
    string(args['pxCaseID'], True)
    require(args['Type'] in ('ScenarioGroup', 'UnitTestCandidate'), 'unsupported Type')
    string(args[tail], True)
    if operation == 'UpdateMemory':
        require(args['Type'] == 'UnitTestCandidate', 'current Generator update profile is candidate-only')


def rows(args):
    envelope = parse(args['RequestsJSON'])
    exact(envelope, ['pxResults'])
    result = envelope['pxResults']
    require(isinstance(result, list) and len(result) > 0, 'nonempty pxResults required')
    return result


def updates(value):
    require(isinstance(value, dict) and bool(value), 'nonempty root patch required')
    require(set(value) <= {'pyStatusValue', 'pyRouterKey'}, 'protected/unauthorized/path field')
    for item in value.values():
        string(item)
    # This helper checks allowed field names/types. Route-specific values and
    # paired transition fields are checked by lifecycle_updates below.


def lifecycle_updates(route):
    require(route in ('OK', 'GENERATOR_REPAIR', 'SEMANTIC_REJECT', 'HUMAN'), 'invalid Validator route')
    return {'pyStatusValue': 'Passed' if route == 'OK' else 'Failed', 'pyRouterKey': route}


def request(operation, args):
    require(operation in ('WriteMemory', 'GetMemory', 'UpdateMemory'), 'unknown operation')
    address(args, operation)
    if operation == 'GetMemory':
        return None
    batch = rows(args)
    groups, guids = set(), set()
    for row in batch:
        exact(row, ['pyGroup', 'pyPayload'] if operation == 'WriteMemory' else ['pyGroup', 'pyGUID', 'pyUpdates'])
        string(row['pyGroup'], True)
        require(row['pyGroup'] not in groups, 'duplicate request group')
        groups.add(row['pyGroup'])
        if operation == 'WriteMemory':
            string(row['pyPayload'], True)
        else:
            string(row['pyGUID'], True)
            require(row['pyGUID'] not in guids, 'duplicate candidate address in current update wave')
            guids.add(row['pyGUID'])
            updates(row['pyUpdates'])
    return batch


def diagnostic(obj):
    require(type(obj['Success']) is bool, 'Success must be JSON boolean')
    string(obj['ErrorCode']); string(obj['ErrorMessage'])
    if obj['Success']:
        require(obj['ErrorCode'] == obj['ErrorMessage'] == '', 'success has errors')
    else:
        require(obj['ErrorCode'] != '' and obj['ErrorMessage'] != '', 'failure lacks diagnostic')


def batch_response(operation, args, response):
    require(operation in ('WriteMemory', 'UpdateMemory'), 'batch response operation')
    address(args, operation)
    # The input may intentionally contain a row-invalid payload/patch in a
    # partial-failure acceptance case. Correlation still has to be unambiguous.
    sent = rows(args)
    correlation = (lambda row: row['pyGroup']) if operation == 'WriteMemory' else (lambda row: (row['pyGroup'], row['pyGUID']))
    try:
        expected = [correlation(row) for row in sent]
        require(len(expected) == len(set(expected)), 'ambiguous request correlation')
    except (KeyError, TypeError) as error:
        raise ContractError('uncorrelatable request') from error
    exact(response, ['Success', 'ResultsJSON', 'ErrorCode', 'ErrorMessage'])
    string(response['ResultsJSON']); diagnostic(response)
    if not response['Success']:
        # Outer failure never promotes embedded rows to success, even if present.
        return {'trusted': False, 'results': {}}
    decoded = parse(response['ResultsJSON']); exact(decoded, ['pxResults'])
    require(isinstance(decoded['pxResults'], list), 'response pxResults must be array')
    found, created_guids = {}, set()
    for row in decoded['pxResults']:
        exact(row, ['pyGroup', 'pyGUID', 'Success', 'ErrorCode', 'ErrorMessage'])
        string(row['pyGroup'], True); string(row['pyGUID']); diagnostic(row)
        key = correlation(row)
        require(key in expected and key not in found, 'unknown/duplicate response correlation')
        if operation == 'UpdateMemory':
            string(row['pyGUID'], True)
        elif row['Success']:
            string(row['pyGUID'], True)
            require(row['pyGUID'] not in created_guids, 'reused created GUID')
            created_guids.add(row['pyGUID'])
        else:
            require(row['pyGUID'] == '', 'failed write returned GUID')
            require(row['ErrorCode'] in ('INVALID_INPUT', 'UNSUPPORTED_TYPE', 'WRITE_FAILED'), 'unknown write row error')
        found[key] = row
    require(set(found) == set(expected), 'missing response rows')
    return {'trusted': True, 'results': found}


def get_response(args, expected_group, response):
    request('GetMemory', args)
    exact(response, ['Success', 'pxCaseID', 'Type', 'pyGroup', 'pyGUID', 'pyPayload', 'ErrorCode', 'ErrorMessage'])
    for key in ('pxCaseID', 'Type', 'pyGroup', 'pyGUID', 'pyPayload'):
        string(response[key])
    diagnostic(response)
    if not response['Success']:
        return None
    require(all(response[k] == args[k] for k in ('pxCaseID', 'Type', 'pyGUID')), 'read identity mismatch')
    string(response['pyGroup'], True)
    if expected_group is not None:
        require(response['pyGroup'] == expected_group, 'read group mismatch')
    string(response['pyPayload'], True)
    return response['pyPayload']


RECORD_FIELDS = {'pyGUID', 'pxCaseID', 'Type', 'pyGroup', 'pyPayload', 'pyStatusValue', 'pyRouterKey'}


def candidate_record(record):
    # Observer is a projection of public canonical fields, not a raw DB row.
    exact(record, RECORD_FIELDS)
    for key in RECORD_FIELDS:
        string(record[key], key not in ('pyStatusValue', 'pyRouterKey'))
    require(record['Type'] == 'UnitTestCandidate', 'expected candidate snapshot')


def created_candidate(args, sent_row, snapshot, returned_guid, previous_guids=()):
    request('WriteMemory', args)
    require(sent_row in rows(args), 'created row absent from request')
    candidate_record(snapshot)
    string(returned_guid, True)
    require(snapshot['pyGUID'] == returned_guid, 'snapshot does not match successful write response GUID')
    require(snapshot['pyGUID'] not in previous_guids, 'candidate version overwrote old GUID')
    require(all(snapshot[k] == args[k] for k in ('pxCaseID', 'Type')), 'created address mismatch')
    require(all(snapshot[k] == sent_row[k] for k in ('pyGroup', 'pyPayload')), 'created content mismatch')
    require(snapshot['pyStatusValue'] == 'Pending' and snapshot['pyRouterKey'] == '', 'candidate initial lifecycle')
    return True


def patched_candidate(args, sent_row, before, after):
    candidate_record(before); candidate_record(after)
    request('UpdateMemory', args)
    require(sent_row in rows(args), 'patch row absent from request')
    require(all(before[k] == args[k] for k in ('pxCaseID', 'Type')), 'patch ownership mismatch')
    require(all(before[k] == sent_row[k] for k in ('pyGUID', 'pyGroup')), 'patch lineage mismatch')
    expected = dict(before)
    expected.update(sent_row['pyUpdates'])
    require(after == expected, 'patch changed protected/omitted fields or failed to persist updates')
    return True


def lifecycle_request(args, current_guid, current_group, route):
    """The v8 Generator profile always sends both lifecycle fields for one version."""
    batch = request('UpdateMemory', args)
    require(len(batch) == 1, 'isolated Generator sends exactly one update row')
    row = batch[0]
    require(row['pyGUID']==current_guid and row['pyGroup']==current_group, 'not current version')
    require(row['pyUpdates']==lifecycle_updates(route), 'lifecycle pair differs from direct route')
    return row


def all_sources_confirmed(args, response):
    """Author source-set gate; successful siblings remain stored but cannot be handed off alone."""
    request('WriteMemory', args)
    require(args['Type']=='ScenarioGroup', 'expected source batch')
    result = batch_response('WriteMemory', args, response)
    require(result['trusted'] and all(row['Success'] for row in result['results'].values()),
            'incomplete source set; zero Generator invocations')
    return {key:row['pyGUID'] for key,row in result['results'].items()}
