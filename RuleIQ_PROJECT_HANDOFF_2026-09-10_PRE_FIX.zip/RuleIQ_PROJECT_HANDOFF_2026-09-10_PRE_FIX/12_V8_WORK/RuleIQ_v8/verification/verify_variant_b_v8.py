"""Adversarial v8 source/interface/sequence tests. Synthetic models are not runtime evidence."""
from pathlib import Path
import copy
import hashlib
import html
import json
import re
from xml.etree import ElementTree as ET
import jsonschema
import variant_b_model as model

a, m = model.a, model.m
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'sources'
checks=[]

def check(name, fn, invalid=False, kind='LOCAL_CONTRACT'):
    detail=''
    try:
        result=fn()
        okay=not invalid and result is not False
    except (a.ContractError,m.ContractError) as error:
        okay=invalid
        detail=str(error) if not okay else ''
    except Exception as error:
        okay=False; detail=type(error).__name__+': '+str(error)
    checks.append({'check':name,'status':'PASS' if okay else 'FAIL','kind':kind,'detail':detail})

def change(value,path,new):
    value=copy.deepcopy(value); node=value
    for key in path[:-1]: node=node[key]
    node[path[-1]]=new
    return value

def fixture(order=1,when=False,info=False,scenarios=2):
    if info:
        filename='FIXTURE_MULTINPCOMB_INFORMATIONAL_NOT_TESTABLE.json' if when else 'FIXTURE_STANDARD_INFORMATIONAL_NOT_TESTABLE.json'
        candidate=json.loads((ROOT/'verification'/filename).read_text())
    else:
        filename='rule-test-unit-case_multInpComb-JsonExample_02_TC_IsPaymentReviewRequired_MultiInput.txt' if when else 'rule-test-unit-case_JsonExample.txt'
        candidate=json.loads((SRC/filename).read_text())
        if when:
            candidate['UnitTestRules'][0]['Scenarios']=candidate['UnitTestRules'][0]['Scenarios'][:scenarios]
            d=candidate['UnitTestRules'][0]['RuleCode']['pyExpectedResults'][0]
            d['pyExpectedResults']=d['pyExpectedResults'][:scenarios]
    count=len(candidate['UnitTestRules'][0]['Scenarios'])
    return {'evidence_kind':'NORMALIZED_SYNTHETIC_SOURCE_NOT_SG_WIRE','sourceValid':True,
            'caseId':'CASE-1','rutType':'Rule-Obj-When' if when else 'Rule-Obj-Model',
            'rutClass':'Demo-Data','rutName':'DemoRule','ruleset':'DemoRules','caseKey':'SYNTHETIC CASE KEY',
            'groupId':f'G{order:03}','groupOrder':order,'scenarioIds':[f'S{x+1:03}' for x in range(count)],
            'mode':'INFORMATIONAL_NOT_TESTABLE' if info else 'EXECUTABLE',
            'simulationGroupKey':('information-' if info else 'simulation-')+str(order),
            'candidateFixture':candidate}

def calls(mem,tool,scope=None):
    return [e for e in mem.events if e['tool']==tool and (scope is None or e['scope']==scope)]

texts={p.name:p.read_text() for p in SRC.glob('*.txt')}
for name,value in a.SCHEMAS.items():
    check('Valid JSON Schema '+name,lambda value=value:jsonschema.Draft202012Validator.check_schema(value),'', 'SCHEMA')
for config,prompt in [('UnitTestGenerator.txt','UnitTestGenerator_Prompt.txt'),('JsonValidator_tool.txt','Validator_Prompt.txt')]:
    def parity(config=config,prompt=prompt):
        tree=ET.fromstring(texts[config])
        markup=re.search(r'<pySystemPrompt>(.*?)</pySystemPrompt>',texts[config],re.S)[1]
        decoded='\n'.join(html.unescape(x) for x in re.findall(r'<p>(.*?)</p>',markup,re.S))
        return decoded==texts[prompt].rstrip('\n')
    check('Exact standalone/embedded parity '+config,parity,kind='SOURCE')
    style='GeneratorRunReport' if config=='UnitTestGenerator.txt' else 'ValidatorReport'
    check('JSON response style '+config,lambda config=config,style=style:style in ET.fromstring(texts[config]).find('.//pyResponseStylePrompt').itertext().__next__(),kind='SOURCE')
tree=ET.fromstring(texts['UnitTestGenerator.txt'])
check('Generator five permitted tools',lambda:set(x.text for x in tree.findall('.//pzKnowledgeTools/rowdata/pyPurpose'))=={'GetMemory','KnowledgeTool','WriteMemory','UpdateMemory'} and [x.text for x in tree.findall('.//pzAgentTools/rowdata/pyPurpose')]==['UnitTestValidator'],kind='SOURCE')
treev=ET.fromstring(texts['JsonValidator_tool.txt'])
check('Validator retains read-only inventory',lambda:set(x.text for x in treev.findall('.//pzKnowledgeTools/rowdata/pyPurpose'))=={'GetMemory','KnowledgeTool','JsonValidationTool'},kind='SOURCE')
for file in ('Main_Agent_Prompt.txt','UnitTestGenerator_Prompt.txt','Validator_Prompt.txt'):
    for stale in ('GR|','VR|','VI|','GEN|','VAL|','ScenarioGroupUUIDs','Memory contract v2','upsert','partial successful persistence handoff','UnitTestGenerator(question','UnitTestValidator(question'):
        check(file+' no stale executable '+stale,lambda file=file,stale=stale:stale not in texts[file],kind='SOURCE')
for phrase in ('ANY unsuccessful/unconfirmed source row prevents ALL Generator invocations','strictly in original groupOrder','An earlier success cannot','no cross-invocation Generator cache'):
    check('Author requires '+phrase,lambda phrase=phrase:phrase in texts['Main_Agent_Prompt.txt'],kind='SOURCE')
check('Naming always uses original order suffix',lambda:'Always append stable G<original groupOrder>' in texts['UnitTestGenerator_Prompt.txt'],kind='SOURCE')
check('Frozen source grouping responsibility synchronized',lambda:next(l for l in texts['Main_Agent_Prompt.txt'].splitlines() if l.startswith('- In the complete Author snapshot, groupOrder')) in texts['UnitTestGenerator_Prompt.txt'],kind='SOURCE')
for name in ('GENERATOR_REPORT_CONTRACT.md','VALIDATOR_REPORT_CONTRACT.md'):
    text=(ROOT/'agent_contracts'/name).read_text().split('\n',1)[1].strip()
    targets=('Main_Agent_Prompt.txt','UnitTestGenerator_Prompt.txt') if name.startswith('GENERATOR') else ('UnitTestGenerator_Prompt.txt','Validator_Prompt.txt')
    check('Normative report copies match '+name,lambda text=text,targets=targets:all(text in texts[t] for t in targets),kind='SOURCE')
catalog_text=texts['Validator_Prompt.txt'].split('## Appendix A.',1)[1].split('## Appendix B.',1)[0]
parsed={k:v.split(', ') for k,v in re.findall(r'^\| ([A-Z_]+) \| ([A-Z_, ]+) \|$',catalog_text,re.M)}
check('Diagnostic catalog remains complete in schema and both agents',lambda:len(parsed)==30 and parsed==a.CATALOG and all('| '+code+' | '+', '.join(actions)+' |' in texts['UnitTestGenerator_Prompt.txt'] for code,actions in parsed.items()),kind='SOURCE')

for agent,key in [('Generator','ScenarioGroupUUID'),('Validator','UnitTestCandidateUUID')]:
    good={'CaseID':' CASE | ё ','RUTType':'Rule-Obj-When',key:' opaque | \\ GUID '}
    check(agent+' accepts exact opaque strings',lambda agent=agent,good=good:a.input_(agent,good))
    for field in good:
        for value in ('',None,[],{},True,3):
            check(agent+' rejects '+field+' '+repr(value),lambda agent=agent,good=good,field=field,value=value:a.input_(agent,dict(good,**{field:value})),True)
        bad=dict(good);bad.pop(field)
        check(agent+' rejects missing '+field,lambda agent=agent,bad=bad:a.input_(agent,bad),True)
    for extra in ('question','ScenarioGroupUUIDs','payload','previousReport'):
        check(agent+' rejects extra '+extra,lambda agent=agent,good=good,extra=extra:a.input_(agent,dict(good,**{extra:'x'})),True)

mem=model.FakeMemory(); source=[fixture(1),fixture(2),fixture(3)]
run=model.author(mem,source)
check('Three groups yield three complete isolated invocations',lambda:run['status']=='Completed' and len(calls(mem,'UnitTestGenerator'))==3,kind='MODEL')
check('One source batch precedes all Generator calls',lambda:mem.events[0]['tool']=='WriteMemory' and len(calls(mem,'WriteMemory','author'))==1 and len(json.loads(mem.events[0]['args']['RequestsJSON'])['pxResults'])==3,kind='MODEL')
check('Reversed source responses still invoke original group order',lambda:[r['groups'][0]['groupOrder'] for r in run['reports']]==[1,2,3],kind='MODEL')
for n in range(1,4):
    scope=f'generator-G{n:03}'
    check('One exact source read '+scope,lambda scope=scope:len(calls(mem,'GetMemory',scope))==1,kind='MODEL')
    check('Independent one Knowledge acquisition '+scope,lambda scope=scope:len(calls(mem,'KnowledgeTool',scope))==1,kind='MODEL')
    check('One-row write and metadata update '+scope,lambda scope=scope:all(len(json.loads(e['args']['RequestsJSON'])['pxResults'])==1 for t in ('WriteMemory','UpdateMemory') for e in calls(mem,t,scope)),kind='MODEL')
check('No cross-invocation artifacts in three scalar inputs',lambda:all(set(e['args'])=={'CaseID','RUTType','ScenarioGroupUUID'} for e in calls(mem,'UnitTestGenerator')) and len({e['args']['ScenarioGroupUUID'] for e in calls(mem,'UnitTestGenerator')})==3,kind='MODEL')
check('Complete run selects exactly final candidates',lambda:len(run['selection']['executable'])==3,kind='MODEL')

for failed in ('G001','G002','G003'):
    fm=model.FakeMemory();fm.failed_sources.add(failed);out=model.author(fm,source)
    check('Source failure '+failed+' prevents every invocation',lambda fm=fm,out=out:out['status']=='Failed' and not calls(fm,'UnitTestGenerator') and len(fm.records)==2,kind='MODEL')
for kind in ('read','write','update','knowledge','malformed','semantic','human'):
    fm=model.FakeMemory();opts={}
    if kind=='read': fm.read_faults.add('generator-G002')
    elif kind=='write': fm.fail_write_scopes.add('generator-G002')
    elif kind=='update': fm.fail_update_scopes.add('generator-G002')
    elif kind=='knowledge': opts={'knowledge_ok':False}
    elif kind=='malformed': opts={'invalid_report':True}
    else: opts={'routes':('SEMANTIC_REJECT' if kind=='semantic' else 'HUMAN',)}
    out=model.author(fm,source,{'G002':opts})
    check('Fail-fast '+kind+' retains earlier result and stops third',lambda fm=fm,out=out:out['status']=='Failed' and len(calls(fm,'UnitTestGenerator'))==2 and out['selection']=={'executable':[],'informational':[]} and any(r.get('pyStatusValue')=='Passed' for r in fm.records.values()),kind='MODEL')
    check('No automatic retry '+kind,lambda fm=fm:len(calls(fm,'GetMemory','generator-G002'))==1 and len(calls(fm,'WriteMemory','generator-G002'))<=1 and len(calls(fm,'UpdateMemory','generator-G002'))<=1,kind='MODEL')
    if kind=='malformed':
        check('Malformed report leaves Pending with zero updates',lambda fm=fm:not calls(fm,'UpdateMemory','generator-G002') and any(r['pyGroup']=='G002' and r.get('pyStatusValue')=='Pending' for r in fm.records.values()),kind='MODEL')
for point in ('source','candidate','lifecycle'):
    fm=model.FakeMemory()
    (fm.lost_update_scopes if point=='lifecycle' else fm.lost_write_scopes).add('author' if point=='source' else 'generator-G001')
    out=model.author(fm,source)
    check('Commit then lost '+point+' response remains failed without retry',lambda fm=fm,out=out,point=point:out['status']=='Failed' and len(calls(fm,'UnitTestGenerator'))==(0 if point=='source' else 1) and len(calls(fm,'WriteMemory','author'))==1 and len(calls(fm,'WriteMemory','generator-G001'))<=1 and len(calls(fm,'UpdateMemory','generator-G001'))<=1,kind='MODEL')

for routes,expected in [(('OK',),'Completed'),(('GENERATOR_REPAIR','OK'),'Completed'),(('GENERATOR_REPAIR','GENERATOR_REPAIR','OK'),'Completed'),(('GENERATOR_REPAIR',)*4,'Failed')]:
    fm=model.FakeMemory();out=model.author(fm,[fixture()],{'G001':{'routes':routes}})
    candidates=[r for r in fm.records.values() if r['Type']=='UnitTestCandidate']
    check('Immutable repair flow '+str(routes),lambda out=out,expected=expected,candidates=candidates,routes=routes:out['status']==expected and len(candidates)==min(len(routes),3) and len({r['pyGUID'] for r in candidates})==len(candidates),kind='MODEL')
    check('Prior version payloads remain readable '+str(routes),lambda candidates=candidates:all(json.loads(r['pyPayload'])==json.loads(candidates[0]['pyPayload']) for r in candidates),kind='MODEL')
    check('Repair does not reacquire source/Knowledge '+str(routes),lambda fm=fm:len(calls(fm,'GetMemory','generator-G001'))==len(calls(fm,'KnowledgeTool','generator-G001'))==1,kind='MODEL')
    check('One metadata update per validation '+str(routes),lambda fm=fm:len(calls(fm,'UpdateMemory','generator-G001'))==len(calls(fm,'UnitTestValidator','generator-G001'))<=3,kind='MODEL')
    if expected=='Completed':
        check('Only final repair version selected '+str(routes),lambda out=out,candidates=candidates:out['selection']['executable']==[candidates[-1]['pyGUID']] and all(r['pyStatusValue']=='Failed' for r in candidates[:-1]),kind='MODEL')
fm=model.FakeMemory();out=model.author(fm,[fixture(1),fixture(2)],{'G001':{'routes':('GENERATOR_REPAIR','GENERATOR_REPAIR','OK')}})
check('Repair budgets independent across invocations',lambda:[r['validationAttempts'] for r in out['reports']]==[3,1],kind='MODEL')
fm=model.FakeMemory();out=model.author(fm,[fixture()],{'G001':{'schema_invalid_attempts':(0,)}})
check('Schema-invalid first version is not read then repaired freshly',lambda:out['status']=='Completed' and not calls(fm,'GetMemory','generator-G001/validator-1') and len(calls(fm,'JsonValidationTool'))==2,kind='MODEL')

when=fixture(when=True);fm=model.FakeMemory();wr=model.author(fm,[when])
candidate=json.loads(fm.records[wr['reports'][0]['candidate']['UUID']]['pyPayload'])
check('Two When scenarios remain one invocation and one two-row candidate',lambda:len(calls(fm,'UnitTestGenerator'))==1 and len(candidate['UnitTestRules'])==1 and len(candidate['UnitTestRules'][0]['Scenarios'])==2 and len(candidate['UnitTestRules'][0]['RuleCode']['pyExpectedResults'][0]['pyExpectedResults'])==2,kind='MODEL')
schema=json.loads((SRC/'rule-test-unit-case_multInpComb-JsonSchema.txt').read_text())
check('Two-scenario When fixture satisfies unchanged candidate schema',lambda:jsonschema.Draft202012Validator(schema).is_valid(candidate),kind='SCHEMA')
fm=model.FakeMemory();partial=model.author(fm,[when],{'G001':{'reject':('S002',)}})
check('Permitted initial When row rejection yields PartiallyCompleted',lambda:partial['status']=='Completed' and partial['reports'][0]['status']=='PartiallyCompleted' and partial['reports'][0]['groups'][0]['representedScenarioIds']==['S001'],kind='MODEL')
fm=model.FakeMemory();empty=model.author(fm,[when],{'G001':{'reject':('S001','S002')}})
check('Rejecting every row produces no candidate write',lambda:empty['status']=='Failed' and not calls(fm,'WriteMemory','generator-G001'),kind='MODEL')
fm=model.FakeMemory();ir=model.author(fm,[fixture(1,when=True,info=True),fixture(2,when=True)])
check('Informational group completes and next invocation proceeds',lambda:ir['status']=='Completed' and len(calls(fm,'UnitTestGenerator'))==2 and ir['reports'][0]['status']=='Completed',kind='MODEL')
check('Informational Generator acquires only schema',lambda:len(calls(fm,'KnowledgeTool','generator-G001'))==1 and calls(fm,'KnowledgeTool','generator-G001')[0]['args']['KnowledgeAreas']=='Rule-Test-Unit-Case_MultInpComb-JsonSchema',kind='MODEL')
check('Informational Validator skips Knowledge',lambda:not calls(fm,'KnowledgeTool','generator-G001/validator-1'),kind='MODEL')
check('Informational Passed is never a runnable test',lambda:len(ir['selection']['informational'])==len(ir['selection']['executable'])==1,kind='MODEL')

good=run['reports'][0];gargs=calls(mem,'UnitTestGenerator')[0]['args']
for path,value in [(['candidate','UUID'],gargs['ScenarioGroupUUID']),(['candidate','CaseID'],'OTHER'),(['groups',0,'sourceUUID'],'other-source'),(['groups',0,'groupId'],'G999'),(['groups',0,'groupOrder'],2),(['groups',0,'representedScenarioIds'],[]),(['groups',0,'representedScenarioIds'],['FOREIGN']),(['validationAttempts'],0),(['validationAttempts'],2),(['repairAttempts'],3),(['errorMessage'],'unexpected'),(['status'],'Unknown')]:
    bad=change(good,path,value)
    check('Generator rejects report mutation '+str(path)+repr(value),lambda bad=bad:a.generator_report(bad,gargs,source[0]),True)
bad=change(good,['candidate','UUID'],'old-version')
check('Generator rejects stale final pointer',lambda:a.generator_report(bad,gargs,source[0],final_guid=good['candidate']['UUID']),True)
for field in good:
    bad=copy.deepcopy(good);bad.pop(field)
    check('Generator report rejects missing '+field,lambda bad=bad:a.generator_report(bad,gargs,source[0]),True)
bad=dict(good,extra='field')
check('Generator report rejects unknown field',lambda:a.generator_report(bad,gargs,source[0]),True)
bad=change(good,['groups'],good['groups']*2)
check('Generator report rejects two groups',lambda:a.generator_report(bad,gargs,source[0]),True)
bad=change(good,['groups',0,'rejectedScenarios'],[{'scenarioId':'S001','reason':'overlap'}]);bad['status']='PartiallyCompleted'
check('Generator report rejects overlap and partial Standard',lambda:a.generator_report(bad,gargs,source[0]),True)
invalid=model.generator(model.FakeMemory(),{'question':'legacy'},'invalid')
check('Invalid invocation report exact and no invented source',lambda:a.generator_report(invalid,{'question':'legacy'}))

failure=copy.deepcopy(good)
failure.update(status='Failed',candidate=None,errorMessage='PROJECTION_FAILED')
failure['groups'][0].update(representedScenarioIds=[],rejectedScenarios=[])
counter_cases={
    'PROJECTION_FAILED':([(0,0),(1,0),(2,1)],[(1,1),(3,2)]),
    'CANDIDATE_WRITE_FAILED':([(0,0),(1,1),(2,2)],[(1,0),(2,1)]),
    'REPAIR_BUDGET_EXHAUSTED':([(3,2)],[(1,0),(2,1)]),
}
for reason in ('VALIDATOR_RESPONSE_INVALID','LIFECYCLE_UPDATE_FAILED','SEMANTIC_REJECTED','HUMAN_REVIEW_REQUIRED'):
    counter_cases[reason]=([(1,0),(2,1),(3,2)],[(0,0),(1,1)])
for reason,(valid_counts,invalid_counts) in counter_cases.items():
    for counts in valid_counts+invalid_counts:
        value=dict(failure,errorMessage=reason,validationAttempts=counts[0],repairAttempts=counts[1])
        check('Failure counter boundary '+reason+' '+str(counts),lambda value=value:a.generator_report(value,gargs,source[0]),counts in invalid_counts)
for position in (1,2):
    fm=model.FakeMemory()
    out=model.author(fm,source[:2],{'G001':{'routes':('GENERATOR_REPAIR',)*3,'repair_unprojectable_at':position}})
    check('Unprojectable repair stops before next write '+str(position),lambda fm=fm,out=out,position=position:
          out['status']=='Failed' and len(out['reports'])==1
          and out['reports'][0]['errorMessage']=='PROJECTION_FAILED'
          and out['reports'][0]['validationAttempts']==position
          and out['reports'][0]['repairAttempts']==position-1
          and len(calls(fm,'WriteMemory','generator-G001'))==position
          and len(calls(fm,'UpdateMemory','generator-G001'))==position
          and len(calls(fm,'UnitTestGenerator'))==1,kind='MODEL')

vargs={'CaseID':'CASE-1','RUTType':'Rule-Obj-When','UnitTestCandidateUUID':'unit-1'}
vreport={**vargs,'groupId':'G001','route':'OK','blocking':0,'warnings':0,'issues':[]}
for path,value in [(['CaseID'],'OTHER'),(['RUTType'],'Rule-Obj-Model'),(['UnitTestCandidateUUID'],'old'),(['groupId'],'G002'),(['groupId'],None),(['blocking'],1),(['warnings'],1),(['route'],'HUMAN')]:
    bad=change(vreport,path,value)
    check('Validator rejects report mutation '+str(path)+repr(value),lambda bad=bad:a.validator_report(bad,vargs,'G001',candidate),True)
for route in ('GENERATOR_REPAIR','SEMANTIC_REJECT','HUMAN'):
    value={**vreport,'route':route,'blocking':1,'issues':[model.issue(route)]}
    check('Validator accepts route '+route,lambda value=value:a.validator_report(value,vargs,'G001',candidate))
    for path,new in [(['issues',0,'unit'],1),(['issues',0,'action'],'BOGUS'),(['issues',0,'scenario'],999),(['issues',0,'decision'],'UNKNOWN'),(['issues',0,'message'],'x'*241),(['issues',0,'path'],'/UnitTestRules/1'),(['blocking'],2),(['issues'],value['issues']*2)]:
        bad=change(value,path,new)
        check('Validator rejects '+route+' '+str(path),lambda bad=bad:a.validator_report(bad,vargs,'G001',candidate),True)
warning={**vreport,'warnings':1,'issues':[dict(model.issue('GENERATOR_REPAIR'),severity='W')]}
check('Warnings alone do not request repair',lambda:a.validator_report(warning,vargs,'G001',candidate))
bad=dict(warning,route='GENERATOR_REPAIR',blocking=1)
check('Warning cannot fabricate blocking repair',lambda:a.validator_report(bad,vargs,'G001',candidate),True)
pre={**vreport,'groupId':None,'route':'GENERATOR_REPAIR','blocking':1,'issues':[model.issue('GENERATOR_REPAIR',False)]}
check('Pre-read schema failure retains exact UUID and null group',lambda:a.validator_report(pre,vargs,'G001',read_succeeded=False))
bad=change(pre,['issues',0,'code'],'ASSERT_MISSING');bad['issues'][0]['action']='ADD_ASSERTION'
check('Pre-read result cannot invent assertion provenance',lambda:a.validator_report(bad,vargs,'G001'),True)
invalid_val={'CaseID':None,'RUTType':'Rule-Obj-When','UnitTestCandidateUUID':None,'groupId':None,'route':'HUMAN','blocking':1,'warnings':0,'issues':[model.issue('HUMAN')]}
check('Invalid Validator input report uses null identities',lambda:a.validator_report(invalid_val,{'RUTType':'Rule-Obj-When'}))
for raw in ('{"status":"Failed","status":"Completed"}','{"x":NaN}','{bad'):
    check('Duplicate/nonfinite/malformed JSON rejected '+raw,lambda raw=raw:a.loads(raw),True)

for field,value in [('groupOrder',3),('groupId','G001'),('caseId','OTHER'),('rutType','Rule-Obj-When'),('rutClass','Other'),('rutName','Other'),('ruleset','Other'),('caseKey','Other')]:
    bad=copy.deepcopy(source[:2]);bad[1][field]=value
    check('Author global audit rejects '+field,lambda bad=bad:model.audit_sources(bad),True)
bad=[fixture(1,when=True),fixture(2,when=True)];bad[1]['simulationGroupKey']=bad[0]['simulationGroupKey']
check('Author rejects duplicate physical When grouping key',lambda:model.audit_sources(bad),True)
check('Empty complete snapshot rejected',lambda:model.audit_sources([]),True)

row={'pyGroup':'G001','pyGUID':'version-2','pyUpdates':m.lifecycle_updates('OK')}
args=model.batch_args('CASE-1','UnitTestCandidate',[row])
check('Paired current-version lifecycle accepted',lambda:m.lifecycle_request(args,'version-2','G001','OK'))
for changes in ({'pyGUID':'version-1'},{'pyGroup':'G002'},{'pyUpdates':{'pyStatusValue':'Passed'}},{'pyUpdates':{'pyStatusValue':'Failed','pyRouterKey':'OK'}},{'pyUpdates':{'pyPayload':'rewritten'}}):
    bad=model.batch_args('CASE-1','UnitTestCandidate',[dict(row,**changes)])
    check('Lifecycle rejects '+str(changes),lambda bad=bad:m.lifecycle_request(bad,'version-2','G001','OK'),True)

for agent,key in [('Generator','ScenarioGroupUUID'),('Validator','UnitTestCandidateUUID')]:
    check(agent+' rejects string-encoded arguments',lambda agent=agent,key=key:a.input_(agent,json.dumps({'CaseID':'C','RUTType':'R',key:'ID'})),True)

class SourceEnvelopeFault(model.FakeMemory):
    fault='missing'
    def write(self,args,scope):
        response=super().write(args,scope)
        if scope=='author':
            rows=json.loads(response['ResultsJSON'])['pxResults']
            if self.fault=='missing': rows=rows[:-1]
            elif self.fault=='duplicate-guid': rows[1]['pyGUID']=rows[0]['pyGUID']
            elif self.fault=='unknown': rows[0]['pyGroup']='UNKNOWN'
            elif self.fault=='outer':
                return dict(response,Success=False,ErrorCode='FAILED',ErrorMessage='Synthetic outer failure')
            response['ResultsJSON']=model.encoded({'pxResults':rows})
        return response
for fault in ('missing','duplicate-guid','unknown','outer'):
    fm=SourceEnvelopeFault();fm.fault=fault;out=model.author(fm,source)
    check('Unconfirmed source set '+fault+' prevents all Generator calls',lambda fm=fm,out=out:out['status']=='Failed' and not calls(fm,'UnitTestGenerator') and len(fm.records)==3,kind='MODEL')

class ReusedVersion(model.FakeMemory):
    first=None
    def write(self,args,scope):
        response=super().write(args,scope)
        if args['Type']=='UnitTestCandidate':
            rows=json.loads(response['ResultsJSON'])['pxResults']
            if self.first is None: self.first=rows[0]['pyGUID']
            else:
                rows[0]['pyGUID']=self.first
                response['ResultsJSON']=model.encoded({'pxResults':rows})
        return response
fm=ReusedVersion();out=model.author(fm,[fixture()],{'G001':{'routes':('GENERATOR_REPAIR','OK')}})
check('Repair returning prior GUID is rejected before revalidation',lambda:out['status']=='Failed' and out['reports'][0]['errorMessage']=='CANDIDATE_WRITE_FAILED' and len(calls(fm,'UnitTestValidator','generator-G001'))==1,kind='MODEL')

fm=model.FakeMemory();pruned=model.author(fm,[when],{'G001':{'reject':('S001',)}})
pruned_unit=json.loads(fm.records[pruned['reports'][0]['candidate']['UUID']]['pyPayload'])['UnitTestRules'][0]
check('When pruning remaps only local row coordinate and keeps source ID',lambda:pruned['reports'][0]['groups'][0]['representedScenarioIds']==['S002'] and '|row=2|' not in pruned_unit['Scenarios'][0]['EvidenceSummary']['AssertionDecisionTrace'] and '|row=1|' in pruned_unit['Scenarios'][0]['EvidenceSummary']['AssertionDecisionTrace'],kind='MODEL')
check('Pruned When fixture still satisfies unchanged schema',lambda:jsonschema.Draft202012Validator(schema).is_valid({'UnitTestRules':[pruned_unit]}),kind='SCHEMA')
bad_records=copy.deepcopy(mem.records)
bad_records[good['candidate']['UUID']]['pyStatusValue']='Pending'
check('Consumer rejects report success without confirmed Passed state',lambda:a.final_selection(run['reports'],bad_records,True),True)
check('Consumer never automatically selects partial failed run',lambda:a.final_selection(run['reports'],mem.records,False)=={'executable':[],'informational':[]})

# Verify educational traces independently; payload redactions deliberately preclude semantic claims.
for path in sorted((ROOT/'examples').glob('T*.json')):
    trace=json.loads(path.read_text())
    def verify_trace(trace=trace):
        a.require(trace['payloads_redacted'] and trace['evidence_kind']=='SYNTHETIC_ILLUSTRATION_NOT_RUNTIME','trace evidence claim')
        steps={s['step']:s for s in trace['steps']}
        for s in steps.values():
            tool=s.get('tool');args=s.get('arguments')
            if tool in ('WriteMemory','UpdateMemory'):
                m.request(tool,args); response=m.batch_response(tool,args,s['response'])
                a.require(response['trusted'],'illustrative success envelope')
            elif tool=='GetMemory': m.get_response(args,s['response']['pyGroup'],s['response'])
            elif tool=='UnitTestGenerator':
                a.input_('Generator',args)
                ret=steps[s['response_at_step']]
                a.require(ret['returns']=='GeneratorRunReport' and ret['step']>s['step'],'Generator return ordering')
                a.generator_report(ret['value'],args)
            elif tool=='UnitTestValidator':
                a.input_('Validator',args)
                ret=steps[s['response_at_step']]
                a.require(ret['returns']=='ValidatorReport' and ret['step']>s['step'],'Validator return ordering')
                a.validator_report(ret['value'],args)
        return True
    check('Illustrative trace contracts '+path.name,verify_trace,kind='SYNTHETIC_TRACE')

failed=[c for c in checks if c['status']=='FAIL']
print(json.dumps({'status':'PASS_LOCAL_CONTRACTS' if not failed else 'FAIL','checks_total':len(checks),'checks_passed':len(checks)-len(failed),'checks_failed':len(failed),'checks':checks,'failed':failed,'scope':'Actual source/schema checks and synthetic normalized-source sequence models. No Pega, source-wire parser, semantic projection or deployed LLM ran.'},indent=2))
raise SystemExit(bool(failed))
