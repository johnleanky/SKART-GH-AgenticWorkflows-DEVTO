#!/usr/bin/env python3
"""Regenerate v8 local verification reports. Never invokes Pega or deployed LLMs."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
VER=ROOT/'verification'
SRC=ROOT/'sources'
SUITES=[
    ('variant_b',VER/'verify_variant_b_v8.py',[]),
    ('memory_versions',ROOT/'memory_contracts/test_memory_contract.py',[SRC]),
    ('risk001',VER/'verify_risk001_v3.py',[SRC,VER]),
    ('examples',VER/'verify_example_alignment_v4.py',[SRC]),
    ('multinpcomb',VER/'verify_multinpcomb_deep_v3.py',[SRC]),
    ('full_project',VER/'verify_full_project_v8.py',[SRC]),
]
rows=[]
for name,script,args in SUITES:
    p=subprocess.run([sys.executable,'-B',str(script),*map(str,args)],capture_output=True,text=True,cwd=ROOT,
                     env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    try:
        result=json.loads(p.stdout)
        checks=result['checks']
        passed=sum(x['status']=='PASS' for x in checks)
        okay=p.returncode==0 and bool(checks) and passed==len(checks)
    except (ValueError,KeyError,TypeError):
        result={'status':'ERROR','stdout':p.stdout,'stderr':p.stderr}
        checks=[]; passed=0; okay=False
    report='verification/'+name.upper()+'_VERIFICATION_v8.json'
    (ROOT/report).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    row={'suite':name,'status':'PASS' if okay else 'FAIL','checks_total':len(checks),
         'checks_passed':passed,'checks_failed':len(checks)-passed,'exit_code':p.returncode,'report':report}
    if p.stderr: row['stderr']=p.stderr
    rows.append(row)
    print(json.dumps(row))
summary={'status':'PASS_LOCAL_CONTRACTS' if all(r['status']=='PASS' for r in rows) else 'FAIL',
         'scope':'Source/schema/fixture checks and explicitly synthetic contract/sequence models; no Pega, deployed LLM, real source-wire semantic projection or runtime isolation certification.',
         'checks_total':sum(r['checks_total'] for r in rows),'checks_passed':sum(r['checks_passed'] for r in rows),
         'checks_failed':sum(r['checks_failed'] for r in rows),'suites':rows,
         'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SRC.glob('*.txt'))},
         'python_version':sys.version.split()[0],'runtime_validation':'NOT_EXECUTED'}
(VER/'VERIFICATION_SUMMARY_v8.json').write_text(json.dumps(summary,indent=2)+'\n')
raise SystemExit(summary['status']!='PASS_LOCAL_CONTRACTS')
