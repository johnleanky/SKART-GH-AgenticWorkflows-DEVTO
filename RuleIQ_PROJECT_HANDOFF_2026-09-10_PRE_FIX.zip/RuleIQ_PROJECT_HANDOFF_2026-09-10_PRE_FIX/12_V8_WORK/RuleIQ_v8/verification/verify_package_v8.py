"""Read-only, portable v8 package integrity and evidence checks (stdlib only)."""
from pathlib import Path
import argparse
import hashlib
import html
import json
import re
from urllib.parse import unquote
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = 'PACKAGE_MANIFEST_SHA256.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root):
    return {p.relative_to(root).as_posix(): p for p in root.rglob('*')
            if p.is_file() and '__pycache__' not in p.parts
            and p.name not in ('.DS_Store', MANIFEST)}


def verify(governance=False):
    checks = []

    def read(path):
        return json.loads((ROOT / path).read_text())

    def check(name, predicate):
        detail = ''
        try:
            okay = bool(predicate())
        except Exception as error:
            okay = False
            detail = type(error).__name__ + ': ' + str(error)
        checks.append({'check': name, 'status': 'PASS' if okay else 'FAIL', 'detail': detail})

    # Required metadata failure is still reported as a nonzero verification result.
    try:
        state = read('CURRENT_STATE.json')
        summary = read('verification/VERIFICATION_SUMMARY_v8.json')
        manifest = read('SOURCE_MANIFEST_v8.json')
        receipt = read('verification/SOURCE_BUILD_RECEIPT.json')
        register = read('CHANGE_REGISTER_v8.json')
        hashes = {p.name: sha(p) for p in sorted((ROOT / 'sources').glob('*.txt'))}
        check('Twenty sources match manifest and suite evidence', lambda:
              len(hashes) == manifest['source_count'] == state['source_count'] == 20
              and hashes == summary['source_sha256']
              == {x['name']: x['sha256'] for x in manifest['sources']}
              and len(manifest['sources']) == 20
              and all((ROOT / 'sources' / x['name']).stat().st_size == x['bytes']
                      for x in manifest['sources']))
        changed = {x['file'] for x in receipt['sources'] if x['changed']}
        check('Only three prompts and two embedded configurations changed', lambda:
              changed == {'Main_Agent_Prompt.txt', 'UnitTestGenerator_Prompt.txt',
                          'Validator_Prompt.txt', 'UnitTestGenerator.txt', 'JsonValidator_tool.txt'}
              and hashes == {x['file']: x['sha256'] for x in receipt['sources']})
        check('Fifteen baseline sources retained byte for byte', lambda:
              len(receipt['sources']) == 20 and all(
                  x['changed'] == (x['sha256'] != x['baseline_sha256']) for x in receipt['sources']))
        baseline = ROOT.parent.parent / '11_V7_WORK' / 'RuleIQ_v7' / 'sources'
        if baseline.is_dir():
            check('Available v7 baseline agrees with every pinned original hash', lambda:
                  all(sha(baseline / x['file']) == x['baseline_sha256'] for x in receipt['sources']))
        check('Four interface schemas match pinned inventory', lambda:
              {x['path']: x['sha256'] for x in manifest['agent_contract_schemas']}
              == {p.relative_to(ROOT).as_posix(): sha(p)
                  for p in (ROOT / 'agent_contracts').glob('*.schema.json')}
              and len(manifest['agent_contract_schemas']) == 4)
        check('Exact scalar input interfaces', lambda: all(
            set(read('agent_contracts/' + agent + 'Input.schema.json')['required']) == set(fields)
            and set(read('agent_contracts/' + agent + 'Input.schema.json')['properties']) == set(fields)
            and read('agent_contracts/' + agent + 'Input.schema.json')['additionalProperties'] is False
            for agent, fields in [('Generator', state['generator_input']), ('Validator', state['validator_input'])]))
        check('All six expected regression suites are represented', lambda:
              {x['suite'] for x in summary['suites']} ==
              {'variant_b', 'memory_versions', 'risk001', 'examples', 'multinpcomb', 'full_project'}
              and len(summary['suites']) == 6)
        passed = set()
        for suite in summary['suites']:
            rows = read(suite['report'])['checks']
            passed.update(x['check'] for x in rows if x['status'] == 'PASS')
            check('Passing evidence: ' + suite['suite'], lambda suite=suite, rows=rows:
                  suite['status'] == 'PASS' and suite['exit_code'] == suite['checks_failed'] == 0
                  and suite['checks_total'] == suite['checks_passed'] == len(rows) > 0
                  and all(x['status'] == 'PASS' for x in rows))
        check('Summary, state and actual check counts agree', lambda:
              summary['status'] == 'PASS_LOCAL_CONTRACTS'
              and summary['checks_total'] == summary['checks_passed']
              == state['checks_total'] == state['checks_passed']
              == sum(s['checks_total'] for s in summary['suites'])
              and state['checks_failed'] == summary['checks_failed'] == 0)
        check('Twelve changes point to actual passing checks', lambda:
              len(register['changes']) == 12 and len({r['id'] for r in register['changes']}) == 12
              and all(r['status'] == 'VERIFIED_LOCAL_CONTRACT' and r['runtime_status'] == 'NOT_EXECUTED'
                      and r['evidence'] and all(e in passed for e in r['evidence'])
                      for r in register['changes']))
        check('Version and runtime boundary are explicit', lambda:
              state['version'] == 'v8' and state['variant'] == 'B'
              and state['memory_contract'] == state['specification'] == 'v3'
              and state['wire_revision'] == '1.4'
              and state['runtime_validation'] == summary['runtime_validation'] == 'NOT_EXECUTED'
              and state['working_scope'] == 'PROMPTS_CONTRACTS_SPECIFICATIONS_AND_LOCAL_VERIFICATION'
              and state['external_implementation_changes'] is False and state['github'] == 'NO_WRITES')
        pins = read('memory_contracts/SOURCE_AUTHORITY.json')['sources']
        check('Memory source authority hashes and line anchors match', lambda:
              len(pins) == 3 and all(p['sha256'] == hashes[p['file']]
                  and all(a['line'] > 0 and a['text'] in
                          (ROOT / 'sources' / p['file']).read_text().splitlines()[a['line'] - 1]
                          for a in p['anchors']) for p in pins))
        audit = read('verification/CONFLICT_AUDIT_v8.json')
        check('Conflict audit hashes and classified lines match current prompts', lambda:
              audit['source_sha256'] == hashes and bool(audit['classified_occurrences'])
              and all(a['sha256'] == hashes[a['file']] and a['line'] > 0
                      and a['text'] == (ROOT / 'sources' / a['file']).read_text().splitlines()[a['line'] - 1]
                      for a in audit['classified_occurrences']))
        for config, prompt in [('UnitTestGenerator.txt', 'UnitTestGenerator_Prompt.txt'),
                               ('JsonValidator_tool.txt', 'Validator_Prompt.txt')]:
            def parity(config=config, prompt=prompt):
                text = (ROOT / 'sources' / config).read_text()
                ET.fromstring(text)
                markup = re.search(r'<pySystemPrompt>(.*?)</pySystemPrompt>', text, re.S)[1]
                decoded = '\n'.join(html.unescape(s) for s in re.findall(r'<p>(.*?)</p>', markup, re.S))
                return decoded == (ROOT / 'sources' / prompt).read_text().rstrip('\n')
            check('XML parses and exact prompt parity: ' + config, parity)
        spec = (ROOT / 'specification/PEGA_IMPLEMENTATION_SPEC_v3.md').read_text()
        work_items = set(re.findall(r'^\| (PI-\d+) \|', spec, re.M))
        check('Twelve Pega work items are specified', lambda:
              work_items == {f'PI-{i:02}' for i in range(1, 13)})
        for directory, count in [('specification', 31), ('memory_contracts', 20)]:
            cases = read(directory + '/ACCEPTANCE_CASES.json')
            check('External acceptance remains unexecuted: ' + directory, lambda cases=cases, count=count:
                  cases['case_count'] == len(cases['cases']) == count and cases['executed'] == 0
                  and len({x['id'] for x in cases['cases']}) == count
                  and all(x['status'] == 'NOT_RUN_EXTERNAL' and x['evidence_required'] for x in cases['cases']))
            if directory == 'specification':
                check('Pega acceptance work-item references resolve', lambda cases=cases:
                      all(x['work_item'] in work_items for x in cases['cases']))

        def document_json():
            for p in ROOT.rglob('*.json'):
                json.loads(p.read_text())
            for p in ROOT.rglob('*.md'):
                for example in re.findall(r'```json\n(.*?)\n```', p.read_text(), re.S):
                    json.loads(example)
            return True
        check('All JSON files and Markdown JSON examples parse', document_json)

        def local_links():
            for path in ROOT.rglob('*.md'):
                for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', path.read_text()):
                    if target.startswith(('http:', 'https:', '#')):
                        continue
                    dest = unquote(target.split('#', 1)[0].strip('<>'))
                    if dest and not (path.parent / dest).exists():
                        raise ValueError(path.relative_to(ROOT).as_posix() + ': ' + target)
            return True
        check('All local Markdown links resolve', local_links)
        check('No symlinks in delivered package', lambda: not any(p.is_symlink() for p in ROOT.rglob('*')))
        if not governance:
            package = read(MANIFEST)
            tracked = {x['path']: x for x in package['files']}
            actual = inventory(ROOT)
            check('Exact package inventory', lambda:
                  package['version'] == 'v8' and set(tracked) == set(actual)
                  and package['file_count'] == len(tracked) == len(package['files']))
            check('Every package hash and byte count matches', lambda:
                  all(name in actual and sha(actual[name]) == row['sha256']
                      and actual[name].stat().st_size == row['bytes'] for name, row in tracked.items()))
    except Exception as error:
        checks.append({'check': 'Required package metadata', 'status': 'FAIL',
                       'detail': type(error).__name__ + ': ' + str(error)})
    failed = [x for x in checks if x['status'] == 'FAIL']
    return {'status': 'PASS' if not failed else 'FAIL', 'checks_total': len(checks),
            'checks_passed': len(checks) - len(failed), 'checks_failed': len(failed),
            'checks': checks, 'failed': failed,
            'scope': 'Read-only local integrity and evidence consistency; no Pega runtime validation.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--governance', action='store_true', help='Check evidence before creating package inventory.')
    result = verify(parser.parse_args().governance)
    print(json.dumps(result, indent=2))
    raise SystemExit(result['status'] != 'PASS')
