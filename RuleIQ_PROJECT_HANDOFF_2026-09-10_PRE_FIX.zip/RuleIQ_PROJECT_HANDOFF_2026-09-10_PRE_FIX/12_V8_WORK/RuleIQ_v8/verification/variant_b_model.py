"""SYNTHETIC TEST MODEL, not Memory/Pega/LLM implementation.

Tests normalize frozen-source metadata into dictionaries and supply a prebuilt candidate
fixture in place of LLM projection. They do not parse ScenarioGroup 1.4 or prove semantic
generation. The model executes observable interface sequencing and fault handling only.
"""
from pathlib import Path
import copy
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'agent_contracts'))
sys.path.insert(0, str(ROOT/'memory_contracts'))
import contracts as a
import memory_contract as m

def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def batch_args(case, type_, rows):
    return {'pxCaseID':case, 'Type':type_, 'RequestsJSON':encoded({'pxResults':rows})}

def envelope(rows):
    return {'Success':True,'ResultsJSON':encoded({'pxResults':rows}),'ErrorCode':'','ErrorMessage':''}

class FakeMemory:
    """In-memory fault-injection double; no persistence or network capability."""
    def __init__(self):
        self.records = {}
        self.events = []
        self.failed_sources = set()
        self.fail_write_scopes = set()
        self.fail_update_scopes = set()
        self.read_faults = set()
        self.lost_write_scopes = set()
        self.lost_update_scopes = set()
        self.serial = 0

    def write(self, args, scope):
        rows = m.request('WriteMemory',args)
        self.events.append({'scope':scope,'tool':'WriteMemory','args':copy.deepcopy(args)})
        result=[]
        for row in rows:
            if scope in self.fail_write_scopes or (args['Type']=='ScenarioGroup' and row['pyGroup'] in self.failed_sources):
                result.append({'pyGroup':row['pyGroup'],'pyGUID':'','Success':False,'ErrorCode':'WRITE_FAILED','ErrorMessage':'Synthetic failure'})
                continue
            self.serial+=1
            guid='synthetic-guid-'+str(self.serial)
            record={'pxCaseID':args['pxCaseID'],'Type':args['Type'],'pyGUID':guid,**copy.deepcopy(row)}
            if args['Type']=='UnitTestCandidate':
                record.update(pyStatusValue='Pending',pyRouterKey='')
                m.created_candidate(args,row,record,guid,self.records)
            self.records[guid]=record
            result.append({'pyGroup':row['pyGroup'],'pyGUID':guid,'Success':True,'ErrorCode':'','ErrorMessage':''})
        if scope in self.lost_write_scopes:
            raise OSError('Synthetic response lost after commit')
        # Deliberately reverse row order to exercise identity-based correlation.
        return envelope(list(reversed(result)))

    def get(self, args, scope):
        m.request('GetMemory',args)
        self.events.append({'scope':scope,'tool':'GetMemory','args':copy.deepcopy(args)})
        record=self.records.get(args['pyGUID'])
        if scope in self.read_faults or record is None or any(record[k]!=args[k] for k in ('pxCaseID','Type')):
            return {'Success':False,'pxCaseID':args['pxCaseID'],'Type':args['Type'],'pyGroup':'','pyGUID':args['pyGUID'],'pyPayload':'','ErrorCode':'READ_FAILED','ErrorMessage':'Synthetic read failure'}
        return {k:record[k] for k in ('pxCaseID','Type','pyGroup','pyGUID','pyPayload')} | {'Success':True,'ErrorCode':'','ErrorMessage':''}

    def update(self, args, scope):
        rows=m.request('UpdateMemory',args)
        self.events.append({'scope':scope,'tool':'UpdateMemory','args':copy.deepcopy(args)})
        result=[]
        for row in rows:
            old=self.records.get(row['pyGUID'])
            failed=scope in self.fail_update_scopes or old is None or any(old[k]!=args[k] for k in ('pxCaseID','Type')) or old['pyGroup']!=row['pyGroup']
            if not failed:
                after=old | row['pyUpdates']
                m.patched_candidate(args,row,old,after)
                self.records[row['pyGUID']]=after
            result.append({'pyGroup':row['pyGroup'],'pyGUID':row['pyGUID'],'Success':not failed,
                           'ErrorCode':'UPDATE_FAILED' if failed else '', 'ErrorMessage':'Synthetic update failure' if failed else ''})
        if scope in self.lost_update_scopes:
            raise OSError('Synthetic response lost after update commit')
        return envelope(result)

def knowledge_keys(rut_type, info=False):
    base='Rule-Test-Unit-Case_MultInpComb-' if rut_type=='Rule-Obj-When' else 'Rule-Test-Unit-Case_'
    return [base+x for x in (['JsonSchema'] if info else ['KnowledgeArea','JsonSchema','JsonExample'])]

def issue(route, read=True):
    code,action={'GENERATOR_REPAIR':('ASSERT_MISSING','ADD_ASSERTION') if read else ('JSON_SCHEMA_INVALID','FIX_JSON'),
                 'SEMANTIC_REJECT':('REASONING_CONTRADICTION','REJECT_SEMANTICS'),
                 'HUMAN':('AMBIGUOUS','HUMAN_REVIEW')}[route]
    return {'severity':'B','code':code,'action':action,'unit':0,'scenario':None,'decision':None,'path':'/','message':'Synthetic diagnostic'}

def validation(mem, args, scope, route='OK', schema_valid=True):
    a.input_('Validator',args)
    key=knowledge_keys(args['RUTType'],True)[0]
    mem.events.append({'scope':scope,'tool':'JsonValidationTool','args':{'CaseID':args['CaseID'],'UUID':args['UnitTestCandidateUUID'],'JsonSchema':key}})
    report={**args,'groupId':None,'route':'GENERATOR_REPAIR','blocking':1,'warnings':0,'issues':[issue('GENERATOR_REPAIR',False)]}
    if not schema_valid:
        return report
    read={'pxCaseID':args['CaseID'],'Type':'UnitTestCandidate','pyGUID':args['UnitTestCandidateUUID']}
    raw=mem.get(read,scope)
    payload=m.get_response(read,None,raw)
    if payload is None:
        report.update(route='HUMAN',issues=[dict(issue('HUMAN'),code='MEMORY_READ_TOOL_ERROR')])
        return report
    candidate=a.loads(payload)
    report['groupId']=raw['pyGroup']
    if 'RuleCode' in candidate['UnitTestRules'][0]:
        mem.events.append({'scope':scope,'tool':'KnowledgeTool','args':{'KnowledgeAreas':','.join(knowledge_keys(args['RUTType']))}})
    report.update(route=route,blocking=int(route!='OK'),issues=[] if route=='OK' else [issue(route)])
    a.validator_report(report,args,raw['pyGroup'],candidate,True)
    return report

def generator(mem, args, scope, routes=('OK',), knowledge_ok=True, reject=(), invalid_report=False, schema_invalid_attempts=(), repair_unprojectable_at=None):
    """One fresh call frame. Source payloads here are normalized MODEL fixtures, not SG wire."""
    report={'status':'Failed','candidate':None,'groups':[], 'validationAttempts':0,'repairAttempts':0,'errorMessage':'INVALID_INPUT'}
    try:
        a.input_('Generator',args)
    except a.ContractError:
        return report
    group={'sourceUUID':args['ScenarioGroupUUID'],'groupId':None,'groupOrder':None,'representedScenarioIds':[],'rejectedScenarios':[]}
    report['groups']=[group]
    reason='SOURCE_READ_FAILED'
    try:
        read={'pxCaseID':args['CaseID'],'Type':'ScenarioGroup','pyGUID':args['ScenarioGroupUUID']}
        raw=mem.get(read,scope)
        payload=m.get_response(read,None,raw)
        m.require(payload is not None,'source read failed')
        reason='SOURCE_INVALID'
        source=a.loads(payload)
        a.require(source['caseId']==args['CaseID'] and source['rutType']==args['RUTType'] and source['groupId']==raw['pyGroup'],'source identity')
        a.require(source['sourceValid'] and source['groupOrder']>0 and len(source['scenarioIds'])==len(set(source['scenarioIds'])),'normalized source gate')
        group.update(groupId=source['groupId'],groupOrder=source['groupOrder'])
        reason='KNOWLEDGE_FAILED'
        mem.events.append({'scope':scope,'tool':'KnowledgeTool','args':{'KnowledgeAreas':','.join(knowledge_keys(args['RUTType'],source['mode']=='INFORMATIONAL_NOT_TESTABLE'))}})
        a.require(knowledge_ok,'synthetic knowledge missing')
        reason='PROJECTION_FAILED'
        a.require(set(reject)<=set(source['scenarioIds']),'foreign rejected Scenario')
        a.require(not reject or (source['rutType']=='Rule-Obj-When' and source['mode']=='EXECUTABLE'),'row pruning outside When')
        kept=[s for s in source['scenarioIds'] if s not in reject]
        reason='NO_REPRESENTABLE_SCENARIO'
        a.require(bool(kept),'no represented Scenario')
        projected=copy.deepcopy(source['candidateFixture'])
        indices=[source['scenarioIds'].index(s) for s in kept]
        unit=projected['UnitTestRules'][0]
        unit['Scenarios']=[unit['Scenarios'][i] for i in indices]
        if reject:
            decision=unit['RuleCode']['pyExpectedResults'][0]
            decision['pyExpectedResults']=[decision['pyExpectedResults'][i] for i in indices]
            for position,scenario in enumerate(unit['Scenarios'],1):
                scenario['EvidenceSummary']['AssertionDecisionTrace']=re.sub(r'\|row=\d+\|',f'|row={position}|',scenario['EvidenceSummary']['AssertionDecisionTrace'])
        versions=[]
        for attempt in range(3):
            if attempt:
                reason='PROJECTION_FAILED'
                a.require(attempt != repair_unprojectable_at, 'synthetic mechanical projection unavailable')
                report['repairAttempts']+=1
            reason='CANDIDATE_WRITE_FAILED'
            # Projection is supplied by fixtures; mechanical versions differ in formatting only.
            candidate_payload=json.dumps(projected,indent=2 if attempt==0 else 4,ensure_ascii=False)
            write=batch_args(args['CaseID'],'UnitTestCandidate',[{'pyGroup':source['groupId'],'pyPayload':candidate_payload}])
            result=m.batch_response('WriteMemory',write,mem.write(write,scope))
            a.require(result['trusted'] and result['results'][source['groupId']]['Success'],'candidate write failed')
            guid=result['results'][source['groupId']]['pyGUID']
            a.require(guid not in [args['ScenarioGroupUUID'],*versions],'reused version GUID')
            versions.append(guid)
            reason='VALIDATOR_RESPONSE_INVALID'
            val_args={'CaseID':args['CaseID'],'RUTType':args['RUTType'],'UnitTestCandidateUUID':guid}
            mem.events.append({'scope':scope,'tool':'UnitTestValidator','args':dict(val_args)})
            report['validationAttempts']+=1
            response=validation(mem,val_args,scope+'/validator-'+str(attempt+1),routes[min(attempt,len(routes)-1)],attempt not in schema_invalid_attempts)
            if invalid_report:
                response['blocking']+=1
            response=a.validator_report(response,val_args,source['groupId'],projected)
            reason='LIFECYCLE_UPDATE_FAILED'
            route=response['route']
            update=batch_args(args['CaseID'],'UnitTestCandidate',[{'pyGroup':source['groupId'],'pyGUID':guid,'pyUpdates':m.lifecycle_updates(route)}])
            m.lifecycle_request(update,guid,source['groupId'],route)
            updated=m.batch_response('UpdateMemory',update,mem.update(update,scope))
            a.require(updated['trusted'] and updated['results'][(source['groupId'],guid)]['Success'],'unconfirmed lifecycle')
            if route=='OK':
                report.update(status='PartiallyCompleted' if reject else 'Completed',candidate={'CaseID':args['CaseID'],'Type':'UnitTestCandidate','UUID':guid},errorMessage='')
                group.update(representedScenarioIds=kept,rejectedScenarios=[{'scenarioId':s,'reason':'Synthetic initial row-only schema incompatibility'} for s in source['scenarioIds'] if s in reject])
                a.generator_report(report,args,source,versions[:-1],guid,projected)
                return report
            if route in ('HUMAN','SEMANTIC_REJECT'):
                reason='HUMAN_REVIEW_REQUIRED' if route=='HUMAN' else 'SEMANTIC_REJECTED'
                break
            reason='REPAIR_BUDGET_EXHAUSTED'
    except (a.ContractError,m.ContractError,OSError,ValueError,KeyError,TypeError):
        pass
    report['errorMessage']=reason
    return report

def audit_sources(sources):
    a.require(bool(sources),'empty source set')
    a.require([s['groupOrder'] for s in sources]==list(range(1,len(sources)+1)), 'noncontiguous group order')
    a.require(len({s['groupId'] for s in sources})==len(sources),'duplicate groups')
    for field in ('caseId','rutType','rutClass','rutName','ruleset','caseKey'):
        a.require(len({s[field] for s in sources})==1,'cross-group identity mismatch')
    keys=[]
    for s in sources:
        a.require(s['scenarioIds'] and len(s['scenarioIds'])==len(set(s['scenarioIds'])),'local Scenario census')
        a.require(s['mode'] in ('EXECUTABLE','INFORMATIONAL_NOT_TESTABLE'),'execution mode')
        if s['rutType']=='Rule-Obj-When':
            key=(s['simulationGroupKey'],s['mode'])
            a.require(key not in keys,'duplicate physical When group')
            keys.append(key)
        else:
            a.require(len(s['scenarioIds'])==1,'standard group cardinality')
    return True

def author(mem,sources,behaviors=None):
    """Models a guarded Author run with strict all-source gate and sequential fresh call frames."""
    reports=[]; behaviors=behaviors or {}
    try:
        audit_sources(sources)
        case=sources[0]['caseId']; rut=sources[0]['rutType']
        write=batch_args(case,'ScenarioGroup',[{'pyGroup':s['groupId'],'pyPayload':encoded(s)} for s in sources])
        mapping=m.all_sources_confirmed(write,mem.write(write,'author'))
        source_guids=set(mapping.values())
        for source in sources:
            args={'CaseID':case,'RUTType':rut,'ScenarioGroupUUID':mapping[source['groupId']]}
            scope='generator-'+source['groupId']
            mem.events.append({'scope':'author','tool':'UnitTestGenerator','args':dict(args)})
            report=generator(mem,args,scope,**behaviors.get(source['groupId'],{}))
            a.generator_report(report,args,source,source_guids | {r['candidate']['UUID'] for r in reports})
            reports.append(report)
            if report['status']=='Failed':
                return {'status':'Failed','reports':reports,'selection':a.final_selection(reports,mem.records,False)}
        return {'status':'Completed','reports':reports,'selection':a.final_selection(reports,mem.records,True)}
    except (a.ContractError,m.ContractError,OSError,ValueError,KeyError):
        return {'status':'Failed','reports':reports,'selection':a.final_selection(reports,mem.records,False)}
