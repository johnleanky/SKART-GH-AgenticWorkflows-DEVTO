"""Executable LOCAL MODEL of documented contracts, not a Pega/LLM runtime.

Kept independent of the apply script. Real schema fixtures are validated against
the shipped schemas by verify_full_project_v8.py. Model-only evidence is labelled.
"""
import json
from decimal import Decimal


def loads(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('duplicate JSON key')
            result[key] = value
        return result
    return json.loads(text, parse_int=Decimal, parse_float=Decimal,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)),
                      object_pairs_hook=unique)


def canonical(value):
    if value is None:
        return 'null'
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, str):
        if any(0xD800 <= ord(c) <= 0xDFFF for c in value):
            raise ValueError('unpaired Unicode surrogate')
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (int, Decimal)):
        dec = Decimal(value)
        if not dec.is_finite():
            raise ValueError('non-finite number')
        if dec == 0:
            return '0'
        result = format(dec, 'f')
        return result.rstrip('0').rstrip('.') if '.' in result else result
    if isinstance(value, list):
        return '[' + ','.join(canonical(item) for item in value) + ']'
    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        return '{' + ','.join(canonical(key)+':'+canonical(value[key])
                              for key in sorted(value)) + '}'
    raise ValueError('unsupported/binary-float JSON value')


def typed(kind, value):
    checks = {
        'string': isinstance(value, str), 'boolean': isinstance(value, bool),
        'number': isinstance(value, (int, Decimal)) and not isinstance(value, bool),
        'null': value is None, 'empty': value == '' and isinstance(value, str),
        'json': isinstance(value, (dict, list)), 'absent': value is None,
    }
    if not checks.get(kind, False):
        raise ValueError('invalid typed value')
    result = {'valueType': kind, 'value': value}
    canonical(result)
    return result


def signature(key, params):
    parts = key.split('@', 2)
    if len(parts) != 3 or parts[0] != 'DP' or not all(parts[1:]):
        raise ValueError('invalid DP key')
    for name, item in params.items():
        if not name or set(item) != {'valueType', 'value'}:
            raise ValueError('invalid parameter')
        typed(item['valueType'], item['value'])
        if item['valueType'] == 'absent':
            raise ValueError('effective map excludes optional omission')
    return canonical({'key': key, 'params': params})


def validate_signature(text, rule, params):
    obj = loads(text)
    if set(obj) != {'key', 'params'} or canonical(obj) != text:
        raise ValueError('invalid canonical signature')
    if obj['key'].split('@', 2)[-1] != rule:
        raise ValueError('rule mismatch')
    if signature(obj['key'], params) != text:
        raise ValueError('signature parameter mismatch')
    return True


def identity_gate(case):
    rule = case.get('RuleJSON', {})
    required = [case.get('pyID'), case.get('TestedRuleKey')]
    required += [rule.get(k) for k in ('pzInsKey','pxObjClass','pyClassName','pyRuleName')]
    if any(not isinstance(value, str) or not value.strip() for value in required):
        return False
    triplet = [rule[k].upper() for k in ('pxObjClass','pyClassName','pyRuleName')]
    return all(text.split()[:3] == triplet for text in
               (case['TestedRuleKey'], rule['pzInsKey']))


def dependency(kind, identity, authoritative_keys):
    if kind == 'NOT_APPLICABLE':
        return identity == 'NOT_APPLICABLE'
    parts = identity.split('@', 2)
    return (kind not in ('DT', 'HELPER') and len(parts) == 3 and
            parts[0] == kind and bool(parts[2]) and
            (parts[1] == '' if kind == 'RUF' else bool(parts[1])) and
            identity in authoritative_keys)


def request_plan(rows):
    ready = [row for row in rows if row['state'] == 'READY']
    if len({row['id'] for row in rows}) != len(rows):
        raise ValueError('duplicate occurrence')
    out = list(dict.fromkeys(row['key'] for row in ready))
    return {'SCAN': [row['id'] for row in ready], 'OUT': out,
            'occurrences': {key: [row['id'] for row in ready if row['key'] == key]
                            for key in out}, 'physical_count': len(out)}


def group_key(scenario):
    if scenario['mode'] == 'INFORMATIONAL_NOT_TESTABLE':
        if scenario['assertions'] or scenario['simulations']:
            raise ValueError('informational executable decisions')
        return canonical({'informationalScenario': scenario['id']})
    if not scenario['simulations']:
        if scenario['required_simulation']:
            raise ValueError('missing simulation')
        return 'NO_SIMULATION'
    return canonical({'simulations': scenario['simulations']})


def storage_gate(scenario):
    if any(scenario['work'].get(k, 0) for k in ('open','ready','ctx','unscanned')):
        return False
    if scenario['mode'] == 'INFORMATIONAL_NOT_TESTABLE':
        return (scenario['assertions'] == scenario['simulations'] == [] and
                bool(scenario['omits']) and bool(scenario['gaps']) and
                scenario['confidence'] == 'Low' and scenario['closure'] == 'Blocked' and
                scenario['terminal_proof'])
    return (bool(scenario['assertions']) and
            (not scenario['required_simulation'] or
             (bool(scenario['simulations']) and scenario['dpa_pass'])))


def knowledge_keys(when, modes):
    prefix = 'Rule-Test-Unit-Case' + ('_MultInpComb-' if when else '_')
    suffixes = ('KnowledgeArea','JsonSchema','JsonExample') if 'EXECUTABLE' in modes else ('JsonSchema',)
    return [prefix+suffix for suffix in suffixes]


def affected_by_missing_knowledge(groups, missing):
    return [group['id'] for group in groups
            if set(knowledge_keys(group['when'], [group['mode']])) & set(missing)]


def validator_one(candidate, schema_valid, knowledge_available=True):
    """Synthetic single-candidate Validator phase model, never a deployed agent."""
    events = ['schema']
    if not schema_valid(candidate):
        return 'GENERATOR_REPAIR', events
    events.append('memory')
    unit = candidate['UnitTestRules'][0]
    if 'RuleCode' not in unit:
        valid = all(s['EvidenceSummary']['OmittedClaimCount'] ==
                    len(s['EvidenceSummary']['AssertionDecisionTrace'].splitlines())
                    for s in unit['Scenarios'])
        return ('OK' if valid else 'SEMANTIC_REJECT'), events
    events.append('knowledge-required')
    return ('OK' if knowledge_available else 'HUMAN'), events


def lifecycle(routes, update_ok=True):
    """One group's per-version lifecycle; names are synthetic model statuses."""
    updates = []
    for attempt, route in enumerate(routes[:3], 1):
        if route is None:
            return {'result':'VALIDATOR_RESPONSE_INVALID','status':'Pending',
                    'attempts':attempt,'updates':updates}
        updates.append((attempt, 'Passed' if route == 'OK' else 'Failed', route))
        if not update_ok:
            return {'result':'LIFECYCLE_UPDATE_FAILED','status':'UNCONFIRMED',
                    'attempts':attempt,'updates':updates}
        if route == 'OK' or route in ('HUMAN','SEMANTIC_REJECT'):
            return {'result':route,'status':'Passed' if route=='OK' else 'Failed',
                    'attempts':attempt,'updates':updates}
    return {'result':'REPAIR_EXHAUSTED','status':'Failed',
            'attempts':min(len(routes),3),'updates':updates}


def presence(initial, effects):
    state = initial
    for effect in effects:
        if effect == 'materialize': state = 'PRESENT'
        elif effect == 'remove': state = 'ABSENT'
        elif effect == 'unknown': state = 'UNKNOWN'
        elif effect != 'skip': raise ValueError(effect)
    return state


def append_and_map(target_items, source_page, mappings, target_class):
    item = {'pxObjClass': target_class}
    for target_leaf, source_leaf in mappings:
        item[target_leaf] = source_page[source_leaf]
    return [*target_items, item]
