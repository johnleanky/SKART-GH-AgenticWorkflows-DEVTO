# Variant B tool-call walkthroughs

These are synthetic protocol illustrations, not observed Pega/LLM executions. GUIDs are
fictional. JSON files contain exact argument/response shapes, but large payloads/Knowledge
are explicitly redacted; markers are not valid ScenarioGroup wire or deployable candidates.
Agent calls refer to the later step where their return arrives. Return steps are not tools.

All source groups are written and their complete unique ordered mapping audited before
the first Generator call. Every Generator gets a fresh context and acquires its own
Knowledge. Initial writes and repairs contain only pyGroup/pyPayload; a separate UpdateMemory
sets lifecycle on that exact version. Every repair uses a new GUID. The case guard spans
source persistence, invocation sequence and final selection.

T01 shows two normal groups producing two candidates. T02 shows two When scenarios inside
one group producing one candidate with two Decision rows. T03 records Failed/GENERATOR_REPAIR
on V1, then writes/validates V2 with another GUID. T04 stops after G002 failure: G003 was
persisted as a source but never generated; G001's Passed candidate remains stored and no
partial automatic test creation starts.

## T01 TWO STANDARD GROUPS

[Complete call/response JSON](T01_TWO_STANDARD_GROUPS.json)

| Step | Actor | Operation | Address / outcome |
|---|---|---|---|
| 1 | Author | WriteMemory | ScenarioGroup: G001 → SG-DEMO-G001, G002 → SG-DEMO-G002 |
| 2 | Author | UnitTestGenerator | SG-DEMO-G001 |
| 3 | Generator G001 | GetMemory | SG-DEMO-G001 |
| 4 | Generator G001 | KnowledgeTool | structural keys |
| 5 | Generator G001 | WriteMemory | UnitTestCandidate: G001 → UTC-DEMO-G001-V1 |
| 6 | Generator G001 | UnitTestValidator | UTC-DEMO-G001-V1 |
| 7 | Validator UTC-DEMO-G001-V1 | JsonValidationTool | UTC-DEMO-G001-V1 |
| 8 | Validator UTC-DEMO-G001-V1 | GetMemory | UTC-DEMO-G001-V1 |
| 9 | Validator UTC-DEMO-G001-V1 | KnowledgeTool | structural keys |
| 10 | Validator UTC-DEMO-G001-V1 | return ValidatorReport | OK |
| 11 | Generator G001 | UpdateMemory | UTC-DEMO-G001-V1 → Passed/OK |
| 12 | Generator G001 | return GeneratorRunReport | Completed |
| 13 | Author | UnitTestGenerator | SG-DEMO-G002 |
| 14 | Generator G002 | GetMemory | SG-DEMO-G002 |
| 15 | Generator G002 | KnowledgeTool | structural keys |
| 16 | Generator G002 | WriteMemory | UnitTestCandidate: G002 → UTC-DEMO-G002-V1 |
| 17 | Generator G002 | UnitTestValidator | UTC-DEMO-G002-V1 |
| 18 | Validator UTC-DEMO-G002-V1 | JsonValidationTool | UTC-DEMO-G002-V1 |
| 19 | Validator UTC-DEMO-G002-V1 | GetMemory | UTC-DEMO-G002-V1 |
| 20 | Validator UTC-DEMO-G002-V1 | KnowledgeTool | structural keys |
| 21 | Validator UTC-DEMO-G002-V1 | return ValidatorReport | OK |
| 22 | Generator G002 | UpdateMemory | UTC-DEMO-G002-V1 → Passed/OK |
| 23 | Generator G002 | return GeneratorRunReport | Completed |
| 24 | Author | return ExternalResponse | Completed |

## T02 ONE WHEN GROUP TWO SCENARIOS

[Complete call/response JSON](T02_ONE_WHEN_GROUP_TWO_SCENARIOS.json)

| Step | Actor | Operation | Address / outcome |
|---|---|---|---|
| 1 | Author | WriteMemory | ScenarioGroup: G001 → SG-DEMO-G001 |
| 2 | Author | UnitTestGenerator | SG-DEMO-G001 |
| 3 | Generator G001 | GetMemory | SG-DEMO-G001 |
| 4 | Generator G001 | KnowledgeTool | structural keys |
| 5 | Generator G001 | WriteMemory | UnitTestCandidate: G001 → UTC-DEMO-G001-V1 |
| 6 | Generator G001 | UnitTestValidator | UTC-DEMO-G001-V1 |
| 7 | Validator UTC-DEMO-G001-V1 | JsonValidationTool | UTC-DEMO-G001-V1 |
| 8 | Validator UTC-DEMO-G001-V1 | GetMemory | UTC-DEMO-G001-V1 |
| 9 | Validator UTC-DEMO-G001-V1 | KnowledgeTool | structural keys |
| 10 | Validator UTC-DEMO-G001-V1 | return ValidatorReport | OK |
| 11 | Generator G001 | UpdateMemory | UTC-DEMO-G001-V1 → Passed/OK |
| 12 | Generator G001 | return GeneratorRunReport | Completed |
| 13 | Author | return ExternalResponse | Completed |

## T03 NEW GUID REPAIR

[Complete call/response JSON](T03_NEW_GUID_REPAIR.json)

| Step | Actor | Operation | Address / outcome |
|---|---|---|---|
| 1 | Author | WriteMemory | ScenarioGroup: G001 → SG-DEMO-G001 |
| 2 | Author | UnitTestGenerator | SG-DEMO-G001 |
| 3 | Generator G001 | GetMemory | SG-DEMO-G001 |
| 4 | Generator G001 | KnowledgeTool | structural keys |
| 5 | Generator G001 | WriteMemory | UnitTestCandidate: G001 → UTC-DEMO-G001-V1 |
| 6 | Generator G001 | UnitTestValidator | UTC-DEMO-G001-V1 |
| 7 | Validator UTC-DEMO-G001-V1 | JsonValidationTool | UTC-DEMO-G001-V1 |
| 8 | Validator UTC-DEMO-G001-V1 | GetMemory | UTC-DEMO-G001-V1 |
| 9 | Validator UTC-DEMO-G001-V1 | KnowledgeTool | structural keys |
| 10 | Validator UTC-DEMO-G001-V1 | return ValidatorReport | GENERATOR_REPAIR |
| 11 | Generator G001 | UpdateMemory | UTC-DEMO-G001-V1 → Failed/GENERATOR_REPAIR |
| 12 | Generator G001 | WriteMemory | UnitTestCandidate: G001 → UTC-DEMO-G001-V2 |
| 13 | Generator G001 | UnitTestValidator | UTC-DEMO-G001-V2 |
| 14 | Validator UTC-DEMO-G001-V2 | JsonValidationTool | UTC-DEMO-G001-V2 |
| 15 | Validator UTC-DEMO-G001-V2 | GetMemory | UTC-DEMO-G001-V2 |
| 16 | Validator UTC-DEMO-G001-V2 | KnowledgeTool | structural keys |
| 17 | Validator UTC-DEMO-G001-V2 | return ValidatorReport | OK |
| 18 | Generator G001 | UpdateMemory | UTC-DEMO-G001-V2 → Passed/OK |
| 19 | Generator G001 | return GeneratorRunReport | Completed |
| 20 | Author | return ExternalResponse | Completed |

## T04 FAIL FAST RETAINS EARLIER CANDIDATE

[Complete call/response JSON](T04_FAIL_FAST_RETAINS_EARLIER_CANDIDATE.json)

| Step | Actor | Operation | Address / outcome |
|---|---|---|---|
| 1 | Author | WriteMemory | ScenarioGroup: G001 → SG-DEMO-G001, G002 → SG-DEMO-G002, G003 → SG-DEMO-G003 |
| 2 | Author | UnitTestGenerator | SG-DEMO-G001 |
| 3 | Generator G001 | GetMemory | SG-DEMO-G001 |
| 4 | Generator G001 | KnowledgeTool | structural keys |
| 5 | Generator G001 | WriteMemory | UnitTestCandidate: G001 → UTC-DEMO-G001-V1 |
| 6 | Generator G001 | UnitTestValidator | UTC-DEMO-G001-V1 |
| 7 | Validator UTC-DEMO-G001-V1 | JsonValidationTool | UTC-DEMO-G001-V1 |
| 8 | Validator UTC-DEMO-G001-V1 | GetMemory | UTC-DEMO-G001-V1 |
| 9 | Validator UTC-DEMO-G001-V1 | KnowledgeTool | structural keys |
| 10 | Validator UTC-DEMO-G001-V1 | return ValidatorReport | OK |
| 11 | Generator G001 | UpdateMemory | UTC-DEMO-G001-V1 → Passed/OK |
| 12 | Generator G001 | return GeneratorRunReport | Completed |
| 13 | Author | UnitTestGenerator | SG-DEMO-G002 |
| 14 | Generator G002 | GetMemory | SG-DEMO-G002 |
| 15 | Generator G002 | KnowledgeTool | structural keys |
| 16 | Generator G002 | WriteMemory | UnitTestCandidate: G002 → UTC-DEMO-G002-V1 |
| 17 | Generator G002 | UnitTestValidator | UTC-DEMO-G002-V1 |
| 18 | Validator UTC-DEMO-G002-V1 | JsonValidationTool | UTC-DEMO-G002-V1 |
| 19 | Validator UTC-DEMO-G002-V1 | GetMemory | UTC-DEMO-G002-V1 |
| 20 | Validator UTC-DEMO-G002-V1 | KnowledgeTool | structural keys |
| 21 | Validator UTC-DEMO-G002-V1 | return ValidatorReport | HUMAN |
| 22 | Generator G002 | UpdateMemory | UTC-DEMO-G002-V1 → Failed/HUMAN |
| 23 | Generator G002 | return GeneratorRunReport | Failed |
| 24 | Author | return ExternalResponse | Failed |
