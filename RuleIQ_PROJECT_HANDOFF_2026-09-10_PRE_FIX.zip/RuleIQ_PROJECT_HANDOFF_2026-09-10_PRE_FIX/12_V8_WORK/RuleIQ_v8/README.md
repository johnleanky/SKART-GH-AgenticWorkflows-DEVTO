# RuleIQ v8 — Variant B

**Current package:** one fresh UnitTestGenerator invocation per physical ScenarioGroup.
Author first confirms all source writes, then invokes each group sequentially and stops
on the first failed/malformed report. A When group may contain several Scenario rows.

## Start here

- [Pega implementation specification v3](specification/PEGA_IMPLEMENTATION_SPEC_v3.md)
- [Memory v3](memory_contracts/MEMORY_TOOL_CONTRACT_v3.md)
- [Agent inputs and JSON reports](agent_contracts/README.md)
- [Step-by-step tool walkthroughs](examples/TOOL_CALL_WALKTHROUGHS.md)
- [Change register](CHANGE_REGISTER_v8.json)
- [Source manifest](SOURCE_MANIFEST_v8.json)

Generator receives CaseID,RUTType,ScenarioGroupUUID; Validator receives
CaseID,RUTType,UnitTestCandidateUUID. Both return single JSON reports. WriteMemory creates
immutable versions with new GUIDs. UpdateMemory changes only current-version lifecycle
metadata. Repairs never overwrite old payloads. Source grammar remains 1.4 and both candidate
schemas remain unchanged. Fifteen of the twenty original source files are byte-identical to v7.

## Verification and boundary

Local checks: **893/893 passed**. These check actual source text, JSON Schemas,
fixtures, supplied Memory evidence and explicitly synthetic sequence models. They do not
execute a Pega agent, parse full source wire in the sequence model, perform LLM semantic
projection, or certify runtime context isolation/durability. The normalized-source model
and redacted walkthroughs are clearly marked; neither is a deployable ScenarioGroup payload.

External work includes real three-parameter bindings, fresh contexts, Memory v3, case
serialization, target deployment/migration and **31 Pega + 20 Memory**
acceptance requirements, all unexecuted. Readable XML configurations are references, not
a complete RAP. No Main export or actual agent-tool parameter-definition export was supplied;
the exact required bindings are specified without fabricated Pega fields.

## Local commands

From this package directory, first verify received bytes:

```sh
python3 -B verification/verify_package_v8.py
```

For semantic/schema/interface regression, install verification/requirements.txt into your
chosen Python environment, then run:

```sh
python3 -B verification/run_all_v8.py
```

The suite rewrites its reports; verify the received manifest before regenerating evidence.
No network, Pega credentials or external service access is used by the tests. Source and
document builders remain in the surrounding 12_V8_WORK workspace and only write v8 artifacts.
The delivered package is self-contained for verification with the declared Python dependencies.
