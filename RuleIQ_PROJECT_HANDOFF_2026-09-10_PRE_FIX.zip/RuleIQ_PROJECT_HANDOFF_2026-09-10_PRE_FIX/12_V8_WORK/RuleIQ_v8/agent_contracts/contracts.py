"""Read-only validation of v8 interfaces and supplied context; no agent/runtime execution."""
from pathlib import Path
import json
import re
import jsonschema

HERE = Path(__file__).resolve().parent
SCHEMAS = {p.name.removesuffix('.schema.json'): json.loads(p.read_text()) for p in HERE.glob('*.schema.json')}
CATALOG = json.loads((HERE/'ISSUE_ACTION_CATALOG.json').read_text())
FAILURE_CODES = {'INVALID_INPUT','SOURCE_READ_FAILED','SOURCE_INVALID','KNOWLEDGE_FAILED',
                 'NO_REPRESENTABLE_SCENARIO','PROJECTION_FAILED','CANDIDATE_WRITE_FAILED',
                 'VALIDATOR_RESPONSE_INVALID','LIFECYCLE_UPDATE_FAILED','SEMANTIC_REJECTED',
                 'HUMAN_REVIEW_REQUIRED','REPAIR_BUDGET_EXHAUSTED'}

class ContractError(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise ContractError(message)

def loads(text):
    def pairs(values):
        result = {}
        for k,v in values:
            require(k not in result, 'duplicate JSON field')
            result[k] = v
        return result
    try:
        return json.loads(text, object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ContractError('nonfinite JSON')))
    except (json.JSONDecodeError, TypeError) as error:
        raise ContractError('invalid JSON') from error

def schema(name, value):
    if isinstance(value, str):
        value = loads(value)
    try:
        # Also reject non-finite numbers and surrogate code points in supplied Python objects.
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
        encoded.encode('utf-8')
        jsonschema.Draft202012Validator(SCHEMAS[name]).validate(value)
    except (jsonschema.ValidationError, ValueError, TypeError, UnicodeError) as error:
        raise ContractError(str(error)) from error
    return value

def input_(agent, args):
    require(isinstance(args, dict), 'three named parameters required, not a serialized question')
    return schema(agent+'Input', args)

def generator_report(report, args, source=None, forbidden_guids=(), final_guid=None, payload=None):
    r = schema('GeneratorRunReport', report)
    try:
        input_('Generator', args)
    except ContractError:
        require(r == {'status':'Failed','candidate':None,'groups':[],
                      'validationAttempts':0,'repairAttempts':0,'errorMessage':'INVALID_INPUT'},
                'invalid invocation must have exact bounded failure')
        return r
    require(len(r['groups']) == 1, 'one source report required')
    group = r['groups'][0]
    require(group['sourceUUID'] == args['ScenarioGroupUUID'], 'wrong source UUID')
    require((group['groupId'] is None) == (group['groupOrder'] is None), 'partial source identity')
    if group['groupId'] is None:
        require(r['status']=='Failed' and r['errorMessage'].split(':',1)[0] in
                ('SOURCE_READ_FAILED','SOURCE_INVALID'), 'unknown group without source failure')
    if source is not None and group['groupId'] is not None:
        require(group['groupId']==source['groupId'] and group['groupOrder']==source['groupOrder'], 'wrong source metadata')
    kept = group['representedScenarioIds']
    rejected = [x['scenarioId'] for x in group['rejectedScenarios']]
    require(len(rejected)==len(set(rejected)) and not set(kept)&set(rejected), 'duplicate/overlapping Scenario census')
    require(r['validationAttempts'] <= r['repairAttempts']+1, 'impossible attempt counts')
    if r['repairAttempts']:
        require(r['validationAttempts'] >= r['repairAttempts'], 'repair without prior Validator attempt')
    if r['status']=='Failed':
        require(not kept and not rejected, 'failed report claims representation')
        reason = r['errorMessage'].split(':',1)[0]
        require(reason in FAILURE_CODES - {'INVALID_INPUT'}, 'unknown failure for valid invocation')
        attempts = (r['validationAttempts'], r['repairAttempts'])
        if reason in ('SOURCE_READ_FAILED','SOURCE_INVALID','KNOWLEDGE_FAILED','NO_REPRESENTABLE_SCENARIO'):
            require(r['validationAttempts']==r['repairAttempts']==0, 'pre-write failure has attempts')
        if reason == 'PROJECTION_FAILED':
            require(attempts in ((0,0),(1,0),(2,1)), 'projection failure outside initial/available repair audit')
        if reason == 'CANDIDATE_WRITE_FAILED':
            require(r['validationAttempts']==r['repairAttempts'], 'failed write cannot have its own Validator attempt')
        if reason in ('VALIDATOR_RESPONSE_INVALID','LIFECYCLE_UPDATE_FAILED','SEMANTIC_REJECTED','HUMAN_REVIEW_REQUIRED'):
            require(r['validationAttempts']==r['repairAttempts']+1, 'post-validation failure has impossible attempts')
        if reason == 'REPAIR_BUDGET_EXHAUSTED':
            require(attempts==(3,2), 'repair budget not exhausted')
        if reason in ('SOURCE_READ_FAILED','SOURCE_INVALID'):
            require(group['groupId'] is None, 'invalid source claims validated identity')
        return r
    require(r['validationAttempts']==r['repairAttempts']+1, 'success attempt relation')
    require(r['candidate']['CaseID']==args['CaseID'], 'wrong candidate case')
    uuid = r['candidate']['UUID']
    require(uuid not in {*forbidden_guids, args['ScenarioGroupUUID']}, 'reused candidate/source UUID')
    if final_guid is not None:
        require(uuid==final_guid, 'not the current confirmed candidate version')
    if source is not None:
        ids = source['scenarioIds']
        require(set(kept)|set(rejected)==set(ids), 'incomplete/foreign Scenario census')
        require(kept==[x for x in ids if x in kept] and rejected==[x for x in ids if x in rejected], 'Scenario order changed')
        if r['status']=='PartiallyCompleted':
            require(args['RUTType']=='Rule-Obj-When' and source['mode']=='EXECUTABLE', 'partial result outside executable When')
    if payload is not None:
        require(len(payload['UnitTestRules'])==1 and len(payload['UnitTestRules'][0]['Scenarios'])==len(kept), 'candidate/Scenario census mismatch')
    return r

def validator_report(report, args, expected_group=None, payload=None, read_succeeded=None):
    r = schema('ValidatorReport', report)
    try:
        input_('Validator', args)
    except ContractError:
        supplied = args if isinstance(args,dict) else {}
        for key in ('CaseID','RUTType','UnitTestCandidateUUID'):
            value = supplied.get(key)
            require(r[key]==(value if isinstance(value,str) and value else None), 'invented invalid-input identity')
        require(r['groupId'] is None and r['route']=='HUMAN' and len(r['issues'])==1, 'invalid-input report shape')
        issue = r['issues'][0]
        require(issue['code']=='AMBIGUOUS' and issue['action']=='HUMAN_REVIEW' and issue['severity']=='B', 'invalid-input diagnostic')
    else:
        require(all(r[k]==args[k] for k in ('CaseID','RUTType','UnitTestCandidateUUID')), 'wrong Validator identity')
    if expected_group is not None and r['groupId'] is not None:
        require(r['groupId']==expected_group, 'wrong candidate group')
    if read_succeeded is True:
        require(r['groupId'] is not None, 'successful read lost identity')
    if read_succeeded is False:
        require(r['groupId'] is None, 'pre-read invented group')
    blocking = [x for x in r['issues'] if x['severity']=='B']
    require(r['blocking']==len(blocking) and r['warnings']==len(r['issues'])-len(blocking), 'issue count mismatch')
    actions = {x['action'] for x in blocking}
    route = 'HUMAN' if 'HUMAN_REVIEW' in actions else 'SEMANTIC_REJECT' if 'REJECT_SEMANTICS' in actions else 'GENERATOR_REPAIR' if actions else 'OK'
    require(r['route']==route, 'route precedence mismatch')
    early = {'JSON_SCHEMA_INVALID','JSON_SCHEMA_MASS_FAILURE','JSON_VALIDATION_TOOL_ERROR','MEMORY_READ_TOOL_ERROR','AMBIGUOUS'}
    scenarios = payload['UnitTestRules'][0]['Scenarios'] if payload is not None else None
    for issue in r['issues']:
        require(re.search(r'~(?![01])', issue['path']) is None, 'invalid JSON pointer escape')
        require(issue['path']=='/' or issue['path'].startswith('/UnitTestRules/0/') or issue['path']=='/UnitTestRules/0', 'foreign unit pointer')
        if r['groupId'] is None:
            require(issue['code'] in early and issue['scenario'] is None and issue['decision'] is None and issue['path']=='/', 'invalid pre-read attribution')
        if issue['scenario'] is None:
            require(issue['decision'] is None, 'decision without Scenario')
        if issue['scenario'] is not None and scenarios is not None:
            n = issue['scenario']
            require(n < len(scenarios), 'Scenario index outside candidate')
            pointer = re.match(r'^/UnitTestRules/0/Scenarios/(\d+)(?:/|$)',issue['path'])
            require(pointer is None or int(pointer[1])==n, 'Scenario pointer mismatch')
            if issue['decision'] is not None:
                trace = scenarios[n]['EvidenceSummary']['AssertionDecisionTrace']
                ids = [line.split('|')[1].removeprefix('id=') for line in trace.splitlines()]
                require(issue['decision'] in ids, 'foreign decision ID')
    return r

def final_selection(reports, records, completed):
    """Only supplied current-run confirmed reports; returns executable and informational UUIDs."""
    if not completed:
        return {'executable':[], 'informational':[]}
    selected = {'executable':[], 'informational':[]}
    seen = set()
    for report in reports:
        schema('GeneratorRunReport', report)
        require(report['status'] in ('Completed','PartiallyCompleted'), 'failed report selected')
        ref = report['candidate']; uuid = ref['UUID']
        require(uuid not in seen and uuid in records, 'missing/repeated selection UUID')
        seen.add(uuid)
        record = records[uuid]
        require(record['pyGUID']==uuid and record['pxCaseID']==ref['CaseID'] and record['Type']=='UnitTestCandidate', 'selection identity mismatch')
        require(record['pyGroup']==report['groups'][0]['groupId'], 'selection group mismatch')
        require((record['pyStatusValue'],record['pyRouterKey'])==('Passed','OK'), 'unconfirmed lifecycle selected')
        candidate = loads(record['pyPayload'])
        require(len(candidate['UnitTestRules'])==1, 'selection cardinality')
        unit = candidate['UnitTestRules'][0]
        info = 'RuleCode' not in unit
        require(bool(unit['Scenarios']) and all((s['Testability']=='NotTestable')==info for s in unit['Scenarios']), 'selection execution mode mismatch')
        selected['informational' if info else 'executable'].append(uuid)
    return selected
