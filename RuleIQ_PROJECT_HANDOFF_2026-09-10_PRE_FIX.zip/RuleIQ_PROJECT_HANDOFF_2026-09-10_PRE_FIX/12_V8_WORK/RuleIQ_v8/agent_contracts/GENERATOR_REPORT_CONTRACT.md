## GeneratorRunReport — normative JSON contract

Return one raw finite duplicate-free JSON object, with exactly status, candidate, groups,
validationAttempts, repairAttempts, errorMessage. Never wrap it in Markdown or persist it.
status is Completed, PartiallyCompleted or Failed. candidate is null for Failed; otherwise
exactly {CaseID: <input CaseID>, Type: "UnitTestCandidate", UUID: <final confirmed Passed/OK GUID>}.
errorMessage is empty on either success and a nonempty diagnostic of at most 240 characters
on Failed. Use the stable failure reason codes from Generator G9 as the diagnostic prefix.

For a valid invocation groups has exactly one object with exactly sourceUUID, groupId,
groupOrder, representedScenarioIds, rejectedScenarios. sourceUUID equals input ScenarioGroupUUID.
groupId and groupOrder are null until a complete local source validation establishes them;
then they equal the source groupId and positive original groupOrder. representedScenarioIds
is an ordered array of unique frozen Scenario IDs. rejectedScenarios is an ordered array of
objects with exactly scenarioId and reason; reason is nonempty and at most 240 characters.
Rejection IDs are unique, disjoint from represented IDs, and follow original source order.
On either success, both arrays partition the entire original Scenario census, preserve
relative order, and representedScenarioIds is nonempty. On Failed both arrays are empty;
do not claim representation from an unvalidated or unconfirmed candidate.

Completed has no rejected Scenarios. Faithfully represented PartiallyTestable or informational
NotTestable is Completed too; this is not evidence that Pega ran a unit test.
PartiallyCompleted requires an executable Rule-Obj-When group with at least one represented
and at least one legitimately rejected Scenario under the existing initial G2 projection
rules. New semantic pruning, Validator-driven removal of a required source Scenario,
conversion of an ASSERT to OMIT, or rejection merely for NotTestable is forbidden.

validationAttempts is the actual count of attempted Validator invocations (0..3), including
an exception. repairAttempts is the count of attempted repaired-candidate WriteMemory calls
(0..2), including failure. Neither counter counts lifecycle UpdateMemory calls. For either
success validationAttempts = repairAttempts + 1; after a failed write the attempted repair
need not have a Validator call. A syntactically invalid invocation makes zero tool calls and
returns Failed, candidate=null, groups=[], both counters 0, errorMessage="INVALID_INPUT".

Source, Knowledge and no-representable-Scenario failures have both counters zero.
PROJECTION_FAILED may occur during initial construction (0,0) or before an available
repair write (validationAttempts,repairAttempts = 1,0 or 2,1). An unprojectable repair
does not increment repairAttempts because no repaired write was attempted.
CANDIDATE_WRITE_FAILED has equal counters. VALIDATOR_RESPONSE_INVALID,
LIFECYCLE_UPDATE_FAILED, SEMANTIC_REJECTED and HUMAN_REVIEW_REQUIRED require
validationAttempts = repairAttempts + 1. REPAIR_BUDGET_EXHAUSTED requires exactly 3 and 2.

Author validates this exact shape, counters, input CaseID/sourceUUID, source groupId/groupOrder,
and source census against its own frozen mapping before accepting the report. Every returned
successful candidate GUID must differ from source GUIDs and earlier groups' candidate GUIDs.
Author never reads candidates or inspects Validator diagnostics. Failed reports must match the
current sourceUUID; known group metadata must match its map. Unknown metadata may be null only
with SOURCE_READ_FAILED or SOURCE_INVALID. A malformed report is not a successful group.
