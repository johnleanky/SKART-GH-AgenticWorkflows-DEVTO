## ValidatorReport — normative JSON contract

Return one raw finite duplicate-free JSON object with exactly CaseID, RUTType,
UnitTestCandidateUUID, groupId, route, blocking, warnings, issues. The first three fields
echo the three exact input strings; only a syntactically invalid invocation may use null
for an unavailable/non-string/empty input. Do not normalize opaque identifiers.
groupId is the pyGroup of the successfully read candidate; it remains null before a valid
GetMemory result. Never invent a groupId from candidate JSON or the supplied UUID.

route is OK, GENERATOR_REPAIR, SEMANTIC_REJECT or HUMAN. issues is an ordered array with
no duplicate issues. Each issue has exactly severity (B or W), code, action, unit (integer 0),
scenario (current zero-based Scenario index or null), decision (existing stable decision ID
or null), path (JSON pointer beginning /), and message (nonempty, at most 240 characters).
Candidate-wide or pre-read issues use scenario=null and decision=null; paths are / or under
/UnitTestRules/0. Scenario indices/decision IDs must exist in the current candidate, and a
decision belongs to that Scenario. Never add another unit coordinate or an inferred ID.
Use only the closed issue/action catalog, preserving all existing diagnostic meanings.

blocking and warnings are nonnegative integer counts of B and W issues. Derive route from
blocking actions with precedence HUMAN_REVIEW -> HUMAN, REJECT_SEMANTICS -> SEMANTIC_REJECT,
any permitted mechanical action -> GENERATOR_REPAIR, no blocking issues -> OK. Warnings
never trigger repair. OK requires nonempty groupId and all input identities, and blocking=0.
Before a successful read, emit only JSON_SCHEMA_INVALID/FIX_JSON,
JSON_SCHEMA_MASS_FAILURE/REBUILD_JSON_FROM_CURRENT_EVIDENCE,
JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW, MEMORY_READ_TOOL_ERROR/HUMAN_REVIEW,
or invalid-input AMBIGUOUS/HUMAN_REVIEW, with null coordinates and path=/.

Generator verifies the complete report and exact CaseID/RUTType/current candidate UUID.
A non-null groupId must equal its source groupId. A null groupId is permitted only for
the documented pre-read failures; it cannot authorize OK. Validate coordinate attribution,
catalog, counts and route before making exactly one lifecycle UpdateMemory. A malformed,
wrong-identity, stale, or contradictory report produces no lifecycle write and terminates
as VALIDATOR_RESPONSE_INVALID; do not infer Failed/HUMAN or consult another invocation.
