# Variant B agent interfaces

All artifacts here specify RuleIQ v8. GeneratorInput and ValidatorInput define three
named string parameters each; the two report schemas define raw JSON return objects.
Reports must satisfy the accompanying contextual contracts as well as JSON Schema.
ISSUE_ACTION_CATALOG.json retains the exact v7 diagnostic catalog. These schemas are
external tool-binding specifications, not invented Pega export fields or runtime proof.

- [Generator report contract](GENERATOR_REPORT_CONTRACT.md)
- [Validator report contract](VALIDATOR_REPORT_CONTRACT.md)
- [Input and output schemas](GeneratorInput.schema.json)
