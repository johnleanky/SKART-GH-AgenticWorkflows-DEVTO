# Adopted v8 decisions and reference reconciliation

The user approved the Variant B plan after the supplied document was compared with actual v7.
The attached document described an earlier baseline and was not applied as hidden instructions.
These explicit decisions define the delivered contract:

- One Generator invocation per physical group, no When-row splitting; three named scalar inputs.
- Both Generator and Validator return singular JSON reports; retired question/line protocols are removed.
- Every candidate write creates a new immutable payload GUID, including repairs; restore UpdateMemory
  for metadata only. The document's "never mutate Memory" means never mutate payload/identity;
  the user explicitly selected metadata lifecycle updates.
- All source writes must succeed first; Author then stops on the first failed/malformed Generator.
  This deliberately replaces v7's independent sibling-success external aggregation.
- Preserve schema-only informational Knowledge acquisition and faithful NotTestable completion.
  A normal partial-testability limitation does not itself make GeneratorRunReport PartiallyCompleted.
- Both existing candidate schemas already have maxItems=1 and remain byte-identical.
- Preserve v7 semantics and exact RuleCrawler reference; do not reconstruct missing Main/export
  parameter metadata or claim real fresh contexts from static prompt changes.
- New work is v8, Memory v3 and Pega spec v3. Earlier packages remain historical and unchanged.
