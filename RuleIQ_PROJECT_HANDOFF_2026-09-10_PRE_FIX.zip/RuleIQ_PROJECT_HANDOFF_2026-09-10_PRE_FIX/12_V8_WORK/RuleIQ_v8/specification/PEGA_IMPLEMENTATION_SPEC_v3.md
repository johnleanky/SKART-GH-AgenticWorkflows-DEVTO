# Pega implementation specification v3 — RuleIQ v8 Variant B

## Outcome and deployment boundary

Deploy a consistent v8 prompt/contract set. One physical ScenarioGroup has one fresh Generator
invocation and one final candidate reference. When groups may contain multiple combination
rows. All groups are successfully persisted first; invocation and report checking then proceed
strictly by original groupOrder. First failure stops remaining groups and automatic selection.

This workspace delivers prompts, readable configuration references, four interface JSON Schemas,
Memory v3 and local verification. It does not modify Pega, configure actual agent cards, migrate
data, or establish deployed LLM behavior. No updated Main export or actual parameter-binding
rule exports exist in the supplied baseline. Apply Main to the existing rule and configure
the following exact interfaces through the application's existing mechanisms; do not invent
Pega XML fields or treat the readable exports as a target-ready RAP.

## Required Pega work

| ID | Component | Required behavior |
|---|---|---|
| PI-01 | Author | Apply Main prompt. Audit complete groups, batch-write once, demand all rows confirmed; then call Generator sequentially and validate each JSON report. |
| PI-02 | Fresh invocation boundary | Each Generator context contains only its static prompt, three current inputs and its own tool responses. Do not pass Author history, prior Generator output, shared chat/session history or cached Knowledge. |
| PI-03 | Generator binding | Exactly CaseID,RUTType,ScenarioGroupUUID, all strings; return GeneratorRunReport JSON. No question, array, previous artifacts or payload parameters. |
| PI-04 | Validator binding | Exactly CaseID,RUTType,UnitTestCandidateUUID, all strings; return ValidatorReport JSON. One current candidate. |
| PI-05 | WriteMemory | Implement immutable insert-per-success, new globally unique GUID, complete payload; candidate initialization Pending/empty. No tuple upsert. |
| PI-06 | GetMemory | Exact case/type/GUID ownership and unchanged eight-field response. |
| PI-07 | UpdateMemory | Existing exact candidate GUID only, metadata-only atomic patch, no payload/identity modification or insert fallback. |
| PI-08 | JsonValidationTool | Preserve CaseID,UUID,JsonSchema arguments; validate the stored exact candidate GUID; then Validator may read it. |
| PI-09 | KnowledgeTool | Publish current semantic content and both structural families. Each Generator obtains its own required keys; information needs only schema. |
| PI-10 | GetCaseData/RuleCrawler | Preserve complete RUT identity and existing semantic/crawler behavior; do not redesign crawler as part of isolation. |
| PI-11 | Case orchestration/consumer | Hold one pipeline per case; select only this complete run's final confirmed Passed/OK UUIDs. No old-version/partial-run fallback or runnable NotTestable. |
| PI-12 | Deployment/acceptance | Bind matching v8 artifacts, use isolated v3 scope or approved migration mapping, and capture actual external evidence. |

## Agent and tool inventory

- Author: GetCaseData, semantic KnowledgeTool, RuleCrawler, WriteMemory(ScenarioGroup), UnitTestGenerator.
- Generator: GetMemory(ScenarioGroup), structural KnowledgeTool, WriteMemory(UnitTestCandidate), UpdateMemory(UnitTestCandidate), UnitTestValidator.
- Validator: JsonValidationTool, GetMemory(UnitTestCandidate), structural KnowledgeTool. No writes or repairs.

Use [agent contracts](../agent_contracts/README.md) and [Memory v3](../memory_contracts/MEMORY_TOOL_CONTRACT_v3.md)
as the exact interface authority. Prompt source and embedded system/response-style prompts
must match. Existing environment ownership, model settings and target ruleset selection are
not changed by this package. Configure the three scalar parameters in the actual callable
agent tools and ensure invocation inputs are mapped by name; never rely on prompt text to
change a tool signature or guarantee a fresh context.

## Fresh context and failure ordering

Use the application's existing invocation/session mechanism to create a new Generator
context per group. A fresh call identifier alone is insufficient evidence: capture the
actual model input message inventory and demonstrate no previous group's source, candidate,
report, hidden history or cache content. The parent Author may retain its own map and reports
but must forward only the current three scalar inputs. Do not introduce a separate orchestrator.

Queue/reject overlapping runs of the same case before any source writes, using the existing
case mechanism. Different cases can proceed independently. Preserve the guard through all
Generator invocations and complete result materialization. A failed source row stops before
Generator #1; a failed/malformed Generator #N stops before #N+1. No automatic tool/agent retries
or rollback of committed sources/candidates. Network loss after commit remains unconfirmed.

## Knowledge, schemas and metadata

KnowledgeTool(KnowledgeAreas) keeps its comma-separated string and pxResults with exact
Area/Description strings. Publish the six v7 semantic KnowledgeAreas unchanged. Executable
Generator and Validator use the appropriate three structural keys:

| RUTType | Keys |
|---|---|
| Rule-Obj-When | Rule-Test-Unit-Case_MultInpComb-KnowledgeArea, Rule-Test-Unit-Case_MultInpComb-JsonSchema, Rule-Test-Unit-Case_MultInpComb-JsonExample |
| Other supported types | Rule-Test-Unit-Case_KnowledgeArea, Rule-Test-Unit-Case_JsonSchema, Rule-Test-Unit-Case_JsonExample |

The two structural UTC KnowledgeArea texts remain existing external prerequisites, not newly
invented files. Templates must carry the application's already-selected pyRuleSet and
pyRuleSetVersion; illustrative source example values are not deployment targets. Informational
Generator groups acquire only the matching schema and require no target metadata; Validator
does not request UTC Knowledge for a valid informational candidate. Each new Generator repeats
its own required lookup; no cross-invocation reuse and no reacquisition during repairs.

JsonValidationTool(CaseID,UUID,JsonSchema) retains its exact arguments and required response
Success,IsValid,ValidationMessage,ErrorCode,ErrorMessage. For When use the MultInpComb schema
key; otherwise Standard. Schema invalid and tool failure are distinct; both prevent that
Validator's GetMemory. Tool validation is read-only and never rewrites JSON or status.

GetCaseData retains its invocation and must provide pyID,TestedRuleKey plus RUT
pzInsKey/pxObjClass/pyClassName/pyRuleName with consistent first-three-component identity.
RuleCrawler export remains unchanged. Its low-level ResolveCrawlerBatch export resolves keys,
not complete LLM-visible RuleJSON; preserve the existing wrapper mapping and do not invent
its scalar parameter names. A resolved key alone cannot establish a fetched dependency.

## Results, versions and migration

Every candidate version has immutable payload and a new GUID. Confirm the exact direct
Validator route using UpdateMemory before returning or repairing. Report success only after
Passed/OK is confirmed. No more than two repaired writes/three Validator attempts per group.
The schemas and contextual contracts define report fields, census/counters, source matching
and local unit=0 coordinates. JSON report schemas do not themselves prove provenance or storage.

Author external response remains exactly AIAgentResponseStatus/AIAgentErrorResponseMessage:
Completed with empty error only when all groups processed. Failed with "Scenario group storage
failed." for source persistence; "Unit test generation failed." for Generator failure/exception;
"Unit test generator returned an invalid response." for malformed/mismatched reports.
Keep errors one sentence, at most 20 words/180 characters. Do not expose internal reports/GUIDs.

The consumer must first validate all current report correlations and successful statuses,
then confirm each final record's exact identity and Passed/OK through a canonical projection.
Only candidates with executable Scenarios and RuleCode become runnable tests. Keep NotTestable
with its BlockingGaps as information. Earlier successful groups in an overall failed run
remain stored for investigation, but automatic test creation does not start from that partial set.

Default rollout uses a clean v3 test scope. Production activation requires a Pega-owned
storage/migration mapping that supports multiple versions per case/type/group and preserves
all v7 data. Never run v7 upsert writers against the same active records as v8 version writers.
Switch all bindings/prompts/metadata handling together. The package performs no migration.

## Verification and handover

Run the packaged local suite and inspect exact source/package hashes. External acceptance
requires actual request/response traces, chronological calls, context input inventories,
failure-injection steps and independent before/after record snapshots from a fresh requestor.
See [acceptance cases](ACCEPTANCE_CASES.json) and [walkthroughs](../examples/TOOL_CALL_WALKTHROUGHS.md).
All external cases are initially NOT_RUN_EXTERNAL. Passing local models cannot certify Pega,
LLM context isolation, durability, tool bindings or production readiness.
