# Pega handover v3

[Implementation specification](PEGA_IMPLEMENTATION_SPEC_v3.md) defines the external work.
[Acceptance cases](ACCEPTANCE_CASES.json) require real runtime evidence.
