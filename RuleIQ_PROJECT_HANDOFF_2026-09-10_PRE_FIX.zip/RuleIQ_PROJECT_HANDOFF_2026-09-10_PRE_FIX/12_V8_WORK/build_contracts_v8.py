"""Build v8 JSON interfaces and their prompt-readable normative definitions."""
from pathlib import Path
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE / 'RuleIQ_v8'
OUT = ROOT / 'agent_contracts'
OUT.mkdir(parents=True, exist_ok=True)
BASE = HERE.parent / '11_V7_WORK/RuleIQ_v7/sources'

def obj(properties, **extra):
    return dict(type='object', additionalProperties=False, required=list(properties), properties=properties, **extra)

STRING = {'type': 'string'}
TEXT = {'type': 'string', 'minLength': 1}
MESSAGE = {'type': 'string', 'minLength': 1, 'maxLength': 240}
NULL = {'type': 'null'}
def nullable(schema):
    return {'anyOf': [schema, NULL]}
def array(items, **kw):
    return dict(type='array', items=items, **kw)
def save(name, value):
    value = {'$schema': 'https://json-schema.org/draft/2020-12/schema', 'title': name, **value}
    (OUT / (name + '.schema.json')).write_text(json.dumps(value, indent=2) + '\n')

for agent, uuid in [('GeneratorInput', 'ScenarioGroupUUID'), ('ValidatorInput', 'UnitTestCandidateUUID')]:
    save(agent, obj({'CaseID': TEXT, 'RUTType': TEXT, uuid: TEXT}))

candidate = obj({'CaseID': TEXT, 'Type': {'const': 'UnitTestCandidate'}, 'UUID': TEXT})
group = obj({'sourceUUID': TEXT, 'groupId': nullable(TEXT),
             'groupOrder': nullable({'type': 'integer', 'minimum': 1}),
             'representedScenarioIds': array(TEXT, uniqueItems=True),
             'rejectedScenarios': array(obj({'scenarioId': TEXT, 'reason': MESSAGE}))})
report = obj({'status': {'enum': ['Completed', 'PartiallyCompleted', 'Failed']},
              'candidate': nullable(candidate), 'groups': array(group, maxItems=1),
              'validationAttempts': {'type': 'integer', 'minimum': 0, 'maximum': 3},
              'repairAttempts': {'type': 'integer', 'minimum': 0, 'maximum': 2},
              'errorMessage': {'type': 'string', 'maxLength': 240}})
report['allOf'] = [
    {'if': {'properties': {'status': {'const': 'Failed'}}},
     'then': {'properties': {'candidate': NULL, 'errorMessage': MESSAGE}},
     'else': {'properties': {'candidate': candidate, 'errorMessage': {'const': ''},
                            'validationAttempts': {'minimum': 1},
                            'groups': {'minItems': 1, 'items': {'properties': {
                                'groupId': TEXT, 'groupOrder': {'type': 'integer', 'minimum': 1},
                                'representedScenarioIds': {'minItems': 1}}}}}}},
    {'if': {'properties': {'groups': {'maxItems': 0}}},
     'then': {'properties': {'status': {'const': 'Failed'}, 'validationAttempts': {'const': 0}, 'repairAttempts': {'const': 0}}}},
    {'if': {'properties': {'status': {'const': 'Completed'}}},
     'then': {'properties': {'groups': {'items': {'properties': {'rejectedScenarios': {'maxItems': 0}}}}}}},
    {'if': {'properties': {'status': {'const': 'PartiallyCompleted'}}},
     'then': {'properties': {'groups': {'items': {'properties': {'rejectedScenarios': {'minItems': 1}}}}}}},
]
save('GeneratorRunReport', report)

catalog_text = (BASE/'Validator_Prompt.txt').read_text().split('## Appendix A. Closed issue/action catalog\n', 1)[1].split('## Appendix B.', 1)[0]
catalog = {code: actions.split(', ') for code, actions in re.findall(r'^\| ([A-Z_]+) \| ([A-Z_, ]+) \|$', catalog_text, re.M)}
assert len(catalog) == 30
(OUT/'ISSUE_ACTION_CATALOG.json').write_text(json.dumps(catalog, indent=2)+'\n')
issue = obj({'severity': {'enum': ['B', 'W']}, 'code': {'enum': list(catalog)},
             'action': {'enum': sorted({a for acts in catalog.values() for a in acts})},
             'unit': {'const': 0, 'type': 'integer'},
             'scenario': nullable({'type': 'integer', 'minimum': 0}),
             'decision': nullable(TEXT), 'path': {'type': 'string', 'pattern': '^/'}, 'message': MESSAGE})
issue['allOf'] = [{'if': {'properties': {'code': {'const': code}}},
                   'then': {'properties': {'action': {'enum': actions}}}} for code, actions in catalog.items()]
validator = obj({'CaseID': nullable(TEXT), 'RUTType': nullable(TEXT),
                 'UnitTestCandidateUUID': nullable(TEXT), 'groupId': nullable(TEXT),
                 'route': {'enum': ['OK', 'GENERATOR_REPAIR', 'SEMANTIC_REJECT', 'HUMAN']},
                 'blocking': {'type': 'integer', 'minimum': 0},
                 'warnings': {'type': 'integer', 'minimum': 0}, 'issues': array(issue, uniqueItems=True)})
validator['allOf'] = [
    {'if': {'properties': {'route': {'const': 'OK'}}},
     'then': {'properties': {'blocking': {'const': 0}, 'groupId': TEXT,
                            'CaseID': TEXT, 'RUTType': TEXT, 'UnitTestCandidateUUID': TEXT,
                            'issues': {'items': {'properties': {'severity': {'const': 'W'}}}}}},
     'else': {'properties': {'blocking': {'minimum': 1}, 'issues': {'minItems': 1}}}},
    {'if': {'anyOf': [{'properties': {key: NULL}} for key in ('CaseID','RUTType','UnitTestCandidateUUID')]},
     'then': {'properties': {'route': {'const': 'HUMAN'}, 'groupId': NULL}}},
]
save('ValidatorReport', validator)

GENERATOR = '''## GeneratorRunReport — normative JSON contract

Return one raw finite duplicate-free JSON object, with exactly status, candidate, groups,
validationAttempts, repairAttempts, errorMessage. Never wrap it in Markdown or persist it.
status is Completed, PartiallyCompleted or Failed. candidate is null for Failed; otherwise
exactly {CaseID: <input CaseID>, Type: "UnitTestCandidate", UUID: <final confirmed Passed/OK GUID>}.
errorMessage is empty on either success and a nonempty diagnostic of at most 240 characters
on Failed. Use the stable failure reason codes from Generator G9 as the diagnostic prefix.

For a valid invocation groups has exactly one object with exactly sourceUUID, groupId,
groupOrder, representedScenarioIds, rejectedScenarios. sourceUUID equals input ScenarioGroupUUID.
groupId and groupOrder are null until a complete local source validation establishes them;
then they equal the source groupId and positive original groupOrder. representedScenarioIds
is an ordered array of unique frozen Scenario IDs. rejectedScenarios is an ordered array of
objects with exactly scenarioId and reason; reason is nonempty and at most 240 characters.
Rejection IDs are unique, disjoint from represented IDs, and follow original source order.
On either success, both arrays partition the entire original Scenario census, preserve
relative order, and representedScenarioIds is nonempty. On Failed both arrays are empty;
do not claim representation from an unvalidated or unconfirmed candidate.

Completed has no rejected Scenarios. Faithfully represented PartiallyTestable or informational
NotTestable is Completed too; this is not evidence that Pega ran a unit test.
PartiallyCompleted requires an executable Rule-Obj-When group with at least one represented
and at least one legitimately rejected Scenario under the existing initial G2 projection
rules. New semantic pruning, Validator-driven removal of a required source Scenario,
conversion of an ASSERT to OMIT, or rejection merely for NotTestable is forbidden.

validationAttempts is the actual count of attempted Validator invocations (0..3), including
an exception. repairAttempts is the count of attempted repaired-candidate WriteMemory calls
(0..2), including failure. Neither counter counts lifecycle UpdateMemory calls. For either
success validationAttempts = repairAttempts + 1; after a failed write the attempted repair
need not have a Validator call. A syntactically invalid invocation makes zero tool calls and
returns Failed, candidate=null, groups=[], both counters 0, errorMessage="INVALID_INPUT".

Source, Knowledge and no-representable-Scenario failures have both counters zero.
PROJECTION_FAILED may occur during initial construction (0,0) or before an available
repair write (validationAttempts,repairAttempts = 1,0 or 2,1). An unprojectable repair
does not increment repairAttempts because no repaired write was attempted.
CANDIDATE_WRITE_FAILED has equal counters. VALIDATOR_RESPONSE_INVALID,
LIFECYCLE_UPDATE_FAILED, SEMANTIC_REJECTED and HUMAN_REVIEW_REQUIRED require
validationAttempts = repairAttempts + 1. REPAIR_BUDGET_EXHAUSTED requires exactly 3 and 2.

Author validates this exact shape, counters, input CaseID/sourceUUID, source groupId/groupOrder,
and source census against its own frozen mapping before accepting the report. Every returned
successful candidate GUID must differ from source GUIDs and earlier groups' candidate GUIDs.
Author never reads candidates or inspects Validator diagnostics. Failed reports must match the
current sourceUUID; known group metadata must match its map. Unknown metadata may be null only
with SOURCE_READ_FAILED or SOURCE_INVALID. A malformed report is not a successful group.
'''
VALIDATOR = '''## ValidatorReport — normative JSON contract

Return one raw finite duplicate-free JSON object with exactly CaseID, RUTType,
UnitTestCandidateUUID, groupId, route, blocking, warnings, issues. The first three fields
echo the three exact input strings; only a syntactically invalid invocation may use null
for an unavailable/non-string/empty input. Do not normalize opaque identifiers.
groupId is the pyGroup of the successfully read candidate; it remains null before a valid
GetMemory result. Never invent a groupId from candidate JSON or the supplied UUID.

route is OK, GENERATOR_REPAIR, SEMANTIC_REJECT or HUMAN. issues is an ordered array with
no duplicate issues. Each issue has exactly severity (B or W), code, action, unit (integer 0),
scenario (current zero-based Scenario index or null), decision (existing stable decision ID
or null), path (JSON pointer beginning /), and message (nonempty, at most 240 characters).
Candidate-wide or pre-read issues use scenario=null and decision=null; paths are / or under
/UnitTestRules/0. Scenario indices/decision IDs must exist in the current candidate, and a
decision belongs to that Scenario. Never add another unit coordinate or an inferred ID.
Use only the closed issue/action catalog, preserving all existing diagnostic meanings.

blocking and warnings are nonnegative integer counts of B and W issues. Derive route from
blocking actions with precedence HUMAN_REVIEW -> HUMAN, REJECT_SEMANTICS -> SEMANTIC_REJECT,
any permitted mechanical action -> GENERATOR_REPAIR, no blocking issues -> OK. Warnings
never trigger repair. OK requires nonempty groupId and all input identities, and blocking=0.
Before a successful read, emit only JSON_SCHEMA_INVALID/FIX_JSON,
JSON_SCHEMA_MASS_FAILURE/REBUILD_JSON_FROM_CURRENT_EVIDENCE,
JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW, MEMORY_READ_TOOL_ERROR/HUMAN_REVIEW,
or invalid-input AMBIGUOUS/HUMAN_REVIEW, with null coordinates and path=/.

Generator verifies the complete report and exact CaseID/RUTType/current candidate UUID.
A non-null groupId must equal its source groupId. A null groupId is permitted only for
the documented pre-read failures; it cannot authorize OK. Validate coordinate attribution,
catalog, counts and route before making exactly one lifecycle UpdateMemory. A malformed,
wrong-identity, stale, or contradictory report produces no lifecycle write and terminates
as VALIDATOR_RESPONSE_INVALID; do not infer Failed/HUMAN or consult another invocation.
'''
(OUT/'GENERATOR_REPORT_CONTRACT.md').write_text(GENERATOR)
(OUT/'VALIDATOR_REPORT_CONTRACT.md').write_text(VALIDATOR)
(OUT/'README.md').write_text('''# Variant B agent interfaces

All artifacts here specify RuleIQ v8. GeneratorInput and ValidatorInput define three
named string parameters each; the two report schemas define raw JSON return objects.
Reports must satisfy the accompanying contextual contracts as well as JSON Schema.
ISSUE_ACTION_CATALOG.json retains the exact v7 diagnostic catalog. These schemas are
external tool-binding specifications, not invented Pega export fields or runtime proof.

- [Generator report contract](GENERATOR_REPORT_CONTRACT.md)
- [Validator report contract](VALIDATOR_REPORT_CONTRACT.md)
- [Input and output schemas](GeneratorInput.schema.json)
''')
print(json.dumps({'schemas': 4, 'diagnostic_codes': len(catalog)}))
