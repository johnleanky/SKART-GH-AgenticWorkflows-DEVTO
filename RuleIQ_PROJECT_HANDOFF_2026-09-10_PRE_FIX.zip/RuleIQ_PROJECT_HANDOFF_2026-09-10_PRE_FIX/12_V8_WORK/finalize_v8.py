"""Verify and package v8 only, then point CURRENT_START_HERE at the verified release.

Run with the Python environment that has verification/requirements.txt installed.
Historical packages are never regenerated or changed.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
ROOT = HERE / 'RuleIQ_v8'
RELEASE = WORKSPACE / '08_RELEASE'
MANIFEST = 'PACKAGE_MANIFEST_SHA256.json'
ARCHIVE = RELEASE / 'RuleIQ_v8_Variant_B_Prompts_Contracts_Pega_Spec.zip'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def files(root, include_manifest=False):
    return {p.relative_to(root).as_posix(): p for p in sorted(root.rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts and p.name != '.DS_Store'
            and (include_manifest or p.name != MANIFEST)}


def run(script, *args, expected=0):
    result = subprocess.run([sys.executable, '-B', str(script), *args],
                            cwd=script.parent, capture_output=True, text=True,
                            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    if result.returncode != expected:
        raise RuntimeError(str(script) + '\n' + result.stdout + '\n' + result.stderr)
    return result


def main():
    governance = json.loads(run(ROOT / 'verification/verify_package_v8.py', '--governance').stdout)
    write_json(ROOT / 'verification/PACKAGE_GOVERNANCE_v8.json', governance)
    rows = [{'path': name, 'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
            for name, path in files(ROOT).items()]
    write_json(ROOT / MANIFEST, {'version': 'v8', 'algorithm': 'SHA-256',
                               'excludes': [MANIFEST, '**/__pycache__/**', '**/.DS_Store'],
                               'file_count': len(rows), 'files': rows})
    local = json.loads(run(ROOT / 'verification/verify_package_v8.py').stdout)
    print(json.dumps({'stage': 'local_package', 'checks': local['checks_total'], 'status': 'PASS'}), flush=True)

    # Stage in a temporary directory; publish the archive only after portable verification.
    with tempfile.TemporaryDirectory(prefix='ruleiq-v8-release-') as staging:
        staging = Path(staging)
        staged_zip = staging / ARCHIVE.name
        entries = files(ROOT, include_manifest=True)
        with zipfile.ZipFile(staged_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name, path in entries.items():
                info = zipfile.ZipInfo('RuleIQ_v8/' + name, date_time=(2026, 9, 11, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                z.writestr(info, path.read_bytes())
        with zipfile.ZipFile(staged_zip) as z:
            if z.testzip() is not None or set(z.namelist()) != {'RuleIQ_v8/' + name for name in entries}:
                raise RuntimeError('Archive inventory or CRC mismatch')
            if any(z.read('RuleIQ_v8/' + name) != path.read_bytes() for name, path in entries.items()):
                raise RuntimeError('Archive bytes differ from verified package')
            z.extractall(staging / 'extracted')
        portable = staging / 'extracted/RuleIQ_v8'
        portable_check = json.loads(run(portable / 'verification/verify_package_v8.py').stdout)
        run(portable / 'verification/run_all_v8.py')
        portable_suite = json.loads((portable / 'verification/VERIFICATION_SUMMARY_v8.json').read_text())
        local_suite = json.loads((ROOT / 'verification/VERIFICATION_SUMMARY_v8.json').read_text())
        if portable_suite != local_suite:
            raise RuntimeError('Portable regression evidence differs from original results')
        # Same interpreter must also reproduce the individual report bytes exactly.
        portable_after = json.loads(run(portable / 'verification/verify_package_v8.py').stdout)
        print(json.dumps({'stage': 'portable_regressions', 'checks': portable_suite['checks_total'],
                          'status': 'PASS'}), flush=True)

        # Prove the new integrity gate catches altered, missing and unexpected artifacts.
        tamper = []
        target = portable / 'sources/UnitTestGenerator_Prompt.txt'
        original = target.read_bytes()
        target.write_bytes(original + b'\nUnexpected change.\n')
        altered = json.loads(run(portable / 'verification/verify_package_v8.py', expected=1).stdout)
        target.write_bytes(original)
        tamper.append({'case': 'changed_source_bytes', 'status': 'PASS', 'rejected_checks': altered['checks_failed']})
        target = portable / 'examples/T01_TWO_STANDARD_GROUPS.json'
        original = target.read_bytes()
        target.unlink()
        missing = json.loads(run(portable / 'verification/verify_package_v8.py', expected=1).stdout)
        target.write_bytes(original)
        tamper.append({'case': 'missing_tracked_artifact', 'status': 'PASS', 'rejected_checks': missing['checks_failed']})
        target = portable / 'unexpected.txt'
        target.write_text('Unexpected artifact.\n')
        extra = json.loads(run(portable / 'verification/verify_package_v8.py', expected=1).stdout)
        target.unlink()
        tamper.append({'case': 'unexpected_artifact', 'status': 'PASS', 'rejected_checks': extra['checks_failed']})
        run(portable / 'verification/verify_package_v8.py')

        RELEASE.mkdir(exist_ok=True)
        archive_bytes = staged_zip.read_bytes()
        ARCHIVE.write_bytes(archive_bytes)
        digest = sha(archive_bytes)
        ARCHIVE.with_suffix('.zip.sha256').write_text(digest + '  ' + ARCHIVE.name + '\n')
        write_json(RELEASE / 'RuleIQ_v8_RELEASE_VERIFICATION.json', {
            'version': 'v8', 'status': 'PASS_LOCAL_RELEASE', 'archive': ARCHIVE.name,
            'sha256': digest, 'archive_bytes': len(archive_bytes), 'archive_entries': len(entries),
            'archive_inventory_and_bytes': 'MATCH_VERIFIED_PACKAGE', 'local_package': local,
            'portable_package_before_regression': portable_check,
            'portable_package_after_regression': portable_after,
            'portable_regression_summary': portable_suite, 'integrity_rejection_checks': tamper,
            'runtime_validation': 'NOT_EXECUTED',
            'scope': 'Local artifacts and synthetic contract models only; real Pega acceptance remains external.'})

    (WORKSPACE / 'CURRENT_START_HERE.md').write_text(f'''# Current package — RuleIQ v8 / Variant B

Use **12_V8_WORK/RuleIQ_v8/** for current work. One fresh Generator invocation owns one
physical ScenarioGroup, including its validation and repair lifecycle. Author confirms the
complete source batch first, processes groups sequentially, and stops on the first failure.
Memory v3 creates a new immutable GUID per candidate version; UpdateMemory changes lifecycle
metadata only. Both agents use three named inputs and return JSON reports.

- [Current package README](12_V8_WORK/RuleIQ_v8/README.md)
- [Complete v8 archive](08_RELEASE/{ARCHIVE.name})
- [Step-by-step tool walkthroughs](12_V8_WORK/RuleIQ_v8/examples/TOOL_CALL_WALKTHROUGHS.md)
- [Pega implementation specification v3](12_V8_WORK/RuleIQ_v8/specification/PEGA_IMPLEMENTATION_SPEC_v3.md)
- [Memory contract v3](12_V8_WORK/RuleIQ_v8/memory_contracts/MEMORY_TOOL_CONTRACT_v3.md)
- [Current state](12_V8_WORK/RuleIQ_v8/CURRENT_STATE.json)
- [Verified release evidence](08_RELEASE/RuleIQ_v8_RELEASE_VERIFICATION.json)

{local_suite['checks_total']} local regression checks passed, including after extracting the archive outside the
workspace. Package hashes, embedded prompts, links and archive contents were checked.
Actual Pega configuration, execution and context isolation remain unexecuted external acceptance.
All delivered artifacts are English.

Earlier packages, including **11_V7_WORK/RuleIQ_v7/**, are preserved historical versions.
They do not define the active v8 contracts. Root START_HERE.md/CURRENT_STATE.json and older
version-specific pointers remain historical snapshots. Do not apply v7 upsert behavior to v8.
''')
    print(json.dumps({'archive': str(ARCHIVE), 'sha256': digest,
                      'checks': local_suite['checks_total'], 'status': 'PASS_LOCAL_RELEASE'}))


if __name__ == '__main__':
    main()
