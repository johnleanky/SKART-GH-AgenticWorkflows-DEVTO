"""Create illustrative v8 tool transcripts. Payload redactions are NOT executable fixtures."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent/'RuleIQ_v8'
OUT=ROOT/'examples'
OUT.mkdir(exist_ok=True)

def encode(x): return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def envelope(rows): return {'Success':True,'ResultsJSON':encode({'pxResults':rows}),'ErrorCode':'','ErrorMessage':''}
def result(group,guid): return {'pyGroup':group,'Success':True,'pyGUID':guid,'ErrorCode':'','ErrorMessage':''}
def get_result(type_,group,guid,payload):
    return {'Success':True,'pxCaseID':'CASE-1','Type':type_,'pyGroup':group,'pyGUID':guid,'pyPayload':payload,'ErrorCode':'','ErrorMessage':''}

def transcript(name,when=False,count=1,rows=1,repair=False,fail_second=False):
    rut='Rule-Obj-When' if when else 'Rule-Obj-Model'
    groups=[f'G{i+1:03}' for i in range(count)]
    steps=[]
    def call(actor,tool,args,response):
        steps.append({'step':len(steps)+1,'actor':actor,'tool':tool,'arguments':args,'response':response})
    source_rows=[{'pyGroup':g,'pyPayload':f'<REDACTED complete ScenarioGroup 1.4 for {g}>'} for g in groups]
    call('Author','WriteMemory',{'pxCaseID':'CASE-1','Type':'ScenarioGroup','RequestsJSON':encode({'pxResults':source_rows})},envelope([result(g,'SG-DEMO-'+g) for g in groups]))
    final=[]
    for order,g in enumerate(groups,1):
        args={'CaseID':'CASE-1','RUTType':rut,'ScenarioGroupUUID':'SG-DEMO-'+g}
        dispatch={'step':len(steps)+1,'actor':'Author','tool':'UnitTestGenerator','arguments':args,'context':'fresh isolated invocation','response_at_step':None}
        steps.append(dispatch)
        call('Generator '+g,'GetMemory',{'pxCaseID':'CASE-1','Type':'ScenarioGroup','pyGUID':args['ScenarioGroupUUID']},get_result('ScenarioGroup',g,args['ScenarioGroupUUID'],source_rows[order-1]['pyPayload']))
        base='Rule-Test-Unit-Case_MultInpComb-' if when else 'Rule-Test-Unit-Case_'
        keys=[base+x for x in ('KnowledgeArea','JsonSchema','JsonExample')]
        knowledge={'pxResults':[{'Area':key,'Description':'<REDACTED full '+key+'>'} for key in keys]}
        call('Generator '+g,'KnowledgeTool',{'KnowledgeAreas':','.join(keys)},knowledge)
        routes=['GENERATOR_REPAIR','OK'] if repair else ['HUMAN'] if fail_second and order==2 else ['OK']
        for attempt,route in enumerate(routes,1):
            guid=f'UTC-DEMO-{g}-V{attempt}'
            payload=f'<REDACTED full candidate JSON for {g} version {attempt}; {rows} Scenario(s), one UnitTestRules entry>'
            call('Generator '+g,'WriteMemory',{'pxCaseID':'CASE-1','Type':'UnitTestCandidate','RequestsJSON':encode({'pxResults':[{'pyGroup':g,'pyPayload':payload}]})},envelope([result(g,guid)]))
            valargs={'CaseID':'CASE-1','RUTType':rut,'UnitTestCandidateUUID':guid}
            vd={'step':len(steps)+1,'actor':'Generator '+g,'tool':'UnitTestValidator','arguments':valargs,'response_at_step':None}
            steps.append(vd)
            call('Validator '+guid,'JsonValidationTool',{'CaseID':'CASE-1','UUID':guid,'JsonSchema':base+'JsonSchema'},{'Success':True,'IsValid':True,'ValidationMessage':'','ErrorCode':'','ErrorMessage':''})
            call('Validator '+guid,'GetMemory',{'pxCaseID':'CASE-1','Type':'UnitTestCandidate','pyGUID':guid},get_result('UnitTestCandidate',g,guid,payload))
            call('Validator '+guid,'KnowledgeTool',{'KnowledgeAreas':','.join(keys)},knowledge)
            issues=[]
            if route!='OK':
                code,action=('ASSERT_MISSING','ADD_ASSERTION') if route=='GENERATOR_REPAIR' else ('AMBIGUOUS','HUMAN_REVIEW')
                issues=[{'severity':'B','code':code,'action':action,'unit':0,'scenario':0 if route=='GENERATOR_REPAIR' else None,'decision':'A001' if route=='GENERATOR_REPAIR' else None,'path':'/UnitTestRules/0/RuleCode/pyExpectedResults' if route=='GENERATOR_REPAIR' else '/','message':'Existing frozen assertion missing from projection' if route=='GENERATOR_REPAIR' else 'Synthetic ambiguity requiring human review'}]
            vr={**valargs,'groupId':g,'route':route,'blocking':len(issues),'warnings':0,'issues':issues}
            returned={'step':len(steps)+1,'actor':'Validator '+guid,'returns':'ValidatorReport','value':vr}
            vd['response_at_step']=returned['step'];steps.append(returned)
            call('Generator '+g,'UpdateMemory',{'pxCaseID':'CASE-1','Type':'UnitTestCandidate','RequestsJSON':encode({'pxResults':[{'pyGroup':g,'pyGUID':guid,'pyUpdates':{'pyStatusValue':'Passed' if route=='OK' else 'Failed','pyRouterKey':route}}]})},envelope([result(g,guid)]))
        success=routes[-1]=='OK'
        ids=[f'S{i+1:03}' for i in range(rows)] if when else [f'S{order:03}']
        report={'status':'Completed' if success else 'Failed','candidate':{'CaseID':'CASE-1','Type':'UnitTestCandidate','UUID':guid} if success else None,
                'groups':[{'sourceUUID':args['ScenarioGroupUUID'],'groupId':g,'groupOrder':order,'representedScenarioIds':ids if success else [],'rejectedScenarios':[]}],
                'validationAttempts':len(routes),'repairAttempts':len(routes)-1,'errorMessage':'' if success else 'HUMAN_REVIEW_REQUIRED'}
        returned={'step':len(steps)+1,'actor':'Generator '+g,'returns':'GeneratorRunReport','value':report}
        dispatch['response_at_step']=returned['step'];steps.append(returned);final.append(report)
        if not success: break
    success=len(final)==len(groups) and all(x['status']=='Completed' for x in final)
    steps.append({'step':len(steps)+1,'actor':'Author','returns':'ExternalResponse','value':{'AIAgentResponseStatus':'Completed' if success else 'Failed','AIAgentErrorResponseMessage':'' if success else 'Unit test generation failed.'}})
    record={'name':name,'evidence_kind':'SYNTHETIC_ILLUSTRATION_NOT_RUNTIME','payloads_redacted':True,
            'note':'Opaque payload markers stand for full valid sources/candidates. This transcript is not an executable source or complete candidate fixture. All UUIDs are fictional.',
            'source_groups':groups,'scenarios_per_group':rows,'steps':steps}
    (OUT/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    return record

traces=[transcript('T01_TWO_STANDARD_GROUPS',count=2),transcript('T02_ONE_WHEN_GROUP_TWO_SCENARIOS',when=True,rows=2),
        transcript('T03_NEW_GUID_REPAIR',repair=True),transcript('T04_FAIL_FAST_RETAINS_EARLIER_CANDIDATE',count=3,fail_second=True)]
sections=[]
for t in traces:
    lines=['## '+t['name'].replace('_',' '),'','[Complete call/response JSON]('+t['name']+'.json)','',
           '| Step | Actor | Operation | Address / outcome |','|---|---|---|---|']
    for s in t['steps']:
        if 'tool' in s:
            args=s['arguments'];address=args.get('ScenarioGroupUUID',args.get('UnitTestCandidateUUID',args.get('pyGUID',args.get('UUID',args.get('Type','structural keys')))))
            outcome=address
            if s['tool']=='WriteMemory':
                results=json.loads(s['response']['ResultsJSON'])['pxResults']
                outcome=args['Type']+': '+', '.join(x['pyGroup']+' → '+x['pyGUID'] for x in results)
            if s['tool']=='UpdateMemory':
                row=json.loads(args['RequestsJSON'])['pxResults'][0]
                outcome=row['pyGUID']+' → '+row['pyUpdates']['pyStatusValue']+'/'+row['pyUpdates']['pyRouterKey']
            lines.append(f"| {s['step']} | {s['actor']} | {s['tool']} | {outcome} |")
        else:
            r=s['value'];outcome=r.get('status',r.get('route',r.get('AIAgentResponseStatus')))
            lines.append(f"| {s['step']} | {s['actor']} | return {s['returns']} | {outcome} |")
    sections.append('\n'.join(lines))
(OUT/'TOOL_CALL_WALKTHROUGHS.md').write_text('''# Variant B tool-call walkthroughs

These are synthetic protocol illustrations, not observed Pega/LLM executions. GUIDs are
fictional. JSON files contain exact argument/response shapes, but large payloads/Knowledge
are explicitly redacted; markers are not valid ScenarioGroup wire or deployable candidates.
Agent calls refer to the later step where their return arrives. Return steps are not tools.

All source groups are written and their complete unique ordered mapping audited before
the first Generator call. Every Generator gets a fresh context and acquires its own
Knowledge. Initial writes and repairs contain only pyGroup/pyPayload; a separate UpdateMemory
sets lifecycle on that exact version. Every repair uses a new GUID. The case guard spans
source persistence, invocation sequence and final selection.

T01 shows two normal groups producing two candidates. T02 shows two When scenarios inside
one group producing one candidate with two Decision rows. T03 records Failed/GENERATOR_REPAIR
on V1, then writes/validates V2 with another GUID. T04 stops after G002 failure: G003 was
persisted as a source but never generated; G001's Passed candidate remains stored and no
partial automatic test creation starts.

'''+ '\n\n'.join(sections)+'\n')
print(json.dumps({'walkthroughs':len(traces),'steps':sum(len(t['steps']) for t in traces)}))
