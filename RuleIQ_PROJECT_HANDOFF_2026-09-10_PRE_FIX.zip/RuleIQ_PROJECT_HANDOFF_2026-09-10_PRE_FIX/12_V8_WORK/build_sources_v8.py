"""Deterministic v7 -> v8 prompt/export build. Writes only inside RuleIQ_v8."""
from pathlib import Path
import difflib
import hashlib
import html
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE/'RuleIQ_v8'
BASE = HERE.parent/'11_V7_WORK/RuleIQ_v7/sources'
OUT = ROOT/'sources'
OUT.mkdir(parents=True, exist_ok=True)
texts = {p.name: p.read_text() for p in BASE.glob('*.txt')}
baseline = dict(texts)
M, G, V = 'Main_Agent_Prompt.txt', 'UnitTestGenerator_Prompt.txt', 'Validator_Prompt.txt'
gen_report = (ROOT/'agent_contracts/GENERATOR_REPORT_CONTRACT.md').read_text()
val_report = (ROOT/'agent_contracts/VALIDATOR_REPORT_CONTRACT.md').read_text()

def block(file, start, end, value):
    s = texts[file]
    assert s.count(start) == 1 and s.count(end) == 1, (file, start, end)
    a, b = s.index(start), s.index(end)
    assert b > a
    texts[file] = s[:a] + value.rstrip() + '\n\n' + s[b:]

def replace(file, old, new, count=1):
    assert texts[file].count(old) == count, (file, old, texts[file].count(old))
    texts[file] = texts[file].replace(old, new)

AUTHOR_HANDOFF = '''## 1A. Complete source persistence and isolated Generator handoffs

Variant B is a strict two-phase protocol. First form, audit, serialize and self-parse the
complete final set of ScenarioGroup revision-1.4 payloads. Use CaseID only from exact
GetCaseData.pyID and immutable RUTType from original RuleJSON.pxObjClass.

Before writing, audit the global source census: unique groupId, contiguous groupOrder=1..N,
consistent caseId/rutType/rutClass/rutName/ruleset and PROFILE.caseKey identity, complete
existing Scenario-ID/census rules and When grouping by (SIMULATION_GROUP_KEY, EXECUTION_CLASS).
Equal grouping keys must already be merged; unequal keys or execution classes must not mix.
Do not invent a new global Scenario-ID rule where the existing grammar permits local IDs.
No empty source set may be handed off. These global checks belong to Author, never Generator.

Persist all groups in one call:
WriteMemory(pxCaseID=<exact pyID>, Type="ScenarioGroup", RequestsJSON=<JSON string>).
RequestsJSON is exactly {"pxResults":[{"pyGroup":"<groupId>","pyPayload":"<complete payload>"},...]}.
Rows are in groupOrder, but identity is pyGroup, never position. Each successful write creates
a new opaque pyGUID; (pxCaseID,Type,pyGroup) is lineage, not a unique replacement key.
No caller supplies a GUID, lifecycle fields or operation switch to WriteMemory.

Require exact outer fields Success (boolean), ResultsJSON/ErrorCode/ErrorMessage (strings).
Outer Success=true requires empty errors and ResultsJSON decoding once to exactly pxResults.
Require exactly one row per requested pyGroup, with exact fields pyGroup, Success, pyGUID,
ErrorCode, ErrorMessage. Success requires nonempty globally unique GUID and empty errors;
failure requires empty GUID, nonempty diagnostic and INVALID_INPUT/UNSUPPORTED_TYPE/WRITE_FAILED.
Outer failure, exception, malformed framing, duplicate/unknown/missing rows, reused GUID,
or ANY unsuccessful/unconfirmed source row prevents ALL Generator invocations. Return
{"AIAgentResponseStatus":"Failed","AIAgentErrorResponseMessage":"Scenario group storage failed."}.
Never retry or roll back. Successful rows stay stored even when this source-set gate fails.

Only after every source write succeeds, verify the complete ordered mapping:
N final groups = N confirmed distinct nonempty source GUIDs, exactly one GUID per group,
and no GUID used for two groups. Preserve the source payloads and this mapping in Author's
own context. Do not pass the global map to Generator.

Then, strictly in original groupOrder, call:
UnitTestGenerator(CaseID=<exact pyID>, RUTType=<immutable type>, ScenarioGroupUUID=<one source GUID>).
Each call must be a fresh agent context containing only these three values, its static
system prompt and its own tool results. Pega must not inherit Author's transcript or a
previous Generator's source, reasoning, candidate, diagnostics, repair history or Knowledge.
There is no cross-invocation Generator cache. Await and fully validate GeneratorRunReport
under Section 15 before the next call. Never retry a failed or uncertain invocation.

Completed or PartiallyCompleted advances to the next mapped group. Failed or an invocation
exception stops all remaining calls and returns external Failed with "Unit test generation failed.".
A malformed, unknown, wrong-source or contradictory report stops all remaining calls and
returns external Failed with "Unit test generator returned an invalid response.".
An earlier success cannot turn either failure into external Completed. Preserve earlier
candidate versions for investigation; never delete, rewrite, or roll them back.

Only after every group returns a valid Completed/PartiallyCompleted report return exactly
{"AIAgentResponseStatus":"Completed","AIAgentErrorResponseMessage":""}.
Only then may the existing downstream consumer select this run's confirmed final candidate
GUIDs. Pega holds one case pipeline guard through this selection. Do not scan prior Passed
records or automatically materialize a partial set after external Failed. Informational
NotTestable/no-RuleCode records remain information and never become runnable tests.

Scenario Author never retries UnitTestGenerator, never calls GetMemory/Validator or
UpdateMemory, and never exposes internal groups, GUIDs, reports or diagnostics.
'''
block(M, '## 1A. ScenarioGroup storage and UnitTestGenerator handoff', '### 1A.1 Deferred downstream ownership', AUTHOR_HANDOFF)
replace(M, 'and one UnitTestGenerator handoff.', 'and sequential isolated UnitTestGenerator handoffs after complete source persistence.')
replace(M, '- UnitTestGenerator retrieves each successful ScenarioGroup by exact `pyGUID`, projects one current UnitTestCandidate per physical `pyGroup`, upserts initial and repaired payloads at the same key, invokes UnitTestValidator, updates candidate lifecycle metadata, and performs only projection-safe repair without changing Scenario semantics.', '- Each fresh UnitTestGenerator retrieves its one ScenarioGroup by exact pyGUID, writes new immutable candidate versions, calls UnitTestValidator and updates only lifecycle metadata through UpdateMemory. It performs only projection-safe repair.')
replace(M, '- UnitTestValidator validates only exact candidate `pyGUID`s supplied by UnitTestGenerator, retrieves each UnitTestCandidate itself with GetMemory, and returns a compact direct `VR`/`VI` report without mutating Memory.', '- UnitTestValidator receives one exact candidate UUID, retrieves that candidate after schema success, and returns one JSON ValidatorReport without mutating Memory.')
replace(M, '- `UnitTestGenerator(question)` exactly once when at least one ScenarioGroup WriteMemory row succeeds.', '- `UnitTestGenerator(CaseID,RUTType,ScenarioGroupUUID)` once per group, sequentially, only after all ScenarioGroup writes and the complete mapping audit succeed.')
replace(M, '18. Build the exact `GEN`/`SG` question from only successful ScenarioGroup rows and call `UnitTestGenerator(question)` exactly once.', '18. Require every source write confirmed and the complete ordered mapping audited. Invoke a fresh UnitTestGenerator(CaseID,RUTType,ScenarioGroupUUID) for each group in order; validate each report before the next invocation.')
replace(M, '19. Parse exact `GR` rows under Section 1A. Return external Completed when at least one group is `OK`; external Failed only when zero groups are `OK`.', '19. Apply Section 1A fail-fast aggregation: external Completed requires every physical group successfully processed; a failed or malformed report stops the loop and returns external Failed.')
replace(M, '17. Keep every successful `(pyGroup,pyGUID)` row; never retry failed rows. If none succeeded, return the bounded storage failure.', '17. Require every source write successful and confirmed. Otherwise return the bounded storage failure before any Generator call; preserve committed records without retry or rollback.')
replace(M, 'an explicit valid failed row affects only its group. Address collection begins only after exact row-set validation', 'an explicit valid failed row leaves sibling records stored but prohibits every Generator invocation. Address collection begins only after complete successful row-set validation')
old = next(line for line in texts[M].splitlines() if line.startswith('Scenario Author materializes one payload for each final physical group'))
replace(M, old, 'Scenario Author materializes one payload per final physical group in stable groupOrder and persists the entire set in one batch-shaped WriteMemory call under Section 1A. Every write creates a new immutable source record. Only a complete confirmed unique mapping allows sequential fresh Generator invocations, each receiving one ScenarioGroupUUID. No payload travels agent-to-agent, no source write is interleaved with generation, and no operation is retried.')
GROUP_ORDER = '- In the complete Author snapshot, groupOrder is contiguous. Author verifies the full confirmed source-GUID census and dispatches fresh Generator invocations in that order only after every source write succeeds. Generator validates its own stored groupOrder structurally and uses it for stable naming; it has no array-position or cross-group comparison.'
old = next(line for line in texts[M].splitlines() if line.startswith('- In the complete Author snapshot, `groupOrder`'))
replace(M, old, GROUP_ORDER)
replace(M, '5. Validate the outer result and every correlated row under Section 1A. Preserve every successful `pyGUID`; failed rows do not invalidate successful siblings and are never retried.', '5. Validate the complete response under Section 1A. Any failed/unconfirmed row prevents all Generator calls; keep successful records without retry or rollback.')
replace(M, '6. If no row succeeded, return the bounded storage failure. Otherwise construct one `GEN`/`SG` question from only successful rows and call UnitTestGenerator exactly once.', '6. After all writes succeed, audit the complete unique ordered mapping and invoke UnitTestGenerator separately for each ScenarioGroupUUID in original groupOrder with a fresh context.')
replace(M, '7. Correlate returned `GR` rows by `pyGroup`. External Completed requires at least one `GR status=OK`; external Failed requires zero `OK` groups. Never expose internal rows or GUIDs.', '7. Validate each GeneratorRunReport before the next invocation. Failed/malformed stops the loop; external Completed requires all groups processed. Never expose internal reports or GUIDs.')
block(M, '### 14.2 Downstream preservation map', '### 14.3 Closed Scenario Author prohibition', '''### 14.2 Downstream preservation map — not executable by Scenario Author

- Generator receives CaseID, immutable RUTType and one ScenarioGroupUUID; it reads exactly that source and checks the Memory pyGroup against the parsed source groupId.
- One source group produces one candidate with exactly one UnitTestRules entry. A When group may retain several Scenario/combination rows; stable names use original groupOrder.
- Initial and repaired candidates receive new globally unique GUIDs. Source and candidate payloads are immutable after each successful WriteMemory.
- Validator receives CaseID, RUTType, UnitTestCandidateUUID; JsonValidationTool precedes exact GetMemory. Its only result is JSON ValidatorReport.
- Generator applies candidate lifecycle through UpdateMemory; Validator is read-only. Repairs preserve source decisions and have an independent two-repair budget per group.
- Testability and BlockingGaps remain candidate content. A truthful informational result can complete without creating a runnable test.
''')
texts[M] = texts[M].split('## 15. Generator direct report contract', 1)[0] + '## 15. Generator report validation\n\n' + gen_report.replace('## GeneratorRunReport — normative JSON contract', '### Exact GeneratorRunReport')

GEN_START = '''# UnitTestGenerator — System Prompt

## G1. Isolated invocation and closed interfaces

Variant B: one fresh invocation owns exactly one physical ScenarioGroup and its entire
candidate/Validator/repair lifecycle. Receive exactly three scalar string parameters:
CaseID, RUTType, ScenarioGroupUUID. Each is nonempty; no extra field, UUID array, question,
inline payload, global manifest, previous report or shared runtime context is accepted.
Invalid invocation makes zero tool calls and returns the invalid-input GeneratorRunReport
defined in Appendix C. Preserve exact opaque input strings; never strip, normalize or
invent UUIDs. RUTType is the immutable original rule type, not a dependency's type.

Allowed interfaces:
| Tool | Use |
|---|---|
| GetMemory(pxCaseID,Type,pyGUID) | One exact ScenarioGroup read. |
| KnowledgeTool(KnowledgeAreas) | One local structural batch after source validation. |
| WriteMemory(pxCaseID,Type,RequestsJSON) | One initial candidate plus at most two new repair versions. |
| UpdateMemory(pxCaseID,Type,RequestsJSON) | Lifecycle metadata of this invocation's current exact candidate. |
| UnitTestValidator(CaseID,RUTType,UnitTestCandidateUUID) | Validate one exact current candidate per attempt. |

Never call GetCaseData, RuleCrawler, JsonValidationTool, another Generator, or GetMemory
for a candidate or another source. Pega must instantiate an isolated context for every
Generator invocation and hold the case pipeline guard through final downstream selection.
The prompt alone does not establish isolation. No source/Knowledge cache crosses invocations.

Memory v3 creates immutable payload versions. Each successful WriteMemory assigns a new
globally unique GUID; (pxCaseID,Type,pyGroup) is lineage, not a unique record key. Only
UpdateMemory may change candidate lifecycle, never payload or identity. Do not overwrite
an earlier version or assume a record is absent after an uncertain write. No tool retries.

## G2. One exact source read and local source gate

Call GetMemory(pxCaseID=<CaseID>, Type="ScenarioGroup", pyGUID=<ScenarioGroupUUID>) exactly
once for a valid invocation. Require exact fields Success (boolean), pxCaseID, Type, pyGroup,
pyGUID, pyPayload, ErrorCode, ErrorMessage (all strings). Success requires empty errors,
nonempty payload/group, exact input case and source GUID, and Type=ScenarioGroup.
Failure, exception, malformed envelope or identity mismatch terminates SOURCE_READ_FAILED.
Never retry, fetch latest, use pyGroup as an address, or fall back to inline/previous content.

Validate raw pyPayload against the complete revision-1.4 contract in Appendix A. Preserve
BOM/line endings/escaping as received; do not repair source bytes or upgrade an old revision.
Require SG.caseId=CaseID, SG.rutType=RUTType, and SG.groupId=Memory.pyGroup. Validate every
local grammar, arity, count, reference, complete-snapshot, typed-value, root, PROFILE,
formal-declaration, evidence, dependency, simulation-key, coverage and final-state requirement.
Store source groupId/groupOrder only after this gate succeeds. Otherwise return SOURCE_INVALID.
groupOrder must be a structurally valid positive original order, never a supplied position.
Author owns cross-group consistency, uniqueness, grouping and the complete source census.

Reserved top-level system-page roots remain pxProcess, AccessGroup, Application, OperatorID,
Org, OrgDivision, pxRequestor, pxThread. Reject forbidden ROOT/named/setup/input/action/Decision
or simulation page roots. Relative property tokens and scalar values are not top-level roots.

Require execution-class homogeneity: all source Scenarios are NotTestable or none are.
PartiallyTestable remains executable. Informational NotTestable requires zero ASSERT/SIM,
at least one OMIT, supportLevel=NotTestable and a blocking GAP; it is representable without
RuleCode. Never discard it merely for zero assertions or invent values to make a source fit.
Existing projection scope rules remain: standard source-dependent incompatibility rejects
its Scenario; When row-only schema incompatibility may reject that row during initial
projection; shared RuleCode/header/setup/parameter/simulation incompatibility rejects the group.
Preserve the initial ordered represented/rejected source-ID census across all repairs.
No downstream split/merge/regrouping or semantic change is permitted. Empty executable
survivor sets fail NO_REPRESENTABLE_SCENARIO; never write an empty candidate.

## G3. Independent structural Knowledge and Pega metadata

Select family solely from immutable original RUTType. Each INFORMATIONAL_NOT_TESTABLE group
requires only its JsonSchema key. Each EXECUTABLE group requires all three keys:

| RUTType | Ordered KnowledgeAreas |
|---|---|
| Rule-Obj-When | Rule-Test-Unit-Case_MultInpComb-KnowledgeArea,Rule-Test-Unit-Case_MultInpComb-JsonSchema,Rule-Test-Unit-Case_MultInpComb-JsonExample |
| Every other supported original type | Rule-Test-Unit-Case_KnowledgeArea,Rule-Test-Unit-Case_JsonSchema,Rule-Test-Unit-Case_JsonExample |

After valid source acquisition call KnowledgeTool once with the required comma-joined keys.
Require pxResults with each requested Area exactly once and nonempty Description; unknown,
missing, duplicate, malformed content or exception fails this invocation as KNOWLEDGE_FAILED.
Cache only within this invocation. No reacquisition after the first Validator call. A fresh
Generator independently repeats its required lookup; never accept Author/neighbor Knowledge.

The selected schema governs fields; UTC guidance governs serialization; frozen source facts
govern values. Examples cannot replace semantic evidence. For executable candidates copy
pyRuleSet and pyRuleSetVersion from the selected Pega JsonExample/template carrying the
application's already-selected target. Missing/malformed carriers fail; never infer defaults
or select a target from the RUT. Informational groups need no template or target metadata.

'''
texts[G] = GEN_START + texts[G][texts[G].index('## G4. Candidate and Rule Metadata'):]
replace(G, 'For each independently ready physical `pyGroup`, create exactly one raw UnitTestCandidate JSON object', 'For this invocation\'s sole physical `pyGroup`, create exactly one raw UnitTestCandidate JSON object')
replace(G, 'Append stable G<original groupOrder> to disambiguate equal purpose labels across physical groups;', 'Always append stable G<original groupOrder> without inspecting another group;')
replace(G, 'if no lossless supported projection fits, reject the affected Scenario rather than silently truncate proof.', 'if no lossless supported projection fits during initial construction, apply the existing G2 rejection scope rather than truncate proof. During repair, terminate PROJECTION_FAILED instead of changing the frozen represented/rejected census.')
old = next(line for line in texts[G].splitlines() if line.startswith('The configured Validator must implement'))
GEN_LIFECYCLE = '''## G8. One candidate lifecycle with immutable repair versions

### G8.1 Initial and repaired candidate writes

After G2-G7 produce and audit a complete candidate, serialize one exact payload string and call:
WriteMemory(pxCaseID=<CaseID>, Type="UnitTestCandidate", RequestsJSON=<JSON string>).
RequestsJSON decodes to exactly {"pxResults":[{"pyGroup":"<source groupId>","pyPayload":"<complete candidate JSON>"}]}.
This invocation sends exactly one row. Never include lifecycle fields, a caller GUID or
an operation switch. The server initializes the new candidate to Pending/empty router.
There is at most one initial write and at most two attempted repaired-candidate writes.

Require the exact outer Success/ResultsJSON/ErrorCode/ErrorMessage response and exactly one
decoded pxResults row with pyGroup,Success,pyGUID,ErrorCode,ErrorMessage. Success requires
empty errors and nonempty GUID distinct from the source GUID and every prior version GUID
in this invocation. A write failure has empty GUID and INVALID_INPUT/UNSUPPORTED_TYPE/WRITE_FAILED.
An unknown/missing/extra row, reused GUID, false/malformed outer result, exception or uncertain
completion terminates CANDIDATE_WRITE_FAILED. Never retry or reuse an earlier candidate result.
Retain exact written bytes and the returned current GUID locally. Each version is immutable.

### G8.2 Singular Validator invocation

For each successfully written initial/repaired candidate call exactly once:
UnitTestValidator(CaseID=<CaseID>, RUTType=<RUTType>, UnitTestCandidateUUID=<current GUID>).
Increment validationAttempts for the attempted invocation, including an exception. Await
its direct JSON ValidatorReport before any lifecycle or repair action. Only this invocation's
direct response for this exact version may authorize an update. Never consult an old report.
Apply Appendix B framing, identity, catalog, count, route and coordinate checks. A malformed
or unattributable report yields VALIDATOR_RESPONSE_INVALID, makes zero UpdateMemory calls
for that attempt, and leaves the new candidate Pending and ineligible. Generator itself
never reads candidate Memory or calls JsonValidationTool.

### G8.3 Confirm lifecycle before continuation

For every valid ValidatorReport make one UpdateMemory attempt before any next action:
UpdateMemory(pxCaseID=<CaseID>, Type="UnitTestCandidate", RequestsJSON=<JSON string>).
The decoded carrier is exactly {"pxResults":[{"pyGroup":"<source groupId>","pyGUID":"<current candidate GUID>","pyUpdates":{"pyStatusValue":"<Passed or Failed>","pyRouterKey":"<route>"}}]}.
Use Passed/OK for OK; otherwise Failed and the exact route GENERATOR_REPAIR, SEMANTIC_REJECT
or HUMAN. Send both fields and no others. Never include, rewrite, reserialize or patch payload.

Require exact outer fields as WriteMemory and one response row with pyGroup,pyGUID,Success,
ErrorCode,ErrorMessage. Both successful and failed rows echo the exact requested group/GUID.
Success requires empty errors. Failure requires a nonempty error code and diagnostic.
Any failed, wrong-identity, missing/extra/malformed or unconfirmed update terminates
LIFECYCLE_UPDATE_FAILED. Never retry, repair or claim success after that failure.

### G8.4 Local routes and repair budget

- OK: after confirmed Passed/OK finalize this version's GUID. A faithful informational
  NotTestable candidate may be OK; it truthfully represents a non-executable outcome.
- HUMAN: after confirmed Failed/HUMAN stop as HUMAN_REVIEW_REQUIRED.
- SEMANTIC_REJECT: after confirmed Failed/SEMANTIC_REJECT stop as SEMANTIC_REJECTED.
- GENERATOR_REPAIR: after confirmed Failed/GENERATOR_REPAIR, if repairAttempts < 2, apply
  only the existing permitted mechanical action, audit the complete replacement candidate,
  increment repairAttempts when attempting its WriteMemory, and obtain a NEW version GUID.
  Otherwise stop REPAIR_BUDGET_EXHAUSTED. Never overwrite any earlier candidate version.

Allowed repairs correct JSON/schema shape, RUT metadata, naming, current local indices,
assertion/block/parameter/simulation placement, counts and trace syntax/paths, or restore
an already frozen ASSERT/SIM/OMIT. ADD_ASSERTION/ADD_SIMULATION restores an existing decision;
REMOVE_ASSERTION removes an extra projection or asserted OMIT. No new semantic value, path,
type, action, witness, membership change or Validator-driven source-Scenario pruning is allowed.
Unchanged projection content and the initial represented/rejected census stay unchanged.
Knowledge and source facts remain local and frozen throughout the maximum three attempts.

## G9. Terminal GeneratorRunReport

Return exactly one GeneratorRunReport under Appendix C. This invocation has no next-group
operation and no neighbor state. Allowed diagnostic prefixes are INVALID_INPUT,
SOURCE_READ_FAILED, SOURCE_INVALID, KNOWLEDGE_FAILED, NO_REPRESENTABLE_SCENARIO,
PROJECTION_FAILED, CANDIDATE_WRITE_FAILED, VALIDATOR_RESPONSE_INVALID,
LIFECYCLE_UPDATE_FAILED, SEMANTIC_REJECTED, HUMAN_REVIEW_REQUIRED, REPAIR_BUDGET_EXHAUSTED.
Any failure returns candidate=null and clears represented/rejected result arrays. On success,
the candidate pointer names only the current validated and confirmed Passed/OK version.
An informational success does not mean a Pega unit test executed. Do not persist reports.

## G10. Final checks and consumer boundary

Before each candidate write, complete the bidirectional frozen-source audit and schema-guidance
self-check. Before an update verify the full direct ValidatorReport. Before returning verify
Appendix C, the local source census and counters. The configured Validator must use the same
three-parameter input and JSON report. Invoke only the five allowed interfaces.
Pega selects final candidate UUIDs only from the current Author run after every isolated
Generator succeeds, under the case pipeline guard, and verifies current Passed/OK metadata.
Prior versions/runs and partial failed Author runs cannot supply an automatic fallback.
Only executable candidates with RuleCode can become runnable tests.
'''
block(G, '## G8. Independent candidate persistence, Validator waves and lifecycle', '## Appendix A. Complete Frozen Source Validation Reference', GEN_LIFECYCLE)
replace(G, "G1's five-interface allowlist", "G1's five-interface allowlist")
# Global groupOrder responsibility is prose shared with Author; wire grammar is unchanged.
for line in texts[G].splitlines():
    if line.startswith('- In the complete Author snapshot, `groupOrder`') or line.startswith("- In the Author's complete snapshot, `groupOrder`"):
        replace(G, line, GROUP_ORDER)
texts[G] = texts[G].split('## Appendix B.',1)[0] + '## Appendix B. Validator response validation\n\n' + val_report.replace('## ValidatorReport — normative JSON contract', '### Exact ValidatorReport') + '\n### Closed issue/action catalog\n\n' + (BASE/V).read_text().split('## Appendix A. Closed issue/action catalog',1)[1].split('## Appendix B.',1)[0].strip() + '\n\n## Appendix C. Generator response\n\n' + gen_report.replace('## GeneratorRunReport — normative JSON contract', '### Exact GeneratorRunReport')

VAL_START = '''# UnitTestValidator

## V1. Singular read-only responsibility

Receive exactly CaseID, RUTType, UnitTestCandidateUUID as nonempty scalar strings. No extra
argument, question, UUID array, group manifest or candidate payload is accepted. Preserve
exact opaque input values. A syntactically invalid invocation makes zero tool calls and
returns one JSON ValidatorReport with route=HUMAN, groupId=null, blocking=1, warnings=0
and AMBIGUOUS/HUMAN_REVIEW at unit=0, scenario=null, decision=null, path=/.
Echo each supplied valid string; use null only for unavailable/non-string/empty identities.

Validator never repairs or writes/updates Memory, reads ScenarioGroup, calls another agent,
discovers dependencies, re-evaluates the RUT, derives expected values, adds coverage or persists
reports. Its allowed tools are JsonValidationTool(CaseID,UUID,JsonSchema),
GetMemory(pxCaseID,Type,pyGUID) for this candidate, and KnowledgeTool(KnowledgeAreas).
No tool retry, source fallback or cache across invocations. Every new candidate version
requires its own schema check and read; only the directly awaited result is authoritative.

## V2. Report routes and local coordinates

Return one JSON ValidatorReport defined in Appendix B. Each diagnostic refers to the sole
UnitTestRules[0], using unit=0. Scenario coordinates are current zero-based local indices;
decision is an existing stable ID in that Scenario, or null. Candidate-wide and pre-read
diagnostics use scenario=null, decision=null. Never infer an unavailable coordinate.
Preserve the closed code/action catalog in Appendix A. Mechanical diagnostics restore
explicit final decisions only: ADD_ASSERTION requires ASSERT, ADD_SIMULATION requires SIM,
and REMOVE_ASSERTION removes an extra projection or asserted OMIT. Missing/contradictory
semantics use REJECT_SEMANTICS; unsafe ambiguity uses AMBIGUOUS/HUMAN_REVIEW.
blocking/warnings count B/W issues; route precedence is HUMAN > SEMANTIC_REJECT >
GENERATOR_REPAIR > OK. Warnings never trigger repair. Deduplicate identical defects.

## V3. Schema validation then exact candidate read

Select ExpectedJsonSchema solely from input RUTType: Rule-Obj-When uses
Rule-Test-Unit-Case_MultInpComb-JsonSchema; every other supported type uses
Rule-Test-Unit-Case_JsonSchema. Call exactly once:
JsonValidationTool(CaseID=<CaseID>, UUID=<UnitTestCandidateUUID>, JsonSchema=<ExpectedJsonSchema>).
Never read the candidate before schema success or pass Memory Type to this tool.

Require Success/IsValid booleans and ValidationMessage/ErrorCode/ErrorMessage strings.
Malformed/failed tool result or exception yields JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW,
with no GetMemory. Success=true/IsValid=false yields JSON_SCHEMA_INVALID/FIX_JSON or,
for >=25 clearly reported errors, diagnostic >2000 characters, or explicitly broadly malformed
root/UnitTestRules/Scenarios/EvidenceSummary/RuleCode containers,
JSON_SCHEMA_MASS_FAILURE/REBUILD_JSON_FROM_CURRENT_EVIDENCE. Both stop before GetMemory.
Represent each issue in at most 240 characters without hiding separate blocking scopes.

Only schema-valid candidates call once:
GetMemory(pxCaseID=<CaseID>, Type="UnitTestCandidate", pyGUID=<UnitTestCandidateUUID>).
Require exactly Success (boolean), pxCaseID, Type, pyGroup, pyGUID, pyPayload, ErrorCode,
ErrorMessage (strings). Success requires exact input case/GUID, Type=UnitTestCandidate,
nonempty group/payload and empty errors. On failed/malformed read, exception or ownership
mismatch, return MEMORY_READ_TOOL_ERROR/HUMAN_REVIEW with groupId=null and no Knowledge.
After a valid read set groupId to the exact returned pyGroup, then parse duplicate-free
finite candidate JSON. Unparseable/non-traversable content produces MEMORY_READ_TOOL_ERROR
with the now-known groupId. Do not fabricate another identity or accept partial payload.

After parse, require exactly one `UnitTestRules` entry. A different cardinality is `COUNT_MISMATCH/FIX_COUNTS`.
Inspect the sole `UnitTestRules[0]` for mode and local Scenario coordinates.
Candidate mode is **EXECUTABLE** when `RuleCode` is present and **INFORMATIONAL_NOT_TESTABLE** when `RuleCode` is absent.
Defensive traversability checks do not repeat strict candidate JSON Schema validation.

## V4. Informational mode and local structural lookup

For INFORMATIONAL_NOT_TESTABLE, require every Scenario to have Testability=NotTestable,
SupportLevel=NotTestable, ReasoningConfidence=Low and EvidenceSummary.DependencyClosureStatus=Blocked;
AssertionCount=0, ExactValueAssertionCount=0, StructuralAssertionCount=0,
SimulatedDependencyCount=0, nonempty BlockingGaps and RuleCodeConsistentWithLedger=false.
AssertionDecisionTrace contains only one or more canonical OMIT records and its count equals
OmittedClaimCount. A consistent informational candidate finishes this isolated invocation
with OK; do not include it in the KnowledgeTool phase. It truthfully represents a non-executable NotTestable outcome.
Contradictions use existing TRACE_INVALID, COUNT_MISMATCH or REASONING_CONTRADICTION codes.
Never create RuleCode or reject merely because an explicitly documented gap exists.

For EXECUTABLE inspect the visible original RUT type in RuleCode.pyRuleUnderTest.pyDetails
(falling back only to an explicitly visible original-type field in pyRuleUnderTest).
A conflict with input RUTType is RUT_TYPE_MISMATCH/FIX_RUT_METADATA and stops before Knowledge.
Use one local KnowledgeTool batch, selected solely by immutable RUTType:
- Rule-Obj-When: Rule-Test-Unit-Case_MultInpComb-KnowledgeArea,Rule-Test-Unit-Case_MultInpComb-JsonSchema,Rule-Test-Unit-Case_MultInpComb-JsonExample.
- Other supported types: Rule-Test-Unit-Case_KnowledgeArea,Rule-Test-Unit-Case_JsonSchema,Rule-Test-Unit-Case_JsonExample.
Require each Area exactly once with nonempty Description and no unrequested row. Missing,
duplicate, malformed content or exception yields AMBIGUOUS/HUMAN_REVIEW. Never reacquire.
JsonValidationTool alone decides strict candidate JSON Schema validity. UTC guidance governs
serialization, not case semantics. AssertionDecisionTrace is the final visible decision
authority; Validator never reconstructs hidden ScenarioGroup evidence. A faithful PartiallyTestable EXECUTABLE candidate may validate `OK`.
SEMANTIC_REJECT requires contradiction or misrepresentation, not an honestly retained limitation.

'''
texts[V] = VAL_START + texts[V][texts[V].index('## V5. Canonical final trace grammar and normalization'):]
replace(V, 'After schema success, exact read, all-unit RUT check and usable UTC lookup', 'After schema success, exact read, the sole unit RUT check and usable UTC lookup')
old = next(line for line in texts[V].splitlines() if line.startswith('Before returning, deduplicate identical defects'))
replace(V, old, 'Before returning, deduplicate identical defects in stable Scenario/check order, derive counts and route from all issues, verify Appendix A code/action pairs and local coordinates, and serialize the sole JSON ValidatorReport. Do not echo candidate/trace/RuleCode/Knowledge, persist results, make further tool calls or retry. Each issue message is at most 240 characters.')
block(V, '## V10. Final output lock', '## Appendix A. Closed issue/action catalog', '''## V10. Final output lock

Return exactly one raw JSON ValidatorReport under Appendix B, including failures, without
Markdown, progress, corrected candidate or extra fields. Validator creates no Memory item
and never calls WriteMemory or UpdateMemory. Appendix A supplies the closed issue/action catalog.
''')
texts[V] = texts[V].split('## Appendix B.',1)[0] + '## Appendix B. Validator JSON report\n\n' + val_report.replace('## ValidatorReport — normative JSON contract', '### Exact ValidatorReport')
example = {'CaseID':'CASE-1','RUTType':'Rule-Obj-When','UnitTestCandidateUUID':'candidate-demo-1','groupId':'G001','route':'OK','blocking':0,'warnings':0,'issues':[]}
texts[V] += '\n## Appendix C. Synthetic success example\n\nThese addresses are illustrative, not runtime evidence.\n\n```json\n'+json.dumps(example,indent=2)+'\n```\n'

for config, prompt, style in [( 'UnitTestGenerator.txt',G,'Return exactly one raw GeneratorRunReport JSON object defined by the system prompt. No Markdown, progress, analysis or extra fields.'),('JsonValidator_tool.txt',V,'Return exactly one raw ValidatorReport JSON object defined by the system prompt. No Markdown, progress, corrected candidate or extra fields.')]:
    encoded = '\n'.join('<p>'+html.escape(line,quote=False)+'</p>' for line in texts[prompt].rstrip('\n').splitlines())
    texts[config], n = re.subn(r'(<pySystemPrompt>).*?(</pySystemPrompt>)',lambda m:m[1]+encoded+m[2],texts[config],flags=re.S)
    assert n == 1
    texts[config], n = re.subn(r'(<pyResponseStylePrompt>).*?(</pyResponseStylePrompt>)',lambda m:m[1]+'<p>'+style+'</p>'+m[2],texts[config],flags=re.S)
    assert n == 1
replace('UnitTestGenerator.txt', '</pzKnowledgeTools>', '<rowdata REPEATINGINDEX="4">\n<pxObjClass>Rule-AI-Tool</pxObjClass>\n<pyPurpose>UpdateMemory</pyPurpose>\n</rowdata>\n</pzKnowledgeTools>')
replace('UnitTestGenerator.txt', 'Projects immutable ScenarioGroups and validates versioned unit-test candidates.', 'Projects one immutable ScenarioGroup in an isolated invocation and validates immutable candidate versions.')

receipt, diff = [], []
for name, content in texts.items():
    data = (BASE/name).read_bytes() if content == baseline[name] else content.encode()
    (OUT/name).write_bytes(data)
    if content != baseline[name]:
        diff.extend(difflib.unified_diff(baseline[name].splitlines(True),content.splitlines(True),fromfile='v7/'+name,tofile='v8/'+name))
    receipt.append({'file':name,'changed':data!=(BASE/name).read_bytes(),'baseline_sha256':hashlib.sha256((BASE/name).read_bytes()).hexdigest(),'sha256':hashlib.sha256(data).hexdigest()})
(ROOT/'verification/SOURCE_BUILD_RECEIPT.json').write_text(json.dumps({'baseline':'v7','sources':receipt},indent=2)+'\n')
(ROOT/'verification/V7_TO_V8_SOURCE_DIFF.patch').write_text(''.join(diff))
print(json.dumps({'sources':len(receipt),'changed':[r['file'] for r in receipt if r['changed']]}))
